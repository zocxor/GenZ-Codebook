/** Private messaging. All writes go through this callable service; clients only read authorized views. */
import {createHash} from 'node:crypto';
import {AggregateField,FieldPath,FieldValue,Timestamp,type Firestore,type Transaction} from 'firebase-admin/firestore';
import {HttpsError} from 'firebase-functions/v2/https';
import {isPremiumActive, type SubscriptionDoc} from './validation/subscriptions';
import {chatAttachments,decodeChatPhoto,decodeChatFile} from './chatAttachments';
import {screenPost} from './validation/chat';
import chatEmoji from './validation/chatEmoji.json';
const supportedReactions = new Set(chatEmoji.map(([glyph])=>glyph));
type Data=FirebaseFirestore.DocumentData;
type Identity={uid:string;token:{email_verified?:boolean;firebase?:unknown}};
const fail=(code:ConstructorParameters<typeof HttpsError>[0],message:string):never=>{throw new HttpsError(code,message);};
const id=(v:unknown)=>typeof v==='string'&&/^[\w-]{1,128}$/.test(v)?v:fail('invalid-argument','Invalid identifier.');
const text=(v:unknown,max:number,optional=false)=>{if(typeof v!=='string'||v.trim().length>max||(!optional&&!v.trim()))return fail('invalid-argument',`Enter ${optional?'up to':'1–'}${max} characters.`);const s=v.trim().replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,'');if(s){const r=screenPost(s);if(!r.ok)return fail('invalid-argument',r.message);}return s;};
const hash=(s:string)=>createHash('sha256').update(s).digest('hex').slice(0,48);
const stamp=()=>FieldValue.serverTimestamp();
const defaults={requests:'everyone',showPresence:false};
const inbox=(db:Firestore,uid:string,cid:string)=>db.doc(`users/${uid}/inbox/${cid}`);
const when=(v:any)=>typeof v?.toMillis==='function'?v.toMillis():Number(v)||0;
const roleAllowed=(c:Data,uid:string)=>c.ownerId===uid||c.roles?.[uid]==='admin'||c.roles?.[uid]==='moderator';
const ownerAllowed=(c:Data,uid:string)=>c.ownerId===uid||c.roles?.[uid]==='admin';
const profileData=(d:Data|undefined,uid:string)=>({uid,name:String(d?.name||'Code Explorer').slice(0,40),avatar:Number(d?.avatar)||0,...(typeof d?.photo==='string'?{photo:d.photo}:{})});
const followEdge=(db:Firestore,from:string,to:string)=>db.doc('profileFollows/'+hash(from+'|'+to));
const followCounts=(db:Firestore,uid:string)=>db.doc('profileFollowCounts/'+uid);
async function changeFollow(db:Firestore,tx:Transaction,from:string,to:string,following:boolean){
 const ref=followEdge(db,from,to);
 if((await tx.get(ref)).exists===following)return;
 if(following)tx.create(ref,{from,to,createdAt:stamp()});
 else tx.delete(ref);
 const delta=following?1:-1;
 tx.set(followCounts(db,from),{following:FieldValue.increment(delta)},{merge:true});
 tx.set(followCounts(db,to),{followers:FieldValue.increment(delta)},{merge:true});
}
export async function messagingAction(db:Firestore,input:Data,identity:Identity|undefined,now=Date.now(),attachments=chatAttachments):Promise<Data>{
 if(!identity)return fail('unauthenticated','Sign in to open Inbox.');
 if(identity.token.email_verified!==true)return fail('permission-denied','Verify your email before messaging.');
 const uid=identity.uid,action=String(input.command||'');
 return db.runTransaction(async tx=>{
  const actorRef=db.doc('users/'+uid),settingsRef=db.doc(`users/${uid}/messaging/preferences`),statsRef=db.doc('messagingStats/global');
  const [actorSnap,settingsSnap,statsSnap]=await Promise.all([tx.get(actorRef),tx.get(settingsRef),(['request','create-group','report','report-user','close-group','admin-summary','admin-report','admin-close-group'].includes(action)?tx.get(statsRef):Promise.resolve({data:()=>({})}))]);
  const actor=actorSnap.data()||{},settings={...defaults,...settingsSnap.data()},stats:Data=statsSnap.data()||{};
  const statsWrite=(delta:Record<string,number>)=>tx.set(statsRef,Object.fromEntries(Object.entries(delta).map(([k,v])=>[k,Math.max(0,(Number(stats[k])||0)+v)])),{merge:true});
  if(action.startsWith('admin-')){
   const [staffSnap,security]=await Promise.all([tx.get(db.doc('admins/'+uid)),tx.get(db.doc('config/security'))]);
   const staff=staffSnap.data()||{};
   if(!staff.active||!['super_admin','moderator','content_manager'].includes(staff.role))return fail('permission-denied','Messaging moderation permission is required.');
   if(security.get('adminMfaRequired')===true&&!(identity.token.firebase as any)?.sign_in_second_factor)return fail('permission-denied','Two-step administrator sign-in is required.');
   if(action==='admin-summary'){
    const [reports,groups]=await Promise.all([tx.get(db.collection('messagingReports').where('status','==','pending').orderBy('createdAt','desc').limit(50)),tx.get(db.collection('messagingGroups').orderBy('updatedAt','desc').limit(50))]);
    tx.create(db.collection('auditLogs').doc(),{actor:uid,role:staff.role,action:'messaging.review',target:'messagingReports',summary:'Viewed reported messages and group metadata',at:stamp(),expireAt:Timestamp.fromMillis(now+365*86400000)});
    return {stats,reports:reports.docs.map(d=>({id:d.id,...d.data()})),groups:groups.docs.map(d=>({id:d.id,...d.data()}))};
   }
   const target=id(input.target),auditRef=db.collection('auditLogs').doc();
   let summary='';
   if(action==='admin-attachment'){
    const report=(await tx.get(db.doc('messagingReports/'+target))).data();
    if(report?.status!=='pending'||report.attachment!==true)return fail('not-found','Reported attachment unavailable.');
    const message=await tx.get(db.doc(`conversations/${report.conversationId}/messages/${report.messageId}`));
    if(message.get('removed')||!(message.get('attachmentExpiresAt')>now))return fail('not-found','Reported attachment unavailable.');
    const data=await attachments.read(report.conversationId,message.get('senderId'),report.messageId);
    tx.create(auditRef,{actor:uid,role:staff.role,action:'messaging.review',target,summary:'Viewed a reported chat attachment',at:stamp(),expireAt:Timestamp.fromMillis(now+365*86400000)});
    return {data,fileName:message.get('fileName')??null};
   }
   if(action==='admin-restrict'){
    const targetRef=db.doc('users/'+target);if(!(await tx.get(targetRef)).exists)return fail('not-found','Account not found.');
    tx.set(targetRef,{messagingRestricted:input.restricted===true},{merge:true});summary=input.restricted===true?'Messaging restricted':'Messaging restriction removed';
   }else if(action==='admin-report'){
    const reportRef=db.doc('messagingReports/'+target),r=(await tx.get(reportRef)).data();if(!r)return fail('not-found','Report not found.');
    if(r.kind==='user'){
     // Reported member (Build 63): dismiss, or restrict their private messaging and close the report.
     const memberRef=db.doc('users/'+r.reportedUid),member=await tx.get(memberRef);
     if(r.status!=='pending')return {duplicate:true};
     const restrict=input.restrict===true&&member.exists;
     if(restrict)tx.set(memberRef,{messagingRestricted:true},{merge:true});
     tx.update(reportRef,{status:restrict?'actioned':'dismissed',reviewedAt:stamp(),reviewedBy:uid});statsWrite({pendingReports:-1});summary=restrict?'Reported member: private messaging restricted':'Member report dismissed';
    }else{
    const cRef=db.doc('conversations/'+r.conversationId),mRef=db.doc(`conversations/${r.conversationId}/messages/${r.messageId}`);
    const [cSnap,mSnap]=await Promise.all([tx.get(cRef),tx.get(mRef)]);
    const reportBoxes=cSnap.exists?await Promise.all((cSnap.get('members') as string[]).map(m=>tx.get(inbox(db,m,r.conversationId)))):[];
    if(r.status!=='pending')return {duplicate:true};
    if(input.remove===true&&mSnap.exists){tx.update(mRef,{text:'Message removed by moderation.',removed:true});reportBoxes.forEach(b=>{if(b.get('lastMessageId')===r.messageId)tx.set(b.ref,{lastMessage:'Message removed by moderation.'},{merge:true});});}
    tx.update(reportRef,{status:input.remove===true?'removed':'dismissed',reviewedAt:stamp(),reviewedBy:uid});statsWrite({pendingReports:-1});summary=input.remove===true?'Reported message removed':'Report dismissed';
    }
   }else if(action==='admin-close-group'){
    const ref=db.doc('conversations/'+target),c=(await tx.get(ref)).data();if(!c||c.type!=='group')return fail('not-found','Group not found.');
    if(c.status==='closed')return {duplicate:true};
    const boxes=await Promise.all(c.members.map((m:string)=>tx.get(inbox(db,m,target))));
    tx.update(ref,{status:'closed',updatedAt:stamp()});tx.set(db.doc('messagingGroups/'+target),{status:'closed',updatedAt:stamp()},{merge:true});
    c.members.forEach((m:string,i:number)=>tx.set(inbox(db,m,target),{...boxes[i]!.data(),status:'closed'},{merge:true}));statsWrite({activeGroups:-1});summary='Group closed';
   }else return fail('invalid-argument','Unknown moderation action.');
   tx.create(auditRef,{actor:uid,role:staff.role,action:'messaging.moderate',target,summary,at:stamp(),expireAt:Timestamp.fromMillis(now+365*86400000)});return {ok:true};
  }
  // A messaging restriction never takes away the ability to report another member (Build 63).
  if(actor.status!=='active'||(actor.messagingRestricted===true&&action!=='report-user'))return fail('permission-denied','Messaging is unavailable for this account.');
  const card=async(member:string)=>profileData((await tx.get(db.doc('publicProfiles/'+member))).data(),member);
  const unblocked=async(other:string,requireActive=true)=>{const [a,b,user]=await Promise.all([tx.get(db.doc(`users/${uid}/messagingBlocks/${other}`)),tx.get(db.doc(`users/${other}/messagingBlocks/${uid}`)),tx.get(db.doc('users/'+other))]);const available=user.get('status')==='active'&&user.get('messagingRestricted')!==true;if(a.exists||b.exists||(requireActive&&!available))return fail('permission-denied','Messaging is unavailable for this user.');return available;};
  const rate=async(kind:string,max:number,windowMs:number,calendarDay=false)=>{
   const ref=db.doc(`users/${uid}/messagingLimits/${kind}`),old=(await tx.get(ref)).data()||{},start=when(old.start),current=calendarDay?Math.floor(now/windowMs)*windowMs:now,same=calendarDay?start===current:now-start<windowMs;
   if(same&&old.count>=max)return fail('resource-exhausted',kind==='attachments'?'You can send up to 10 attachments per day. Try again after midnight UTC.':'Please wait before trying again.');
   return ()=>tx.set(ref,{start:same?start:current,count:same?old.count+1:1});
  };
  const notify=(target:string,key:string,data:Data)=>tx.set(db.doc(`users/${target}/messageNotifications/${key}`),{...data,createdAt:stamp(),read:false});
  if(action==='connections'){
   const target=id(input.uid);
   if(target!==uid)await unblocked(target);
   const followers=input.list==='followers';
   if(!followers&&input.list!=='following')return fail('invalid-argument','Choose Followers or Following.');
   const throttle=await rate('connections',30,60000);
   let page=db.collection('profileFollows').where(followers?'to':'from','==',target).orderBy(FieldPath.documentId()).limit(21);
   if(input.cursor)page=page.startAfter(id(input.cursor));
   const matches=(await tx.get(page)).docs;
   const users=await Promise.all(matches.slice(0,20).map(async edge=>{
    const member=edge.get(followers?'from':'to') as string;
    if(member!==uid){
     try{await unblocked(member);}
     catch(error){if(error instanceof HttpsError&&error.code==='permission-denied')return null;throw error;}
    }
    return card(member);
   }));
   throttle();
   return {users:users.filter(Boolean),cursor:matches.length>20?matches[19]!.id:null};
  }
  if(action==='profile'||action==='follow'){
   const other=id(input.uid);
   if(other!==uid)await unblocked(other);
   if(action==='follow'){
    if(other===uid||typeof input.following!=='boolean')return fail('invalid-argument','Choose another user to follow.');
    const throttle=await rate('follows',30,60000);
    await changeFollow(db,tx,uid,other,input.following);
    throttle();return {ok:true};
   }
   const [person,entitlement,counts,edge,conversation,likes]=await Promise.all([
    card(other),tx.get(db.doc(`users/${other}/subscription/current`)),tx.get(followCounts(db,other)),
    other===uid?null:tx.get(followEdge(db,uid,other)),
    other===uid?null:tx.get(db.doc('conversations/dm-'+hash([uid,other].sort().join('|')))),
    tx.get(db.collection('communityPosts').where('uid','==',other).where('status','==','approved')
      .where('hidden','==',false).aggregate({received:AggregateField.sum('likeCount')})),
   ]);
   const sub=(entitlement.data() as SubscriptionDoc|undefined)??null;
   return {person:{...person,premiumUntil:isPremiumActive(sub,now)?Date.parse(sub!.expiryTime):0,
    postLikes:likes.data().received||0,followers:counts.get('followers')||0,followingCount:counts.get('following')||0,following:edge?.exists===true,
    chatStatus:conversation?.get('status')||null,conversationId:conversation?.exists?conversation.id:null,
    requestedByMe:conversation?.get('requestedBy')===uid}};
  }
  if(action==='search'){
   const q=text(input.query,40);if(q.length<2)return {users:[]};
   const throttle=await rate('search',30,60000),found=new Map<string,Data>();
   const code=(await tx.get(db.doc('referrals/'+q.toUpperCase()))).data();
   if(code?.uid){const c=await card(code.uid);found.set(c.uid,c);}
   const normalized=await tx.get(db.collection('publicProfiles').orderBy('nameLower').startAt(q.toLowerCase()).endAt(q.toLowerCase()+'\uf8ff').limit(12));normalized.docs.forEach(d=>found.set(d.id,profileData(d.data(),d.id)));
   for(const prefix of new Set([q,q.toLowerCase(),q.charAt(0).toUpperCase()+q.slice(1).toLowerCase(),q.toUpperCase()])){
    const rows=await tx.get(db.collection('publicProfiles').orderBy('name').startAt(prefix).endAt(prefix+'\uf8ff').limit(8));
    rows.docs.forEach(d=>found.set(d.id,profileData(d.data(),d.id)));
   }
   const out:Data[]=[];
   for(const [key,value]of found){if(key===uid)continue;try{await unblocked(key);out.push(value);}catch{/* do not reveal blocked/suspended accounts */}}
   throttle();return {users:out.slice(0,20)};
  }
  if(action==='preferences'){
   if(!['everyone','nobody'].includes(input.requests)||typeof input.showPresence!=='boolean')return fail('invalid-argument','Choose your messaging privacy settings.');
   tx.set(settingsRef,{requests:input.requests,showPresence:input.showPresence});return {ok:true};
  }
  if(action==='block'){
   const other=id(input.uid);if(other===uid)return fail('invalid-argument','Choose another user.');
   const ref=db.doc(`users/${uid}/messagingBlocks/${other}`);
   if(input.blocked===false)tx.delete(ref);
   else {
    const outgoing=followEdge(db,uid,other),incoming=followEdge(db,other,uid);
    const [a,b]=await Promise.all([tx.get(outgoing),tx.get(incoming)]);
    if(a.exists||b.exists){
     if(a.exists)tx.delete(outgoing);
     if(b.exists)tx.delete(incoming);
     tx.set(followCounts(db,uid),{following:FieldValue.increment(-Number(a.exists)),followers:FieldValue.increment(-Number(b.exists))},{merge:true});
     tx.set(followCounts(db,other),{following:FieldValue.increment(-Number(b.exists)),followers:FieldValue.increment(-Number(a.exists))},{merge:true});
    }
    tx.set(ref,{uid:other,createdAt:stamp()});
   }
   return {ok:true};
  }
  if(action==='report-user'){
   // Build 63: report a member (Google Play UGC policy: users can report users, not only content).
   // Allowed after blocking them; one report per reporter and member; same staff-only queue as message reports.
   const other=id(input.uid);if(other===uid)return fail('invalid-argument','You cannot report yourself.');
   const reason=text(input.reason,120),note=text(input.note??'',300,true),ref=db.doc('messagingReports/'+hash(uid+'|user|'+other));
   const [existing,account,publicProfile]=await Promise.all([tx.get(ref),tx.get(db.doc('users/'+other)),tx.get(db.doc('publicProfiles/'+other))]);
   if(!account.exists)return fail('not-found','Account not found.');
   if(existing.exists)return {duplicate:true};
   const reportedUser=db.doc('messagingReportedUsers/'+other),reportedBefore=await tx.get(reportedUser);
   const throttle=await rate('reports',20,86400000);
   const p=publicProfile.data()||{},details=[p.bio,p.location,p.interests].filter((v:unknown)=>typeof v==='string'&&v.trim()).map((v:string)=>v.trim()).join(' · ');
   tx.create(ref,{kind:'user',reporterId:uid,reportedUid:other,reason,note,text:details.slice(0,600),senderName:String(p.name||'Community member').slice(0,40),status:'pending',createdAt:stamp()});
   if(!reportedBefore.exists)tx.create(reportedUser,{createdAt:stamp()});throttle();statsWrite({pendingReports:1,totalReports:1,...(!reportedBefore.exists?{reportedUsers:1}:{})});return {ok:true};
  }
  if(action==='presence'){
   tx.set(db.doc('messagingPresence/'+uid),{lastSeen:stamp(),onlineUntil:input.online===false?0:now+65000});return {ok:true};
  }
  if(action==='request'){
   // Build 65: no message requests. Messaging someone opens an active conversation straight away (the command keeps
   // its old name so older app builds and tests keep working). Blocks, privacy "Nobody", suspension and rate limits still apply.
   const other=id(input.uid);if(other===uid)return fail('invalid-argument','Choose another user.');await unblocked(other);
   const cid='dm-'+hash([uid,other].sort().join('|')),ref=db.doc('conversations/'+cid);
   const contact=(m:string,peer:string)=>tx.set(db.doc(`users/${m}/messagingContacts/${peer}`),{conversationId:cid});
   const [old,targetPrefs,myCard,theirCard,myBox,theirBox]=await Promise.all([tx.get(ref),tx.get(db.doc(`users/${other}/messaging/preferences`)),card(uid),card(other),tx.get(inbox(db,uid,cid)),tx.get(inbox(db,other,cid))]);
   if(old.exists){
    const status=old.get('status');
    if(status==='rejected')return fail('permission-denied','This conversation is not available.');
    if(status==='pending'){          // a request from an earlier build: open it for both people
     tx.update(ref,{status:'active',updatedAt:stamp()});
     for(const [m,peer,b]of [[uid,other,myBox],[other,uid,theirBox]] as const){contact(m,peer);if(b.exists)tx.set(b.ref,{status:'active',...(m===uid?{deleted:false,archived:false}:{}),updatedAt:stamp()},{merge:true});}
     return {id:cid,status:'active',duplicate:true};
    }
    if(myBox.exists&&(myBox.get('deleted')||myBox.get('archived')))tx.update(myBox.ref,{deleted:false,archived:false,updatedAt:stamp()});
    return {id:cid,status,duplicate:true};
   }
   if(targetPrefs.get('requests')==='nobody')return fail('permission-denied','This user is not accepting private messages.');
   const throttle=await rate('requests',10,86400000);
   tx.create(ref,{type:'personal',members:[uid,other],ownerId:uid,requestedBy:uid,status:'active',roles:{},createdAt:stamp(),updatedAt:stamp()});
   for(const [m,peer]of [[uid,theirCard],[other,myCard]] as const){tx.set(inbox(db,m,cid),{conversationId:cid,type:'personal',peerId:peer.uid,name:peer.name,avatar:peer.avatar,photo:peer.photo||'',status:'active',requestedBy:uid,unread:0,createdAt:stamp(),updatedAt:stamp(),lastMessage:'',pinned:false,muted:false,archived:false,deleted:false});contact(m,peer.uid);}
   throttle();statsWrite({personalConversations:1});return {id:cid,status:'active'};
  }
  if(action==='create-group'){
   const name=text(input.name,60),description=text(input.description??'',240,true),cid='group-'+hash(uid+'|'+id(input.requestId)),ref=db.doc('conversations/'+cid);
   if(!['private','invite-only'].includes(input.privacy))return fail('invalid-argument','Choose group privacy.');
   if((await tx.get(ref)).exists)return {id:cid,duplicate:true};
   const me=await card(uid),throttle=await rate('groups',3,86400000);
   const value={type:'group',name,description,privacy:input.privacy,ownerId:uid,members:[uid],roles:{[uid]:'owner'},status:'active',createdAt:stamp(),updatedAt:stamp()};
   tx.create(ref,value);tx.set(inbox(db,uid,cid),{conversationId:cid,type:'group',name,memberCount:1,ownerId:uid,status:'active',unread:0,updatedAt:stamp(),lastMessage:'Group created',pinned:false,muted:false,archived:false,deleted:false});
   tx.set(db.doc('messagingGroups/'+cid),{name,ownerId:uid,memberCount:1,status:'active',updatedAt:stamp()});throttle();statsWrite({activeGroups:1});return {id:cid};
  }
  if(action==='respond-invite'){
   const cid=id(input.conversationId),invRef=db.doc(`users/${uid}/messageInvites/${cid}`),cRef=db.doc('conversations/'+cid);
   const [invSnap,cSnap]=await Promise.all([tx.get(invRef),tx.get(cRef)]),inv=invSnap.data(),c=cSnap.data();
   if(!inv||inv.status!=='pending'||!c||c.type!=='group'||c.status!=='active')return fail('failed-precondition','Invitation is no longer available.');
   await unblocked(inv.invitedBy);const boxes=await Promise.all(c.members.map((m:string)=>tx.get(inbox(db,m,cid))));
   const actorCard=await card(uid),decision=input.accept===true;
   if(decision&&c.members.length>=50)return fail('resource-exhausted','This group is full (50 members).');
   tx.update(invRef,{status:decision?'accepted':'rejected',respondedAt:stamp()});
   if(decision&&!c.members.includes(uid)){
    const members=[...c.members,uid],roles={...c.roles,[uid]:'member'};
    tx.update(cRef,{members,roles,updatedAt:stamp()});tx.set(db.doc('messagingGroups/'+cid),{memberCount:members.length,updatedAt:stamp()},{merge:true});
    c.members.forEach((m:string,i:number)=>{tx.set(inbox(db,m,cid),{memberCount:members.length},{merge:true});if(!boxes[i]!.get('muted'))notify(m,'join-'+cid+'-'+uid,{type:'group',conversationId:cid,title:c.name,body:actorCard.name+' joined the group'});});
    tx.set(inbox(db,uid,cid),{conversationId:cid,type:'group',name:c.name,ownerId:c.ownerId,memberCount:members.length,status:'active',unread:0,updatedAt:stamp(),lastMessage:'You joined the group',pinned:false,muted:false,archived:false,deleted:false,visibleFrom:stamp()});
   }
   return {id:cid};
  }
  if(action==='notifications-read'){
   const notifications=await tx.get(db.collection(`users/${uid}/messageNotifications`).where('read','==',false).limit(100));notifications.docs.forEach(d=>tx.update(d.ref,{read:true}));return {ok:true};
  }
  const cid=id(input.conversationId),cRef=db.doc('conversations/'+cid),c=(await tx.get(cRef)).data();
  if(action==='inbox-settings'){
   if(!(await tx.get(inbox(db,uid,cid))).exists)return fail('permission-denied','Inbox entry not found.');
   const patch:Data={};for(const k of ['pinned','muted','archived','deleted'])if(typeof input[k]==='boolean')patch[k]=input[k];
   if(patch.deleted===true){patch.hiddenBefore=stamp();patch.unread=0;}
   tx.set(inbox(db,uid,cid),patch,{merge:true});return {ok:true};
  }
  if(!c||!Array.isArray(c.members)||!c.members.includes(uid))return fail('permission-denied','You are not a member of this conversation.');
  const members=c.members as string[],boxes=await Promise.all(members.map(m=>tx.get(inbox(db,m,cid)))),myBox=boxes[members.indexOf(uid)]!.data()||{};
  if(c.type==='personal')await unblocked(members.find(m=>m!==uid)!,c.status!=='closed');
  if(action==='respond-request'){
   if(c.type!=='personal'||c.status!=='pending'||c.requestedBy===uid)return fail('permission-denied','Only the recipient may respond to this request.');
   const status=input.accept===true?'active':'rejected';tx.update(cRef,{status,updatedAt:stamp()});
   if(status==='active')members.forEach(m=>tx.set(db.doc(`users/${m}/messagingContacts/${members.find(v=>v!==m)}`),{conversationId:cid}));
   members.forEach(m=>tx.set(inbox(db,m,cid),{status,lastMessage:'',updatedAt:stamp()},{merge:true}));
   notify(c.requestedBy,'response-'+cid,{type:'request',conversationId:cid,title:status==='active'?'Message request accepted':'Message request declined',body:''});return {ok:true};
  }
  if(action==='viewing'){tx.set(inbox(db,uid,cid),{activeUntil:0},{merge:true});return {ok:true};}
  const legacyPending=c.type==='personal'&&c.status==='pending'&&action!=='respond-request';   // requests from earlier builds open on first use
  if(['read','delivered'].includes(action)&&!['active','closed'].includes(c.status)&&!legacyPending)return fail('failed-precondition','This conversation is not open yet. Try again.');
  if(action==='read'){
   tx.set(inbox(db,uid,cid),{unread:0,readAt:stamp(),deliveredAt:stamp(),activeUntil:now+45000},{merge:true});tx.set(db.doc(`conversations/${cid}/receipts/${uid}`),{uid,readAt:stamp(),deliveredAt:stamp()},{merge:true});return {ok:true};
  }
  if(action==='delivered'){tx.set(db.doc(`conversations/${cid}/receipts/${uid}`),{uid,deliveredAt:stamp()},{merge:true});return {ok:true};}
  if(action==='roster'){
   const result=[];for(const m of members){const [p,prefs,pres,block,ownBlock]=await Promise.all([card(m),tx.get(db.doc(`users/${m}/messaging/preferences`)),tx.get(db.doc('messagingPresence/'+m)),tx.get(db.doc(`users/${m}/messagingBlocks/${uid}`)),tx.get(db.doc(`users/${uid}/messagingBlocks/${m}`))]);result.push({...p,role:c.roles?.[m]||'member',...(['active','closed'].includes(c.status)&&prefs.get('showPresence')===true&&!block.exists&&!ownBlock.exists?{lastSeen:when(pres.get('lastSeen')),online:pres.get('onlineUntil')>now}:{}),readAt:when(boxes[members.indexOf(m)]!.get('readAt'))});}
   return {members:result,conversation:{id:cid,type:c.type,name:c.name||'',description:c.description||'',privacy:c.privacy||'',ownerId:c.ownerId,status:c.status,roles:c.roles||{}}};
  }
  if(action==='attachment'){
   if(c.type!=='personal'||!['active','closed'].includes(c.status))return fail('permission-denied','This attachment is unavailable.');
   const mid=id(input.messageId),[message,hidden]=await Promise.all([
    tx.get(cRef.collection('messages').doc(mid)),
    tx.get(db.doc(`users/${uid}/hiddenMessages/${cid}_${mid}`)),
   ]);
   if(!message.exists||message.get('removed')||hidden.exists||!(message.get('attachmentExpiresAt')>now)
      ||when(message.get('createdAt'))<Math.max(when(myBox.visibleFrom),when(myBox.hiddenBefore))){
    return fail('not-found','This attachment is no longer available.');
   }
   const sender=message.get('senderId');
   if(!members.includes(sender))return fail('permission-denied','This attachment is unavailable.');
   return {data:await attachments.read(cid,sender,mid),fileName:message.get('fileName')??null};
  }
  if(c.status!=='active'&&!legacyPending&&!['report','hide-message'].includes(action))return fail('failed-precondition','This conversation is closed. Earlier messages remain available.');
  if(action==='typing'){
   const throttle=await rate('typing',25,60000);tx.set(db.doc(`conversations/${cid}/typing/${uid}`),{uid,until:input.typing===false?0:now+7000});throttle();return {ok:true};
  }
  if(action==='send'){
   const messageId=id(input.requestId),ref=db.doc(`conversations/${cid}/messages/${messageId}`);
   if((await tx.get(ref)).exists)return {id:messageId,duplicate:true};
   const hasPhoto=input.image!==undefined,hasFile=input.file!==undefined;
   if((hasPhoto||hasFile)&&c.type!=='personal')return fail('failed-precondition','Attachments are available in personal chats only.');
   if(hasPhoto&&hasFile)return fail('invalid-argument','Attach one item per message.');
   const file=hasFile?decodeChatFile(input.file?.name,input.file?.data):null;
   const bytes=file?.bytes??(hasPhoto?decodeChatPhoto(input.image):null);
   const caption=text(input.text??'',1500,!!bytes),value=caption||(file?file.name:'Photo'),name=(await card(uid)).name,replyId=input.replyTo?id(input.replyTo):'';
   let reply:Data|undefined;
   if(replyId){reply=(await tx.get(db.doc(`conversations/${cid}/messages/${replyId}`))).data();if(!reply||reply.removed||when(reply.createdAt)<Math.max(when(myBox.visibleFrom),when(myBox.hiddenBefore)))return fail('invalid-argument','The message you are replying to is unavailable.');}
   const recipients=new Set([uid]);if(c.type==='group'){for(const m of members)if(m!==uid&&await unblocked(m,false))recipients.add(m);}else members.forEach(m=>recipients.add(m));
   const throttle=await rate('messages',30,60000);
   const attachmentThrottle=bytes?await rate('attachments',10,86400000,true):null;
   const attachmentExpiresAt=bytes?await attachments.save(db,cid,uid,messageId,bytes,now,file?.contentType):0;
   tx.create(ref,{senderId:uid,name,text:value,createdAt:stamp(),...(attachmentExpiresAt?{attachmentExpiresAt,attachmentCaption:!!caption,...(file?{fileName:file.name}:{})}:{}),...(reply?{replyTo:replyId,replyName:reply.name||'Code Explorer'}:{}),removed:false});
   tx.update(cRef,{updatedAt:stamp(),...(legacyPending?{status:'active'}:{})});
   if(legacyPending)members.forEach(m=>tx.set(db.doc(`users/${m}/messagingContacts/${members.find(v=>v!==m)}`),{conversationId:cid}));
   members.forEach((m,i)=>{
    if(!recipients.has(m))return;
    const old=boxes[i]!.data()||{},active=old.activeUntil>now;
    tx.set(inbox(db,m,cid),{...(legacyPending?{status:'active'}:{}),lastMessage:value.slice(0,100),lastMessageId:messageId,updatedAt:stamp(),unread:m===uid||active?0:(Number(old.unread)||0)+1,deleted:false,archived:false,...(m===uid?{readAt:Timestamp.fromMillis(now)}:{})},{merge:true});
    if(m!==uid&&!old.muted&&!active)notify(m,cid+'-'+messageId,{type:'message',conversationId:cid,title:c.type==='group'?c.name:name,body:value.slice(0,100)});
   });throttle();attachmentThrottle?.();tx.set(statsRef,{totalMessages:FieldValue.increment(1)},{merge:true});return {id:messageId};
  }
  if(action==='invite'){
   if(c.type!=='group'||!roleAllowed(c,uid))return fail('permission-denied','Only group administrators and moderators may invite.');
   const target=id(input.uid);if(members.includes(target))return {duplicate:true};await unblocked(target);
   const [prefs,old]=await Promise.all([tx.get(db.doc(`users/${target}/messaging/preferences`)),tx.get(db.doc(`users/${target}/messageInvites/${cid}`))]);
   if(prefs.get('requests')==='nobody')return fail('permission-denied','This user is not accepting invitations.');
   if(old.exists&&(old.get('status')!=='accepted'||now-when(old.get('respondedAt'))<86400000))return fail('already-exists','This user has already received an invitation.');
   if(members.length>=50)return fail('resource-exhausted','This group is full (50 members).');
   const throttle=await rate('invites',20,86400000);
   tx.set(db.doc(`users/${target}/messageInvites/${cid}`),{conversationId:cid,name:c.name,invitedBy:uid,status:'pending',createdAt:stamp()});notify(target,'invite-'+cid,{type:'invite',conversationId:cid,title:'Group invitation',body:c.name});throttle();return {ok:true};
  }
  if(action==='group-update'){
   if(c.type!=='group'||!ownerAllowed(c,uid))return fail('permission-denied','Only the owner or an administrator can edit this group.');
   const name=text(input.name,60),description=text(input.description??'',240,true);
   tx.update(cRef,{name,description,updatedAt:stamp()});members.forEach(m=>tx.set(inbox(db,m,cid),{name},{merge:true}));tx.set(db.doc('messagingGroups/'+cid),{name,updatedAt:stamp()},{merge:true});members.forEach((m,i)=>{if(m!==uid&&!boxes[i]!.get('muted'))notify(m,'details-'+cid,{type:'group',conversationId:cid,title:name,body:'Group details updated'});});return {ok:true};
  }
  if(action==='group-member'){
   const target=id(input.uid);if(c.type!=='group'||!members.includes(target))return fail('invalid-argument','Choose a group member.');
   const command=String(input.role),self=target===uid&&command==='remove';
   if(target===c.ownerId&&command!=='owner')return fail('permission-denied','Transfer ownership before the owner leaves.');
   if(command==='owner'){
    if(c.ownerId!==uid||target===uid)return fail('permission-denied','Only the owner can transfer ownership to another member.');
    tx.update(cRef,{ownerId:target,roles:{...c.roles,[uid]:'admin',[target]:'owner'}});members.forEach(m=>tx.set(inbox(db,m,cid),{ownerId:target},{merge:true}));tx.set(db.doc('messagingGroups/'+cid),{ownerId:target,updatedAt:stamp()},{merge:true});return {ok:true};
   }
   if(!self){if(command==='remove'){if(!roleAllowed(c,uid)||(c.roles?.[target]==='admin'&&c.ownerId!==uid)||(c.roles?.[uid]==='moderator'&&c.roles?.[target]!=='member'))return fail('permission-denied','You cannot remove this member.');}else if(c.ownerId!==uid||!['admin','moderator','member'].includes(command))return fail('permission-denied','Only the owner can assign group roles.');}
   const roles={...c.roles};if(command==='remove')delete roles[target];else roles[target]=command;
   const next=command==='remove'?members.filter(m=>m!==target):members;
   tx.update(cRef,{members:next,roles,updatedAt:stamp()});
   members.forEach(m=>tx.set(inbox(db,m,cid),m===target&&command==='remove'?{status:'left',unread:0,activeUntil:0}:{memberCount:next.length},{merge:true}));
   members.filter(m=>m!==uid).forEach((m,i)=>{const old=boxes[members.indexOf(m)]!.data()||{};if(!old.muted)notify(m,'role-'+cid+'-'+target,{type:'group',conversationId:cid,title:c.name,body:command==='remove'?'Group membership updated':'A group role was updated'});});
   tx.set(db.doc('messagingGroups/'+cid),{memberCount:next.length,updatedAt:stamp()},{merge:true});return {ok:true};
  }
  if(action==='close-group'){
   if(c.type!=='group'||c.ownerId!==uid)return fail('permission-denied','Only the group owner can close the group.');
   tx.update(cRef,{status:'closed',updatedAt:stamp()});members.forEach(m=>tx.set(inbox(db,m,cid),{status:'closed'},{merge:true}));tx.set(db.doc('messagingGroups/'+cid),{status:'closed',updatedAt:stamp()},{merge:true});members.forEach((m,i)=>{if(m!==uid&&!boxes[i]!.get('muted'))notify(m,'closed-'+cid,{type:'group',conversationId:cid,title:c.name,body:'The group has been closed'});});statsWrite({activeGroups:-1});return {ok:true};
  }
  const messageId=id(input.messageId),mRef=db.doc(`conversations/${cid}/messages/${messageId}`),message=(await tx.get(mRef)).data();
  if(!message||when(message.createdAt)<Math.max(when(myBox.visibleFrom),when(myBox.hiddenBefore)))return fail('not-found','Message unavailable.');
  if(action==='hide-message'){tx.set(db.doc(`users/${uid}/hiddenMessages/${cid+'_'+messageId}`),{conversationId:cid,messageId,createdAt:stamp()});return {ok:true};}
  if(action==='react'){
   if(message.removed)return fail('failed-precondition','This message has been removed.');
   if(input.emoji!==''&&!supportedReactions.has(input.emoji))return fail('invalid-argument','Choose a supported reaction.');
   const throttle=await rate('reactions',60,60000),ref=db.doc(`conversations/${cid}/messages/${messageId}/reactions/${uid}`);input.emoji?tx.set(ref,{uid,emoji:input.emoji}):tx.delete(ref);throttle();return {ok:true};
  }
  if(action==='remove-message'){
   if(c.type!=='group'||!roleAllowed(c,uid))return fail('permission-denied','Group moderation permission required.');tx.update(mRef,{text:'Message removed by a group administrator.',removed:true});boxes.forEach(b=>{if(b.get('lastMessageId')===messageId)tx.set(b.ref,{lastMessage:'Message removed by a group administrator.'},{merge:true});});return {ok:true};
  }
  if(action==='report'){
   const reason=text(input.reason,120),note=text(input.note??'',300,true),rid=hash(uid+'|'+cid+'|'+messageId),ref=db.doc('messagingReports/'+rid);
   if((await tx.get(ref)).exists)return {duplicate:true};
   const reportedUser=db.doc('messagingReportedUsers/'+message.senderId),reportedBefore=await tx.get(reportedUser);
   const throttle=await rate('reports',20,86400000);
   tx.create(ref,{reporterId:uid,reportedUid:message.senderId,conversationId:cid,messageId,reason,note,text:String(message.text).slice(0,1500),senderName:message.name||'',...(message.attachmentExpiresAt>now?{attachment:true,fileName:message.fileName??null}:{}),status:'pending',createdAt:stamp()});if(!reportedBefore.exists)tx.create(reportedUser,{createdAt:stamp()});throttle();statsWrite({pendingReports:1,totalReports:1,...(!reportedBefore.exists?{reportedUsers:1}:{})});return {ok:true};
  }
  return fail('invalid-argument','Unknown messaging action.');
 });
}

/** Account tombstone integration. Partners retain delivered history; departed accounts lose membership. */
export async function purgeMessagingUser(db:Firestore,uid:string){
 const follows=db.collection('profileFollows');
 for(const field of ['from','to']){
  for(;;){
   const batch=await follows.where(field,'==',uid).limit(100).get();
   if(batch.empty)break;
   for(const edge of batch.docs)await db.runTransaction(tx=>changeFollow(db,tx,edge.get('from'),edge.get('to'),false));
  }
 }
 const rows=await db.collection('conversations').where('members','array-contains',uid).get();
 for(const row of rows.docs)await db.runTransaction(async tx=>{
  const c=(await tx.get(row.ref)).data();if(!c||!c.members.includes(uid))return;
  const remaining=(c.members as string[]).filter(m=>m!==uid),boxes=await Promise.all(remaining.map(m=>tx.get(inbox(db,m,row.id))));
  const statsRef=db.doc('messagingStats/global'),stats=(await tx.get(statsRef)).data()||{};
  const close=c.type==='personal'||c.ownerId===uid,roles={...c.roles};
  const endStatus=c.type==='personal'&&['pending','rejected'].includes(c.status)?'rejected':'closed';delete roles[uid];
  tx.update(row.ref,{...(c.type==='group'?{members:remaining,roles}:{}),...(close?{status:endStatus}:{}),updatedAt:stamp()});
  remaining.forEach((m,i)=>tx.set(boxes[i]!.ref,{...(close?{status:endStatus}:{}),...(c.type==='group'?{memberCount:remaining.length}:{}),lastMessage:close?(endStatus==='rejected'?'':'Conversation closed after an account was deleted'):'A member left the group',updatedAt:stamp()},{merge:true}));
  if(c.type==='group'){
   tx.set(db.doc('messagingGroups/'+row.id),{memberCount:remaining.length,...(close?{status:endStatus}:{}),updatedAt:stamp()},{merge:true});
   if(close&&c.status==='active')tx.set(statsRef,{activeGroups:Math.max(0,(stats.activeGroups||0)-1)},{merge:true});
  }
 });
}
