# Build 82 — AdMob app-ads.txt published to the website (1.0.7)

- AdMob could not verify the app ("We couldn't verify GenZ Codebook (Android)") because the developer website had no `app-ads.txt`. The app already requests ads; Google checks the website file before it serves them.
- New file `app-ads.txt` at the project root with the exact line from AdMob's setup instructions: `google.com, pub-977667186789824, DIRECT, f08c47fec0942fa0`. Nothing else in the file.
- New step "Stage app-ads.txt for hosting" in `.github/workflows/deploy-firebase.yml`: after the admin build it copies `app-ads.txt` into `admin/dist/` (the Firebase Hosting public root), so it is served at `https://gen-z-code-55caf.web.app/app-ads.txt`. A file in `admin/public/` would have landed at `/admin/app-ads.txt`, which AdMob does not crawl — that is why the step exists. It fails loudly if the file is missing.
- No database change: no Firestore rules, indexes, collections or Cloud Functions touched. No app code, branding, signing or product IDs changed. Build label raised 81 → 82 in `app.json`, `android/app/build.gradle` and the `tests/build40.test.ts` pin. Version name stays 1.0.7.

App and backend type checks, 200 app tests, 23 backend in-memory tests (after `npm run build` in `functions/` — the guide's check sequence omits the build step and the tests need the compiled `lib/`), 40 admin tests, the admin production build, the security scan (183 checked, no findings), and the Android JavaScript bundle export passed. The app-ads.txt staging was verified end to end: the file lands at `admin/dist/app-ads.txt` with the exact AdMob line and not under `/admin/`. Firestore rules tests did not run locally (no Java or Firebase CLI in this environment); they run in the Deploy Firebase workflow, which blocks the deploy if they fail. Android device testing was unavailable.

Deploy Firebase with target `admin-portal` (hosting only) to publish the file, then check `https://gen-z-code-55caf.web.app/app-ads.txt` in a browser and press "Check for updates" in AdMob. Then build the Android AAB and upload the new version to Google Play.

# Build 81 — Community post menu alignment (1.0.7)

- A post’s three-dot menu opens beside the button on the same row, with a narrower panel that sizes to its action text. At the screen edge, the menu shifts enough to remain visible.
- The owner’s menu contains Remove my post. Other users’ posts retain Report and Block.

App and backend type checks, 200 app tests, 68 backend tests, 40 admin tests, 76 Firestore rules tests, the admin production build, the targeted static scan, and the Android JavaScript bundle export passed. The placement and panel dimensions were checked in code. Android device testing was unavailable.

Build and upload the new Android app. No Firebase deployment is required for this update over Build 80.

# Build 80 — Community dropdowns and Inbox pin styling (1.0.7)

- Community Chat Room, Posts feed and individual post menus use the same compact dropdown and text rows as the Inbox. Each menu opens next to its three-dot button, and a check mark indicates the selected feed filter.
- Pinned Inbox conversations use the standard row background. The pin icon identifies the pinned conversation, and the unread count remains visible.
- The app version is 1.0.7 as requested. The Android source build code advances to 80.

App and backend type checks, 200 app tests, 68 backend tests, 76 Firestore rules tests, the admin tests and production build, the targeted static scan, and the Android JavaScript bundle export passed. Device testing was not performed.

These UI changes require a new Android build. No Firebase deployment is required for this update over Build 79.

# Build 79 — Chat, mobile sign-in and Daily Code cards (1.0.9)

- Home uses the Encode card’s compact input, heading and control spacing for Decode. Clear sits on the Decode allowance row, and conversion results and optional ads sit below the forms.
- The Inbox uses a pin glyph and normal row colours for pinned conversations. Inside chat, a pinned message keeps its highlight. Personal messages offer Delete for me, sender-only Delete for everyone and Forward in the compact message actions. Gold and blue badges appear alongside usernames in the private conversation header, messages and group roster.
- Group owners and admins can choose a photo or one of four group icons and set posting to only admins or open to everyone. The server enforces the posting permission.
- Community’s room, feed and post menus open in a top overlay. The Community Get Credits controls were removed.
- The account screen centres Welcome back and the Google sign-in control. The back arrow and the two profile sharing actions use bare icons. Android offers signup and sign-in through Firebase phone verification. Phone users can add an email to meet the existing verification requirement for community features.
- Super admins can register their own custom sharing code in Settings. Previously registered referral links continue to resolve. Daily Code lets editors set a separate word on Home or Codebook for a selected UTC date or use the shared code. Publication history is collapsed by default.

Validation passed for 200 app tests, 68 backend tests, 40 admin tests, 76 Firestore rules tests, app and backend TypeScript, the admin production build, the targeted static scan and the Android JavaScript bundle. The native build attempt stopped at the Gradle download. SMS delivery and Android verification still require a signed-device test.

Run the Firebase **community** deployment and then build Android. Verify Phone sign-in, SMS region policy and the signing certificate fingerprints in Firebase. Use a Firebase test number before trying a real SMS. The native instant-verification path exchanges a freshly verified phone sign-in token for the app session and requires the callable's runtime service account to be able to sign Firebase custom tokens.

# Build 78 — Original profile activity cards (1.0.8)

Restored the Slangs, Codes and Posts card rendering from Build 76, including its gradients, icon tints and white labels. Both owner and public profiles use this component. The surrounding profile uses the Build 77 design and per-account appearance preference.

App typecheck, 200 app tests, security scan and Android bundle export passed. This is an Android app-only update over Build 77. Build and distribute the new APK or AAB.

# Build 77 — Light profile cards and remembered appearance (1.0.8)

The owner and public profile cards use the welcome card’s blue, lavender and aqua gradient, translucent circles, white border and navy text. React Native Paper 5.15.5 supplies the light profile action buttons. The Slangs, Codes and Posts tiles use coordinated pastel fills.

Profile appearance defaults to light. A choice is stored under the signed-in account on the device and shared by all profile views. Guest preferences are separate. The profile waits for the saved choice before drawing its card. The login implementation is identical to Build 76.

The app typecheck, 200 app tests, 64 backend tests, 40 admin tests, portal production build, security scan and Android bundle export passed. The two new tests cover restoring the selection, account isolation and concurrent toggles. The profile illustration uses example data. Native phone interaction was not tested.

From Build 76 this is an Android app update only. Build an APK or AAB. If the Build 76 backend has not yet been deployed, deploy its community target before distributing this app.

# Build 76 — Compact sign-in, messaging controls and Daily Code attribution (1.0.8)

The sign-in fields and submit button now precede secondary actions. Home places My applications in the Daily Code overflow menu. Settings → App controls lets a super admin show the original contributor’s public display name on Home and Codebook. The switch defaults to off. Codes without a recorded creator have no byline.

Inbox and group member actions open at their triggering row. A gold bookmark marks pinned chats and personal message pins. Messaging settings independently control new private chats, group invitations, online status and last seen. Existing preferences supply the initial values. Clearing personal, group or community history affects the current account. Moderators can archive the existing community room history for everyone from the room menu or portal moderation page. Moderation records and newer messages are preserved.

198 app tests, 64 backend tests, 40 portal tests and 75 Firestore emulator rules tests passed. App and server type checks, Android bundle export, portal/site production builds and repository security scan passed. Layout previews use sample data. Native Android touch interaction, keyboard behaviour and real account sign-in still need a device check.

Deploy Firebase using the community target before building the Android APK or AAB. Submit a new AAB for Play distribution.

# Build 75 — Compact inbox menus and group code sharing (1.0.7)

The shared overflow menu fits its labels and ends after its last option. Longer menus can scroll on short screens. Inbox conversations sit together with a thin divider. In an active open group, tap the group name or choose Group info to see, copy or share the existing join code. The recipient can paste it under Inbox → + → Join by group code. Private groups continue to use invitations.

The app and backend typechecks, 198 app tests, 61 backend tests, 40 admin tests, the Firestore emulator rules suite, the security scan, admin build and Android bundle export passed. A Yoga layout check covered short, long and height-constrained menus. The native phone interface and share sheet still need device testing.

This is an Android app update. Build and distribute the new APK or AAB. This change requires no additional Firebase deployment over Build 74.

# Build 74 — Profile background and Android inbox alerts (1.0.7)

Light profiles use the Threat Shield card’s gradient and corner circles. Inbox filters, per-chat actions and conversation actions use a shared full-height vertical menu. Messaging settings include online visibility, invitation privacy, blocked users and opt-in Android alerts. Personal and group messages have independent sound selections with three original tones or silent. Vibration supports off, short and double pulse. Tapping an alert opens Inbox.

Deploy Firebase functions (including communityFeature and deliverInboxAlert) and hosting for the privacy page before releasing the Android app. With the included workflow, select the community target. With an older workflow, use everything. Alerts need Android notification permission and Firebase Cloud Messaging delivery. In the Play data safety declaration, review the use of a Firebase registration token for optional message delivery.

Validation covered app and backend typechecks, app, backend and admin tests, the static security scan, the admin production build and Android bundle export. A native APK and on-device delivery test remain pending because the Gradle distribution could not be downloaded here. On a device, enable alerts, close the app normally, send a personal and a group message from another account, and verify the selected sound, vibration, tap destination and per-chat mute.

# Build 73 — Single three-dot conversation menu (1.0.8)

A plain top-right overflow opens a vertical text menu over personal and group conversations. Chat details and Group info replace the separate eye control. Menus close on selection, outside tap or Android Back. The chat header pairs the 32-unit profile image with a regular 15-unit name and a 17-unit back arrow. App-only release from Build 72.

# Build 72 — Compact chat action icons (1.0.7)

Personal chats display Report, Block, Theme, Mute, Pin and Close as icons. Group chats display the applicable actions. Inbox row actions and the common conversation details controls use the same compact style. Chat titles use 17 units and messages use 15 at the default text scale. Chat, activity, conversion and reward text use regular weights in the updated elements and request Calibri by family name. Devices without that family use their system fallback. Screen readers announce each action. An X dismisses the menu, and moderation confirmations remain in place. Build a new Android APK or AAB. The backend requirement is the same as Build 71.

# GenZ Codebook V7 — Build 71 (version 1.0.6)

- Home records when the reward sheet is displayed on this installation. Automatic display requires an available reward and 24 elapsed hours, including after dismissing the sheet or restarting the app. Manual access and award eligibility continue to use the existing collection paths.
- The encoder accepts the current decoder suggestion and restores its source text, including ambiguous expressions. Standalone input recognises the illustrated “Lowkey cooked rn” sentence and the decoder’s conversational phrases. Interpretation, suggestions and charging retain their existing logic.
- In the existing owner and member profile layouts, Hide and View appear beside Recent activity, Slangs, Codes and Posts under the tab bar. These are local reading controls.
- Create a group by choosing another member. The owner and selected member receive active inbox entries in one transaction. Every member of a new open group can add a person or copy the group code. An eligible user can join from Inbox → + → Join by group code. Existing groups retain their stored access settings. Blocks, admission preferences, membership limits and moderator removals are enforced on the server.
- Tap a direct-chat title to open the member profile, or tap a group title for member details. The three-dot and eye controls use compact icons and labelled actions. Members can pin a chat from its menu. The conversation reuses message rows, avoids sorting on composer changes, subscribes once to typing updates and fetches roster details concurrently.
- Checks include app and backend type checks, app and backend tests, Android bundle export, Firestore rules and realtime messaging emulator tests, static scan, and admin tests and build. Chat title, Back, Pin and group details were also exercised in a simulated client. Physical Android interaction latency requires device testing.
- Release the Firebase community target first, then build an Android APK for testing and an AAB for Play. Older app builds must update to select a member when creating a new group.

# GenZ Codebook V7 — Build 70 (version 1.0.5)

Removed three literal JSX spaces emitted as raw text children of the private message list and conversation detail views. The Android 13 report records 13 Fabric failures inserting a child at index 1 into an empty native parent. The component test caught the invalid first child on the Build 69 personal chat path. The same check passed after the change for personal, group and new-message search routes, including loading, empty and populated conversations, focusing the composer, typing, opening details and going back. It uses simulated services and native components.

The new regression test checks the compiled messaging screen for literal text under layout components. App and Functions typechecks, 195 app tests, 59 backend tests, the static security scan, admin checks and builds, and Android bundle export passed. An Android device run remains pending. Build a new APK, confirm the reported tap sequence on the affected phone, then build the Play AAB for release. This change requires no Firebase deployment.

---

# GenZ Codebook V7 — Build 69 (version 1.0.5)

Inbox cards with unread messages use a blue background and border. The existing live unread count controls the highlight for personal and group conversations. The default appearance returns when the count clears. Build and test a new Android app. Build 69 requires no additional Firebase deployment.

---

# GenZ Codebook V7 — Build 68 (version 1.0.4)

- The Android report recorded repeated Fabric mount failures: `addViewAt` tried to insert at index 1 when the native parent had zero children. The recording shows the app closing from Inbox and New Message.
- The Inbox tab now has a persistent native host. Messaging keeps native container boundaries for the screen, header, conversation list and people search results, and disables offscreen child clipping in messaging scroll views. This reduces native view reparenting as live data arrives or the user switches screens.
- The app and Functions typechecks, 194 app tests, 59 in-memory Functions tests, static security scan, admin tests and builds, and the Android JavaScript bundle export passed. Verify the native crash fix on the affected Android phone.
- Build 68 needs a new Android build. Run the **Android APK** workflow and verify opening Inbox, opening an existing conversation, starting a new message from search, and switching between Community and Inbox on the affected phone. Then build and upload a new Play AAB for internal testing. Build 68 adds no Firebase deployment step. See the Build 67 entry for any earlier deployment still pending.

---

# GenZ Codebook V7 — Build 67 (version 1.0.3)

- Create Your Own Code links to ChatGPT with the requested label. The link sends no form fields.
- Unhandled screen errors display **Under maintenance** with a retry button. Unexpected Community server errors display a maintenance notice and preserve the existing handling for connection errors, validation errors and specific attachment errors.
- Community reaction reads now require a verified, active account and a live parent message, preventing anonymous access to reactor identifiers.

## Security review

The source review covered authentication and account-state checks, admin role/MFA rules, Firestore and Storage access, verified purchases, credential handling and Android release transport. The static scan and emulator checks complement these controls. Live Firebase IAM, monitoring, App Check and deployed rules require console access to verify.

The production dependency audits reported 12 moderate entries in the app, 13 in Functions and zero in the admin portal. The audit reported no high or critical entries in those three dependency trees. Most recommendations require major Expo or Firebase SDK updates. Test those upgrades separately with native sign-in, ads and billing.

Priorities are to roll out Firebase App Check, monitor verification rates before enforcement, and verify Cloud Functions and billing alerts plus bucket IAM. The current callable checks verified identity and caps instances. App Check would give it an additional client attestation signal.

Run **Deploy Firebase → community** if Build 66 is still pending, or **rules-and-indexes** if Build 66’s Functions are already deployed. Build and upload a new Play AAB after testing an internal APK.

---

# GenZ Codebook V7 — Build 66 (version 1.0.2)

- The private conversation header stays in place and the branding header is hidden. The five-tab dock returns when the keyboard closes. Android API 30+ uses animated native IME insets for the edge-to-edge window. Older Android keeps the resize fallback and iOS uses keyboard avoidance. The flexible message list and multiline composer share the available height.
- Chat bubbles use compact timestamps and receipt icons. The list follows new messages near the bottom and preserves the visible position when older messages are loaded. The conversation menu includes a saved light/dark preference.
- Inbox opens to a single list of personal chats and groups. Search is in the heading. Conversation types, All, Unread, Archived and messaging privacy are in the three-dot menu. Row actions use labelled icons for accessibility.
- Inbox and Community share a searchable Unicode emoji catalog. Community reactions are limited to verified active users reacting to someone else’s live message. Each user can replace or remove their reaction. The Community header puts Get Credits and Leaderboard alongside the title, with Inbox available from the tab dock.
- Home shows the whole-message meaning separately from the Decode breakdown, and Encode shows the original meaning under the coded sentence. The Codebook tab and guide cover expression types, examples and learning steps.
- Attachment retries retain their expiry record, even if one upload attempt fails. Drafts stay available for retry. Storage access errors explain the service problem. The configured bucket is still `gen-z-code-55caf.firebasestorage.app`. If production uploads still return 503, check `chat attachment upload failed` in the Cloud Functions logs. A 404 calls for checking bucket provisioning and a 403 calls for checking object permissions on the function’s runtime service account. Confirm both a photo and a file using two test accounts.

## Validation and release

App and backend typechecks, 193 app tests, 59 in-memory backend tests, 74 Firestore emulator tests, the static scan, admin tests and builds, and the Android JavaScript bundle export passed. Live two-account photo and file delivery and Android/iOS keyboard acceptance require a test device and access to the deployed service.

Use **Deploy Firebase → community** to activate the reaction rules and expanded private reaction catalog. Then run **Android APK** for an internal test build and build a new Play AAB after the device check. Verify multiline typing and sending, new messages while typing, restoring the tab dock, opening older history, and photo and file delivery on two Android screen sizes.

---

# GenZ Codebook V7 — Build 65 (version 1.0.1): direct messaging, + attachment tray, block and report, Inbox +

| Requested | Done |
|---|---|
| Remove the message request option | **No requests any more.** Messaging someone opens an active conversation at once. The Requests tab, accept / decline cards and “waiting for acceptance” wording are gone, and the privacy choice now reads “Who can message you or invite you to groups?” (Everyone / Nobody). The backend `request` command keeps its name but creates an active chat, and requests left over from earlier builds open by themselves. Blocks, the “Nobody” choice, suspensions and the 10-new-chats-a-day limit still apply. |
| Block and report | Every personal chat has a ⋮ menu: **Report user**, **Block user**, Mute. When someone you don’t know writes first, a “Don’t know this person?” strip with Report and Block appears until you reply or dismiss it. Message-level report is unchanged. |
| Photo / file options in the wrong place | The wide “Attach photo / Attach file” buttons are gone. The composer is now WhatsApp-style: a **+** button, the text bar with the emoji inside it, and Send. **+** opens an icon-only tray (photo, file, Codebook word). |
| + in the Inbox to start a message | A **+** button on the Inbox opens **New message** and **New group**. New message now lists the people you follow and your followers (one tap opens the chat) above the search box. |
| Mistakes in your screenshot | (1) The empty band between the app header and the chat header was a second status-bar gap; fixed. (2) “Could not reach the Community service” hid the server’s real reason when a photo upload failed; the app now shows the server’s own message, and the server logs the cause. (3) The “Free messaging · 0/1500” line is gone (the counter shows only near the limit). |

## About the photo error in your screenshot
The server only sends that wording when the **upload to Cloud Storage fails**. The bucket name in the code (`gen-z-code-55caf.firebasestorage.app`) matches `google-services.json`, so the likely causes are on the Firebase side. Open Firebase Console → Functions → Logs and look for **“chat attachment upload failed”** (new in this build): `code 404` means the bucket does not exist or Storage was never set up (Console → Storage → Get started); `code 403` means the functions account lacks the Storage Object Admin role. Until it is fixed, users see “Photo and file sharing is not available yet. You can still send text messages.” I could not test uploads against your Firebase project from here.

## Tests
App 191 of 191 (8 new), backend in-memory 35 of 35 for messaging plus 23 more (new: direct messaging, legacy pending requests, failed-upload logging). Typecheck passes. Firestore rules are unchanged, so the earlier emulator rules tests still apply. Not run on a real phone.

## Deploy
Redeploy the Cloud Functions (`communityFeature` and the other messaging functions), `admin-portal` (privacy page wording), and upload the new AAB (build 65).

## Build 64 — 19 November 2026

- **Navigation bar:** removed the 22px light fade strip drawn above the bottom dock (`src/NavBar.tsx`). On dark screens such as the dark profile it showed as a blurry white line; the dock, its backdrop and indicator are unchanged.
- **Profile Slangs / Codes / Posts cards in dark mode** (`src/SocialProfile.tsx`, owner and public profiles): the deep purple / navy / maroon tiles nearly disappeared on the navy dark profile. In dark mode they now use natural, mid-depth jewel tones of the same colours (amethyst #6E45C9→#3B1F7A, sapphire #2F67C2→#16386F, garnet #B23A48→#6B1A26) with a soft border, a subtle top sheen, a white icon chip and a light ring on the selected card. They read clearly against the navy background without looking neon, and white text stays at 5.5:1 or better. Light mode keeps the approved tiles. App-only change.
- **Profile cards consistent:** removed the outline that only the selected card had (Codes showed a stray white line on first open). All three cards now look the same; the tab bar below shows which one is open, and screen readers still hear "selected".
- **Get Premium and Buy Credits highlighted on the profile** (`src/ProfileDashboard.tsx`): the plain "Buy Credits & Premium" row under Credits is now two buttons — gold **Get Premium** ("No pop-up ads"; shows **Premium active · Manage plan** for subscribers) and blue **Buy Credits** ("Credit packs"). Get Premium opens the shop scrolled to the Premium section (new optional `focus` prop on `TokenShopScreen`); Buy Credits and every other way in open the shop at the top. No purchase logic changed.
- Android build code **64**; display version stays **1.0.1**. Includes everything from Builds 62–63.
- **Checks run:** app typecheck, 182/182 app tests, security scan (0 findings), Expo Android bundle export; backend typecheck + 33 and 23 tests; admin typecheck, 40/40 tests, production build. Preview: `docs/build64-previews/` (real `NavBar` component and the card styles rendered with react-native-web, not a device screenshot).
- **Deploy:** no new Firebase changes. If Build 63's **Deploy Firebase → community** has already run, skip it; otherwise run it once. Then Android APK + AAB and upload **Build 64** to Play.

## Build 63 — 19 November 2026

- **Report user (Google Play UGC policy).** Members could report posts and messages and block people, but not report a *person*. A member's profile ⋯ menu now has **Report user** with reasons (Harassment or bullying, Spam or scam, Inappropriate profile, Pretending to be someone, Child safety concern, Other), separate from **Block private messages**. It works after blocking, is limited to one report per member and 20 reports a day, and the reported person is not told who reported them. Reports go to the existing staff-only queue (`messagingReports`, `kind: 'user'`, with a copy of the member's public profile text) via the existing `communityFeature` callable (new command `report-user`). In admin → **Messaging**, member reports show as "Reported member" with **Restrict messaging** (restricts and closes the report) or **Dismiss**; both are audit-logged. A member whose messaging is restricted can still report. No Firestore rules or indexes change for this.
- **Privacy policy** (`admin/site/privacy.html`, effective 19 November 2026): adds public profiles (nickname, photo, user code, optional bio, location, interests, favourite categories), followers / following, member reports and their retention (profile and follow links are removed when the account is deleted).
- **Admin notifications to all, selected or a custom group.** Admin → **Send notifications** now has *Send to*: **All users**, **Selected users** (add people by user code, e-mail or user ID, up to 500) or **Custom group** (active in / joined in the last 1, 7, 30 or 90 days, optionally one app version; uses the existing user indexes; the newest 500 receive it). Targeted notices store a `recipients` list and an `audienceLabel`; Firestore rules let only those recipients (and Super Admins) read them. The app fetches notices for everyone plus those addressed to the user, shows them under Notifications → Announcements with a **FOR YOU** tag, and counts them on the bell. Every send is audited (`notification.send`). New pure helper `admin/src/lib/notifyAudience.ts` with tests.
- **Easier to find:** the sidebar item is now **Send notifications** — second in the list, megaphone icon, highlighted in both themes — and Super Admins get a **📣 Send notification** button on the Dashboard welcome banner. (The page is visible to Super Admin accounts only.)
- **Daily Code calendar colours restored (admin portal, both themes).** Since the V9.1 restyle a generic glass-button rule out-ranked the calendar colours, so days showed only the text "Published". Now: green = reserved / scheduled / approved, deeper green = published, amber = pending, grey = past, ring = selected day; legend matches. The app's own date picker already used fixed green/amber/grey and is unchanged.
- **Dark mode, warm KPI cards on every page:** KPI/stat cards now use the warm half of the palette (sun #FFDB43 → amber #FFAA1D → coral #FF7F52 → ember #EC634A) with dark ink text and white glass icon chips; every other card keeps the teal glass and gets a thin amber→coral highlight along its top edge plus a warmer rim. Dark-only (`--k-*` and `--card-accent` tokens); Light mode unchanged.
- **Portal logo display:** the logo file is already a rounded app tile, so the Dashboard banner now shows it at full size without a second dark box around it (the old 42px-in-56px frame hid the "G" in dark mode). Logo artwork unchanged.
- Tests added/updated: `functions/tests/messaging.test.cjs` (report user end-to-end incl. after block, duplicates, self, restricted reporter, staff restrict/dismiss, audit), `tests/build63.test.ts`, `admin/tests/notifyAudience.test.ts`, Build 63 cases in `admin/tests/theme.test.ts`, and a Firestore rules test for targeted announcements (create limits, recipient-only reads via the app's query, no edits).
- Android build code **63**; display version stays **1.0.1**.
- **Checks run:** app typecheck, 180/180 app tests, security scan (0 findings), Expo Android bundle export; backend typecheck + 33 and 23 in-memory tests; admin typecheck, 40/40 tests, production build. Rendered previews in `docs/build63-previews/` (browser renders, not device screenshots). **Not run here:** Firestore emulator rules tests (emulator download blocked) — they run in Deploy Firebase, which refuses to deploy if any fail.
- **Deploy:** Deploy Firebase → **community** (rules for targeted notices, `communityFeature` for Report user, hosting for the portal and privacy policy). Then Android APK + AAB. Upload **Build 63** to Play, not Build 62.

## Build 62 — 19 November 2026

- **APK workflow fix.** The Android APK job failed on `tests/billing.test.ts` test 23 ("portal AuditAction has 30 actions, expected 29"). Build 61 correctly added `notification.send` to both the portal `AuditAction` type and the `auditLogs` allow-list in `firestore.rules`, but left the pinned count at 29. Both lists agree; the pin is now 30. The Play AAB job in the same run was already green.
- **Codes: copy from search.** While searching, a **Top match** card appears directly under the search box with the code, long form and meaning, plus **Copy code**, **Copy meaning** and a full-width **Copy all details**, and a **Details & meaning** link. The **Inside the code** page now opens with the same copy bar at the top; the code and long form are also selectable. Copy text is built in `src/termCopy.ts` (pure, tested); the bar is `src/TermCopyBar.tsx` (uses the existing `expo-clipboard`). A green "Copied" state confirms each copy and is announced to screen readers.
- **Admin → user notifications: verified and completed.** Build 61's Super Admin announcements (portal → Notifications → `adminAnnouncements`, audited, immutable) and the app's Notifications → Announcements list were already wired and their rules correct. Missing piece: users were never told something new had arrived. The header bell now shows a red count of announcements published since the user last opened Notifications (refreshed on app open, on resume and every 15 minutes); unseen items carry a **NEW** tag. "Seen" is a per-account timestamp stored on the device only — no Firestore writes, no rule changes. These remain in-app notices; no Android system push is sent (FCM is not configured in this app).
- **Private messaging: checked.** All 20 messaging commands the app sends have a matching handler in `functions/src/messaging.ts`; the 7 backend messaging scenarios pass; every server query is covered by an existing index; client listeners read only owner/participant paths allowed by the rules. No defects found, no messaging code changed. A new root test pins the app↔server command mapping.
- **Admin portal, Dark mode only: "Liquid Glass V9 Next"** in the owner's palette — deep teal `#155E70`, teal `#008082`, amber `#FFAA1D`, sun `#FFDB43`, coral `#FF7F52`, ember `#EC634A`. Frosted teal glass cards with gradient light-catching rims over an aurora background; amber→coral gradient for primary actions, the active nav item, avatar and theme switch (dark ink text for contrast); palette-matched KPI tiles, charts, pills, notices, calendar and sign-in. Every rule is scoped to `:root[data-theme="dark"]`; Light mode is unchanged. Solid fallbacks for browsers without backdrop blur and for "reduce transparency". Also fixed a dark-only leftover that painted ghost buttons violet.
- **Admin layout fix (both themes, no colour change):** the V9.1 desktop grid was declared after the 960px breakpoint, so on phones the sidebar kept a fixed 272px column. The stacked mobile layout is re-asserted last.
- Tests added: `tests/build62.test.ts` (copy text, wiring, announcement filtering/badge, messaging command mapping), a Build 62 theme test in `admin/tests/theme.test.ts`, and a Firestore rules test that signed-in users can list announcements with the app's exact query (and cannot list unfiltered).
- Android build code **62**; display version stays **1.0.1**.
- **Checks run:** app typecheck, 176/176 app tests, security scan (0 findings), Expo Android bundle export; backend typecheck + 32 and 23 in-memory tests; admin typecheck, 33/33 tests, production build. Browser renders of the real `DictionaryScreen`/`TermDetail` components (react-native-web) and of the compiled dark admin CSS are in `docs/build62-previews/` — these are previews, not Android device screenshots. **Not run here:** Firestore emulator rules tests (emulator download blocked in this workspace) — they run in the Deploy Firebase workflow, which refuses to deploy if any fail.
- **Deploy:** Deploy Firebase → **community** (rules tests + hosting for the admin theme; no rules or functions logic changed), then Android APK with the AAB option for the Codes copy and bell badge.

## Build 61 — 19 November 2026
- UI: highlighted Edit profile in light mode using existing primary action treatment.
- UI: Posts statistic tile changed from purple to dark red on owner and public profiles.
- Codes dictionary filter now shows All, English and Universal; Urdu and Roman Urdu remain in dictionary records and underlying language support, unchanged.
- Admin: introduced Super Admin-only in-app announcements with sender confirmation, recent history, and immutable audited Firestore documents; visible on signed-in users’ Notifications screen. No device push delivery is implied or implemented. Deploy Firestore rules and hosting, then APK for user display.
- Android build code advanced to 61; all existing profile sharing and verification logic preserved.

## Build 60 — 19 November 2026

- Implemented the requested real, coloured **Slangs / Codes / Posts** count cards in the shared `src/SocialProfile.tsx` UI, which appears on both owner and searched-user profiles. Each card displays the existing live content count, icon and label, and opens its existing content tab when tapped.
- Left Followers / Following / Likes statistics and upper profile identity, inline code / link icons, verification ticks, settings, credits, tabs and existing data queries unchanged. No backend, Firebase, admin palette or security changes.
- Advanced app / Gradle build code and matching test to **60**; display version remains `1.0.1`.
- Deployment: **new Android APK/AAB required** to see UI; **no Firebase deployment needed** for this presentation-only change.
- Verification: source check and ZIP integrity; full dependency-backed test/build must run in CI. Preview is a source-faithful browser rendering of the edited component, not a screenshot of the running Android APK.

## Build 59 — 19 November 2026

- Updated **admin portal styling only** in `admin/src/theme.css`: Light is royal-blue with a sky-blue background; Dark is dark-teal with teal accents, including welcome and sign-in treatments.
- Preserved all user statistics, six-card desktop row, routes, verification badges, referral features, Firebase rules, authentication and backend logic.
- Incremented app and Gradle build code to 59 solely to keep release packaging versioned according to the project guide; version name remains 1.0.1. No mobile application logic changed.
- To publish the palette, use **Deploy Firebase → Hosting (admin website)**. An APK/AAB upload is **not required** for a CSS-only admin change.
- Checks: source consistency, admin source completeness and ZIP integrity; full dependency-backed test and production build in CI required.

## Build 58 — 19 November 2026

- Fixed the stale `tests/build40.test.ts` assertion that still required Android build 55 despite `app.json` and Gradle already reporting Build 57. The test now checks Build 58 in both sources.
- Incremented Android `versionCode` and the Gradle default to **58**, retaining display version **1.0.1**. No UI, blue/golden badges, user profiles, admin appearance, Firebase, or backend logic was changed.
- Validation: targeted source check and ZIP integrity; complete CI test suite and Android artifact build should run in GitHub Actions.
- Deployment: replace the old repository ZIP with this Build 58 ZIP and rerun Android APK workflow; no Firebase deployment required for this fix.

## Build 57 — 19 November 2026

- Kept the existing profile identity, code placement, blue and gold verification badges, social metrics, and horizontal Overview / Slangs / Codes / Posts tabs unchanged.
- Owner profile: retained only two compact inline icons beside the existing sharing code — Copy code and Copy invite link. Removed the extra Share invite link icon from that inline row; the existing referral code and link generation remain unchanged.
- Public profile: added the same two compact inline icons beside the existing user's sharing code. Copy code copies the displayed referral code; the link icon copies the existing install/referral link. Existing Follow, Message, profile statistics, and content tabs remain in place.
- No Firebase, Firestore, API, authentication, security rules, or backend changes. No Firebase deployment required. A new Android build is required to distribute the UI update.
- Android build code raised to **57**; display version remains **1.0.1**. Verification: source-level review and ZIP integrity; automated typecheck, tests, Android bundle export, and device QA remain to be run in the project CI/device environment.

## Build 56 — 19 November 2026

- Added a compact horizontal Overview / Slangs / Codes / Posts tab bar beneath the existing social-profile summary and owner-only controls. The upper profile identity, statistics, About, Credits, settings, and action controls are unchanged.
- Overview combines the existing approved community posts and live dictionary contributions; the other tabs reuse the existing filtered data. Likes received and owner-only Liked posts remain available through their existing controls. No Firebase, database, security rules, API, authentication, or backend logic changed.
- Android build code raised to **56**; display version remains **1.0.1**.
- Verification: pending in this workspace; see checks below in handoff. No Firebase deployment required. A new Android build is required to distribute the UI update.

## Build 55 — 18 November 2026

- Admin portal uses ivory and warm pearl in Light Mode, ink navy in Dark Mode, and Liquid Glass accents on shared cards, navigation and controls. Smaller labels use stronger contrast in both modes.
- The owner’s profile puts Copy and Share actions beside the invite code and an icon-only user search in the header. Slangs, Codes, Posts and Likes received open on tap. Liked posts remain owner-only. The shop shortcut reads Buy Credits & Premium.
- Android and admin portal display version **1.0.1**. Android build code is **55**.
- Verification: app typecheck, 171 app tests, 32 admin tests, the admin production build, the Android bundle export and the targeted security scan.
- Build 55 adds no Firebase rules, indexes or Functions changes beyond Build 54. Deploy the admin portal through the configured Hosting workflow. If deploying directly from Build 53, apply the Build 54 community deployment first. Use the Android APK workflow with the Play AAB option for Internal testing.

## Build 54 — 18 November 2026

- Added the approved V9 profile to the You screen and member profiles. Both have a Light/Dark control, the original blue and gold verification seals, and two divided rows for Followers / Following / Likes and Slangs / Codes / Posts.
- The tabs use public, approved community posts and live dictionary contributions. Liked and the Credits balance remain owner-only. Posts reuse the existing comment and report screens. Follow, Messages, and connection lists reuse the existing messaging backend.
- Edit Profile supports an optional bio, location, interests and favorite categories. Public profile rules validate these fields. The existing user code identifies members because Build 53 uses nicknames and user codes.
- Moved learning points level, rank, streak, mastered cards, achievements, review access, and performance history to **Play → Game progress & achievements**.
- Checks: application typecheck, 171 application tests, targeted security scan, Expo Android bundle export, 55 backend tests, admin tests and production builds, and 70 Firestore emulator rules tests. Live Android device and Play Store smoke tests are pending.
- Release: run **Deploy Firebase → community** and wait for the profile posts index to finish building. Then use **Android APK** with the Play AAB option for an Internal testing release.

## Build 53 — 18 November 2026

- Aligned Followers, Following, Likes, and Credits in equal-width columns, with a single-line label and a distinct color for each count.

## Build 52 — 18 November 2026

- Own and public profiles show the total likes received on visible, approved community posts.
- The signed-in user's own profile shows their current Credits balance and opens the wallet on tap.
- Reserved a dedicated spot for the highlighted Ad +10 chip in the single-row header.
- Deploy Firebase with the community target and wait for the new community-post index to be ready before testing the app. Check likes on an approved post and Credits against the wallet.

## Build 51 — 18 November 2026

- Redesigned the profile with a slim cover, inline verification seals, icon-only shortcuts, aligned code and invite controls, and plain-text Followers and Following links.
- Added Apply to the Home Daily Code card. It opens the existing application flow.
- This release changes the Android UI. The existing Build 50 community deployment is required for follower lists.

## Build 50 — 18 November 2026

- Redesigned the profile header and moved Inbox, Find people and Edit into its main actions.
- Added Followers and Following buttons with paginated lists and account visibility checks. Four learning stats stay on one compact horizontal row.
- Moved invite sharing next to the profile code and replaced the separate referral card with a short reward note.
- Deploy Firebase with the community target before installing the updated Android build. Verify transitions between profiles, social lists and Inbox in Internal testing.

## Build 49 — 18 November 2026

- Accepted one-to-one chats support one compressed photo or one document per message, with an optional caption. Supported documents are PDF, DOCX, XLSX, PPTX, and UTF-8 TXT. Attachments must be under 1 MB. Photo sizing is capped at 1,280 pixels on the longest side. A shared limit allows ten attachments per account per UTC day.
- Recipients tap to fetch the attachment. Photos open in the app. Android opens documents in an installed viewer or offers the system share sheet. Pending requests and group chats do not accept attachments.
- Attachment access ends at 29 days. The existing scheduled function deletes expired objects using a retryable queue. Google Cloud soft-delete settings can temporarily retain an inaccessible recovery copy. Firestore stores the message and attachment metadata, while the binary stays in the existing private Cloud Storage bucket. Only the server can fetch it for eligible participants or authorized moderators reviewing a pending report.
- Validation covers app typecheck and tests, static security scan, Android JavaScript bundle, functions typecheck/build and in-memory tests, Firestore and Cloud Storage emulator tests, and admin typecheck/tests/build. Signed Android device testing and production IAM are pending.
- Release with **Deploy Firebase → community**. Verify the Cloud Functions runtime identity can create, read, and delete objects in the existing private bucket. Confirm that deployed Storage rules deny direct client access. Build a new AAB and test a photo and a document between two accounts in Internal testing. Update Play Console Data safety for optional Photos and Files and docs before production release.

## Build 48 — 18 November 2026

- Profile cards use three sections: identity, metrics, and actions. Active Premium subscriptions add a Golden Ticket header. The lower sections stay in the light app palette. Your profile includes streak, cleared levels, mastery, saved words, and XP. Public profiles show follower and following counts.
- Find people by nickname or user code from the profile or Inbox. Public profiles support Follow and Unfollow. Blocking clears follows between the two accounts. Blue verification identifies verified users and gold verification identifies the owner or authorised staff. Both ticks appear on profiles and in search results.
- The Inbox has a Requests tab for pending and declined personal requests. The Message button opens accepted chats directly. New personal contacts still require acceptance. Accepted chats show actual message previews and unread counts.
- Validation passed for app TypeScript, 171 app tests, the static security scan, the Android bundle export, backend TypeScript/build and 52 in-memory tests, 69 Firestore rules tests, ten emulator messaging tests, and the admin tests and build. Signed device testing and production deployment are pending.
- Release with **Deploy Firebase → community**, then build the new Android AAB and upload it to Google Play Internal testing. Follow records and counts are created as users follow each other. No backfill is required.

## Build 47 — 17 November 2026: Reference profile card and unified navigation

Profile layout follows the reference's simple card/portrait structure without a cover image: centered avatar overlapping a plain white card, nickname and verified badge, user code, rank, real learning statistics, full-width Edit profile, XP and backup sync. Existing referrals and settings remain below. No follower/post metrics or unrelated social features were invented.

The top-right avatar now opens the complete profile dashboard. The duplicate You navigation item is removed; editing stays inside the profile. Bottom navigation contains Home, Codes, Community, Inbox and Play. Inbox opens the existing private personal/group messaging screen, including existing account-verification gates. It shows unread-conversation count. Community envelope grows from 23 to 31 px with a 48 px touch area; navigation envelope is 28 px. Selection indicator clears when the profile, outside the tab bar, is open. No backend, rules, prices, data or admin source changed.

Validated: app typecheck, all 171 tests, static security scan, Android JavaScript bundle export; backend typecheck and in-memory tests; admin tests/build and extracted ZIP admin completeness check. Profile screenshot uses an isolated sample account with the actual profile and navigation components. Production sign-in/messaging and signed APK/AAB device QA were not performed. See `docs/build47-previews/profile-and-navigation.png`.

Release: replace the prior project ZIP with the complete Build 47 ZIP, build and test a new APK/AAB, then upload to Play. No Firebase redeploy for these changes if Build 45 messaging is already live. If not, follow BUILD45_MESSAGING.md and deploy `community` first with its updated repository-root workflow.

## Build 46 — 17 November 2026: Premium profile design

Redesigned the You profile with a white identity card, compact plum progress panel, pastel activity tiles, lavender referral card and individual aligned settings cards. Added a clear edit-profile action. Retained existing data, rewards, referral copy/share, sync, sign-out, verification and expandable learning/settings actions. No backend, admin, dictionary, messaging or security-rule changes relative to Build 45. Sample-account screenshot: `docs/build46-previews/premium-profile.png`.

Validation: app typecheck and 171 app tests; targeted security scan; Android JavaScript bundle export; backend typecheck and in-memory tests; admin tests and production build. The screenshot renders the real component with isolated sample data. Signed Android APK/AAB and physical-device QA were not performed.

Release: replace the previous ZIP with this complete Build 46 project, build a new APK/AAB and upload through the existing workflow. No Firebase deployment for the profile change if Build 45 is already deployed. Otherwise deploy Build 45's cumulative messaging changes using `community` first, including its updated root deploy workflow as documented in BUILD45_MESSAGING.md.

## Build 45 — 17 November 2026: Private Inbox and groups (version 1.1.0)

Implemented the previously supplied messaging prompt on top of Build 44: Community-header Inbox, personal requests and accepted chats, private invitation groups and roles, real-time history/receipts/typing, privacy/blocks/reports, in-app notifications, dictionary sharing, and audited admin moderation. Credits and existing navigation are unchanged. The existing callable and account-deletion trigger are extended; private writes are server-only with participant and history-boundary rules.

See [the complete implementation report](BUILD45_MESSAGING.md) for the modified files, schema, verified tests, screenshots, rate limits and remaining device/live acceptance checks. Text-only release; no private image uploads or new push system. Android bundle, app/admin checks, official rules and messaging emulator tests passed; production/device acceptance remains pending.

Deploy target **community**, copy the updated Deploy Firebase workflow out of the ZIP into the repository workflow directory, then build/test the new APK/AAB. Hosting-only deployment is insufficient. No destructive migration, new Firebase project, billing changes or new secret.

---

## Build 44 — 17 November 2026: archive completeness repair

Build 43's packaging filter incorrectly excluded every folder named lib, including admin/src/lib (source code). All 12 omitted admin library modules are restored unchanged from the supplied project. No app or admin behavior changes beyond Build 43. Build label increased to 44 in app.json and Android Gradle, with the existing version assertion updated.

Validation is performed against the extracted deliverable ZIP, not only the working directory: original source-file inventory and byte comparison; archive integrity; admin source-completeness checker; app/admin/backend TypeScript; app/admin/backend tests; admin production build. No rules or backend source changes. The previous Android bundle check still applies to unchanged application source; a signed native build and live Firebase deploy have not been run here.

Release: replace the old repository ZIP with GenZ_Codebook_V7_Build44.zip (keep exactly one project ZIP), then rerun Deploy Firebase → admin-portal. Existing workflow files are unchanged. Use Build 44 for the next APK/AAB build as well. No migration or new secrets required.

---

## Build 43 — 17 November 2026

### Scope and behavior
- Community → +Post Slang now searches the existing Codebook dictionary (bundled entries plus published content overlay), using the existing ranked search engine. Select a result to fill the term, meaning, example and suggested post category. Dictionary details are read-only; the existing post-category chips remain available. Editing the query or receiving a content update clears selection. Unselected text cannot enable submission.
- The picker respects existing post limits (term 30, meaning/example 200 characters). Entries exceeding those limits are excluded from shareable results. No new dictionary, collection, charge or publication flow was introduced.
- Profile: removed the tier-coloured hero card, enlarged the avatar, placed identity/rank and XP in a compact unboxed section, flattened the invitation section, and aligned statistics and settings rows with separators and consistent icons. Existing account, sync, refresh, sign-out, referrals and expandable sections remain wired to their original actions. Header and bottom navigation are unchanged.
- Admin login: explicit theme tokens for readable labels, captions, inputs, focus outlines and primary buttons; white title on the branded panel. Added the existing Light / Dark / System switcher to the login form.
- Build label is 43 in app.json and Android Gradle. Version name stays 1.0.1. No signing changes.
- The separate attached Inbox / personal and group messaging specification is NOT implemented in this scoped update. It conflicts with the direct request to change nothing beyond the specified screens, and needs scope confirmation.

### Validation
- App TypeScript: passed. App tests: 171 passed. Targeted security scan: 157 files checked, no findings.
- Admin tests: 32 passed. Admin TypeScript and both production builds: passed.
- Backend TypeScript/build: passed. In-memory regression tests: 20 + 23 passed. The test command requires building functions/lib first; after that prerequisite all passed.
- Android production JavaScript/Hermes export: passed. This is a bundle check, not a signed APK/AAB or a device test.
- Browser checks: actual login rendered in Light and Dark; theme switching verified. Isolated React Native Web fixtures rendered the actual changed profile and post components. Checked LOL results/selection, selection invalidation and no-match state, BRB selection including example/category. Screenshots are in docs/build43-previews/. App screenshots use a sample signed-out profile, not a live account. Native ads were stubbed only in the temporary fixture; those stubs and fixture entry are not included in this ZIP.
- Full-app web export is not supported by the existing native Google Mobile Ads import; this pre-existing web limitation was not altered. Android export passes.
- No authenticated posting, Credit charge, signed-in profile/referral rendering or real Android keyboard/device test was performed. Existing server validation and fees remain unchanged.
- Firestore rules/indexes and backend source were not modified; rules emulator suite was not rerun.

### Modified files
admin/src/App.tsx; admin/src/theme.css; src/CommunityPostsPanel.tsx; src/ProfileDashboard.tsx; app.json; android/app/build.gradle; tests/build40.test.ts; README.md; docs/V7_UPGRADE_REPORT.md.
Added: docs/build43-previews/app-changes.png and admin-changes.png.

### Deployment
1. Replace the repository's single project ZIP with Build 43; keep existing workflows.
2. Run Deploy Firebase with target **admin-portal** (hosting only) for the login changes. No functions/rules deployment or data migration is needed.
3. Run Android APK with the Play AAB option and upload the new AAB to Internal testing first. Verify signed-in post selection/submission, profile sync/referrals and keyboard behavior on Android, then promote through the normal Play release flow.
4. No Play product, pricing or Firebase configuration changes are required. No deployment was performed in this workspace.

---

# GenZ Codebook V7 — Build 42 (version 1.0.1): admin Claymorphism redesign + Community layout

| Requested | Done |
|---|---|
| Admin portal = the supplied Claymorphism reference | `admin/src/theme.css` rewritten (replaces the Build 40-1 neon theme). Light = the reference: #F0EBFF page with soft purple and orange balls, floating rich-purple sidebar (#6740C9 to #895BE8) with 3D icon chips and a pink-lavender raised active pill, white clay cards (26-28 px radius, purple-tinted layered shadows), pastel KPI cards (blue, peach, lavender, mint) with coloured 3D icon bubbles, pill buttons, inset pill search, purple gradient charts with subtle gridlines. |
| Dark mode | Same shapes, spacing and components in deep violet (#151033 page, #43309F sidebar). |
| Light / Dark / System | Same switcher in the header, order Light, Dark, System. Remembered, instant, no reload, no flash (`public/theme-init.js`), System follows the OS. |
| Compact welcome bar | 112 px high on desktop, one row: name, email and role, Platform status, Registered users, logo. The small "WORKSPACE OVERVIEW" label is hidden. |
| All pages | Every page shares the same tokens, so tables, forms, calendar, referrals tree, notices and sign-in use the clay look. Nothing removed: all 12 menu items kept; Posts moderation, Daily Code and Verified Badges got their own icons. |
| App: Community > Posts | "Post Slang" and the three-dots button now sit on the same row as the "Community" heading (Posts tab only). The duplicate “Credits” line above the feed was removed (Credits already show in the top bar). |

Backend, Firestore rules, roles and logins untouched; no new dependencies. Checks: app typecheck and 170 tests, admin typecheck and 32 tests, admin production build, security scan; both themes rendered at 1360 px and 390 px. Fonts: the portal's CSP only allows bundled fonts and none is bundled, so headings use a rounded system font stack at heavy weight. **Deploy:** Firebase `admin-portal`, and upload the new AAB (build 42).

# GenZ Codebook V7 — Build 40 (version 1.0.1)

| Requested | Done |
|---|---|
| No automatic ads; relaxed, optional only | Removed every automatic full-screen ad except the post-delete one: after the 3rd activity, on finishing a round, after adding a word, after a post. |
| One small skippable ad after a level | After a **cleared level** the result page offers an optional “Watch a short ad” card (`src/SupportAdButton.tsx`). Shown only if a skippable ad is loaded, never with Premium, disappears after use. |
| Ad on post delete | Kept, now **skippable**: deleting your own post opens a full-screen ad with a close X while the delete runs. No ad loaded or Premium = no ad; the delete never waits. |
| “Watch an ad → get a benefit” everywhere | Same pattern as the quiz hint: a **locked level** now offers “Watch ad” to unlock it (`unlockLevelByAd`, costs no points). Existing: quiz hint, +5 conversions, +10 Credits buttons. |
| Version 1.0.1 | `app.json` version 1.0.1, `android/app/build.gradle` versionName 1.0.1, build label 40. |

Texts updated: Terms (About), Threat Shield “Ads”, privacy page (`admin/site/privacy.html`), profile help. Backend unchanged.
**Deploy:** Firebase `admin-portal` (privacy text only), then build and upload the new AAB.

# GenZ Codebook V7 — Build 39

| Requested | Done |
|---|---|
| Ad when a user deletes their post | Removing your own post in Community now shows a **full-screen (interstitial) ad** while the delete runs (`showInterstitialForAction`). Not a rewarded ad, not a banner (the app has no banners); never with Premium; at most once per 2-minute cooldown; the post is removed even if no ad loads. |
| Sign-in / sign-up page too white | V8 look in the app’s light colours: tinted page, holographic welcome banner with the logo, glowing orbs and feature chips, frosted form card with a soft gradient frame, light neon “portal” panel (Google’s official button + E-mail), icon fields, glowing gradient button (`src/AuthPortal.tsx`). No dark panel. |
| Game level icons | Each level has its own bright glossy icon (shine, coloured glow); passed levels get a ✓ badge, locked ones keep their colour softened with a 🔒 badge (`GlossyIcon` in `src/ui.tsx`). |
| Profile picture colours | The 11 icon avatars each have their own theme — light (sunshine, gold, blush), bright (sky, mint, violet, teal, coral, caramel) and dark (graphite, midnight) — instead of all fading to dark purple. Same 12 choices, so saved profiles keep their picture. |
| Sync should be automatic | **Sign out** is one tap: it syncs automatically, then signs out (no keep-or-remove choice; your learning stays on the phone and in your account). Signing in with another account switches the phone automatically when nothing is waiting to upload (only asks if unsynced changes would be lost). Pending changes also upload when the app goes to the background. To wipe a phone: Threat Shield → Delete all data on this device. |
| Threat Shield listed 8 protections by name | Now a shield status with four general areas — **Account, This device, Backup, Privacy** — each only “Protected / Action needed / Off”, with one simple fix when needed. The individual protections and technical details are no longer shown. “What we store” and “Recent account activity” are folded, and the storage notes were corrected (no banner ads; Credits on the account; Google Play purchases). |
| Daily reward could be collected again on another screen | One daily reward everywhere (Home card, daily pop-up, You page, Wallet): one tap gives **+10 Credits** (server, once per UTC day) **and +10 learning points**; every button shows “Collected today” at once and checks the server receipt on start (`src/dailyReward.ts`). |
| Admin portal: edit / replace / delete today’s Daily Code | Daily Codes → Published: today’s row has **✎ Edit**, **⇄ Replace with <picked word>** and **🗑 Remove** (same server commands as the app, audit-logged). Past days show “Archived”; a removed day shows “Removed by an administrator”. |

Tests: app 166/166 (new: Threat Shield areas, sync account switching, Build 39 checks), backend 43/43, admin 26/26 + build, security scan clean, Android bundle export OK; sign-in page (360 px and 390 px), Threat Shield, Play levels and avatars checked in a phone-size preview. Version code **39**. No backend function changes since Build 38: deploy Firebase **admin-portal** (portal Daily Code actions) — **everything** also works — then build and upload the AAB.

# GenZ Codebook V7 — Build 38

| Requested | Done |
|---|---|
| Edit / replace / delete the running Daily Code, admins only | Super Admins and Content Managers see ✏️ Edit, ⇄ Replace and 🗑 Remove on today’s Daily Code card (Home and Codes). Edit changes the code, meaning and category for everyone at once (live). Replace searches the dictionary (safe entries only), or takes a typed code, and publishes it as today’s code straight away (audit: `daily-code.replace-live`). Remove takes it off Home and Codes for the rest of the UTC day; the app shows its standard word of the day and the scheduler does not republish it. Server: new `daily-admin` commands `edit-live` / `remove-live` (today only, role checked, audit-logged). A removed paid request is not refunded automatically (the admin can grant Credits). |
| Expired verification link | The You page and the account page say “Link expired or not working? Send a new link” (button **Send new link** / **Send new verification link**). The new e-mail carries a fresh link. |
| Sign out on the You page and the profile page | Sign-out icon in the You page header, a **Sign out** button at the bottom of the You page, and a **Your account → Sign out** card on the profile page (top-right picture). All open the existing safe sign-out choice (sync first, keep or remove learning data, Cancel). |
| Futuristic login / sign-up buttons | New neon “portal” panel: dark gradient with a neon frame and a slow light sweep (off with reduce motion), Google’s **official** button in a neon ring (Google branding rules), a matching neon E-mail tile, a glowing gradient **Sign in with e-mail / Create account** button and a neon pill to switch between sign-in and sign-up (`src/AuthPortal.tsx`). |
| Deploy run red although deployed | `deploy-firebase.yml` now treats only Firebase’s optional container-image cleanup-policy message as a warning; any other error still fails. `rtdnHandler` needed the deploy account to create Pub/Sub topics (owner added **Pub/Sub Editor**). |

Tests: app 156/156, backend 43/43 (new: edit/remove today’s Daily Code), admin 25/25 + build, security scan clean, Android bundle export OK; login panel and Daily Code admin tools checked in a phone-size preview. Version code **38**. Deploy **everything** (Daily Code commands + `rtdnHandler`), then upload the AAB.

# GenZ Codebook V7 — Build 37

**Google Play purchases switched on.** Credit packs (`tokens_1000` … `tokens_100000`) and Premium (`premium_monthly` / `premium_yearly`) now appear in Get Credits. Every purchase is checked with Google Play on our server (`verifyPurchase`, `verifySubscription`) before any Credits are added, using the `PLAY_SERVICE_ACCOUNT_JSON` secret.

| Change | Why |
|---|---|
| `shared/backend.json` → `tokenPurchasesEnabled: true` | Shows Credit packs and Premium. |
| Premium checkout uses the same switch (`src/subscription.ts`), no longer blocked by `SPARK_MODE` | `SPARK_MODE` only controls free community contributions; it had hidden Premium permanently. |
| **Fix:** a Premium subscription is linked to the first account that verifies it | Before, every account signed in on the same phone (same Google Play purchase) would also get Premium and the 10,000/200,000 Credits. Other accounts now get "already linked to another GenZ Codebook account". |
| **Fix:** after a plan change (monthly → yearly), the old plan's expiry no longer switches off the new plan | The old token's late "expired" notice overwrote the active entitlement. |
| **Fix:** a pending or inactive subscription is no longer reported as "Premium is active" | The server now answers "Payment is pending…" / "not active". New vs already-active is decided by whether Credits were granted for this period. |
| Credit packs are recorded under Google Play's own order ID, and the pack Google reports must match | The app's value is only a fallback; IDs with slashes are refused. |
| Wording: Premium = "No pop-up ads" (rewarded videos stay optional); Terms say Premium renews until cancelled in Google Play | Accurate benefits (Play subscription policy). |

Tests: app 155/155, backend 42/42 (7 new purchase tests run the real handlers against the in-memory database with Google Play simulated — 5 of them fail on the Build 36 backend, which confirms they catch the bugs), admin 25/25 + build, security scan clean, Android bundle export OK. **Not yet tested on a phone:** a real license-tester purchase on the internal testing track (owner step).

Version code **37**. Deploy order: create the Pub/Sub topic `genz-codebook-rtdn` → Deploy Firebase **everything** (adds `verifyPurchase`, `verifySubscription`, `rtdnHandler`) → set Real-time developer notifications in Play Console → upload the AAB to **Internal testing** and test with license testers → promote. Known limit: a refunded Credit pack is not taken back automatically (the admin portal can deduct Credits).

# GenZ Codebook V7 — Build 36

**Google Play readiness (User Generated Content policy):** users can now **block** other users (chat message ⚑, post ⋮, comment ⊘; Settings → Blocked users to unblock; blocked people's messages, posts and comments are hidden) and must **agree to the community rules** once before their first chat message, post, comment or new word; the sign-up form states the Terms and Privacy Policy. The in-app Terms and the public privacy policy were corrected (Credits are account-based; no banner ads; blocking; referrals; leaderboard). Credit packs and Premium are hidden until Google Play checkout is switched on, so no button in the app is non-functional.

| Reported | Fix |
|---|---|
| Wallet showed 44 and 54 Credits | 44 is the server-verified (spendable) balance; 54 was an older wallet record that earlier app versions mixed with device learning points. The wallet now shows only the verified Credits, with **Purchased** and **Learning points** labelled separately. The admin portal shows the spendable Credits from the server (new `user-balance` action). No history was changed or deleted. |
| 1 free word a day, then 100 Credits | Server: the first dictionary word each UTC day is free, each extra one costs 100 (admin price). The form shows "Today's word is free" / the price. |
| Daily Code: "Daily Code Display", 100 Credits, 1 free a month | Server: the first request each UTC month is free, extra requests 100. Cancelling or rejecting a free request gives the free use back (no Credit refund); paid requests are refunded as before. Renamed everywhere. |
| Daily reward 5 vs 10 | The daily account reward is 10 Credits (server and every label). Highlighted gold "Daily reward · +10 Credits" button with a collected state. |
| Google button blue | Uses Google's official sign-in button (white, Google "G"). Login shows **Sign in/up with: [Google] [E-mail]** side by side, the e-mail form below. |
| Daily Code cards | Home card is blue again; the Codes page card is gold. |
| Social icons looked fake | Brand look: Instagram rounded-square gradient, Facebook blue circle with "f", WhatsApp green, red e-mail. |
| Slow screens | Faster entrance animations (≈0.16 s, no long stagger), sheets fade instead of slide, the most-used sheets are preloaded after start, Credits show instantly from the last confirmed value, and the Wallet shows history before the Google Play checks finish. |
| Leaderboard | Real 🥇🥈🥉 medals for the top 3. Tabs **Levels** (ranked by game XP, shows level, rank title, XP and Credits), **Word creators** (most community words) and **Top posters** (most approved posts, likes break ties). Top 3 on gold/silver/bronze cards with medals; your row is outlined. |
| Leaderboard / Back to chat / wallet not visible | Header buttons on their own row: green **Get Credits**, gold **Join leaderboard / Leaderboard**, solid blue **Back to chat**. "Community" title no longer wraps. |
| Chat messages | Each person's messages have their own light background colour. |
| Home icon | Bottom bar Home uses a house icon. |
| E-mail verification | The verification e-mail is sent at sign-up in the phone's language; a pop-up says where it went (check Spam); the You page shows "Verify your e-mail" with Resend / I've verified and re-checks when you return to the app. Unverified accounts can't chat, post, use Credits or open the portal (enforced by rules and server). |

Version code **36**. Firebase: deploy **community** (rules: leaderboard XP/level/rank; functions: free word/day, free Daily Code/month, 100 prices, daily reward 10, admin balance; hosting: privacy page and admin portal). If you saved prices in admin Settings earlier (150/250), set **Extra dictionary word** and **Extra Daily Code Display** to 100 there. Checks: app 154/154, admin 25/25 + build, backend 35/35 (the emulator test files now also run without Java via `npm run test:memory`; 4 new Credit tests), security scan clean, Android bundle export; chat, leaderboard, Daily Code cards, social icons and reward button checked in a phone-size browser preview. The rules test additions run in the GitHub deploy workflow.

# GenZ Codebook V7 — Build 35

| Reported | Fix |
|---|---|
| Verified Badge page text cut off at the edge, not premium | Redesigned: gold hero with a large seal, "Get the Verified badge" and the price; Blue and Gold tiers as full-width cards (no side-by-side text that overflowed); "What you get" and "How it works"; the application card with cost, balance, what's missing, Get Credits and Confirm; your application status when one is open. |
| Purple profile card; restore gold and blue | The profile card is gold for a gold badge and blue for a blue badge again (navy for no badge). The badge now sits on a white ring, so it stays clearly visible on the gold or blue card. |
| Daily Code cards (Home and Codes) both blue | Both are now deep teal–emerald, distinct from the blue/gold profile cards, with matching label and category colours. |
| Chat shows the "30 Credits" page for a second although paid | The app waited for the server's chat-pass check before showing the chat. Today's pass is now remembered on the phone, so the chat opens straight away; on first check a short "Opening the chat room…" shows instead of the payment page. The server still verifies the pass on every message. |

Version code **35**. Includes Builds 32–34-1. App-only changes: no Firebase deploy needed for this build (deploy **community** if you haven't since Build 32, and **admin-portal** for the Referrals page). Checks: app 154/154, admin 25/25, typecheck, security scan clean, Android bundle export passed; the badge page, profile cards and Daily Code cards were checked in a phone-size browser preview.

# GenZ Codebook V7 — Build 34-1 (admin: Referrals page)

- New admin page **Referrals** (roles with Users access): referred sign-ups, lead users ranked by **whole chain** (everyone who joined through them at every level), direct invites, levels, last join, and whether each lead **started the chain** or joined via someone else.
- **Find a user's chain** by invite code (GZXXXXXX), user ID or e-mail (e-mail for Super/Support admins). The chain view shows who invited them up to the top lead user, direct invites, whole chain, levels (L1/L2/…), an expandable tree of every person, and **Download CSV** (level, user ID, name, e-mail for PII roles, invite code, invited by, code used, joined).
- Reads only `referralClaims`, which the rules already allow for admin roles; no rules or server change. Names/e-mails are shown only to roles allowed to see them; others see the public invite code.
- App unchanged (versionCode stays **34**): deploy **admin-portal** only. Checks: admin typecheck, 25/25 admin tests (5 new chain tests), production build, security scan clean; page checked in a browser with 124 sample sign-ups (100-person chain, 5 levels, CSV export).

# GenZ Codebook V7 — Build 34 (invite link on the profile)

- **Invite card on the main You page:** your invite code, a copy button, **Share invite link**, and how many friends joined (+100 Credits each). Guests see "Create account" to get a code.
- **The shared link is now a Google Play link** that carries the code (`…details?id=com.genzmode.app&referrer=utm_source=invite&utm_content=GZXXXXXX`), with the code also written in the message. The old `genzcode://` link could not be tapped in WhatsApp/Instagram and did nothing for people without the app. The Play link opens once the app is published.
- The friend types the code in the sign-up form (it is in the message). Optional later: auto-fill the code from the Play install referrer (needs one small native module; testable only on a Play-installed build).
- The referral history (who you invited, who invited you) stays under Wallet & rewards; an outdated "chat and posting are free" note was removed.
- Includes Builds 32–33. Version code **34**. Checks: app 154/154 (new invite-link test), typecheck, security scan clean, Android bundle export passed.

# GenZ Codebook V7 — Build 33 (Google sign-in)

- **Google sign-in switched on.** The fresh `android/app/google-services.json` (Android OAuth client for SHA-1 `5E:8F:…:F6:25`, the GitHub APK key) is in the project, and `GOOGLE_WEB_CLIENT_ID` is set to the Web client `1095502586634-09bohub3v58v9f25lmssqu37na02ugpd.apps.googleusercontent.com`. The login page now shows "Continue with Google".
- For Play builds, add the **upload key** and **Play App Signing key** SHA-1s in Firebase as well (Play Console → App integrity), or Google sign-in will show "developer error" on Play-installed copies.
- Restored "ID token" in five technical messages that the Tokens→Credits rename had changed (Google sign-in and the purchase-verification server).
- Includes everything in Build 32. Version code **33**. Checks: app 154/154, typecheck, backend build + 11/11, security scan clean, Android bundle export passed.

# GenZ Codebook V7 — Build 32 update (after device testing of Build 31)

| Reported | Fix |
|---|---|
| Tester: "Cloud sync refused … account may be restricted" | Not a restriction. The database rule accepted profile avatars 0–5, but the app offers 12 (0–11); anyone using avatar 6–11 had every sync refused. The rule now accepts 0–11 (new rules test included). **Deploy community** to apply it. |
| Tester: chat "permission-denied" although verified | That phone ran the old Build 29 app, which cannot pay for a Chat Pass while paid community is on. Testers need Build 32, or turn paid community off in admin Settings until they update. |
| Chat messages appear ~2 s after sending | Each send ran four network checks one after another (account, e-mail, chat switch, rate limit) and the message only appeared when the live feed echoed it. The checks now run in parallel once, are reused for 3 minutes (pre-run when the room opens), the 10-second limit is tracked on the phone, and your message shows instantly as "Sending…" and is removed or restored to the box if the server refuses it. The security rules still check everything on every message. |
| "Enter for today" greyed although Credits are enough | The required "Vibe check" chip was easy to miss. It is now a large "I agree to be respectful" checkbox, and the reason the button is disabled is shown under it (tick the box / you need N more Credits). |
| Trophy icon unclear | Header pill now says **Join leaderboard** (joins and opens it), **Leaderboard** when joined, **Back to chat** while open; the board has Join/Leave. |
| Daily Code shows another code first, then today's | The offline fallback word showed until the live listener answered (~3 s). Now: the last code seen today shows at once (memory/device), one quick read runs alongside the listener, and a "Loading today's code…" placeholder shows until the real one arrives. The offline word only appears with no connection (after 6 s) or when today has no published code. |
| Profile card blue hides the blue badge; too large | The profile card is now a dark plum gradient for everyone, so blue and gold badges stand out, with smaller padding, name and sync row. |
| Social links buried in Settings | "Follow us" Instagram / Facebook / WhatsApp / Email icons sit in one row at the bottom of the You page, with **Rate the app** and **Feedback** tiles above them. |
| Buy Credits: text cut off, badge price missing | One full-width list with no truncation: chat (day), post, new word, Daily Code, **Verified badge review 5,000**, Encode and Decode (after the daily free allowance), each with a one-line explanation. |
| "Create your own code" gone from home | It only showed in Decode mode before a result. It now shows on the home page in both Decode and Encode modes, with its Credit price when paid community is on (price read after first paint). |
| Premium and ad-free | Premium Monthly **10,000 Credits** and Yearly **200,000 Credits** each period (app and server tables), ad-free while active, rewarded ads optional. Recommended Play prices **$4.99/month** and **$39.99/year** (save 33%). Subscribe buttons appear once checkout is enabled; until then the plans say "Opens with Google Play checkout". |
| Google sign-in card "Not set up yet" | Hidden until the Web client ID is set (see the setup steps given with this build). |
| Posts: hearts and comments vanish for ~3 s after switching from Chat | Switching tabs rebuilt the feed from empty ("Loading posts…") and reset your likes until they reloaded. The last feed per filter, your likes/saves and verified badges are now kept in memory, so Posts shows instantly with the right hearts while live data refreshes in the background. |
| Leftover "tokens" wording | Remaining labels (wallet, leaderboard, referral, chat pass) now say Credits; the post button typo "Credens" is fixed. |

Version code **32**. Firebase changes: Firestore rules (avatar 0–11) — deploy **community**, then rebuild the APK. The Premium grant table lives in the purchase functions (`verifySubscription` and the Play notification handler), which are deployed with the **functions** target once the `PLAY_SERVICE_ACCOUNT_JSON` secret is set.

Checks for this update: app 154/154 tests, app and admin typecheck, backend build + 11/11 in-memory tests, security scan clean (146 files), Android Hermes bundle export passed. Rules tests (including the new avatar test) run in your GitHub deploy workflow.

# GenZ Codebook V7 — Build 31 update (after device testing of Build 30)

| Reported | Fix |
|---|---|
| Admin calendar showed no colours | Reserved/scheduled and published dates are green, pending requests amber, past dates grey, with a legend. |
| Portal not V7 / "liquid glass" | New glass theme: frosted cards and top bar, gradient sidebar and buttons, soft colour background, focus rings; reduced-motion respected. |
| Empty dark squares in the portal | The logos were served from `public/` and, when missing, came back as the portal page through the `/admin/**` rewrite. They are now bundled build assets. |
| Portal pages open after a long pause (follow-up) | Root causes: `firebase.json` sent `Cache-Control: no-store` for all of `/admin/**`, so the portal code was re-downloaded on every visit; the Dashboard downloaded the whole 4.9 MB dictionary (~0.44 MB compressed) just to show the entry count; every page switch remounted the page and re-ran all its queries; and card/number animations took up to ~1 s. Fixes: hashed code files are cached for a year (new deploys use new file names), entry pages and the dictionary revalidate via ETag; the Dashboard count comes from the bundled manifest; the dictionary downloads at most once per session; opened pages stay mounted; other pages' code is prefetched after sign-in; animations shortened to ~0.2–0.35 s. A repeat Dashboard visit now downloads only a revalidation check instead of ~640 KB. |
| Portal slow to open | Startup checks run in parallel (admin role + email reload; token + two-step setting), the login audit write no longer blocks, and each page loads on demand (Dashboard prefetched while the session is checked). |
| Encode: weak results, "you → j00", "headach" not converted | The encoder now converts every word or phrase with a sensible code, including community words (HOD), and never uses leetspeak or emoji except everyday codes. The result card highlights codes, with copy and share buttons; tap a code to switch it. |
| 10 free each for Encode and Decode, then Credits | Each has its own free daily allowance (admin: default 10), then a Credit price per conversion (admin: default 5; 0 = free). Charged by the server only after a successful conversion, once per request; an optional ad gives +5. |
| Change Credit prices | Admin Settings → Prices: chat day, post, new word, Daily Code, badge review, Encode, Decode. The server charges the same live price; refunds return what was actually paid. |
| Buy Credits page empty | Always shows what Credits buy, free ways to earn, all 7 packs with their planned prices ($1.99–$25.99) and the Premium (ad-free) monthly/yearly plans. Buttons say "Opens soon" until checkout is enabled. |
| Badge error with an email | The badge box accepts an email or a user ID. Badges are **blue** (verified users) or **gold** (owner/staff, Super Admin only). |
| Badge/profile colour | Seal-style badge beside the name; the profile card is gold for gold badges and blue for blue badges. "Verified badge" is the first row of the profile list. |
| Profile photo missing on posts | Posts and comments show the author's avatar icon and, if they opt in ("Show my photo on my posts"), a 96 px photo from `publicProfiles/{uid}` (owner-written, public read, deleted with the account). The privacy policy and About text were updated. **Also update the Play Data safety form: Photos — optional, shared publicly by user choice.** |

Version code **31**. Firebase changes in this update: `communityFeature` (prices, `convert-fee`, refunds use the paid amount, public card removed on account deletion), Firestore rules (`config/app.prices`, `decodeFreeDaily`, `publicProfiles`, badge `tier`). Deploy **community** again, then rebuild the APK.

Checks for this update: app 154/154 tests, admin 20/20 + production build, backend 11/11 (in-memory Firestore), security scan clean, Android Hermes bundle export passed. Firestore rules and the backend emulator suite run in your GitHub deploy workflow.

---

# GenZ Codebook V7 — Build 30 upgrade report

Source: Build 29 (`GenZ_Codebook_Build29_Deploy_Fix`). Android version code **30** (version name 1.0.0). Package, signing and release credentials are unchanged.

This build fixes the ten priorities in order and adds the parts of the V7 brief listed below. **It is not the whole V7 brief.** Section 8 lists exactly what is still open and what each item needs. Nothing was deployed from this workspace.

## 1. Modifications

| Area | Files |
|---|---|
| Startup speed | `metro.config.js` (new), `src/engine.ts`, `src/discovery.ts`, `src/reviewQueue.ts`, `App.tsx`, `scripts/measure-startup.mts` (new) |
| Sign-in persistence | `src/auth/chunkedStorage.ts` (new), `src/auth/persistence.native.ts`, `src/secure/session.ts`, `src/services.ts` |
| Community | `src/optimistic.ts` (new), `src/CommunityPostsPanel.tsx`, `src/CommunityScreen.tsx` |
| Daily Code (app) | `src/ContributionScreens.tsx` |
| Credits / paid mode | `src/appConfig.ts` (new), `src/publishing.ts`, `src/communityFeatures.ts`, `src/SubmitForms.tsx`, `functions/src/communityPolicy.json` |
| V7 header | `src/AppHeader.tsx` (new), `src/AdRewardButton.tsx`, `App.tsx` |
| Encode Message | `src/encode.ts`, `src/encodeQuota.ts`, `src/EncodePanel.tsx` (new), `App.tsx` |
| Social & support | `shared/brand.ts`, `src/FollowUs.tsx` (new), `src/SettingsScreen.tsx`, `src/AboutScreen.tsx` |
| Wording (Tokens → Credits) | 85 user-facing strings across `src/`, `admin/src/pages/`, `shared/`, `functions/src/` |
| Backend | `functions/src/communityFeatures.ts`, `functions/src/communityEndpoints.ts` |
| Security rules and indexes | `firebase/firestore.rules`, `firebase/firestore.indexes.json` |
| Admin portal | `admin/src/lib/metrics.ts`, `admin/src/pages/Dashboard.tsx`, `admin/src/firebase.ts`, `admin/src/pages/Users.tsx`, `CommunityWorkflow.tsx`, `DailyCodesList.tsx` (new), `Settings.tsx`, `Logs.tsx`, `admin/src/lib/dailyRows.ts` (new) |
| Browser favicon only | `admin/public/favicon.{ico,svg}`, `admin/site/public/favicon.{ico,svg}`, `assets/favicon.png` (Expo **web** favicon), cache-busting `?v=8` in the HTML pages. Android launcher, adaptive and splash icons are untouched. |
| Version | `app.json` versionCode 30, `android/app/build.gradle` default 30 |
| Tests | `functions/tests/community-features.test.cjs` (balances updated for the 50-Credit post), `tests/{optimistic,chunkedStorage,encode,social}.test.ts`, `admin/tests/dailyRows.test.ts`, `functions/tests/{fake-firestore.cjs,credits-daily.fake.test.cjs}` (new); wording/fee/header assertions updated in `tests/{posts,chat,notifications,referral}.test.ts` |

## 2. Fixed bugs and root causes

1. **30-second Home startup.** Before the first frame, the app built all 30 quiz levels (re-sorting ~5,000 words with `localeCompare` for each level) and the full search/decoder index (`normalize` + `toLocaleLowerCase` on every entry): **232,990 locale-sensitive string calls**. On Android, Hermes runs each through a JNI call into java.text, which is why phones took tens of seconds while desktop measurements looked small. All five tabs were also mounted, hidden, at launch, and Expo's default Metro setting (`inlineRequires: false`) evaluated every module (Firebase SDK, billing, ads, all screens) before the first frame.
   *Fix:* ASCII fast path and lazy index (built 1.2 s after Home appears), one ordinal sort, quiz levels generated when Play first opens, each tab mounted on first visit, inline requires on.
2. **Admin 500-Credit grant "did not work".** The admin page showed "Something went wrong" for every Cloud Function error, because its error mapper only knew Firestore error codes. The real reason was never visible. The grant logic itself works: a test grants 500, rejects the duplicate request and spends the Credits on a Daily Code. The portal already requires a verified email, so the remaining server refusals are wrong role, two-step sign-in required (`config/security.adminMfaRequired`) or an inactive target account. Each now shows its own message, and the server separates the role and two-step messages.
3. **Daily Code Confirm button greyed out.** In the app, Confirm stayed disabled until a word *chip* was tapped. Typing "HDOT" in the search box did not select it, and nothing said why the button was disabled. A taken date or a low balance were also silent. In the admin portal, scheduled words such as HDOT appeared only as a calendar cell, with no list or actions.
4. **Chatroom asking signed-in users to sign in.** Screens could not tell "still restoring the saved session" from "signed out", so during startup they showed "Sign in to chat". The session was also stored as one SecureStore value; SecureStore documents a ~2 KB limit per value and a Firebase session can exceed it, so some sessions were not restored after a restart.
6. **Admin Dashboard "This report needs a database index" / "Platform status: Unavailable".** The Users report's learning totals (sum/average of five `stats.*` fields) need a composite index, but the index was never declared in `firebase/firestore.indexes.json`; a code comment wrongly said none was needed. It was created by hand in the console, and the **community** deploy runs with `--force`, which removes indexes that are not in the file. *Fix:* the index is now declared, so every deploy creates and keeps it. The totals are also optional, so user counts and platform status load while the index builds.
5. **Likes and saves taking 2–3 s.** The UI waited for a Firestore transaction plus the next feed snapshot before changing the heart.

## 3. New features

- **Encode Message (Home → Encode).** Converts plain text into codes from the GenZ Codebook dictionary, on the device. "Hello, how are you?" becomes "Hello, hru?" and "to be honest I don't know" becomes "tbh idk". Matching is case-insensitive; punctuation and unmatched words are kept; phrases never join across punctuation. Ordinary single words change only to well-known codes. Tap a code to cycle through alternatives. Copy, Share, Edit and "Decode it" are included. A free daily limit is set by the admin (default 10), and an optional rewarded ad gives +5. A conversion is counted only when something was encoded.
- **V7 header** (per the reference image): GZ mark + wordmark, with the tagline on wider phones; gold Credit pill; blue "Ad +10" pill; bell; avatar with a gradient ring. It stays on one row on narrow phones, and the Credit balance shows on every tab.
- **V7 post card:** gradient avatar, verified badge, time, code chip, "# category" chip, "Meaning:", red heart with count, comment count, and Save/Copy/Share pills (icon-only under 400 px). Likes and saves update instantly and roll back if the server refuses.
- **Daily Code form:** numbered steps; an exact search match is selected automatically; the calendar shows green = reserved, amber = pending, grey = unavailable; the reason Confirm is disabled is shown in a list, with a **Get Credits** button when short.
- **Admin Daily Codes list** with Upcoming / Pending / Approved & scheduled / Published / Rejected / All tabs, and per-row ✓ Approve (with date), ✎ Edit, ⇄ Replace (refunds the requester) and 🗑 Delete (refunds the requester). The applications queue has one-step **Approve & schedule**. Every disabled button explains itself.
- **Admin Credits card:** grant and **deduct** (reason required, never below zero), both with confirmation and idempotent request IDs. If the backend is unreachable, the grant falls back to the audited ledger write.
- **Paid community switch** (admin Settings → Credits): chat day pass 30 · post 50 · new dictionary code 150. It is enforced by the Cloud Function, the app and the Firestore rules. It is **off by default**.
- **Stay connected** (Settings and About): Instagram, Facebook, WhatsApp Channel and Help & Support email. Only these fixed https links open; if a link can't open, it is copied instead. No rewards are offered for following.
- **Browser favicon** from the supplied GZ icon (transparent corners; 16/32/48/64 px .ico, SVG, 196 px PNG).

## 4. Firebase changes (deploy required)

- **`communityFeature` function:**
  - New `deduct-tokens` action (writes ledger type `admin_debit`; the wallet check accepts it only as a negative amount).
  - `daily-admin` gains `approve` with a date (approve and schedule in one step), `edit-schedule` and `replace-schedule` (refunds the requester in full).
  - The scheduler publishes an admin's edited text.
  - Clearer role and two-step messages.
  - Paid create-code / create-post / chat-pass run only when `config/app.paidCommunity` is true.
- **Policy:** `postFee` is now 50 (from 25). The others are unchanged: chat 30/day, dictionary code 150, Daily Code 250, referral +100.
- **Firestore rules:**
  - `config/app` accepts `paidCommunity`, `encodeFreeDaily` and `encodeCreditCost` (type- and range-checked).
  - When paid mode is on, chat messages need an unexpired `chatPasses/{uid}`, and direct free post/code writes are refused.
  - Collections and existing fields are not renamed or deleted. "Credits" is display wording only; the `tokenLedger`, `tokenWallet` and `tokens.*` names stay as they are for compatibility.
- **One new composite index:** `users` on `stats.levels`, `stats.quizzes`, `stats.reviewed`, `stats.saved`, `stats.streak` (admin Dashboard totals). It takes a few minutes to build after deploy.

## 5. Admin portal changes

- **Errors:** the real Cloud Function message is shown (not deployed, session expired, wrong role, two-step required, unreachable, or the server's own text).
- **Users → Credits:** grant/deduct with confirmation, plus a verification-email shortcut if an admin email is ever unverified.
- **Daily Codes:** the new list, Approve & schedule, inline reasons for disabled buttons.
- **Settings:** the Credits switch and Encode limits.
- **Logs:** filters for the new Daily Code and deduction audit actions.
- The V7 *visual* restyle of the portal and the expanded dashboard statistics are **not** in this build.

## 6. Performance (measured)

`node --import tsx scripts/measure-startup.mts` measures the work done before the first screen can paint:

| | Build 29 | Build 30 |
|---|---|---|
| Locale-sensitive string calls before first paint | **232,990** (170,370 `localeCompare`, 31,310 `normalize`, 31,310 `toLocaleLowerCase`) | **0** |
| JS time on desktop Node (relative only) | 318 ms | 127 ms |
| Deferred until after first paint | — | index + 30 levels: 92 ms, 8,588 `normalize` (non-ASCII entries only) |

Desktop Node is much faster than a phone at these calls, so the phone saving is far larger than the desktop numbers suggest. **A real-device cold start has not been measured.** Please time it on the same phone before and after.

## 7. Security and testing results

- App: TypeScript passes; **150/150 tests**. New tests cover instant likes (6), chunked session storage (6: >2 KB sessions, legacy migration, crash safety, Keystore failure, removal, surrogate pairs), Encode Message (8) and social links (3).
- Backend: compiles; **9/9** tests run the real compiled `communityFeatures` against an in-memory Firestore stand-in. They cover a 500 grant with duplicate protection, role checks, deduction limits, a 250-Credit Daily Code with Approve & schedule, an approved code published on its date, an unapproved request never published (automatic word plus refund), edit/replace/delete with refunds, the chat pass charged once per UTC day, and a 50-Credit post refused when short. The stand-in is not the Firestore emulator.
- Admin: TypeScript passes; **20/20 tests**; production build passes.
- Security scan (`scripts/security-scan.mjs`): no findings (a targeted static scan, not a penetration test).
- **Firestore rules: 61/61 passed on the official emulator** in your GitHub Actions deploy run (they could not run in this workspace because the emulator download is blocked).
- **Backend emulator tests** (`functions/tests/community-features.test.cjs`): the first CI run failed 5 of 20 tests. All five were hard-coded to the old 25-Credit post price (for example, expecting 325 instead of 300). They were updated to the 50-Credit price: 15 assertion lines, with no backend code changed. They must pass in your next CI run before deployment continues.
- No device, live Firebase, AdMob or Play test was possible.

## 8. Remaining issues and what each needs

| Item | Status / what is needed |
|---|---|
| Google sign-in | Add the SHA-1 and SHA-256 of the upload key **and** the Play App Signing key in Firebase → Project settings → Android app; download the new `google-services.json`; confirm the Web OAuth client ID used by `src/googleAuth.ts`. |
| Phone number + OTP | Not built. The Firebase JS SDK needs a reCAPTCHA verifier, which React Native lacks; a native auth module (for example `@react-native-firebase/auth`) and a native rebuild are needed. Owner decision. |
| Password visibility toggle, merged profiles across methods | Not done. |
| Credit purchases and ad-free | Still disabled (`tokenPurchasesEnabled: false`). Needs the Play service-account secret, final product IDs (Credit packs plus an explicit ad-free product), and an internal-track test purchase. |
| Rewarded interstitial | Needs a new AdMob ad unit ID. Banner, interstitial and rewarded already exist. UMP consent was not audited. |
| Encode Message charged in Credits | The admin setting is stored but **not charged** in Build 30 (free limit + rewarded ad only). Needs a small server action. |
| Ranked Posts, blue/gold badges, profile upgrade, feedback replies, user search by username, separated Credit-history categories, admin dashboard statistics | Not in this build. |
| V7 restyle of the remaining screens and the admin portal | Partial (header, post cards, Encode, Daily Code form). |
| Learning points vs Credits | Two balances remain: server Credits (spendable) and device-only learning points (games and level unlocks). Merging them is a product decision. |

## 9. APK / AAB status

`npx expo export --platform android --clear` **passed** with inline requires enabled: Hermes bytecode bundle 9.09 MB. No native APK or signed AAB was built here (no Android SDK or signing keys). Build with **Actions → Android APK**, then the existing signed AAB release process. Version code 30 updates Build 29.

## 10. Deployment and Play readiness

1. Your repository uses **ZIP mode**: keep exactly **one** project ZIP at the repository root (this full ZIP) and delete any other `.zip` there. The workflows extract it automatically.
2. Run **Actions → Firestore rules tests**. Do not deploy until it passes. (The deploy workflow also runs the rules and backend tests before it deploys anything.)
3. Run **Actions → Deploy Firebase → community** (rules, Hosting/admin portal, `communityFeature`, scheduler).
4. Run **Actions → Android APK**, install Build 30 over Build 29 and time the cold start.
5. In the admin portal, grant 500 Credits to a test account and confirm the header updates. If it fails, the message now says why.
6. Only then turn on **Settings → Credits → Charge Credits for community features**. Users on Build 29 cannot pay for chat or posts once it is on.
7. Play readiness is **not complete**: Billing, ad-free, Google/phone sign-in, consent and real-device QA remain (section 8).
