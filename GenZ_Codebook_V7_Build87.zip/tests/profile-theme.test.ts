import test from 'node:test';
import assert from 'node:assert/strict';
import {createProfileTheme} from '../src/profileTheme';

test('profile mode defaults to light and restores the last choice for each account',async()=>{
 const values=new Map<string,string>();
 const storage={getItem:async(key:string)=>values.get(key)??null,setItem:async(key:string,value:string)=>{values.set(key,value);}};
 const first=createProfileTheme(storage,'first');
 await first.load();assert.equal(first.snapshot(),false);
 const observed:boolean[]=[];
 const stop=first.subscribe(()=>observed.push(first.snapshot()));
 await first.toggle();stop();
 const signedInAgain=createProfileTheme(storage,'first'),other=createProfileTheme(storage,'other');
 await Promise.all([signedInAgain.load(),other.load()]);
 assert.equal(signedInAgain.snapshot(),true);assert.equal(other.snapshot(),false);
 await signedInAgain.toggle();assert.equal(values.get('first'),'light');
 assert.deepEqual(observed,[true]);
});

test('late hydration and quick toggles keep the most recent choice',async()=>{
 let finish!:(value:string)=>void;
 const changes:string[]=[];
 const theme=createProfileTheme({getItem:()=>new Promise<string>(resolve=>{finish=resolve;}),
  setItem:async(_key,value)=>{changes.push(value);}},'test');
 const load=theme.load();const writes=[theme.toggle(),theme.toggle(),theme.toggle()];
 finish('light');await Promise.all([load,...writes]);
 assert.equal(theme.snapshot(),true);assert.deepEqual(changes,['dark','light','dark']);
});
