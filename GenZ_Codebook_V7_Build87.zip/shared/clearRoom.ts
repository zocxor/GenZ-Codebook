export async function clearRoom(run:(data:Record<string,unknown>)=>Promise<{cutoff?:unknown;more?:unknown}>) {
  let page=await run({});
  while(page.more===true)page=await run({cutoff:page.cutoff});
}
