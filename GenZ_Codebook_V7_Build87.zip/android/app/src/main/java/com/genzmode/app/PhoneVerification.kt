package com.genzmode.app

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.uimanager.ViewManager
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

class PhoneVerification(private val context: ReactApplicationContext) : ReactContextBaseJavaModule(context) {
    override fun getName() = "PhoneVerification"

    @ReactMethod
    fun start(phone: String, promise: Promise) {
        val host = context.currentActivity
        if (host == null) {
            promise.reject("phone/unavailable", "Open the app to send a verification code.")
            return
        }

        host.runOnUiThread {
            val auth = FirebaseAuth.getInstance()
            var completed = false
            fun resolve(key: String, value: String) {
                if (completed) return
                completed = true
                promise.resolve(Arguments.createMap().apply { putString(key, value) })
            }
            fun reject(cause: Exception?) {
                if (completed) return
                completed = true
                val code = (cause as? FirebaseAuthException)?.errorCode ?: "phone/verification-failed"
                promise.reject(code, cause?.localizedMessage ?: "Phone verification failed. Try again.")
            }

            val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                    resolve("verificationId", id)
                }

                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    if (completed) return
                    auth.signInWithCredential(credential).addOnCompleteListener { result ->
                        val nativeUser = result.resultOrNull()?.user
                        if (nativeUser == null) {
                            reject(result.exception)
                        } else {
                            nativeUser.getIdToken(false).addOnCompleteListener { tokenResult ->
                                val token = tokenResult.resultOrNull()?.token
                                auth.signOut()
                                if (token == null) reject(tokenResult.exception) else resolve("idToken", token)
                            }
                        }
                    }
                }

                override fun onVerificationFailed(error: FirebaseException) {
                    reject(error)
                }

                override fun onCodeAutoRetrievalTimeOut(id: String) {
                    resolve("verificationId", id)
                }
            }
            try {
                PhoneAuthProvider.verifyPhoneNumber(
                    PhoneAuthOptions.newBuilder(auth)
                        .setPhoneNumber(phone)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(host)
                        .setCallbacks(callbacks)
                        .build()
                )
            } catch (cause: Exception) {
                reject(cause)
            }
        }
    }

    private fun <T> com.google.android.gms.tasks.Task<T>.resultOrNull(): T? =
        if (isSuccessful) result else null
}

class PhoneVerificationPackage : ReactPackage {
    override fun createNativeModules(context: ReactApplicationContext): List<NativeModule> =
        listOf(PhoneVerification(context))

    override fun createViewManagers(context: ReactApplicationContext): List<ViewManager<*, *>> = emptyList()
}
