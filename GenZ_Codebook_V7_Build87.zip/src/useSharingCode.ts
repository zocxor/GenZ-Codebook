import {useEffect,useState} from 'react';
import {doc,onSnapshot} from 'firebase/firestore';
import {isReferralCode,referralCodeForUid} from '../shared/referral';
import {cloudDbLive} from './firebase/app';

export function useSharingCode(uid?:string){
 const [override,setOverride]=useState<{uid:string;code:string}|null>(null);
 useEffect(()=>{
  if(!uid)return;
  return onSnapshot(doc(cloudDbLive(),'config','ownerSharingCode-'+uid),snapshot=>{
   const data=snapshot.data();
   setOverride(typeof data?.uid==='string'&&isReferralCode(data.code)?{uid:data.uid,code:data.code}:null);
  },()=>setOverride(null));
 },[uid]);
 return override&&override.uid===uid?override.code:referralCodeForUid(uid??'');
}
