type ThemeStorage = {
 getItem:(key:string)=>Promise<string|null>;
 setItem:(key:string,value:string)=>Promise<void>;
};

export function createProfileTheme(storage:ThemeStorage,key:string){
 let dark=false,loaded=false,edited=false;
 let loading:Promise<void>|undefined;
 let writes=Promise.resolve();
 const listeners=new Set<()=>void>();
 const publish=(value:boolean)=>{
  if(dark===value)return;
  dark=value;
  listeners.forEach(listener=>listener());
 };
 return {
  snapshot:()=>dark,
  ready:()=>loaded||edited,
  subscribe:(listener:()=>void)=>{
   listeners.add(listener);
   return ()=>{listeners.delete(listener);};
  },
  load:()=>{
   if(!loaded&&!loading){
    loading=storage.getItem(key).then(value=>{
     if(!edited)publish(value==='dark');
    }).catch(()=>{}).finally(()=>{
     loaded=true;loading=undefined;listeners.forEach(listener=>listener());
    });
   }
   return loading??Promise.resolve();
  },
  toggle:()=>{
   edited=true;
   const value=!dark;
   publish(value);
   writes=writes.catch(()=>{}).then(()=>storage.setItem(key,value?'dark':'light'));
   return writes;
  },
 };
}
