import {NativeModules,Platform} from 'react-native';
import {PhoneAuthProvider,signInWithCredential,signInWithCustomToken} from 'firebase/auth';
import {accountAuth} from './auth/client';
import {exchangePhoneVerification} from './communityFeatures';

type Verification = {verificationId:string;idToken?:never}|{idToken:string;verificationId?:never};
const native=NativeModules.PhoneVerification as {start(phone:string):Promise<Verification>}|undefined;
export const phoneSignInAvailable=Platform.OS==='android'&&!!native;

export async function startPhoneSignIn(phone:string){
 if(!native)throw new Error('Phone sign-in is available in the Android app.');
 const result=await native.start(phone);
 if(result.idToken)await signInWithCustomToken(accountAuth,await exchangePhoneVerification(result.idToken));
 return result.verificationId;
}

export async function confirmPhoneSignIn(verificationId:string,code:string){
 await signInWithCredential(accountAuth,PhoneAuthProvider.credential(verificationId,code));
}

export function phoneSignInError(error:unknown){
 const code=(error as {code?:string})?.code;
 switch(code){
  case 'auth/invalid-verification-code':return 'That code is incorrect. Check the SMS and try again.';
  case 'auth/code-expired':
  case 'auth/session-expired':return 'That code expired. Request another SMS.';
  case 'auth/too-many-requests':
  case 'ERROR_TOO_MANY_REQUESTS':return 'Too many attempts. Wait and try again.';
  case 'auth/invalid-phone-number':
  case 'ERROR_INVALID_PHONE_NUMBER':return 'Enter your mobile number with the country code.';
  case 'auth/network-request-failed':return 'Check your connection and try again.';
  default:return 'Phone verification could not complete. Check the number and try again.';
 }
}
