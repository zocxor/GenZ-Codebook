import React,{useRef,useState} from 'react';
import {Pressable,ScrollView,StyleSheet,Text,View} from 'react-native';
import {C} from './ui';

type MenuColors={surface:string;line:string;ink:string;field:string};
const lightColors:MenuColors={surface:'#fff',line:C.line,ink:C.ink,field:C.soft};
export type OverflowMenuProps={headerHeight?:number;anchor?:MenuAnchor;compact?:boolean;onDismiss:()=>void;children:React.ReactNode;colors?:MenuColors};

export function OverflowMenuItem({label,onPress,selected,colors=lightColors}:{label:string;onPress:()=>void;selected?:boolean;colors?:MenuColors}){
 return <Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityState={{selected}} onPress={onPress} style={({pressed})=>({minHeight:44,justifyContent:'center',paddingHorizontal:10,backgroundColor:pressed?(colors.field):'transparent'})}>
  <Text style={{fontFamily:'Calibri',fontSize:15,fontWeight:'400',color:colors.ink}}>{label}{selected?'  ✓':''}</Text>
 </Pressable>;
}
export type MenuAnchor={x:number;y:number;width:number;height:number};
export function OverflowMenu({headerHeight=0,anchor,compact=false,onDismiss,children,colors=lightColors}:OverflowMenuProps){
 const ref=useRef<View>(null);
 const [frame,setFrame]=useState<MenuAnchor|null>(null);
 const [contentHeight,setContentHeight]=useState<number>();
 const measure=()=>ref.current?.measureInWindow((x,y,width,height)=>setFrame({x,y,width,height}));
 const top=anchor&&frame?Math.max(8,anchor.y-frame.y):headerHeight;
 const below=anchor?top+anchor.height:top;
 const beside=compact&&!!anchor&&!!frame;
 const above=!beside&&!!anchor&&!!frame&&below+270>frame.height&&top>frame.height-below;
 const menuTop=beside&&frame
  ?Math.max(8,Math.min(top,frame.height-(contentHeight??0)-8))
  :above?8:below;
 const right=anchor&&frame
  ?Math.max(8,frame.width-(anchor.x-frame.x+(beside?-4:anchor.width)))
  :8;
 return <View ref={ref} collapsable={false} onLayout={measure} accessibilityViewIsModal style={[StyleSheet.absoluteFill,{zIndex:30,elevation:8}]}>
  <Pressable accessibilityRole="button" accessibilityLabel="Dismiss menu" onPress={onDismiss} style={StyleSheet.absoluteFill}/>
  {(!anchor||frame)&&<View pointerEvents="box-none" style={{position:'absolute',top:menuTop,left:8,right,bottom:above&&frame?Math.max(8,frame.height-top):8,alignItems:'flex-end',justifyContent:above?'flex-end':'flex-start'}}>
   <ScrollView keyboardShouldPersistTaps="always"
    onContentSizeChange={compact?(_,height)=>setContentHeight(height+2):undefined}
    style={{flexGrow:0,flexShrink:1,maxWidth:'100%',backgroundColor:colors.surface,borderRadius:12,borderWidth:1,borderColor:colors.line,elevation:5,
     ...(compact?{width:152,height:contentHeight,opacity:contentHeight===undefined?0:1}:{minWidth:170})}}
    contentContainerStyle={{paddingVertical:4}}>
    {children}
   </ScrollView>
  </View>}
 </View>;
}
