import React from 'react';
import {Modal} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {OverflowMenu,type MenuAnchor} from './OverflowMenu';

export function CommunityMenu({anchor,compact,children,onDismiss}:{anchor:MenuAnchor;compact?:boolean;children:React.ReactNode;onDismiss:()=>void}){
 return <Modal transparent animationType="none" onRequestClose={onDismiss}>
  <SafeAreaView style={{flex:1}} edges={['left','right','bottom']}>
   <OverflowMenu anchor={anchor} compact={compact} onDismiss={onDismiss}>{children}</OverflowMenu>
  </SafeAreaView>
 </Modal>;
}
