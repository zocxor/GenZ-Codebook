import React,{useEffect,useState} from 'react';
import {AppState,Linking,NativeModules,PermissionsAndroid,Platform,Text,View} from 'react-native';
import {Button,C,Chip,Glass} from './ui';
import {messaging} from './messaging';
import {accountAuth} from './firebase/app';

const alerts=NativeModules.InboxAlerts as {
 account:(uid:string)=>void; read:(uid:string)=>Promise<string>; save:(uid:string,value:string)=>void;
 token:()=>Promise<string>; preview:(tone:string,vibration:string)=>void;
}|undefined;
const defaults={enabled:false,personal:'prism',group:'tidal',vibration:'short'};
type Options=typeof defaults;
const load=async(uid:string):Promise<Options>=>({...defaults,...JSON.parse(await alerts!.read(uid))});
async function register(uid:string,enabled:boolean){
 const token=await alerts!.token();
 if(accountAuth.currentUser?.uid!==uid)throw new Error('Account changed');
 await messaging('alert-device',{token,enabled});
}
export function useMessageAlertAccount(uid:string|undefined,restoring:boolean){
 useEffect(()=>{
  if(!alerts||restoring)return;
  alerts.account(uid||'');
  if(!uid)return;
  let live=true;
  const refresh=async()=>{if((await load(uid)).enabled&&live)await register(uid,true);};
  void refresh().catch(()=>{});
  const sub=AppState.addEventListener('change',state=>{if(state==='active')void refresh().catch(()=>{});});
  return ()=>{live=false;sub.remove();};
 },[uid,restoring]);
}
export function MessageAlertSettings({uid}:{uid:string}){
 const [expanded,setExpanded]=useState(false);
 const [options,setOptions]=useState<Options|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 useEffect(()=>{let live=true;if(alerts)void load(uid).then(v=>{if(live)setOptions(v);},()=>{if(live)setError('Could not load alert preferences.');});return()=>{live=false;};},[uid]);
 if(!alerts)return null;
 const save=(value:Options)=>{alerts.save(uid,JSON.stringify(value));setOptions(value);};
 const toggle=async()=>{
  if(!options||busy)return;
  setBusy(true);setError('');
  try{
   const enabled=!options.enabled;
   if(enabled&&Number(Platform.Version)>=33&&(await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS))!=='granted'){
    setError('Allow notifications in Android settings to receive message alerts.');return;
   }
   if(!enabled)save({...options,enabled});
   await register(uid,enabled);
   if(enabled)save({...options,enabled});
  }catch{setError('Could not sync alert registration. Check your connection and try again.');}
  finally{setBusy(false);}
 };
 return <Glass><Text accessibilityRole="header" style={{fontSize:18,fontWeight:'700',color:C.ink}}>Message alerts</Text>
  {options&&<>
   <Button light title={busy?'Saving…':options.enabled?'Turn off message alerts':'Turn on message alerts'} disabled={busy} onPress={()=>void toggle()}/>
   <Chip label={expanded?'Hide sound and vibration':'Sound and vibration'} selected={expanded} onPress={()=>setExpanded(!expanded)}/>
   {expanded&&<>{(['personal','group'] as const).map(kind=><View key={kind} style={{gap:6}}>
    <Text style={{color:C.ink}}>{kind==='group'?'Group':'Personal'} message tone</Text>
    <View style={{flexDirection:'row',flexWrap:'wrap',gap:6}}>{['prism','tidal','pebble','silent'].map(tone=><Chip key={tone} label={tone[0]!.toUpperCase()+tone.slice(1)} selected={options[kind]===tone} onPress={()=>{if(busy)return;save({...options,[kind]:tone});alerts.preview(tone,'off');}}/>)}</View>
   </View>)}
   <Text style={{color:C.ink}}>Vibration</Text>
   <View style={{flexDirection:'row',flexWrap:'wrap',gap:6}}>{['off','short','double'].map(v=><Chip key={v} label={v==='double'?'Double pulse':v==='short'?'Short':'Off'} selected={options.vibration===v} onPress={()=>{if(busy)return;save({...options,vibration:v});alerts.preview('silent',v);}}/>)}</View>
   </>}
   <Button light title="Open Android app settings" onPress={()=>void Linking.openSettings().catch(()=>setError('Could not open Android settings.'))}/>
  </>}
  {!!error&&<Text accessibilityLiveRegion="polite" style={{color:C.ink}}>{error}</Text>}
 </Glass>;
}
