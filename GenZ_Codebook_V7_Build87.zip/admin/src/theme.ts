/** Theme preference store: Light, Dark (Cyber Teal) or Cafe. Applied through
 *  <html data-theme>, so switching never re-renders pages or touches forms,
 *  filters or any other state. The matching pre-paint script is
 *  public/theme-init.js. There is no System option: an unknown stored value
 *  (including the old 'system') falls back to Light. */
import {useSyncExternalStore} from 'react';

export type ThemePref = 'light' | 'dark' | 'cafe';
export type ThemeResolved = 'light' | 'dark' | 'cafe';
export const THEME_KEY = 'genz-admin-theme';
export const THEME_PREFS: readonly ThemePref[] = ['light', 'dark', 'cafe'];
export const THEME_COLORS: Record<ThemePref, string> = {light: '#F8FAFC', dark: '#06363A', cafe: '#FFFBF3'};

export const parsePref = (value: unknown): ThemePref => (value === 'light' || value === 'dark' || value === 'cafe' ? value : 'light');
/** The preference IS the theme: it is applied as-is, never derived from the OS. */
export const resolveTheme = (pref: ThemePref): ThemeResolved => parsePref(pref);

const listeners = new Set<() => void>();
function readStored(): ThemePref {
  try {return parsePref(localStorage.getItem(THEME_KEY));} catch {return 'light';}
}
let pref: ThemePref = readStored();

function apply(): void {
  if (typeof document === 'undefined') return;
  const resolved = resolveTheme(pref);
  const root = document.documentElement;
  root.setAttribute('data-theme', resolved);
  root.setAttribute('data-theme-pref', pref);
  root.style.colorScheme = resolved === 'dark' ? 'dark' : 'light';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', THEME_COLORS[resolved]);
}
function emit(): void {
  apply();
  listeners.forEach(f => {try {f();} catch {/* ignore */}});
}
/** Save and apply a preference. A storage failure (private mode) still applies it for this visit. */
export function setThemePref(next: ThemePref): void {
  pref = parsePref(next);
  try {localStorage.setItem(THEME_KEY, pref);} catch {/* not persisted */}
  emit();
}
if (typeof window !== 'undefined') window.addEventListener('storage', e => {if (e.key === THEME_KEY) {pref = readStored(); emit();}});   // other tabs
apply();

const subscribe = (f: () => void) => {listeners.add(f); return () => {listeners.delete(f);};};
export function useThemePref(): ThemePref {return useSyncExternalStore(subscribe, () => pref, () => 'light');}
