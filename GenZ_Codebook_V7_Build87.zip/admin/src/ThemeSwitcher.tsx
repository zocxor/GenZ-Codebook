import React from 'react';
import {setThemePref, useThemePref, type ThemePref} from './theme';

const icon = {width: 17, height: 17, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.9, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true};
const OPTIONS: {id: ThemePref; label: string; svg: React.ReactNode}[] = [
  {id: 'light', label: 'Light', svg: <svg {...icon}><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></svg>},
  {id: 'dark', label: 'Dark', svg: <svg {...icon}><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" /></svg>},
  {id: 'cafe', label: 'Cafe', svg: <svg {...icon}><path d="M4 10h13v5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5Z" /><path d="M17 11h1.5a2.5 2.5 0 0 1 0 5H17" /><path d="M8 7c0-1.2 1-1.3 1-2.5M12 7c0-1.2 1-1.3 1-2.5" /></svg>},
];
/** Light / Dark / Cafe switch for the top header. Arrow keys move between the options. */
export default function ThemeSwitcher() {
  const pref = useThemePref();
  const onKey = (e: React.KeyboardEvent) => {
    const i = OPTIONS.findIndex(o => o.id === pref);
    const step = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 0;
    if (!step) return;
    e.preventDefault();
    setThemePref(OPTIONS[(i + step + OPTIONS.length) % OPTIONS.length]!.id);
  };
  return <div className="theme-switch" role="radiogroup" aria-label="Colour theme" onKeyDown={onKey}>
    {OPTIONS.map(o => <button key={o.id} type="button" role="radio" aria-checked={pref === o.id} tabIndex={pref === o.id ? 0 : -1}
      className={pref === o.id ? 'on' : ''} title={`${o.label} theme`} onClick={() => setThemePref(o.id)}>{o.svg}<span className="sr-only">{o.label}</span></button>)}
  </div>;
}
