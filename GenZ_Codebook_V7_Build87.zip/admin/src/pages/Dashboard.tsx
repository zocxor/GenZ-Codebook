import manifest from '../../../src/data/manifest.json';
import React from 'react';
import {collection, getDocs, limit, orderBy, query} from 'firebase/firestore/lite';
import {useSession} from '../App';
import {can} from '../rbac';
import {Card, Stat, Stats, Bar, Skeleton, Notice, useLoad, fmt, pct, when, Donut, AreaChart} from '../ui';
import {db, errorMessage} from '../firebase';
import {userMetrics, activityHistogram, retentionMetrics, versionMetrics, contentMetrics, moderationMetrics, securityMetrics, referralMetrics} from '../lib/metrics';

/**
 * Dashboard v6 (premium SaaS redesign): icon-tile KPI cards, a real "users by
 * day last active" area chart and a user-overview donut — every figure still
 * queried live from Firestore. No trends are shown (there is no previous-period
 * data to compute them from) and no figure is estimated or simulated.
 */

/** Inline stroke icons (no dependency, no external assets). */
const svgProps = {width: 22, height: 22, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round'} as const;
const ICON = {
  users: <svg {...svgProps} aria-hidden="true"><circle cx="9" cy="8" r="3.5" /><path d="M3.5 19c.6-3 2.8-4.5 5.5-4.5s4.9 1.5 5.5 4.5" /><circle cx="17" cy="9" r="2.6" /><path d="M16.2 14.6c2.2.3 3.8 1.7 4.3 4" /></svg>,
  activity: <svg {...svgProps} aria-hidden="true"><path d="M3 12h4l3 8 4-16 3 8h4" /></svg>,
  calendar: <svg {...svgProps} aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M8 3v4M16 3v4M3 10h18" /></svg>,
  calendarCheck: <svg {...svgProps} aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M8 3v4M16 3v4M3 10h18" /><path d="m9 16 2 2 4-4" /></svg>,
  userPlus: <svg {...svgProps} aria-hidden="true"><circle cx="10" cy="8" r="3.5" /><path d="M4.5 19c.6-3 2.8-4.5 5.5-4.5 1.5 0 2.8.5 3.8 1.3" /><path d="M18 8v6M15 11h6" /></svg>,
  shieldOff: <svg {...svgProps} aria-hidden="true"><path d="M12 3 5 6v5c0 5 3 8.5 7 10 4-1.5 7-5 7-10V6Z" /><path d="m4 4 16 16" /></svg>,
  shieldCheck: <svg {...svgProps} aria-hidden="true"><path d="M12 3 5 6v5c0 5 3 8.5 7 10 4-1.5 7-5 7-10V6Z" /><path d="m9 12 2 2 4-4" /></svg>,
  quiz: <svg {...svgProps} aria-hidden="true"><circle cx="12" cy="12" r="9" /><path d="M9.5 9.5a2.5 2.5 0 1 1 3.6 2.2c-.8.4-1.1 1-1.1 1.8" /><path d="M12 17h.01" /></svg>,
  bookmark: <svg {...svgProps} aria-hidden="true"><path d="M6 3h12v18l-6-4.5L6 21Z" /></svg>,
  review: <svg {...svgProps} aria-hidden="true"><path d="M21 12a9 9 0 1 1-2.6-6.3" /><path d="M21 3v6h-6" /></svg>,
  layers: <svg {...svgProps} aria-hidden="true"><path d="m12 3 9 5-9 5-9-5Z" /><path d="m3 13 9 5 9-5" /></svg>,
  flame: <svg {...svgProps} aria-hidden="true"><path d="M12 3s5 4.5 5 9.5a5 5 0 0 1-10 0c0-2 1-3.8 2.5-5 .3 1.2 1 2 2 2.5C11.3 8 11.5 5 12 3Z" /></svg>,
};

function Section<T>({title, subtitle, load, render, index}: {title: string; subtitle: string; load: () => Promise<T>; render: (d: T) => React.ReactNode; index: number}) {
  const {data, error, loading, reload} = useLoad(load, []);
  return <Card title={title} subtitle={subtitle} index={index} actions={<button className="btn ghost" onClick={reload} disabled={loading}><span className={loading ? 'spin' : ''} aria-hidden="true">↻</span> Refresh</button>}>
    {loading ? <Skeleton rows={4} /> : error ? <Notice kind="error">{errorMessage(error)}</Notice> : data ? render(data) : null}
  </Card>;
}

type FeedItem = {key: string; icon: React.ReactNode; tint: string; title: string; detail: React.ReactNode; ms: number};

export default function Dashboard() {
  const {role} = useSession();
  const [bundled, setBundled] = React.useState<number | null>(null);
  React.useEffect(() => {Promise.resolve(manifest.uniqueEntries).then(setBundled).catch(() => setBundled(null));}, []);
  /** One live user-metrics load shared by the KPI cards and the
   * user-overview donut, so all three always agree. */
  const users = useLoad(() => userMetrics(), []);
  /** Active-users period: Weekly = last 7 days, Monthly = last 30 days,
   * Yearly = last 365 days — all counted live the same way. */
  const [activePeriod, setActivePeriod] = React.useState<'weekly' | 'monthly' | 'yearly'>('monthly');
  const active = users.data ? activePeriod === 'weekly' ? {num: users.data.wau, hint: 'last 7 days'} : activePeriod === 'yearly' ? {num: users.data.yau, hint: 'last 365 days'} : {num: users.data.mau, hint: 'last 30 days'} : null;
  const showUsers = can(role, 'users.read');
  let i = 0;
  return <div className="stack">
    {showUsers && <Card title="Users" subtitle="Signed-in accounts only." index={i++} actions={<button className="btn ghost" onClick={users.reload} disabled={users.loading}><span className={users.loading ? 'spin' : ''} aria-hidden="true">↻</span> Refresh</button>}>
      {users.loading ? <Skeleton rows={4} /> : users.error ? <Notice kind="error">{errorMessage(users.error)}</Notice> : users.data ? <>
        <div className="dash-first-row">
          <Stat label="Total registered users" num={users.data.total} hint="active + suspended" icon={ICON.users} tint="blue" />
          <Stat label="Total active users" num={active!.num} hint={active!.hint} icon={ICON.activity} tint="green" extra={<div className="seg-tabs" role="tablist" aria-label="Active users period">
            {(['weekly', 'monthly', 'yearly'] as const).map(p => <button key={p} type="button" role="tab" aria-selected={activePeriod === p} className="seg-tab" onClick={() => setActivePeriod(p)}>{p === 'weekly' ? 'Weekly' : p === 'monthly' ? 'Monthly' : 'Yearly'}</button>)}
          </div>} />
          <Card title="User overview" subtitle="Active in the last 30 days, inactive, and suspended accounts." index={i++} actions={<button className="btn ghost" onClick={users.reload} disabled={users.loading}><span className={users.loading ? 'spin' : ''} aria-hidden="true">↻</span> Refresh</button>}>
            <Donut totalLabel="Total users" segments={[
              {label: 'Active in last 30 days', value: users.data.mau, color: 'var(--c-blue)'},
              {label: 'Inactive', value: Math.max(0, (users.data.total - users.data.suspended) - users.data.mau), color: 'var(--c-muted)'},
              {label: 'Suspended', value: users.data.suspended, color: 'var(--c-purple)'},
            ]} />
          </Card>
        </div>
      </> : null}
    </Card>}

    {showUsers && <Section index={i++} title="Referrals" subtitle="Completed referral sign-ups and the Credits they paid. Names come from the user's synced profile when your role can read it; otherwise the public referral code is shown — never an e-mail." load={() => referralMetrics()} render={d => <>
      <Stats className="stats-accent">
        <Stat label="Referred sign-ups" num={d.total} hint="completed referrals" icon={ICON.userPlus} tint="green" />
        <Stat label="Referral Credits paid" num={d.tokensPaid} hint={d.tokensDerived ? '2 × 100 per completed referral (from claims)' : 'sum of referral ledger entries'} icon={ICON.quiz} tint="amber" />
      </Stats>
      {d.top.length ? <div className="table-wrap"><table><thead><tr><th>Top referrer</th><th>Referrals</th></tr></thead><tbody>{d.top.map((t, idx) => <tr key={idx}><td>{t.label}</td><td>{fmt(t.count)}</td></tr>)}</tbody></table></div> : <p className="muted">No referrals yet.</p>}
      {d.capped && <p className="small muted">Top referrers are from the {fmt(d.sample)} most recent claims; the totals above are exact counts.</p>}
    </>} />}

    {showUsers && <Card title="Learning activity" subtitle="Activity figures come from each account’s last sync. Active = last sync time, so users who learn offline appear when they next connect." index={i++} actions={<button className="btn ghost" onClick={users.reload} disabled={users.loading}><span className={users.loading ? 'spin' : ''} aria-hidden="true">↻</span> Refresh</button>}>
      {users.loading ? <Skeleton rows={4} /> : users.error ? <Notice kind="error">{errorMessage(users.error)}</Notice> : users.data ? <>
        <Stats className="stats-compact">
          <Stat label="Quiz rounds completed" num={users.data.quizzes} hint="last 200 each" icon={ICON.quiz} tint="purple" />
          <Stat label="Saved words" num={users.data.saved} hint="sum across users" icon={ICON.bookmark} tint="blue" />
          <Stat label="Words in review" num={users.data.reviewed} icon={ICON.review} tint="amber" />
          <Stat label="Avg. levels played" num={users.data.avgLevels} digits={2} hint="of 4" icon={ICON.layers} tint="green" />
          <Stat label="Avg. current streak" num={users.data.avgStreak} digits={2} hint="days" icon={ICON.flame} tint="pink" />
        </Stats>
        {users.data.totalsError != null && <Notice kind="info">Learning totals are unavailable until the dashboard index finishes building (deployed with the community target). User counts above are current. {errorMessage(users.data.totalsError)}</Notice>}
      </> : null}
    </Card>}

    {showUsers && <Section index={i++} title="Users by day last active (most recent activity)" subtitle="Last 30 days, by most recent activity." load={() => activityHistogram()} render={d => (d.sample === 0 || d.days.every(v => v === 0)) ? <p className="muted">No activity recorded yet.</p> : <>
      <AreaChart points={d.days} labels={d.labels} />
      <p className="small muted">A user active on several days appears once, on their most recent day. From the 2,000 most recently active accounts.</p>
    </>} />}

    {(can(role, 'audit.read') || can(role, 'users.read')) && <Section index={i++} title="Recent activity" subtitle="Latest admin actions and newest sign-ups, straight from Firestore." load={async (): Promise<FeedItem[]> => {
      const items: FeedItem[] = [];
      if (can(role, 'audit.read')) {
        const snap = await getDocs(query(collection(db, 'auditLogs'), orderBy('at', 'desc'), limit(6)));
        snap.docs.forEach(d => {
          const a = d.data() as {action?: string; target?: string; summary?: string; at?: {toMillis?: () => number}};
          items.push({key: `audit-${d.id}`, icon: ICON.shieldCheck, tint: 'blue', title: a.action ?? 'Admin action', detail: a.summary ? `${a.target ?? ''} — ${a.summary}` : (a.target ?? ''), ms: a.at?.toMillis?.() ?? 0});
        });
      }
      if (can(role, 'users.read')) {
        const snap = await getDocs(query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(3)));
        snap.docs.forEach(d => {
          const u = d.data() as {createdAt?: {toMillis?: () => number}};
          items.push({key: `user-${d.id}`, icon: ICON.userPlus, tint: 'green', title: 'New user registered', detail: <code>{d.id.slice(0, 10)}</code>, ms: u.createdAt?.toMillis?.() ?? 0});
        });
      }
      items.sort((a, b) => b.ms - a.ms);
      return items;
    }} render={items => items.length ? <div className="feed">{items.map(it => <div className="feed-row" key={it.key}>
      <span className={`feed-ico tint-${it.tint}`} aria-hidden="true">{it.icon}</span>
      <div style={{minWidth: 0}}><strong>{it.title}</strong><span>{it.detail}</span></div>
      <span className="feed-num">{when(it.ms)}</span>
    </div>)}</div> : <p className="muted">No recent activity yet.</p>} />}

    {can(role, 'users.read') && <Section index={i++} title="Retention" subtitle="Share still active N days after sign-up." load={() => retentionMetrics()} render={d => <>
      <div className="bar-grid">{d.rows.map(r => <Bar key={r.day} label={`Day ${r.day}`} fraction={r.rate ?? 0} display={pct(r.rate)} hint={`${fmt(r.retained)} of ${fmt(r.eligible)} eligible`} />)}</div>
      <p className="small muted">Computed from {fmt(d.sample)} sign-ups (maximum 2,000 most recent). For full cohort analysis export Firestore to BigQuery.</p>
    </>} />}
    {can(role, 'users.read') && <Section index={i++} title="App versions" subtitle="Reported by the 500 most recently active accounts." load={() => versionMetrics()} render={d => d.rows.length ? <div className="table-wrap"><table><thead><tr><th>Version</th><th>Accounts</th><th>Share</th></tr></thead><tbody>{d.rows.map(r => <tr key={r.version}><td>{r.version}</td><td>{fmt(r.count)}</td><td><span className="share-cell"><span className="bar"><span className="bar-fill" style={{display: 'block', width: `${Math.max(0, Math.min(100, (r.count / d.sample) * 100))}%`}} /></span><span>{pct(r.count / d.sample)}</span></span></td></tr>)}</tbody></table></div> : <p className="muted">No active accounts yet.</p>} />}
    {can(role, 'content.read') && <Section index={i++} title="Slang database" subtitle="Bundled entries ship inside the app; CMS entries are working copies managed here." load={() => contentMetrics()} render={d => <Stats>
      <Stat label="Bundled in app" num={bundled} hint="read-only baseline" />
      <Stat label="Live CMS entries" num={d.live} hint="delivered without an app update" />
      <Stat label="Drafts" num={d.draft} />
      <Stat label="In review" num={d.review} />
      <Stat label="Archived" num={d.archived} />
    </Stats>} />}
    {(can(role, 'reports.moderate') || can(role, 'feedback.read')) && <Section index={i++} title="Reports & feedback" subtitle="Submitted by signed-in users from the app." load={() => moderationMetrics()} render={d => <Stats>
      {can(role, 'submissions.review') && <Stat label="Pending suggestions" num={d.pending} />}
      {can(role, 'reports.moderate') && <Stat label="Open content reports" num={d.openReports} />}
      {can(role, 'reports.moderate') && <Stat label="Open chat reports" num={d.openChatReports} />}
      {can(role, 'feedback.read') && <><Stat label="Feedback (new)" num={d.feedbackNew} /><Stat label="Feedback (total)" num={d.feedbackTotal} /><Stat label="Avg. rating" value={d.avgRating === null ? '—' : `${d.avgRating.toFixed(2)} / 5`} /></>}
    </Stats>} />}
    {can(role, 'security.read') && <Section index={i++} title="Security events (7 days)" subtitle="Events reported by signed-in clients and the portal. Server-side rule denials are not logged by Firestore itself." load={() => securityMetrics()} render={d => d.total ? <div className="table-wrap"><table><thead><tr><th>Type</th><th>Count</th></tr></thead><tbody>{d.byType.map(([t, n]) => <tr key={t}><td>{t}</td><td>{fmt(n)}</td></tr>)}</tbody></table></div> : <p className="muted">No security events in the last 7 days.{d.capped ? ' (capped at 1,000)' : ''}</p>} />}
    <p className="small muted">No figure on this page is estimated or simulated — every number is queried live from Firestore when you open or refresh a card.</p>
  </div>;
}
