import React,{useEffect,useState} from 'react';
import {collection,doc,documentId,endAt,getDoc,getDocs,limit,orderBy,query,startAt} from 'firebase/firestore/lite';
import {db,errorMessage} from '../firebase';
import {Card,Notice,Pill} from '../ui';
import policy from '../../../functions/src/communityPolicy.json';
import type {DailyWord} from '../lib/dailyWordPicker';
import {dailyRows,type DailyRow,type DailyTab} from '../lib/dailyRows';

const day=(t=Date.now())=>new Date(t).toISOString().slice(0,10);
const tabs:{id:DailyTab;label:string}[]=[{id:'upcoming',label:'Upcoming'},{id:'pending',label:'Pending'},{id:'approved',label:'Approved & scheduled'},{id:'published',label:'Published'},{id:'rejected',label:'Rejected'},{id:'all',label:'All'}];
const tone=(s:string)=>['published','approved','scheduled'].includes(s)?'good':['rejected','cancelled','missed'].includes(s)?'bad':s==='pending'?'warn':'info';
const cap=(s:string)=>s.charAt(0).toUpperCase()+s.slice(1);

/** "Submitted by" identity cell: avatar initial + name, role and UID as a small second line.
 *  Display only — the same name, role and UID the table showed before. */
const whoParts=(s:string)=>{const [name,role]=s.split(' · ');return {name:name||s,role:role||''};};
function WhoCell({submittedBy,uid}:{submittedBy:string;uid?:string}){
  const {name,role}=whoParts(submittedBy);
  const sub=[role,uid].filter(Boolean).join(' · ');
  return <span className="who-cell"><span className="who-avatar" aria-hidden="true">{(name.trim().charAt(0)||'?').toUpperCase()}</span><span><span className="who-name">{name}</span>{sub&&<span className="who-sub">{sub}</span>}</span></span>;
}

/**
 * Daily Codes Management: one list of every reserved, scheduled, published and
 * rejected Daily Code. Previously admin-scheduled words (for example HDOT) were only
 * visible as a calendar cell; this list shows them with their actions.
 */
export default function DailyCodesList({picked,refresh,onChanged,run}:{picked?:DailyWord;refresh:number;onChanged:()=>void;run:(input:Record<string,unknown>,success:string)=>Promise<boolean>}){
  const [rows,setRows]=useState<DailyRow[]>([]),[tab,setTab]=useState<DailyTab>('upcoming'),[loading,setLoading]=useState(true),[error,setError]=useState('');
  const [editing,setEditing]=useState(''),[term,setTerm]=useState(''),[meaning,setMeaning]=useState(''),[category,setCategory]=useState('');
  const [approveDate,setApproveDate]=useState<Record<string,string>>({});
  const today=day(),firstDate=day(Date.now()+86_400_000),maxDate=day(Date.now()+policy.bookingDays*86_400_000);
  useEffect(()=>{
    let alive=true;setLoading(true);setError('');
    const from=day(Date.now()-30*86_400_000);
    const range=(name:string)=>getDocs(query(collection(db,name),orderBy(documentId()),startAt(from),endAt(maxDate)));
    void (async()=>{
      const [slots,pubs,recent]=await Promise.all([range('dailyCodeDates'),range('dailyCodePublic'),getDocs(query(collection(db,'dailyCodeApplications'),orderBy('createdAt','desc'),limit(200)))]);
      const ids=[...new Set(slots.docs.map(d=>d.get('applicationId')).filter((v):v is string=>typeof v==='string'))];
      const apps=Object.fromEntries((await Promise.all(ids.map(id=>getDoc(doc(db,'dailyCodeApplications',id))))).filter(d=>d.exists()).map(d=>[d.id,d.data()]));
      const closed=recent.docs.filter(d=>['rejected','cancelled'].includes(String(d.get('status')))).slice(0,50).map(d=>({id:d.id,...d.data()}));
      return dailyRows({slots:slots.docs.map(d=>({id:d.id,...d.data()})),published:pubs.docs.map(d=>({id:d.id,...d.data()})),applications:apps,closed,today});
    })().then(r=>{if(alive)setRows(r);},e=>{if(alive)setError(errorMessage(e));}).finally(()=>{if(alive)setLoading(false);});
    return ()=>{alive=false;};
  },[refresh,maxDate]);
  const visible=rows.filter(r=>tab==='all'||r.tabs.includes(tab));
  const startEdit=(r:DailyRow)=>{setEditing(r.date);setTerm(r.code);setMeaning(r.meaning);setCategory(r.category);};
  const act=async(input:Record<string,unknown>,success:string)=>{if(await run(input,success)){setEditing('');onChanged();}};
  return <Card title="Daily Codes" subtitle="Every scheduled, requested and published Daily Code. Dates are UTC. If no approved code exists for a date, an automatic dictionary word is published.">
    <div className="seg-tabs" role="tablist">{tabs.map(t=><button key={t.id} role="tab" aria-selected={tab===t.id} className="seg-tab" onClick={()=>setTab(t.id)}>{t.label} <span className="seg-count">{rows.filter(r=>t.id==='all'||r.tabs.includes(t.id)).length}</span></button>)}</div>
    {error&&<Notice kind="error">{error}</Notice>}
    {loading?<p className="muted">Loading Daily Codes…</p>:!visible.length?<p className="muted">{tab==='upcoming'?'No upcoming Daily Codes. Use the calendar above to schedule one.':'Nothing in this view.'}</p>:
    <div className="table-wrap"><table><thead><tr><th>Date (UTC)</th><th>Code</th><th>Meaning</th><th>Submitted by</th><th>Approval</th><th>Publication</th><th>Actions</th></tr></thead>
    <tbody>{visible.map(r=><React.Fragment key={r.key}><tr>
      <td><strong>{r.date}</strong>{r.date===today&&<div className="muted small">Today</div>}</td>
      <td><strong>{r.code||'—'}</strong>{r.category&&<div className="muted small">{r.category}</div>}{r.edited&&<div className="muted small">Edited</div>}</td>
      <td>{r.meaning||'—'}</td>
      <td><WhoCell submittedBy={r.submittedBy} uid={r.uid}/></td>
      <td><Pill tone={tone(r.approval)}>{cap(r.approval)}</Pill></td>
      <td><Pill tone={tone(r.publication)}>{cap(r.publication)}</Pill></td>
      <td><div className="row wrap">
        {r.canApprove&&(()=>{const d=approveDate[r.key]??(r.date>=firstDate?r.date:'');const why=!d?'Choose a publication date.':d<firstDate||d>maxDate?`Choose a date from ${firstDate} to ${maxDate}.`:'';
          return <><input aria-label={`Publication date for ${r.code}`} type="date" min={firstDate} max={maxDate} value={d} onChange={e=>setApproveDate(v=>({...v,[r.key]:e.target.value}))}/>
            <button className="btn primary" title={why||'Approve and schedule'} disabled={!!why} onClick={()=>void act({action:'daily-admin',command:'approve',id:r.applicationId,date:d},`${r.code} approved and scheduled for ${d}.`)}>✓ Approve</button>{why&&<span className="muted small">{why}</span>}</>;})()}
        {r.canEdit&&<button className="btn" title="Edit code, meaning or category" onClick={()=>startEdit(r)}>✎ Edit</button>}
        {r.canEdit&&<button className="btn" disabled={!picked} title={picked?`Replace with ${picked.term}`:'Pick a word in “Choose a Daily Code” above first'} onClick={()=>{if(picked&&window.confirm(`Replace ${r.code||'this entry'} on ${r.date} with ${picked.term}?${r.applicationId?'\nThe user who requested this date will be refunded in full.':''}`))void act({action:'daily-admin',command:'replace-schedule',date:r.date,wordId:picked.id,wordSource:picked.source},`${r.date} now features ${picked.term}.`);}}>⇄ Replace{picked?` with ${picked.term}`:''}</button>}
        {r.canEdit&&<button className="btn danger" title="Remove this scheduled entry" onClick={()=>{if(window.confirm(`Delete the ${r.date} Daily Code${r.code?` (${r.code})`:''}?${r.applicationId?'\nThe user will be refunded in full.':''}`))void act({action:'daily-admin',command:'cancel-schedule',date:r.date},`${r.date} schedule removed.`);}}>🗑 Delete</button>}
        {r.canManageLive&&<button className="btn" title="Edit today’s running Daily Code" onClick={()=>startEdit(r)}>✎ Edit</button>}
        {r.canManageLive&&<button className="btn" disabled={!picked} title={picked?`Show ${picked.term} today instead`:'Pick a word in “Choose a Daily Code” above first'} onClick={()=>{if(picked&&window.confirm(`Replace today’s Daily Code ${r.code||''} with ${picked.term}?\nIt changes on Home and Codes for everyone straight away.`))void act({action:'daily-admin',command:'edit-live',date:r.date,term:picked.term,meaning:picked.meaning,category:picked.category,replace:true},`Today’s Daily Code is now ${picked.term}.`);}}>⇄ Replace{picked?` with ${picked.term}`:''}</button>}
        {r.canManageLive&&<button className="btn danger" title="Remove today’s running Daily Code" onClick={()=>{if(window.confirm(`Remove today’s Daily Code${r.code?` (${r.code})`:''}?\nIt disappears from Home and Codes for everyone; the app shows its standard word of the day and nothing else is published today.`))void act({action:'daily-admin',command:'remove-live',date:r.date},'Today’s Daily Code was removed.');}}>🗑 Remove</button>}
        {!r.canEdit&&!r.canApprove&&!r.canManageLive&&<span className="muted small">{r.publication==='published'?'Archived':r.publication==='removed'?'Removed by an administrator':'No actions'}</span>}
      </div></td>
    </tr>
    {editing===r.date&&(r.canEdit||r.canManageLive)&&<tr><td colSpan={7}><div className="row wrap">
      <label className="field">Code<input value={term} maxLength={40} onChange={e=>setTerm(e.target.value)}/></label>
      <label className="field grow">Meaning<input value={meaning} maxLength={500} onChange={e=>setMeaning(e.target.value)}/></label>
      <label className="field">Category<input value={category} maxLength={40} onChange={e=>setCategory(e.target.value)}/></label>
      <button className="btn primary" disabled={!term.trim()||!meaning.trim()||!category.trim()} title={!term.trim()||!meaning.trim()||!category.trim()?'Code, meaning and category are required':'Save'} onClick={()=>void act({action:'daily-admin',command:r.canManageLive?'edit-live':'edit-schedule',date:r.date,term:term.trim(),meaning:meaning.trim(),category:category.trim()},r.canManageLive?'Today’s Daily Code was updated for everyone.':`${r.date} updated.`)}>Save changes</button>
      <button className="btn" onClick={()=>setEditing('')}>Cancel</button>
    </div></td></tr>}
    </React.Fragment>)}</tbody></table></div>}
  </Card>;
}
