/* Runs before first paint (external file: the portal CSP forbids inline scripts).
   Applies the saved theme (light / dark / cafe) so there is no flash of the
   wrong theme. An unknown stored value (including the old stored value)
   falls back to light. */
(function () {
  var colors = {light: '#F8FAFC', dark: '#06363A', cafe: '#FFFBF3'};
  try {
    var pref = localStorage.getItem('genz-admin-theme');
    if (pref !== 'light' && pref !== 'dark' && pref !== 'cafe') pref = 'light';
    var root = document.documentElement;
    root.setAttribute('data-theme', pref);
    root.setAttribute('data-theme-pref', pref);
    root.style.colorScheme = pref === 'dark' ? 'dark' : 'light';
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', colors[pref]);
  } catch (e) {
    document.documentElement.setAttribute('data-theme', 'light');
  }
})();
