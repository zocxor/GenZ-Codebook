import {getFirestore,FieldValue} from 'firebase-admin/firestore';
import {getMessaging} from 'firebase-admin/messaging';
import {onDocumentCreated} from 'firebase-functions/v2/firestore';

export const deliverInboxAlert=onDocumentCreated(
 {document:'users/{uid}/messageNotifications/{notice}',region:'us-central1',retry:true},
 async event=>{
  const notice=event.data?.data();
  if(notice?.type!=='message'||Date.now()-Date.parse(event.time)>300000)return;
  const {uid,notice:id}=event.params;
  const db=getFirestore();
  const devices=db.doc(`users/${uid}/alertDevices/registered`);
  const [registration,inbox]=await Promise.all([devices.get(),db.doc(`users/${uid}/inbox/${notice.conversationId}`).get()]);
  const tokens=registration.get('tokens') as string[]|undefined;
  if(!tokens?.length||inbox.get('muted')||inbox.get('deleted')||!(inbox.get('unread')>0))return;
  const result=await getMessaging().sendEachForMulticast({tokens,
   data:{recipient:uid,event:id,kind:notice.kind==='group'?'group':'personal'},
   android:{priority:'high',ttl:300000}});
  const expired=tokens.filter((_,i)=>result.responses[i]?.error?.code==='messaging/registration-token-not-registered');
  if(expired.length)await devices.update({tokens:FieldValue.arrayRemove(...expired)});
  if(result.responses.some(r=>r.error&&['messaging/internal-error','messaging/server-unavailable','messaging/quota-exceeded'].includes(r.error.code)))throw new Error('Temporary message delivery failure');
 });
