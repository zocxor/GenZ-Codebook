const {test,after}=require('node:test'),assert=require('node:assert/strict');
const {initializeApp,deleteApp}=require('firebase-admin/app'),{getFirestore}=require('firebase-admin/firestore');
const {messagingAction}=require('../lib/messaging');
assert.ok(process.env.FIRESTORE_EMULATOR_HOST,'Use emulator or in-memory preload.');
const app=initializeApp({projectId:'demo-genz-feature-core'}),db=getFirestore(app);after(()=>deleteApp(app));
const run=(uid,command,data={},now=Date.now())=>messagingAction(db,{command,...data},{uid,token:{email_verified:true}},now);
const denied=code=>e=>e.code===code;
async function user(uid,name=uid){await db.doc('users/'+uid).set({status:'active'});await db.doc('publicProfiles/'+uid).set({name,avatar:0});return uid;}
async function pair(prefix,legacyPending=false){const a=await user(prefix+'-a'),b=await user(prefix+'-b'),{id}=await run(a,'request',{uid:b});if(legacyPending){await db.doc('conversations/'+id).set({status:'pending'},{merge:true});for(const u of [a,b])await box(u,id).set({status:'pending',lastMessage:''},{merge:true});}return {a,b,id};}
const box=(u,c)=>db.doc(`users/${u}/inbox/${c}`);
test('messaging: authentication, direct messaging with no request step, idempotency, sender integrity and free delivery',async()=>{
 const {a,b,id}=await pair('request');
 await assert.rejects(messagingAction(db,{command:'search'},undefined),denied('unauthenticated'));
 await assert.rejects(messagingAction(db,{command:'search'},{uid:a,token:{email_verified:false}}),denied('permission-denied'));
 // Build 65: starting a chat opens it for both people at once. There is nothing to accept.
 assert.equal((await db.doc('conversations/'+id).get()).get('status'),'active');
 assert.equal((await box(a,id).get()).get('status'),'active');assert.equal((await box(b,id).get()).get('status'),'active');
 assert.ok((await db.doc(`users/${b}/messagingContacts/${a}`).get()).exists);
 assert.equal((await db.collection(`users/${b}/messageNotifications`).get()).size,0,'opening a chat sends no request notice');
 await assert.rejects(run(b,'respond-request',{conversationId:id,accept:true}),denied('permission-denied'));
 const result=await Promise.all([run(a,'send',{conversationId:id,text:'Hello 😊',requestId:'same'}),run(a,'send',{conversationId:id,text:'Hello 😊',requestId:'same'})]);assert.equal(result.filter(r=>r.duplicate).length,1);
 assert.equal((await box(b,id).get()).get('unread'),1);await run(b,'read',{conversationId:id});assert.equal((await box(b,id).get()).get('unread'),0);
 await run(b,'send',{conversationId:id,text:'Welcome',requestId:'reply',replyTo:'same',senderId:a});const m=(await db.doc(`conversations/${id}/messages/reply`).get()).data();assert.equal(m.senderId,b);assert.equal(m.replyTo,'same');assert.equal(m.replyText,undefined);
 assert.equal((await db.collection(`users/${a}/tokenLedger`).get()).size,0);
 await user('outsider');await assert.rejects(run('outsider','roster',{conversationId:id}),denied('permission-denied'));
});
test('messaging: rejection, preferences, mutual block, suspension and restriction are enforced',async()=>{
 const p=await pair('privacy');await db.doc('conversations/'+p.id).set({status:'rejected'},{merge:true});await assert.rejects(run(p.a,'request',{uid:p.b}),denied('permission-denied'));
 const c=await user('private-c');await run(c,'preferences',{requests:'nobody',showPresence:false});await assert.rejects(run(p.a,'request',{uid:c}),denied('permission-denied'));
 const {a,b,id}=await pair('blocks');await run(b,'block',{uid:a});for(const u of [a,b])await assert.rejects(run(u,'send',{conversationId:id,text:'Blocked',requestId:'no'}),denied('permission-denied'));
 await run(b,'block',{uid:a,blocked:false});await run(a,'send',{conversationId:id,text:'Allowed',requestId:'yes'});
 await db.doc('users/'+b).set({status:'suspended'},{merge:true});await assert.rejects(run(a,'send',{conversationId:id,text:'No',requestId:'suspended'}),denied('permission-denied'));
 await db.doc('users/'+b).set({status:'active',messagingRestricted:true},{merge:true});await assert.rejects(run(b,'search',{query:'hello'}),denied('permission-denied'));
});
test('messaging: group invitations, privilege escalation prevention, roles, removals, ownership and closure',async()=>{
 const a=await user('group-owner'),b=await user('group-member'),c=await user('group-third'),{id}=await run(a,'create-group',{name:'Code Crew',description:'Learn together',memberId:await user('legacy-initial'),requestId:'group-1'});
 assert.equal((await run(a,'create-group',{name:'Code Crew',description:'',privacy:'private',requestId:'group-1'})).duplicate,true);
 // Simulate a previously stored invite-only group to cover the legacy invitation flow.
 await db.doc('conversations/'+id).set({privacy:'invite-only'},{merge:true});
 await run(a,'invite',{conversationId:id,uid:b});await assert.rejects(run(b,'send',{conversationId:id,text:'Not yet',requestId:'early'}),denied('permission-denied'));await run(b,'respond-invite',{conversationId:id,accept:true});
 await assert.rejects(run(b,'group-member',{conversationId:id,uid:b,role:'admin'}),denied('permission-denied'));await assert.rejects(run(b,'group-member',{conversationId:id,uid:a,role:'remove'}),denied('permission-denied'));
 await run(a,'group-member',{conversationId:id,uid:b,role:'moderator'});await run(b,'invite',{conversationId:id,uid:c});await run(c,'respond-invite',{conversationId:id,accept:true});
 await run(c,'send',{conversationId:id,text:'Hello',requestId:'group-msg'});await run(b,'remove-message',{conversationId:id,messageId:'group-msg'});assert.equal((await db.doc(`conversations/${id}/messages/group-msg`).get()).get('removed'),true);
 await run(b,'group-member',{conversationId:id,uid:c,role:'remove'});await assert.rejects(run(c,'roster',{conversationId:id}),denied('permission-denied'));
 await assert.rejects(run(a,'group-member',{conversationId:id,uid:a,role:'remove'}),denied('permission-denied'));await run(a,'group-member',{conversationId:id,uid:b,role:'owner'});await run(a,'group-member',{conversationId:id,uid:a,role:'remove'});
 await run(b,'group-update',{conversationId:id,name:'New name',description:'Updated'});assert.equal((await box(b,id).get()).get('name'),'New name');await run(b,'close-group',{conversationId:id});await assert.rejects(run(b,'send',{conversationId:id,text:'Closed',requestId:'closed'}),denied('failed-precondition'));
});
test('messaging: mute and active view suppress notifications; presence is private by default; reactions and hide work',async()=>{
 const {a,b,id}=await pair('options');await run(b,'inbox-settings',{conversationId:id,muted:true,pinned:true,archived:true});const before=(await db.collection(`users/${b}/messageNotifications`).get()).size;
 await run(a,'send',{conversationId:id,text:'Quiet message',requestId:'quiet'});assert.equal((await db.collection(`users/${b}/messageNotifications`).get()).size,before);assert.equal((await box(b,id).get()).get('archived'),false);
 await run(b,'react',{conversationId:id,messageId:'quiet',emoji:'👍'});assert.equal((await db.doc(`conversations/${id}/messages/quiet/reactions/${b}`).get()).get('emoji'),'👍');await run(b,'hide-message',{conversationId:id,messageId:'quiet'});assert.equal((await db.collection(`users/${b}/hiddenMessages`).get()).size,1);
 await run(b,'presence');let roster=await run(a,'roster',{conversationId:id});assert.equal(roster.members.find(m=>m.uid===b).lastSeen,undefined);await run(b,'preferences',{requests:'everyone',showPresence:true});roster=await run(a,'roster',{conversationId:id});assert.equal(roster.members.find(m=>m.uid===b).online,true);
 await run(b,'read',{conversationId:id});await run(b,'inbox-settings',{conversationId:id,muted:false});const count=(await db.collection(`users/${b}/messageNotifications`).get()).size;await run(a,'send',{conversationId:id,text:'Viewing',requestId:'viewed'});assert.equal((await db.collection(`users/${b}/messageNotifications`).get()).size,count);await run(b,'viewing',{conversationId:id});await run(a,'send',{conversationId:id,text:'Notify now',requestId:'notify'});assert.equal((await db.collection(`users/${b}/messageNotifications`).get()).size,count+1);assert.ok((await run(a,'roster',{conversationId:id})).members.find(m=>m.uid===b).readAt>0);await run(b,'inbox-settings',{conversationId:id,deleted:true});assert.equal((await box(b,id).get()).get('deleted'),true);
});
test('messaging: reports expose only reported content, moderation is permission checked and audit logged',async()=>{
 const {a,b,id}=await pair('reports');await run(a,'send',{conversationId:id,text:'Report this sample',requestId:'reported'});await run(b,'report',{conversationId:id,messageId:'reported',reason:'Spam'});assert.equal((await run(b,'report',{conversationId:id,messageId:'reported',reason:'Spam'})).duplicate,true);
 const staff=await user('messaging-mod');await db.doc('admins/'+staff).set({active:true,role:'moderator'});await assert.rejects(run(a,'admin-summary'),denied('permission-denied'));
 const summary=await run(staff,'admin-summary'),r=summary.reports.find(r=>r.conversationId===id);assert.ok(r);assert.equal(r.text,'Report this sample');assert.equal(summary.conversations,undefined);
 await run(staff,'admin-report',{target:r.id,remove:true});assert.equal((await db.doc(`conversations/${id}/messages/reported`).get()).get('removed'),true);assert.ok((await db.collection('auditLogs').where('actor','==',staff).get()).size>=1);
 await run(staff,'admin-restrict',{target:a,restricted:true});await assert.rejects(run(a,'search',{query:'hello'}),denied('permission-denied'));
});
// Build 63: Google Play UGC policy requires reporting users, not only content.
test('messaging: members can report a user (even after blocking); staff can dismiss or restrict; queue is staff-only',async()=>{
 const reporter=await user('ru-reporter'),target=await user('ru-target','Spam Bot');
 await db.doc('publicProfiles/'+target).set({bio:'Buy followers here',location:'Somewhere'},{merge:true});
 await assert.rejects(run(reporter,'report-user',{uid:reporter,reason:'Spam or scam'}),denied('invalid-argument'));
 await assert.rejects(run(reporter,'report-user',{uid:'ru-nobody',reason:'Spam or scam'}),denied('not-found'));
 await assert.rejects(run(reporter,'report-user',{uid:target,reason:''}),denied('invalid-argument'));
 await run(reporter,'block',{uid:target});
 assert.deepEqual(await run(reporter,'report-user',{uid:target,reason:'Spam or scam',note:'Sends links'}),{ok:true});
 assert.equal((await run(reporter,'report-user',{uid:target,reason:'Spam or scam'})).duplicate,true);
 const restricted=await user('ru-restricted');await db.doc('users/'+restricted).set({messagingRestricted:true},{merge:true});
 assert.deepEqual(await run(restricted,'report-user',{uid:target,reason:'Harassment or bullying'}),{ok:true});
 await assert.rejects(run(reporter,'admin-summary'),denied('permission-denied'));
 const staff=await user('ru-mod');await db.doc('admins/'+staff).set({active:true,role:'moderator'});
 const mine=(await run(staff,'admin-summary')).reports.filter(r=>r.kind==='user'&&r.reportedUid===target);
 assert.equal(mine.length,2);
 const first=mine.find(r=>r.reporterId===reporter);
 assert.equal(first.senderName,'Spam Bot');assert.equal(first.text,'Buy followers here · Somewhere');assert.equal(first.note,'Sends links');assert.equal(first.status,'pending');
 await run(staff,'admin-report',{target:first.id,restrict:true});
 assert.equal((await db.doc('users/'+target).get()).get('messagingRestricted'),true);
 assert.equal((await db.doc('messagingReports/'+first.id).get()).get('status'),'actioned');
 assert.equal((await run(staff,'admin-report',{target:first.id,restrict:true})).duplicate,true);
 const second=mine.find(r=>r.reporterId===restricted);
 await run(staff,'admin-report',{target:second.id,remove:false});
 assert.equal((await db.doc('messagingReports/'+second.id).get()).get('status'),'dismissed');
 assert.ok((await db.collection('auditLogs').where('actor','==',staff).get()).size>=3);
});
test('messaging: bounded user-code search and server-side send rate limit',async()=>{
 const {a,b,id}=await pair('rates');await db.doc('referrals/GZTEST01').set({uid:b});const found=await run(a,'search',{query:'GZTEST01'});assert.equal(found.users[0].uid,b);assert.equal(found.users[0].email,undefined);const now=Date.now();
 for(let i=0;i<30;i++)await run(a,'send',{conversationId:id,text:'Test '+i,requestId:'rate-'+i},now);await assert.rejects(run(a,'send',{conversationId:id,text:'Over limit',requestId:'limit'},now),denied('resource-exhausted'));
});
test('messaging: account deletion revokes membership and closes owner groups without transferring ownership',async()=>{
 const {purgeMessagingUser}=require('../lib/messaging'),a=await user('deleted-owner'),b=await user('retained-member');
 const {id}=await run(a,'create-group',{name:'Deletion test',description:'',memberId:b,requestId:'delete-group'});await run(a,'send',{conversationId:id,text:'Retained history',requestId:'retained'});
 await db.doc('users/'+a).set({status:'deleted'},{merge:true});await purgeMessagingUser(db,a);
 const c=(await db.doc('conversations/'+id).get()).data();assert.equal(c.status,'closed');assert.equal(c.ownerId,a);assert.deepEqual(c.members,[b]);assert.equal((await box(b,id).get()).get('status'),'closed');assert.equal((await db.doc(`conversations/${id}/messages/retained`).get()).get('text'),'Retained history');
 await assert.rejects(run(a,'search',{query:'hello'}),denied('permission-denied'));
});

test('public profiles expose verified Premium and transactional follow counts without private account fields',async()=>{
 const a=await user('social-a'),b=await user('social-b','Golden Reader');
 const now=Date.UTC(2026,10,18),end=now+3600000;
 await db.doc('users/'+b).set({email:'private@example.com'},{merge:true});
 await db.doc('publicProfiles/'+b).set({nameLower:'golden reader',premiumUntil:end+5000},{merge:true});
 assert.equal((await run(a,'search',{query:'GOLDEN R'})).users[0].uid,b);
 assert.equal((await run(a,'profile',{uid:b},now)).person.premiumUntil,0);
 await db.doc(`users/${b}/subscription/current`).set({state:'SUBSCRIPTION_STATE_CANCELED',expiryTime:new Date(end).toISOString(),purchaseToken:'private'});
 await Promise.all([run(a,'follow',{uid:b,following:true},now),run(a,'follow',{uid:b,following:true},now)]);
 const {person}=await run(a,'profile',{uid:b},now);
 assert.deepEqual(person,{uid:b,name:'Golden Reader',avatar:0,premiumUntil:end,postLikes:0,followers:1,followingCount:0,following:true,chatStatus:null,conversationId:null,requestedByMe:false});
 assert.equal((await run(a,'profile',{uid:b},end)).person.premiumUntil,0);
 assert.equal((await run(a,'profile',{uid:a},now)).person.followingCount,1);
 await assert.rejects(run(a,'follow',{uid:a,following:true},now),denied('invalid-argument'));
 await run(a,'follow',{uid:b,following:false},now);
 await run(a,'follow',{uid:b,following:false},now);
 assert.equal((await run(a,'profile',{uid:b},now)).person.followers,0);
 await run(a,'follow',{uid:b,following:true},now);
 await run(b,'block',{uid:a,blocked:true},now);
 await assert.rejects(run(a,'profile',{uid:b},now),denied('permission-denied'));
 assert.equal((await run(b,'profile',{uid:b},now)).person.followers,0);
 await run(b,'block',{uid:a,blocked:false},now);
 await run(a,'follow',{uid:b,following:true},now);
 await db.doc('users/'+a).set({status:'deleted'},{merge:true});
 await require('../lib/messaging').purgeMessagingUser(db,a);
 assert.equal((await run(b,'profile',{uid:b},now)).person.followers,0);
});

test('a profile chat opens directly and retains the actual message preview',async()=>{
 const {a,b,id}=await pair('profile-chat');
 assert.equal((await box(b,id).get()).get('lastMessage'),'');
 const person=(await run(b,'profile',{uid:a})).person;
 assert.equal(person.chatStatus,'active');
 assert.equal(person.requestedByMe,false);
 await run(a,'send',{conversationId:id,text:'First real message',requestId:'first-real'});
 await run(b,'inbox-settings',{conversationId:id,archived:true});
 assert.deepEqual(await run(b,'request',{uid:a}),{id,status:'active',duplicate:true});
 assert.equal((await box(b,id).get()).get('archived'),false);
 assert.equal((await box(b,id).get()).get('lastMessage'),'First real message');
});

// Build 65: conversations created by earlier builds as "requests" simply open; nobody has to accept anything.
test('messaging: a request left over from an earlier build opens by itself',async()=>{
 const first=await pair('legacy',true);
 assert.equal((await db.doc('conversations/'+first.id).get()).get('status'),'pending');
 await run(first.a,'send',{conversationId:first.id,text:'Hello again',requestId:'legacy-1'});
 assert.equal((await db.doc('conversations/'+first.id).get()).get('status'),'active');
 for(const u of [first.a,first.b])assert.equal((await box(u,first.id).get()).get('status'),'active');
 assert.equal((await box(first.b,first.id).get()).get('unread'),1);
 const second=await pair('legacy2',true);
 assert.deepEqual(await run(second.b,'request',{uid:second.a}),{id:second.id,status:'active',duplicate:true});
 for(const u of [second.a,second.b])assert.equal((await box(u,second.id).get()).get('status'),'active');
 const third=await pair('legacy3',true);                       // older app builds can still answer a pending request
 await run(third.b,'respond-request',{conversationId:third.id,accept:true});
 assert.equal((await db.doc('conversations/'+third.id).get()).get('status'),'active');
 await run(third.a,'send',{conversationId:third.id,text:'Works',requestId:'legacy-3'});
});

test('chat attachments work in personal chats only, enforce quota, and expire',async()=>{
 const {a,b,id}=await pair('photo');
 const outsider=await user('photo-outsider');
 // Minimal test JPEG with a 1x1 frame header. The fake storage never decodes pixels.
 const image=Buffer.from('ffd8ffc0000b080001000101011100ffd9','hex').toString('base64');
 const calls=[],saved=new Map();
 const file={name:'Notes.txt',data:Buffer.from('One short note.').toString('base64')};
 const start=Date.UTC(2026,10,18,12);
 const ttl=29*86400000;
 const photos={
  save:async(_db,cid,uid,mid,bytes,now,type)=>{calls.push(['save',cid,uid,mid]);saved.set(mid,bytes.toString('base64'));if(mid==='first-file')assert.equal(type,'text/plain');return now+ttl;},
  read:async(cid,uid,mid)=>{calls.push(['read',cid,uid,mid]);return saved.get(mid);},
 };
 const send=(actor,command,data={},now=start)=>messagingAction(db,{command,conversationId:id,...data},{uid:actor,token:{email_verified:true}},now,photos);
 const group=await run(a,'create-group',{name:'Pictures group',memberId:b,requestId:'photos-group'});
 await assert.rejects(send(a,'send',{conversationId:group.id,image,requestId:'group-photo'}),denied('failed-precondition'));
 await assert.rejects(send(a,'send',{image:'abc',requestId:'invalid-photo'}),denied('invalid-argument'));
 const wide=Buffer.from('ffd8ffc0000b080001100001011100ffd9','hex').toString('base64');
 await assert.rejects(send(a,'send',{image:wide,requestId:'wide-photo'}),denied('invalid-argument'));
 await send(a,'send',{image,requestId:'first-photo'});
 const stored=(await db.doc(`conversations/${id}/messages/first-photo`).get()).data();
 assert.equal(stored.attachmentExpiresAt,start+ttl);
 assert.equal(stored.text,'Photo');
 assert.equal(stored.image,undefined);
 assert.equal((await box(b,id).get()).get('lastMessage'),'Photo');
 assert.equal((await send(a,'send',{image,requestId:'first-photo'})).duplicate,true);
 assert.deepEqual(await send(b,'attachment',{messageId:'first-photo'}),{data:image,fileName:null});
 await assert.rejects(send(outsider,'attachment',{messageId:'first-photo'}),denied('permission-denied'));
 const moderator=await user('photo-moderator');
 await db.doc('admins/'+moderator).set({active:true,role:'moderator'});
 await send(b,'report',{messageId:'first-photo',reason:'Harassment'});
 const report=(await run(moderator,'admin-summary')).reports.find(r=>r.messageId==='first-photo');
 assert.equal(report.attachment,true);
 await assert.rejects(send(outsider,'admin-attachment',{target:report.id}),denied('permission-denied'));
 assert.deepEqual(await send(moderator,'admin-attachment',{target:report.id}),{data:image,fileName:null});
 await run(moderator,'admin-report',{target:report.id,remove:false});
 await assert.rejects(send(moderator,'admin-attachment',{target:report.id}),denied('not-found'));
 await assert.rejects(send(b,'attachment',{messageId:'first-photo'},start+ttl),denied('not-found'));
 await send(b,'hide-message',{messageId:'first-photo'});
 await assert.rejects(send(b,'attachment',{messageId:'first-photo'}),denied('not-found'));
 await run(b,'block',{uid:a,blocked:true});
 await assert.rejects(send(b,'attachment',{messageId:'first-photo'}),denied('permission-denied'));
 await run(b,'block',{uid:a,blocked:false});
 await assert.rejects(send(a,'send',{image,file,requestId:'two-attachments'}),denied('invalid-argument'));
 await assert.rejects(send(a,'send',{file:{...file,name:'Notes.exe'},requestId:'bad-file'}),denied('invalid-argument'));
 await assert.rejects(send(a,'send',{file:{...file,name:'Notes.pdf'},requestId:'wrong-format'}),denied('invalid-argument'));
 await assert.rejects(send(a,'send',{file:{name:'big.txt',data:Buffer.alloc(1000000,65).toString('base64')},requestId:'big-file'}),denied('invalid-argument'));
 await send(a,'send',{file,requestId:'first-file'});
 assert.deepEqual(await send(b,'attachment',{messageId:'first-file'}),{data:file.data,fileName:file.name});
 await assert.rejects(send(b,'attachment',{messageId:'first-file'},start+ttl),denied('not-found'));
 for(let n=3;n<=10;n++)await send(a,'send',{image,text:'Caption',requestId:'photo-'+n});
 await assert.rejects(send(a,'send',{image,requestId:'over-limit'}),denied('resource-exhausted'));
 assert.equal(calls.filter(call=>call[0]==='save').length,10);
 await send(a,'send',{image,requestId:'new-day'},start+12*3600000);
});

test('connection lists show the correct direction and omit blocked users',async()=>{
 const a=await user('connection-a'),b=await user('connection-b'),c=await user('connection-c');
 await run(a,'follow',{uid:b,following:true});
 await run(c,'follow',{uid:b,following:true});
 assert.deepEqual((await run(a,'connections',{uid:a,list:'following'})).users.map(p=>p.uid),[b]);
 assert.deepEqual((await run(b,'connections',{uid:b,list:'followers'})).users.map(p=>p.uid).sort(),[a,c]);
 await run(a,'block',{uid:c,blocked:true});
 assert.deepEqual((await run(a,'connections',{uid:b,list:'followers'})).users.map(p=>p.uid),[a]);
 await assert.rejects(run(a,'connections',{uid:c,list:'followers'}),denied('permission-denied'));
});

test('profile likes sum visible approved posts only',async()=>{
 const a=await user('likes-reader'),b=await user('likes-author');
 for(const [key,patch] of Object.entries({first:{likeCount:4},second:{likeCount:3},hidden:{hidden:true},pending:{status:'pending'},other:{uid:a}})){
  await db.doc('communityPosts/likes-'+key).set({uid:b,status:'approved',hidden:false,likeCount:99,...patch});
 }
 assert.equal((await run(a,'profile',{uid:b})).person.postLikes,7);
});

// Build 65: a failed photo upload says why (and logs it) instead of looking like a lost connection.
test('chat attachments: a missing Storage bucket gives a clear message, logs the cause and keeps the retry record',async()=>{
 const storage=require('firebase-admin/storage'),{logger}=require('firebase-functions/v2'),{chatAttachments}=require('../lib/chatAttachments');
 const realGet=storage.getStorage,realError=logger.error,logged=[];
 const failWith=code=>{storage.getStorage=()=>({bucket:()=>({name:'test-bucket',file:()=>({save:async()=>{const e=new Error('The specified bucket does not exist.');e.code=code;throw e;}})})});};
 logger.error=(...args)=>logged.push(args);
 try{
  const bytes=Buffer.from('ffd8ffc0000b080001000101011100ffd9','hex'),now=Date.UTC(2026,10,19,12);
  failWith(404);
  await assert.rejects(chatAttachments.save(db,'dm-x','user-x','message-1',bytes,now),e=>e.code==='unavailable'&&/not available yet.*text messages/i.test(e.message));
  assert.equal(logged.length,1);assert.equal(logged[0][1].code,404);assert.equal(logged[0][1].bucket,'test-bucket');
  const jobs=db.collection('chatAttachmentExpiry');
  assert.equal((await jobs.get()).size,1,'keep the expiry record for retries');
  storage.getStorage=()=>({bucket:()=>({name:'test-bucket',file:()=>({save:async()=>undefined})})});
  const expiry=await chatAttachments.save(db,'dm-x','user-x','message-1',bytes,now+60_000);
  assert.equal(expiry,now+29*86400000,'successful retry uses the original expiry');
  assert.equal((await jobs.get()).size,1);
  failWith(500);
  await assert.rejects(chatAttachments.save(db,'dm-x','user-x','message-2',bytes,now),e=>e.code==='unavailable'&&/Attachment upload could not complete/.test(e.message));
 }finally{storage.getStorage=realGet;logger.error=realError;}
});

test('messaging: extended emoji reactions replace and clear one reaction per user', async () => {
 const {a,b,id}=await pair('extended-reaction');
 await run(a,'send',{conversationId:id,text:'Hello',requestId:'emoji-target'});
 const target={conversationId:id,messageId:'emoji-target'};
 const ref=db.doc(`conversations/${id}/messages/emoji-target/reactions/${b}`);
 await run(b,'react',{...target,emoji:'🫶'});
 assert.equal((await ref.get()).get('emoji'),'🫶');
 await run(b,'react',{...target,emoji:'👍🏽'});
 assert.equal((await ref.get()).get('emoji'),'👍🏽');
 await assert.rejects(run(b,'react',{...target,emoji:'arbitrary text'}),denied('invalid-argument'));
 await run(b,'react',{...target,emoji:''});
 assert.equal((await ref.get()).exists,false);
});

test('open groups require two people, respect privacy, and support member additions and self-join',async()=>{
 const a=await user('open-owner'),b=await user('open-first'),c=await user('open-next'),d=await user('open-join');
 const form={name:'Open group',requestId:'open-create'};
 await assert.rejects(run(a,'create-group',form),denied('invalid-argument'));
 await assert.rejects(run(a,'create-group',{...form,memberId:a}),denied('invalid-argument'));
 await run(b,'preferences',{requests:'nobody',showPresence:false});
 await assert.rejects(run(a,'create-group',{...form,memberId:b}),denied('permission-denied'));
 await run(b,'preferences',{requests:'everyone',showPresence:false});
 const {id}=await run(a,'create-group',{...form,memberId:b});
 assert.equal((await box(b,id).get()).get('memberCount'),2);
 assert.equal((await run(a,'create-group',{...form,memberId:b})).duplicate,true);
 const group={conversationId:id};
 await assert.rejects(run(d,'add-member',{...group,uid:c}),denied('permission-denied'));
 await run(b,'add-member',{...group,uid:c});
 await run(c,'block',{uid:d,blocked:true});
 await assert.rejects(run(d,'join-group',group),denied('permission-denied'));
 await run(c,'block',{uid:d,blocked:false});
 await run(d,'join-group',group);assert.equal((await run(d,'join-group',group)).duplicate,true);
 assert.equal((await box(a,id).get()).get('memberCount'),4);
 await run(a,'group-member',{...group,uid:d,role:'remove'});
 await assert.rejects(run(d,'join-group',group),denied('permission-denied'));
 await run(a,'close-group',group);
 await assert.rejects(run(b,'add-member',{...group,uid:d}),denied('failed-precondition'));
});
test('Android alert registration is per account, idempotent and removable',async()=>{
 const a=await user('alerts-a'),b=await user('alerts-b'),token='example-registration-token:device';
 const ref=uid=>db.doc(`users/${uid}/alertDevices/registered`);
 await run(a,'alert-device',{token,enabled:true,uid:b});
 await run(a,'alert-device',{token,enabled:true});
 assert.deepEqual((await ref(a).get()).get('tokens'),[token]);
 assert.equal((await ref(b).get()).exists,false);
 await assert.rejects(run(a,'alert-device',{token:'',enabled:true}),denied('invalid-argument'));
 await run(a,'alert-device',{token,enabled:false});
 assert.deepEqual((await ref(a).get()).get('tokens'),[]);
});
