import React from 'react';
import {StyleSheet, View} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';

export function ShieldBackground({attention=false}:{attention?:boolean}) {
  return <LinearGradient accessible={false} pointerEvents="none"
    colors={attention ? ['#FFF8E7','#FFFFFF','#F1ECFF'] : ['#EAF1FF','#FFFFFF','#EFE9FF']}
    start={{x:0,y:0}} end={{x:1,y:1}} style={StyleSheet.absoluteFill}>
    <View style={styles.violet}/><View style={styles.aqua}/>
  </LinearGradient>;
}
const styles=StyleSheet.create({
  violet:{position:'absolute',width:180,height:180,borderRadius:90,backgroundColor:'rgba(99,102,241,.10)',top:-60,right:-50},
  aqua:{position:'absolute',width:150,height:150,borderRadius:75,backgroundColor:'rgba(6,182,212,.10)',bottom:-50,left:-40},
});
