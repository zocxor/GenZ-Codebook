import {ShieldBackground} from './ShieldBackground';
/**
 * Threat Shield — privacy & security centre. Replaces the former "Privacy & safety" sheet.
 * Shows only real, defined checks (see shield/status.ts) and real controls.
 * Threat Shield is a set of app protections; it is not antivirus or a firewall.
 */
import React, {useEffect, useRef, useState} from 'react';
import {View, Text, Pressable, Switch, StyleSheet, Platform, Animated, Easing} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Button, FadeIn, Icon, IconName, IconTile, SectionHeader, confirmAction} from './ui';
import {shieldChecks, shieldZones, ShieldCheck, ShieldZone, ago} from './shield/status';
import {useReducedMotion} from './motion';
import {useLearningState, useStorageHealth, useSyncStatus, useAccountUser, useSecurityEvents, repository, getCloud} from './services';
import {setSearchHistory, clearBrowsingHistory, resetScores, resetReviewProgress, removeAllSaved, Action} from './learning';
import {unavailableSavedCount} from './profile';
import {PRIVACY_POLICY_URL} from './secure/config';
import {COMPANY, SUPPORT_EMAIL} from '../shared/brand';

const eventLabels: Record<string, string> = {login_failed: 'Failed sign-in attempt', login_throttled: 'Sign-in paused after repeated failures', login_succeeded_after_failures: 'Signed in after failed attempts', session_expired: 'Session ended by the server', reauth_failed: 'Identity check failed', sync_permission_denied: 'Server refused a sync request', sync_blocked_account_status: 'Sync paused by account status', storage_quarantine: 'Damaged data set aside', content_validation_rejected: 'Invalid content update ignored', account_deleted: 'Account deleted', account_deletion_started: 'Account deletion started', admin_access_denied: 'Admin access denied'};
const zoneIcon: Record<ShieldZone['id'], {icon: IconName; from: string; to: string}> = {
  account: {icon: 'person-circle', from: '#3B82F6', to: '#6366F1'},
  device: {icon: 'phone-portrait', from: '#06B6D4', to: '#3B82F6'},
  backup: {icon: 'cloud-done', from: '#8B5CF6', to: '#EC4899'},
  privacy: {icon: 'lock-closed', from: '#10B981', to: '#0EA5E9'},
};
const pill: Record<ShieldZone['status'], {bg: string; fg: string; icon: IconName}> = {
  protected: {bg: '#DCFCE7', fg: '#166534', icon: 'checkmark-circle'},
  attention: {bg: '#FEF3C7', fg: '#92400E', icon: 'alert-circle'},
  off: {bg: '#E0E7FF', fg: '#3730A3', icon: 'remove-circle'},
};

/** Big shield with a soft pulse (still when "reduce motion" is on). */
function ShieldEmblem({ok}: {ok: boolean}) {
  const reduced = useReducedMotion();
  const pulse = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (reduced) return;
    const loop = Animated.loop(Animated.timing(pulse, {toValue: 1, duration: 2400, easing: Easing.out(Easing.quad), useNativeDriver: true}));
    loop.start();
    return () => loop.stop();
  }, [reduced, pulse]);
  const ring = (delay: number) => ({opacity: pulse.interpolate({inputRange: [0, 1], outputRange: [.45 - delay, 0]}), transform: [{scale: pulse.interpolate({inputRange: [0, 1], outputRange: [1, 1.55 + delay]})}]});
  const colors = ok ? ['#4F7CFF', '#7C5CFF'] as const : ['#F5B82E', '#E8960C'] as const;
  return <View style={s.emblem}>
    {!reduced && <><Animated.View style={[s.ring, {borderColor: colors[0]}, ring(0)]} /><Animated.View style={[s.ring, {borderColor: colors[1]}, ring(.15)]} /></>}
    <LinearGradient colors={colors} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.emblemCore}>
      <View style={s.emblemShine} />
      <Icon name={ok ? 'shield-checkmark' : 'shield-half'} size={44} color="#fff" />
    </LinearGradient>
  </View>;
}

export default function ThreatShieldScreen({onOpenAccount, onExport, onDeleteLocal, onClearMessage, deleting}: {onOpenAccount: () => void; onExport: () => void; onDeleteLocal: () => void; onClearMessage: () => void; deleting: boolean}) {
  const state = useLearningState(), health = useStorageHealth(), sync = useSyncStatus(), user = useAccountUser(), events = useSecurityEvents();
  const [secure, setSecure] = useState<boolean | null>(null);
  const [notice, setNotice] = useState('');
  useEffect(() => {
    if (Platform.OS === 'web') {setSecure(false); return;}
    import('expo-secure-store').then(m => m.isAvailableAsync()).then(setSecure).catch(() => setSecure(false));
  }, []);
  const checks = shieldChecks({health, volatile: repository.isVolatile, state, sync, signedIn: !!user, emailVerified: !!user?.emailVerified, secureSessionStorage: secure, events, now: Date.now()});
  const zones = shieldZones(checks);
  const needs = zones.filter(z => z.status === 'attention');
  const [showStore, setShowStore] = useState(false), [showActivity, setShowActivity] = useState(false);
  const act = (a: Action, done: string) => repository.mutate(a).then(() => setNotice(done)).catch(() => setNotice('That change could not be saved. Please try again.'));
  const confirm = confirmAction;
  const runAction = (action: ShieldCheck['action']) => {
    if (action === 'retry-storage') void repository.load();
    else if (action === 'sync-now') void getCloud()?.engine.syncNow();
    else onOpenAccount();
  };
  const actionLabel = (a: ShieldCheck['action']) => a === 'retry-storage' ? 'Try again' : a === 'sync-now' ? 'Sync now' : a === 'sign-in' ? 'Sign in' : 'Open account';
  const orphans = unavailableSavedCount(state);

  return <>
    <FadeIn>
      <View style={s.hero}>
        <ShieldBackground attention={!!needs.length}/>
        <Text style={s.heroEyebrow}>THREAT SHIELD</Text>
        <ShieldEmblem ok={!needs.length} />
        <Text accessibilityRole="header" style={s.heroTitle}>{needs.length ? 'Needs your attention' : 'You’re protected'}</Text>
        <Text style={s.heroBody}>{needs.length ? `${needs.length === 1 ? 'One area needs' : `${needs.length} areas need`} a quick fix below.` : 'All protections are running quietly in the background.'}</Text>
        <View style={s.heroBar}>{zones.map(z => <View key={z.id} style={[s.heroSeg, {backgroundColor: z.status === 'attention' ? '#F59E0B' : z.status === 'off' ? '#A5B4FC' : '#22C55E'}]} />)}</View>
      </View>
    </FadeIn>
    {!!notice && <Pressable accessibilityRole="button" onPress={() => setNotice('')} style={s.notice}><Icon name="checkmark-circle-outline" size={18} color="#175e47" /><Text accessibilityLiveRegion="polite" style={s.noticeText}>{notice}</Text></Pressable>}

    <FadeIn delay={60}>
      <View style={s.zones}>
        {zones.map(z => {const zi = zoneIcon[z.id], p = pill[z.status]; return <View key={z.id} accessible accessibilityLabel={`${z.title}: ${z.label}`} style={[s.zone, z.status === 'attention' && s.zoneAlert]}>
          <LinearGradient colors={[zi.from, zi.to]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.zoneIcon}><View style={s.zoneShine} /><Icon name={zi.icon} size={22} color="#fff" /></LinearGradient>
          <Text style={s.zoneTitle}>{z.title}</Text>
          <View style={[s.pill, {backgroundColor: p.bg}]}><Icon name={p.icon} size={13} color={p.fg} /><Text style={[s.pillText, {color: p.fg}]}>{z.label}</Text></View>
          {z.status !== 'protected' && !!z.tip && <Text style={[s.zoneTip, z.status === 'off' && {color: C.muted}]}>{z.tip}</Text>}
          {z.status !== 'protected' && !!z.action && <Pressable accessibilityRole="button" onPress={() => runAction(z.action)} style={s.inlineAction}><Text style={s.link}>{actionLabel(z.action)}</Text></Pressable>}
        </View>;})}
      </View>
      <Text style={[s.fine, {textAlign: 'center', marginTop: 6}]}>For your safety, the individual protections aren’t listed.</Text>
    </FadeIn>

    <FadeIn delay={120}>
      <SectionHeader eyebrow="PRIVACY" title="Privacy settings" />
      <View style={s.card}>
        <View style={s.toggleRow}>
          <IconTile icon="search-outline" from={C.accent} to="#2E9BFF" size={36} iconSize={18} />
          <View style={{flex: 1, gap: 3}}><Text style={s.checkTitle}>Remember my searches</Text><Text style={s.caption}>Kept only on this device (last 20).</Text></View>
          <Switch accessibilityLabel="Remember my searches" value={state.device.searchHistory} onValueChange={v => void act(setSearchHistory(v), v ? 'Search history is on for this device.' : 'Search history turned off and cleared.')} />
        </View>
        <Button light title={`Clear browsing history (${state.recent.length + state.searches.length})`} icon="time-outline" disabled={!state.recent.length && !state.searches.length} onPress={() => void act(clearBrowsingHistory, 'Recently viewed words and searches were cleared.')} />
        <Button light title="Clear my current message" icon="chatbox-outline" onPress={onClearMessage} />
      </View>
    </FadeIn>

    <FadeIn delay={160}>
      <SectionHeader eyebrow="YOUR DATA" title="Export, reset & delete" />
      <View style={s.card}>
        <Button light title="Export my learning data" icon="download-outline" onPress={onExport} />
        <Button light title="Remove all saved words" icon="bookmark-outline" disabled={!Object.values(state.saved).some(r => !r.d)} onPress={() => confirm('Remove all saved words?', user ? 'They will also be removed from your other signed-in devices.' : 'This removes every saved word on this device.', () => void act(removeAllSaved, 'All saved words were removed.'))} />
        <Button light title="Reset quiz scores & streak" icon="trophy-outline" onPress={() => confirm('Reset scores and streak?', 'Best scores, round history and streak days are reset' + (user ? ' on all your signed-in devices.' : '.'), () => void act(resetScores, 'Scores, round history and streak were reset.'))} />
        <Button light title="Reset word review progress" icon="repeat-outline" onPress={() => confirm('Reset review progress?', 'Spaced-repetition schedules and mastery are cleared' + (user ? ' on all your signed-in devices.' : '.'), () => void act(resetReviewProgress, 'Word review progress was reset.'))} />
        <Button light disabled={deleting} title={deleting ? 'Deleting…' : 'Delete all data on this device'} icon="trash-bin-outline" onPress={() => confirm('Delete data on this device?', user ? 'This removes your nickname, saved words and progress from this device. Your cloud copy stays in your account and returns next time you sync. To delete it, delete your account.' : 'This removes your nickname, saved words and learning progress from this device. It cannot be undone.', onDeleteLocal)} />
        <Button light title={user ? 'Account & account deletion' : 'Sign in or create an account'} icon="person-circle-outline" onPress={onOpenAccount} />
        {orphans > 0 && <Text style={s.caption}>{orphans} saved {orphans === 1 ? 'entry refers' : 'entries refer'} to words not in this version of the dictionary. They are kept safely and reappear if the words return.</Text>}
      </View>
    </FadeIn>

    <Pressable accessibilityRole="button" accessibilityState={{expanded: showStore}} onPress={() => setShowStore(v => !v)} style={s.fold}>
      <IconTile icon="server-outline" from={C.accent} to={C.purple} size={36} iconSize={18} />
      <View style={{flex: 1}}><Text style={s.checkTitle}>What we store, and where</Text><Text style={s.caption}>Your data, in plain words</Text></View>
      <Icon name={showStore ? 'chevron-up' : 'chevron-down'} size={18} color={C.muted} />
    </Pressable>
    {showStore && [
      {icon: 'phone-portrait-outline' as IconName, title: 'On this device', body: 'Nickname, avatar, saved words, scores, review schedule and streaks. Uninstalling deletes it.'},
      {icon: 'cloud-outline' as IconName, title: 'In your account (only if you sign in)', body: 'The same learning records, synced automatically so they survive reinstalling. Recently viewed words and searches are never uploaded.'},
      {icon: 'people-outline' as IconName, title: 'Community (only if you take part)', body: 'Your nickname, messages, posts and comments are public in the community until you delete them, a moderator hides them, or you delete your account.'},
      {icon: 'trophy-outline' as IconName, title: 'Leaderboard (only if you join it)', body: 'Your nickname, game level and Credits are public. Leaving deletes your entry.'},
      {icon: 'star-outline' as IconName, title: 'Credits', body: 'Credits belong to your account. Every change is recorded in your Credit history on our server.'},
      {icon: 'card-outline' as IconName, title: 'Purchases (Google Play)', body: 'Credit packs and Premium are paid through Google Play — this app never sees your card. We keep the order ID so a purchase is added exactly once.'},
      {icon: 'megaphone-outline' as IconName, title: 'Ads', body: 'Optional reward videos and short skippable ads (one opens when you delete your own post; none with Premium). Ads are non-personalised.'},
      {icon: 'lock-closed-outline' as IconName, title: 'Never collected', body: 'Decoded messages, contacts, location, microphone, or camera. No analytics SDK.'},
    ].map(v => <View key={v.title} style={s.card}><View style={s.inline}><IconTile icon={v.icon} from={C.accent} to={C.purple} size={36} iconSize={18} /><Text style={[s.checkTitle, {flex: 1}]}>{v.title}</Text></View><Text style={s.body}>{v.body}</Text></View>)}

    <Pressable accessibilityRole="button" accessibilityState={{expanded: showActivity}} onPress={() => setShowActivity(v => !v)} style={s.fold}>
      <IconTile icon="pulse-outline" from="#0EA5E9" to={C.purple} size={36} iconSize={18} />
      <View style={{flex: 1}}><Text style={s.checkTitle}>Recent account activity</Text><Text style={s.caption}>{events.length ? `${Math.min(events.length, 8)} recent ${events.length === 1 ? 'event' : 'events'} on this device` : 'Nothing unusual on this device'}</Text></View>
      <Icon name={showActivity ? 'chevron-up' : 'chevron-down'} size={18} color={C.muted} />
    </Pressable>
    {showActivity && <FadeIn>
      <View style={s.card}>
        {events.length === 0 ? <Text style={s.caption}>No security events recorded on this device.</Text> : events.slice(0, 8).map((e, i) => <View key={i} style={s.event}><Icon name="ellipse" size={8} color={e.type.includes('failed') || e.type.includes('denied') ? '#c26b20' : C.accent} /><Text style={[s.caption, {flex: 1, color: C.navy}]}>{eventLabels[e.type] ?? e.type}</Text><Text style={s.fine}>{ago(Date.now() - e.at)}</Text></View>)}
        <Text style={s.fine}>Kept on this device only.</Text>
      </View>
    </FadeIn>}
    <Text style={s.fine}>Privacy questions or data requests: {SUPPORT_EMAIL} ({COMPANY}).</Text>
    <Text style={s.fine}>Threat Shield is not antivirus and does not scan your device. Privacy policy: {PRIVACY_POLICY_URL}</Text>
  </>;
}

const s = StyleSheet.create({
  hero: {borderRadius: 24, borderWidth: 1.5, borderColor: '#DCE6FB', paddingVertical: 20, paddingHorizontal: 16, gap: 8, alignItems: 'center', shadowColor: '#4F46E5', shadowOffset: {width: 0, height: 10}, shadowOpacity: 0.12, shadowRadius: 20, elevation: 4, overflow: 'hidden'},
  heroEyebrow: {fontSize: 11, fontWeight: '900', letterSpacing: 2, color: '#4F46E5'},
  emblem: {width: 112, height: 112, alignItems: 'center', justifyContent: 'center', marginVertical: 6},
  ring: {position: 'absolute', width: 96, height: 96, borderRadius: 48, borderWidth: 3},
  emblemCore: {width: 92, height: 92, borderRadius: 46, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', borderWidth: 3, borderColor: 'rgba(255,255,255,.85)', shadowColor: '#4F46E5', shadowOpacity: .35, shadowRadius: 14, shadowOffset: {width: 0, height: 6}, elevation: 8},
  emblemShine: {position: 'absolute', top: 4, left: 14, right: 14, height: 34, borderRadius: 30, backgroundColor: 'rgba(255,255,255,.25)'},
  heroBar: {flexDirection: 'row', gap: 6, marginTop: 6},
  heroSeg: {width: 42, height: 6, borderRadius: 3},
  zones: {flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 4},
  zone: {flexGrow: 1, flexBasis: '46%', backgroundColor: '#fff', borderRadius: 20, borderWidth: 1.5, borderColor: '#E2E8F5', padding: 14, gap: 8, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.08, shadowRadius: 12, elevation: 2},
  zoneAlert: {borderColor: '#FCD34D', backgroundColor: '#FFFBEB'},
  zoneIcon: {width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', borderTopWidth: 1.5, borderTopColor: 'rgba(255,255,255,.6)'},
  zoneShine: {position: 'absolute', top: 0, left: 0, right: 0, height: 18, backgroundColor: 'rgba(255,255,255,.22)'},
  zoneTitle: {fontSize: 15, fontWeight: '900', color: C.navy},
  zoneTip: {fontSize: 12, lineHeight: 17, color: '#78350F'},
  pill: {flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', gap: 4, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 4},
  pillText: {fontSize: 12, fontWeight: '800'},
  fold: {flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 12, marginTop: 8},
  heroTitle: {fontSize: 19, fontWeight: '900', color: C.navy, textAlign: 'center', letterSpacing: -0.4},
  heroBody: {fontSize: 13, lineHeight: 19, color: C.muted, textAlign: 'center'},
  group: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, marginTop: 8, paddingHorizontal: 6, paddingVertical: 4, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3, overflow: 'hidden'},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 12, gap: 10, marginTop: 8, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3},
  check: {flexDirection: 'row', gap: 12, paddingVertical: 8, paddingHorizontal: 10, alignItems: 'flex-start'},
  checkIcon: {width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center'},
  checkTitle: {fontSize: 15, fontWeight: '800', color: C.navy},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  body: {fontSize: 13, lineHeight: 20, color: C.muted},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  inlineAction: {minHeight: 36, justifyContent: 'center', alignSelf: 'flex-start'},
  link: {fontSize: 13, color: C.accent, fontWeight: '800'},
  toggleRow: {flexDirection: 'row', alignItems: 'center', gap: 12},
  inline: {flexDirection: 'row', alignItems: 'center', gap: 12},
  event: {flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 30},
  notice: {flexDirection: 'row', gap: 9, padding: 14, borderRadius: 16, borderWidth: 1, borderColor: '#bfe6cf', backgroundColor: '#e1f5e9', alignItems: 'center'},
  noticeText: {flex: 1, color: '#175e47', fontSize: 14, lineHeight: 20},
});
