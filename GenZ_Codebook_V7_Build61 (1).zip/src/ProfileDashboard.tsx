import type {PublicAbout} from './publicProfile';
import {ProfileAction,ProfileIcon,SocialProfile,useProfileColors} from './SocialProfile';
import {doc,onSnapshot} from 'firebase/firestore';
import {cloudDbLive} from './firebase/app';
import {isPremiumActive,type SubscriptionDoc} from '../shared/subscriptions';
import {messaging,type ProfileDetails,type ConnectionList} from './messaging';
import {FollowUsRow} from './FollowUs';
import AccountTokens from './AccountTokens';
import {BACKEND_URL} from './backend';
import {VerifiedBadge,useBadges} from './VerifiedBadge';
/**
 * Account profile and the saved progress panels rendered by the Play page.
 */
import {SPARK_MODE} from '../shared/deployment';
import React, {useEffect, useMemo, useState} from 'react';
import {View, Text, Pressable, StyleSheet, Linking, ActivityIndicator, AppState} from 'react-native';
import {sendVerificationEmail, refreshVerified} from './emailVerification';
import {PLAY_STORE_URL, SUPPORT_EMAIL, supportMailto} from '../shared/brand';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Glass, Icon, IconName, Button, BrandAvatar, CompanyFooter, IconTile, ProgressBar, SectionHeader} from './ui';
import {LearningState, Profile, streak, totalXP, localDayOf} from './profile';
import {levelFor, TOKENS} from '../shared/tokens';
import {stages, unlocked} from './games';
import {termsById, Term, contentManifest, terms} from './content';
import {dueTerms} from './reviewQueue';
import {ago} from './shield/status';
import type {SyncStatus} from './sync/engine';
import {APP_VERSION} from './secure/config';
import {useAccountUser} from './services';
import {useAvatarPhoto} from './avatarPhoto';
import {referralCodeForUid, referralInstallLink} from '../shared/referral';
import * as Clipboard from 'expo-clipboard';
import {levelNameForId} from './discovery';
import {ensureReferralCode, fetchReferralCount, fetchReferredBy, fetchReferredFriends, type ReferredByInfo, type ReferredFriendView} from './referral';

import {RANKS, rankFor} from './ranks';
export {RANKS, rankFor};
const stageName = (id: string) => stages.find(s => s.id === id)?.name ?? levelNameForId(id) ?? (id === 'review' ? 'Daily review' : id.startsWith('daily-') ? 'Daily five' : id.startsWith('shuffle-') ? 'Shuffle: ' + id.slice(8, 9).toUpperCase() + id.slice(9) : id);

type Props = {
  about: PublicAbout; profile: Profile; sync: SyncStatus; signedInEmail: string | null;
  onEdit: () => void; onOpen: (sheet: 'login' | 'export' | 'guide' | 'privacy' | 'feedback' | 'suggest' | 'wallet' | 'shop' | 'notifications' | 'dashboard' | 'achievements' | 'settings' | 'about' | 'my-suggestions' | 'daily-apply' | 'daily-history' | 'my-posts' | 'verification') => void; onAccount: (mode: 'signin' | 'create') => void; onSignOut?: () => void;
  onFindPeople: () => void; onMessages: () => void; onConnections: (list:ConnectionList) => void; messageCount: number; credits: number | null; active?: boolean;
  onSavedWords: () => void; onRefresh: () => void;
};

export default function ProfileDashboard({about,profile: p, sync, signedInEmail, onEdit, onOpen, onAccount, onSignOut, onSavedWords, onRefresh, onFindPeople, onMessages, onConnections, messageCount, credits, active=true}: Props) {
  const now = Date.now();
  const photo = useAvatarPhoto();
  const user = useAccountUser();
  const badges=useBadges(user?[user.uid]:[]);
  const [subscription,setSubscription]=useState<{uid:string;data:SubscriptionDoc|null}|null>(null);
  const [social,setSocial]=useState<{uid:string;data:ProfileDetails}|null>(null);
  const [socialRetry,setSocialRetry]=useState(0);
  const [socialError,setSocialError]=useState(false);
  const [clock,setClock]=useState(Date.now());
  useEffect(()=>{
    if(!user)return;
    const uid=user.uid;
    return onSnapshot(doc(cloudDbLive(),`users/${uid}/subscription/current`),snap=>{
      setSubscription({uid,data:snap.exists()?snap.data() as SubscriptionDoc:null});
    },()=>setSubscription(null));
  },[user?.uid]);
  useEffect(()=>{
    if(!active)return;
    setClock(Date.now());
    const timer=setInterval(()=>setClock(Date.now()),30000);
    return()=>clearInterval(timer);
  },[active]);
  useEffect(()=>{
    if(!active||!user?.emailVerified)return;
    const uid=user.uid;
    let live=true;
    setSocialError(false);
    void messaging('profile',{uid}).then(r=>{if(live)setSocial({uid,data:r.person});},()=>{if(live){setSocial(null);setSocialError(true);}});
    return()=>{live=false;};
  },[active,user?.uid,user?.emailVerified,socialRetry]);
  const premium=isPremiumActive(subscription&&subscription.uid===user?.uid?subscription.data:null,clock);
  const counts=social&&social.uid===user?.uid?social.data:null;
  // Referral: the code is deterministic from the UID (shared/referral.ts),
  // so it shows immediately; the effect below registers it in Firestore
  // and counts successful referrals (0 when none — never invented).
  const myReferralCode = user ? referralCodeForUid(user.uid) : '';
  // E-mail verification reminder: chat, posts and Credits need a verified e-mail (enforced by the server).
  const [verifiedNow, setVerifiedNow] = useState(false), [verifyNote, setVerifyNote] = useState(''), [verifyBusy, setVerifyBusy] = useState(false);
  const needsVerify = !!user && !!user.email && !user.emailVerified && !verifiedNow;
  const checkVerified = async (quiet = false) => {
    if (!user) return;
    setVerifyBusy(!quiet);
    const ok = await refreshVerified(user);
    setVerifyBusy(false);
    if (ok) {setVerifiedNow(true); setVerifyNote('E-mail verified. Chat, posts and Credits are unlocked.');}
    else if (!quiet) setVerifyNote('Not verified yet. Open the link in the e-mail first (check Spam too), then tap “I’ve verified”.');
  };
  useEffect(() => {
    if (!needsVerify) return;
    const sub = AppState.addEventListener('change', st => {if (st === 'active') void checkVerified(true);});
    return () => sub.remove();
  }, [needsVerify, user?.uid]);
  const [codeCopyStatus,setCodeCopyStatus]=useState('');
  useEffect(()=>setCodeCopyStatus(''),[myReferralCode]);
  const copyRegistrationCode=async()=>{
    if(!myReferralCode)return;
    try{await Clipboard.setStringAsync(myReferralCode);setCodeCopyStatus('Sharing code copied');}
    catch{setCodeCopyStatus('Could not copy the code. Press and hold it to copy.');}
  };
  const copyReferralLink=async()=>{
    if(!myReferralCode)return;
    try{await Clipboard.setStringAsync(referralInstallLink(myReferralCode));setCodeCopyStatus('Invite link copied');}
    catch{setCodeCopyStatus('Could not copy the invite link.');}
  };
  const [referralCount, setReferralCount] = useState<number | null>(null);
  // Who referred this user, and who they referred — display names only
  // (see src/referral.ts: names come from public sources; a null name means
  // "Referred by a user" / "A friend", never a UID). Null = not loaded yet
  // (or the load failed — nothing is shown rather than a wrong fact).
  const [referredBy, setReferredBy] = useState<ReferredByInfo | null>(null);
  const [referredFriends, setReferredFriends] = useState<ReferredFriendView[] | null>(null);
  useEffect(() => {
    if (!user) {setReferralCount(null); setReferredBy(null); setReferredFriends(null); return;}
    void ensureReferralCode(user.uid).catch(() => {});
    void fetchReferralCount(user.uid).then(setReferralCount);
    let cancelled = false;
    void fetchReferredBy(user.uid).then(v => {if (!cancelled) setReferredBy(v);}).catch(() => {});
    void fetchReferredFriends(user.uid, 10).then(v => {if (!cancelled) setReferredFriends(v);}).catch(() => {});
    return () => {cancelled = true;};
  }, [user?.uid]);
  const syncLabel = !signedInEmail ? 'Stored on this device only' : sync.phase === 'idle' && !sync.pending ? `Backed up${sync.lastSyncAt ? ' · ' + ago(now - sync.lastSyncAt) : ''}` : sync.phase === 'syncing' ? 'Syncing…' : sync.phase === 'offline' ? 'Offline · will sync later' : sync.pending ? 'Changes waiting to sync' : 'Sync needs attention';
  const syncIcon: IconName = !signedInEmail ? 'phone-portrait-outline' : sync.phase === 'idle' && !sync.pending ? 'cloud-done-outline' : sync.phase === 'offline' ? 'cloud-offline-outline' : 'cloud-upload-outline';
  const syncing = sync.phase === 'syncing';
  const [section,setSection] = useState<'wallet'|'contributions'|'account'|null>(null);
  const colors=useProfileColors();
  const [menu,setMenu]=useState(false);
  const toggle = (next:NonNullable<typeof section>) => setSection(current=>current===next?null:next);

  return <>
    <View style={{backgroundColor:colors.bg,gap:10,padding:14,borderRadius:16}}>
      <View style={s.between}>
        <Text accessibilityRole="header" style={[s.pageTitle,{color:colors.ink,flex:1}]}>Your profile</Text>
        <ProfileIcon colors={colors} label={colors.dark?'Switch to light profile':'Switch to dark profile'} name={colors.dark?'sunny-outline':'moon-outline'} onPress={colors.toggle}/>
        <ProfileIcon colors={colors} label="Search users" name="search-outline" onPress={onFindPeople}/>
        <ProfileIcon colors={colors} label="Profile options" name="ellipsis-horizontal" onPress={()=>setMenu(v=>!v)}/>
      </View>
      <View style={{flexDirection:'row',alignItems:'center',gap:12}}>
        <BrandAvatar index={p.avatar} size={72} photo={p.usePhoto?photo:null}/>
        <View style={{flex:1,gap:4}}>
          <View style={s.nameLine}><Text accessibilityRole="header" style={[s.heroName,{color:colors.ink}]}>{p.name}</Text>
            <VerifiedBadge verified={!!user&&badges.has(user.uid)} tier={badges.tier(user?.uid)} size={20}/></View>
          {!!myReferralCode&&<View style={{flexDirection:'row',alignItems:'center',flexWrap:'wrap'}}>
            <Text selectable style={{color:colors.muted,flexShrink:1}}>{myReferralCode}</Text>
            <ProfileIcon colors={colors} label="Copy sharing code" name="copy-outline" onPress={()=>void copyRegistrationCode()}/>
            <ProfileIcon colors={colors} label="Copy invite link" name="link-outline" onPress={()=>void copyReferralLink()}/>
          </View>}
          {!!codeCopyStatus&&<Text accessibilityLiveRegion="polite" style={{color:colors.muted}}>{codeCopyStatus}</Text>}
        </View>
      </View>
      {!!about.bio&&<Text numberOfLines={2} style={{color:colors.ink}}>{about.bio}</Text>}
      {!!about.location&&<Text style={{color:colors.muted}}>{about.location}</Text>}
      <ProfileAction colors={colors} label="Edit profile" primary onPress={onEdit}/>
      {menu&&<View style={{gap:6}}>
        <ProfileAction colors={colors} label={messageCount?`Messages (${messageCount})`:'Messages'} onPress={onMessages}/>
        <ProfileAction colors={colors} label="Settings" onPress={()=>onOpen('settings')}/>
        <ProfileAction colors={colors} label="Saved words" onPress={onSavedWords}/>
      </View>}
      {socialError&&<ProfileAction colors={colors} label="Couldn’t load connections · Retry" onPress={()=>setSocialRetry(v=>v+1)}/>}
      <SocialProfile key={user?.uid??'guest'} uid={active&&user?.emailVerified?user.uid:undefined} owner colors={colors} about={about}
       followers={counts?.followers} following={counts?.followingCount} likes={counts?.postLikes}
       onConnections={user?.emailVerified?onConnections:undefined} credits={credits} onWallet={user?()=>onOpen('wallet'):undefined}/>
    </View>
    <View style={s.profileOverview}>
      <View style={s.profileActions}>
      <Row title="Buy Credits &amp; Premium" description={premium?'Premium active':undefined} icon="ticket-outline" from="#F1EAFE" to="#E6DCFC" onPress={()=>onOpen('shop')} last/>
      {signedInEmail ? <View style={s.syncRow}>
        <Pressable accessibilityRole="button" onPress={() => onOpen('login')} style={[s.syncChip, {flex: 1, minHeight: 40, paddingVertical: 7}]}>
          <Icon name={syncIcon} size={16} color={C.accent} />
          <View style={{flex:1,gap:2}}><Text style={s.rowTitle}>Backup Sync</Text><Text style={s.caption} numberOfLines={1}>{syncLabel}</Text></View>
          <Icon name="chevron-forward" size={14} color={C.muted} />
        </Pressable>
        <Pressable accessibilityRole="button" accessibilityLabel="Refresh profile" accessibilityState={{disabled: syncing}} disabled={syncing} onPress={()=>{setSocialRetry(v=>v+1);onRefresh();}} style={[s.refreshBtn, {width: 42, height: 42}, syncing && s.refreshBtnBusy]}>
          {syncing ? <ActivityIndicator color={C.accent} /> : <Icon name="refresh-outline" size={20} color={C.accent} />}
        </Pressable>
        {!!onSignOut && <Pressable accessibilityRole="button" accessibilityLabel="Sign out" onPress={onSignOut} style={s.refreshBtn}><Icon name="log-out-outline" size={19} color={C.muted}/></Pressable>}

      </View> : <View style={{gap: 8}}>
        <View style={s.authRow}>
          <Pressable accessibilityRole="button" onPress={() => onAccount('signin')} style={[s.authBtn, s.authPrimary]}><Icon name="log-in-outline" size={18} color={C.accent} /><Text style={[s.authText, {color: C.accent}]}>Sign in</Text></Pressable>
          <Pressable accessibilityRole="button" onPress={() => onAccount('create')} style={[s.authBtn, s.authGhost]}><Icon name="person-add-outline" size={18} color={C.accent} /><Text style={s.authText}>Create account</Text></Pressable>
        </View>
        <Text style={s.heroHint}>Back up your progress to use it on any phone.</Text>
      </View>}
      </View>
    </View>

    {needsVerify && <View style={s.verify} accessibilityLiveRegion="polite">
      <View style={{flexDirection: 'row', gap: 10, alignItems: 'flex-start'}}>
        <Icon name="mail-unread" size={24} color="#B45309" />
        <View style={{flex: 1, gap: 2}}>
          <Text style={s.verifyTitle}>Verify your e-mail</Text>
          <Text style={s.caption}>Open the link we sent to {user?.email} to unlock chat, posts and Credits. Can’t find it? Check Spam or Promotions.</Text>
          <Text style={[s.caption, {fontWeight: '700', color: '#92400E'}]}>Link expired or not working? Tap “Send new link” and open the newest e-mail.</Text>
        </View>
      </View>
      <View style={s.row}>
        <View style={{flex: 1}}><Button light title="Send new link" icon="mail-outline" disabled={verifyBusy} onPress={() => {if (user) {setVerifyBusy(true); void sendVerificationEmail(user).then(r => {setVerifyBusy(false); setVerifyNote(r.message);});}}} /></View>
        <View style={{flex: 1}}><Button title={verifyBusy ? 'Checking…' : 'I’ve verified'} icon="checkmark-circle-outline" disabled={verifyBusy} onPress={() => void checkVerified()} /></View>
      </View>
    </View>}
    {!!verifyNote && <Text accessibilityLiveRegion="polite" style={[s.caption, {textAlign: 'center'}]}>{verifyNote}</Text>}
    {!!myReferralCode&&<View style={s.rewardNote}><Icon name="gift-outline" color={C.purple} size={16}/><Text style={s.caption}>When a friend joins with your code, you each earn {TOKENS.REFERRAL_REWARD} Credits.</Text></View>}
    <Text style={s.sectionLabel}>ACCOUNT & COMMUNITY</Text>
    <View style={s.groupStack}>
    <ProfileGroup icon="shield-checkmark-outline" title="Verified badge" detail={user&&badges.has(user.uid)?(badges.tier(user.uid)==='gold'?'Gold · GenZ Codebook team':'Blue · verified'):'See eligibility and apply'} open={false} onPress={()=>onOpen('verification')}>{null}</ProfileGroup>
    <ProfileGroup icon="wallet-outline" title="Wallet & rewards"  open={section==='wallet'} onPress={()=>toggle('wallet')}>
    <Glass>
      <AccountTokens/>
      <View style={s.row}>
        {!!BACKEND_URL&&<View style={{flex: 1}}><Button title="Buy Credits" icon="card-outline" onPress={() => onOpen('shop')} /></View>}
        <View style={{flex: 1}}><Button title="Wallet" icon="wallet-outline" light onPress={() => onOpen('wallet')} /></View>
      </View>
      {signedInEmail && myReferralCode ? <View style={s.referralBox}>
        <Text style={s.referralLabel}>Your referrals</Text>
        <Text style={s.caption}>{referralCount === null ? 'Counting your referrals…' : referralCount === 0 ? `No friends joined with your code yet — share it to earn ${TOKENS.REFERRAL_REWARD} Credits each.` : `${referralCount} friend${referralCount === 1 ? '' : 's'} joined with your code · +${(referralCount * TOKENS.REFERRAL_REWARD).toLocaleString()} Credits earned`}</Text>
        {referredBy && referredBy.claimed === false && <Text style={s.caption}>You joined directly — no one referred you.</Text>}
        {referredBy && referredBy.claimed === true && <Text style={s.caption}>Referred by {referredBy.displayName ?? 'a user'} — you both got {TOKENS.REFERRAL_REWARD} Credits.</Text>}
        {referredFriends && referredFriends.length > 0 && <View style={{gap: 4}}>
          <Text style={s.referralLabel}>Friends you referred</Text>
          {referredFriends.map((f, i) => <Text key={i} style={s.caption}>• {f.displayName ?? 'A friend'}{f.joinedAtMs ? ` — joined ${ago(now - f.joinedAtMs)}` : ''}</Text>)}
          {referralCount !== null && referralCount > referredFriends.length && <Text style={s.caption}>and {referralCount - referredFriends.length} more</Text>}
        </View>}
      </View> : signedInEmail ? <Text style={s.caption}>Your referral code appears here once you’re back online.</Text> : null}
    </Glass>
    </ProfileGroup>
    <ProfileGroup icon="create-outline" title="Contributions" open={section==='contributions'} onPress={()=>toggle('contributions')}>
      <Glass style={{padding:4,gap:0}}>
        <Row icon="create-outline" from={C.purple} to="#9B7BFF" title="Suggest a word" onPress={()=>onOpen('suggest')}/>
        <Row icon="list-outline" from={C.purple} to="#9B7BFF" title="My suggestions" onPress={()=>onOpen('my-suggestions')}/>
        <Row icon="albums-outline" from={C.purple} to="#9B7BFF" title="My Posts" onPress={()=>onOpen('my-posts')}/>
{!!BACKEND_URL&&<Row icon="calendar-outline" from={C.accent} to={C.purple} title="Daily Code Display" description="1 free every month" onPress={()=>onOpen('daily-apply')}/>}
        <Row icon="list-outline" from={C.accent} to={C.purple} title="Daily Code applications" onPress={()=>onOpen('daily-history')}/>
        <Row icon="shield-checkmark-outline" from={C.accent} to={C.purple} title="Verified Badge" onPress={()=>onOpen('verification')} last/>
      </Glass>
    </ProfileGroup>
    <ProfileGroup icon="settings-outline" title="Account & settings" open={section==='account'} onPress={()=>toggle('account')}>
      <Glass style={{padding:4,gap:0}}>
        <Row icon="person-circle-outline" from={C.accent} to="#4D8DFF" title="My account" description={signedInEmail ? `Signed in · ${syncLabel.toLowerCase()}` : 'Back up and sync'} onPress={() => onOpen('login')} />
        <Row icon="notifications-outline" from="#0EA5E9" to="#38BDF8" title="Notifications" description="Activity and Credit updates" onPress={() => onOpen('notifications')} />
        <Row icon="settings-outline" from="#64748B" to="#94A3B8" title="Settings" onPress={() => onOpen('settings')} />
        <Row icon="shield-checkmark-outline" from="#0D9488" to="#14B8A6" title="Threat Shield" onPress={() => onOpen('privacy')} />
        <Row icon="download-outline" from={C.accent} to="#4D8DFF" title="Export learning data" onPress={() => onOpen('export')} />
        <Row icon="chatbubble-ellipses-outline" from={C.purple} to="#A78BFA" title="Send feedback" onPress={() => onOpen('feedback')} />
        <Row icon="mail-outline" from="#0EA5E9" to="#38BDF8" title="Contact support" description={SUPPORT_EMAIL} onPress={() => void Linking.openURL(supportMailto()).catch(() => {})} />
        <Row icon="help-buoy-outline" from="#8B5CF6" to="#C4B5FD" title="Where do I start?" onPress={() => onOpen('guide')} last />
      </Glass>
    </ProfileGroup>
    </View>

    <View style={s.quickRow}>
      <Pressable accessibilityRole="button" accessibilityLabel="Rate GenZ Codebook on Google Play" onPress={() => void Linking.openURL(PLAY_STORE_URL).catch(() => {})} style={({pressed}) => [s.quick, pressed && {opacity: .8}]}>
        <IconTile icon="star" from={C.gold} to="#E89B0C" size={38} iconSize={19} /><View style={{flex: 1}}><Text style={s.quickTitle}>Rate the app</Text><Text style={s.fine}>On Google Play</Text></View>
      </Pressable>
      <Pressable accessibilityRole="button" accessibilityLabel="Send feedback" onPress={() => onOpen('feedback')} style={({pressed}) => [s.quick, pressed && {opacity: .8}]}>
        <IconTile icon="chatbubble-ellipses" from={C.purple} to="#A78BFA" size={38} iconSize={19} /><View style={{flex: 1}}><Text style={s.quickTitle}>Feedback</Text><Text style={s.fine}>Ideas & bugs</Text></View>
      </Pressable>
    </View>
    <FollowUsRow />
    {!!signedInEmail && !!onSignOut && <Button light title="Sign out" icon="log-out-outline" onPress={onSignOut} />}
    <View style={s.versionRow} accessible accessibilityLabel={`GenZ Codebook version ${APP_VERSION}`}>
      <View style={s.versionPill}><View style={s.versionDot} /><Text style={s.versionText}>v{APP_VERSION}</Text></View>
      <Text style={s.fine}>{terms.length.toLocaleString()} entries{terms.length !== contentManifest.uniqueEntries ? ' (includes published updates)' : ''}</Text>
    </View>
    <CompanyFooter />
  </>;
}

export function PlayProgress({state,profile:p,onOpen,onSavedWords,onOpenTerm,onReview,onUnlockLevel}:Pick<Props,'profile'|'onOpen'|'onSavedWords'>&{state:LearningState;onOpenTerm:(t:Term)=>void;onReview:()=>void;onUnlockLevel:(stageId:string)=>void}){
  const now=Date.now();
  const [expanded,setExpanded]=useState(false);
  const d = useMemo(() => {
    const xp = totalXP(p.best);
    const rank = rankFor(xp);
    const st = streak(state.days, now);
    const mastered = Object.values(p.progress).filter(r => r.mastery >= 80).length;
    const due = dueTerms(p, now).length;
    const week = Array.from({length: 7}, (_, i) => {const t = new Date(now); t.setHours(12, 0, 0, 0); t.setDate(t.getDate() - (6 - i)); const key = localDayOf(t.getTime()); return {key, label: t.toLocaleDateString('en', {weekday: 'narrow'}), count: state.days[key] ?? 0, today: i === 6};});
    const weekMax = Math.max(1, ...week.map(w => w.count));
    const attempts = Object.values(state.attempts).sort((a, b) => b.at - a.at);
    const cleared = stages.filter(g => (p.best[g.id] ?? 0) >= 60).length;
    const played = stages.filter(g => p.best[g.id] !== undefined).length;
    const recent = state.recent.map(r => termsById.get(r.id)).filter((t): t is Term => !!t).slice(0, 8);
    const perfect = Object.values(p.best).some(v => v === 100);
    const badges: {icon: IconName; label: string; earned: boolean; hint: string}[] = [
      {icon: 'chatbubbles', label: 'Code cracker', earned: played > 0, hint: 'Play a level'},
      {icon: 'star', label: 'Perfect round', earned: perfect, hint: 'Score 5 / 5'},
      {icon: 'bookmark', label: 'Word collector', earned: p.saved.length >= 5, hint: 'Save 5 words'},
      {icon: 'flame', label: 'On a roll', earned: st.best >= 3, hint: '3-day streak'},
      {icon: 'calendar', label: 'Week warrior', earned: st.best >= 7, hint: '7-day streak'},
      {icon: 'school', label: 'Sharp memory', earned: mastered >= 10, hint: 'Master 10 words'},
    ];
    return {xp, rank, st, mastered, due, week, weekMax, attempts, cleared, recent, badges, weekAnswers: week.reduce((a, w) => a + w.count, 0), weekDays: week.filter(w => w.count > 0).length, reviewing: Object.keys(p.progress).length, tokens: levelFor(state.tokens.balance), nextLocked: stages.find((g, i) => !unlocked(i, p.best, state.tokens.unlockedLevels))};
  }, [state, p, now - (now % 60_000)]);

  return <ProfileGroup icon="school-outline" title="Game progress & achievements" open={expanded} onPress={()=>setExpanded(v=>!v)}>
      <View style={s.metricsSection}>
        <Text accessibilityRole="header" style={s.overviewHeading}>Learning stats</Text>
        <View style={s.profileStats}>
          <Stat icon="flame" value={String(d.st.current)} label="Streak" accessibilityName="Day streak" />
          <Stat icon="game-controller" value={String(d.cleared)} label="Cleared" accessibilityName="Levels cleared" />
          <Stat icon="ribbon" value={String(d.mastered)} label="Mastered" />
          <Stat icon="bookmark" value={String(p.saved.length)} label="Saved" accessibilityName="Saved words" onPress={onSavedWords} />
        </View>
      </View>
      <View style={s.xpPanel}>
        <View style={s.between}><Text accessibilityRole="header" style={s.overviewHeading}>Rank progress</Text><Text style={s.xpValue}>{d.xp} XP</Text></View>
        <View accessibilityRole="progressbar" accessibilityValue={{min: 0, max: 100, now: Math.round(d.rank.progress * 100)}}>
          <View style={s.xpTrack}><LinearGradient colors={['#7951DC','#5365FF']} start={{x:0,y:0}} end={{x:1,y:0}} style={{height:6,borderRadius:6,width:`${Math.round(d.rank.progress*100)}%`}}/></View>
        </View>
        <View style={s.between}><Text style={s.progressHint}>{d.rank.name}</Text><Text style={s.progressHint}>{d.rank.next ? `${d.rank.next.xp - d.xp} XP to ${d.rank.next.name}` : 'Top rank reached'}</Text></View>
      </View>
    <Glass>
      <SectionHeader eyebrow="LEARNING POINTS" title={`${state.tokens.balance.toLocaleString()} learning points · Level ${d.tokens.level} ${d.tokens.name}`} action={<IconTile icon="star" from={C.gold} to="#E89B0C" size={40} iconSize={20} />} />
      <View accessibilityRole="progressbar" accessibilityValue={{min: 0, max: 100, now: Math.round(d.tokens.progress * 100)}}>
        <ProgressBar value={d.tokens.progress} color={C.gold} height={10} />
      </View>
      <Text style={s.caption}>{d.tokens.next ? `${(d.tokens.next.tokens - state.tokens.balance).toLocaleString()} points to ${d.tokens.next.name}` : 'Top learning points level reached'}</Text>
      <Text style={s.caption}>Learning points: games and guest ads. Credits: verified ads +10 and daily reward +10. Earn: watch an ad +10 · visit daily +5 · perfect round +10 · Daily Five +15 · word accepted +20 · friend joins with your code +100. Unlock a level early for 50 learning points, or by choosing to watch an ad.</Text>
      {d.nextLocked && (state.tokens.balance >= TOKENS.UNLOCK_LEVEL_COST
        ? <Button title={`Unlock ${d.nextLocked.name} early · ${TOKENS.UNLOCK_LEVEL_COST} points`} icon="lock-open-outline" onPress={() => onUnlockLevel(d.nextLocked!.id)} />
        : <Text style={s.caption}>Earn {(TOKENS.UNLOCK_LEVEL_COST - state.tokens.balance).toLocaleString()} more points to unlock {d.nextLocked.name} early.</Text>)}
    </Glass>
      <Glass style={{padding:4,gap:0}}>
        <Row icon="pulse-outline" from={C.accent} to={C.purple} title="Learning dashboard" onPress={() => onOpen('dashboard')} />
        <Row icon="ribbon-outline" from={C.gold} to="#E89B0C" title="Achievements" onPress={() => onOpen('achievements')} last />
      </Glass>
    <Glass>
      <SectionHeader eyebrow="THIS WEEK" title={d.weekAnswers ? `${d.weekAnswers} answers · ${d.weekDays} of 7 days` : 'A fresh week'} action={<Icon name="pulse-outline" color={C.accent} size={24} />} />
      <View style={s.bars} accessible accessibilityLabel={`Activity in the last 7 days: ${d.week.map(w => w.count).join(', ')} answers`}>
        {d.week.map(w => <View key={w.key} style={s.barCol}>
          <View style={s.barSlot}><LinearGradient colors={w.today ? [C.accent, C.purple] : ['#B9D2F5', '#8EAEEA']} style={[s.bar, {height: w.count ? `${Math.max(12, (w.count / d.weekMax) * 100)}%` : 4, opacity: w.count ? 1 : 0.5}]} /></View>
          <Text style={[s.barLabel, w.today && {color: C.accent, fontWeight: '900'}]}>{w.label}</Text>
        </View>)}
      </View>
      {!d.weekAnswers && <Text style={s.caption}>Answer one quiz question to start a streak.</Text>}
    </Glass>

    <Glass>
      <SectionHeader eyebrow="LEARNING PATH" title={`${d.cleared} of ${stages.length} levels cleared`} />
      <View style={s.path}>
        {stages.map((g, i) => {const best = p.best[g.id]; const done = (best ?? 0) >= 60; const open = unlocked(i, p.best, state.tokens.unlockedLevels); return <React.Fragment key={g.id}>
          {i > 0 && <View style={[s.pathLine, done && {backgroundColor: g.color}]} />}
          <View accessible accessibilityLabel={`${g.name}: ${done ? `cleared, best ${best}%` : open ? 'unlocked' : 'locked'}`} style={[s.node, done ? {backgroundColor: g.color, borderColor: g.color} : open ? {borderColor: g.color} : null]}>
            <Icon name={done ? 'checkmark' : open ? g.icon : 'lock-closed'} size={done ? 20 : 17} color={done ? '#fff' : open ? g.color : C.muted} />
          </View>
        </React.Fragment>;})}
      </View>
      <View style={s.reviewRow}>
        <IconTile icon="repeat" from="#0E9F8A" to="#34C3A5" size={40} iconSize={20} />
        <View style={{flex: 1}}><Text style={s.rowTitle}>{d.due ? `${d.due} ${d.due === 1 ? 'word is' : 'words are'} ready to review` : d.reviewing ? 'Reviews are scheduled' : 'Your review queue is empty'}</Text>{d.reviewing ? <Text style={s.caption}>{d.reviewing} words in review</Text> : null}</View>
        {d.due > 0 && <Pressable accessibilityRole="button" onPress={onReview} style={s.smallCta}><Text style={s.smallCtaText}>Review</Text></Pressable>}
      </View>
    </Glass>
    {d.attempts.length > 0 && <>
    <Glass>
      <SectionHeader eyebrow="RECENT ROUNDS" title="Your recent rounds" action={<Text style={s.caption}>{d.attempts.length} saved</Text>} />
      {d.attempts.slice(0, 3).map((a, i) => {const pct = Math.round((a.score / a.total) * 100); return <View key={i} style={s.attempt}>
        <View style={{flex: 1}}><Text style={s.rowTitle} numberOfLines={1}>{stageName(a.stage)}</Text><Text style={s.caption}>{ago(now - a.at)}</Text></View>
        <View style={[s.scorePill, {backgroundColor: pct >= 60 ? '#E1F5E9' : '#FFF1E6'}]}><Text style={[s.scoreText, {color: pct >= 60 ? '#13684A' : '#97501C'}]}>{a.score}/{a.total}</Text></View>
      </View>;})}
    </Glass>
    </>}

    <View style={{gap: 12}}>
      <SectionHeader eyebrow="ACHIEVEMENTS" title="Your little wins" />
      <View style={s.badges}>{d.badges.map(b => <View key={b.label} accessible accessibilityLabel={`${b.label}: ${b.earned ? 'earned' : 'not yet. ' + b.hint}`} style={[s.badge, !b.earned && {opacity: 0.6}]}>
        <IconTile icon={b.earned ? b.icon : (b.icon + '-outline') as IconName} from={b.earned ? C.gold : '#CBD8E8'} to={b.earned ? '#E89B0C' : '#9FB4CC'} size={44} iconSize={22} />
        <Text style={s.badgeText} numberOfLines={1}>{b.label}</Text>
        <Text style={s.fine}>{b.earned ? 'Earned' : b.hint}</Text>
      </View>)}</View>
    </View>
    {d.recent.length > 0 && <>
    <Glass>
      <SectionHeader eyebrow="RECENTLY VIEWED" title="Recently viewed" />
      <View style={s.wrap}>{d.recent.map(t => <Pressable key={t.id} accessibilityRole="button" accessibilityLabel={`Open ${t.expression}`} onPress={() => onOpenTerm(t)} style={({pressed}) => [s.recentChip, pressed && {opacity: 0.75}]}><Text style={s.recentText} numberOfLines={1}>{t.expression}</Text></Pressable>)}</View>
    </Glass>
    </>}

  </ProfileGroup>;
}

function ProfileGroup({icon,title,detail,open,onPress,children}:{icon:IconName;title:string;detail?:string;open:boolean;onPress:()=>void;children:React.ReactNode}) {
  return <View style={s.group}>
    <Pressable accessibilityRole="button" accessibilityState={{expanded:open}} onPress={onPress} style={({pressed})=>[s.groupHead,pressed&&{backgroundColor:C.soft}]}>
      <View style={s.groupIcon}><Icon name={icon} color={C.accent} size={19}/></View>
      <View style={{flex:1,minWidth:0}}>
        <Text style={s.rowTitle}>{title}</Text>
        {!!detail&&<Text style={s.caption}>{detail}</Text>}
      </View>
      <Icon name={open?'chevron-up':'chevron-forward'} color={C.muted} size={16}/>
    </Pressable>
    {open&&<View style={s.groupBody}>{children}</View>}
  </View>;
}

function Stat({icon,value,label,accessibilityName=label,onPress}:{icon:IconName;value:string;label:string;accessibilityName?:string;onPress?:()=>void}) {
  const tint=icon==='flame'?'#FFF0E7':icon==='bookmark'?'#EFE9FB':'#E8F0FD';
  const ink=icon==='flame'?'#B66436':icon==='bookmark'?'#7651C7':'#3665C7';
  const body=<><View style={[s.statIcon,{backgroundColor:tint}]}><Icon name={icon} color={ink} size={16}/></View><Text style={s.statValue} numberOfLines={1}>{value}</Text><Text style={s.statLabel}>{label}</Text></>;
  return onPress?<Pressable accessibilityRole="button" accessibilityLabel={`${accessibilityName}: ${value}`} onPress={onPress} style={s.stat}>{body}</Pressable>:<View accessible accessibilityLabel={`${accessibilityName}: ${value}`} style={s.stat}>{body}</View>;
}
function Row({icon, from, to, title, description, onPress, last}: {icon: IconName; from: string; to: string; title: string; description?: string; onPress: () => void; last?: boolean}) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={({pressed}) => [s.settingRow, !last && s.settingDivider, pressed && {opacity: 0.8, backgroundColor: C.soft}]}><IconTile icon={icon} from={from} to={to} size={40} iconSize={20} /><View style={{flex: 1, gap: 3}}><Text style={s.rowTitle}>{title}</Text>{description && <Text style={s.caption} numberOfLines={1}>{description}</Text>}</View><Icon name="chevron-forward" size={17} color={C.muted} /></Pressable>;
}

const s = StyleSheet.create({
  pageHeading:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingHorizontal:3,paddingTop:5,paddingBottom:13,gap:12},
  eyebrow:{fontSize:9,fontWeight:'800',letterSpacing:1.6,color:'#69758D'},pageTitle:{fontSize:24,fontWeight:'800',letterSpacing:-.8,color:C.navy},
  profileOverview:{gap:8},
  profileHero:{gap:6,paddingHorizontal:15,paddingTop:38,paddingBottom:7,borderRadius:20,overflow:'hidden',backgroundColor:'#FFFFFF',borderWidth:1,borderColor:'#E9EDF6'},
  profileCover:{position:'absolute',top:0,left:0,right:0,height:75,overflow:'hidden'},
  heroOrbit:{position:'absolute',width:176,height:176,borderRadius:88,borderWidth:1,borderColor:'#566996',right:-57,top:-50},
  innerOrbit:{width:153,height:153,borderRadius:77,right:-38,top:-43},
  goldOrbit:{borderColor:'#AE8449'},
  profileIdentity:{flexDirection:'row',alignItems:'flex-end',justifyContent:'space-between',flexWrap:'wrap',gap:6},
  identityDetails:{gap:2},
  nameLine:{flexDirection:'row',alignItems:'center',gap:7},
  codeLine:{flexDirection:'row',alignItems:'center',alignSelf:'flex-start',borderRadius:10,paddingLeft:10,backgroundColor:'#F2F5FA',maxWidth:'100%'},
  rankRow:{flexDirection:'row',flexWrap:'wrap',alignItems:'center',gap:8},
  codeControl:{width:40,height:40,alignItems:'center',justifyContent:'center'},
  rewardNote:{flexDirection:'row',alignItems:'center',gap:7,paddingHorizontal:4,paddingVertical:5},
  userCode:{fontSize:12,fontWeight:'700',letterSpacing:.7,color:C.navy,flexShrink:1},
  heroFeedback:{fontSize:13,color:'#53617B',fontWeight:'600'},
  heroActions:{flexDirection:'row',gap:5},
  heroAction:{width:44,height:44,borderRadius:22,borderWidth:1,borderColor:'#DFE5F0',backgroundColor:'#FFFFFF',alignItems:'center',justifyContent:'center'},
  messageBadge:{position:'absolute',top:1,right:0,paddingHorizontal:3,minWidth:13,borderRadius:7,backgroundColor:'#4259CD',alignItems:'center'},
  messageBadgeText:{color:'#FFFFFF',fontSize:8,fontWeight:'800'},
  premiumTag:{flexDirection:'row',alignItems:'center',gap:4,borderRadius:8,paddingHorizontal:6,paddingVertical:2,backgroundColor:'#FFF3DA'},
  premiumText:{color:'#78521A',fontSize:11,fontWeight:'700'},
  goldAvatar:{borderColor:'#FFF0CC'},
  overviewHeading:{color:C.navy,fontSize:14,fontWeight:'800',flexShrink:1},
  profileStats:{flexDirection:'row',gap:5},
  xpPanel:{gap:9,padding:14,borderRadius:18,backgroundColor:'#FFFFFF',borderWidth:1,borderColor:'#E9EDF6'},
  xpValue:{fontSize:17,fontWeight:'800',color:C.navy},
  xpTrack:{height:6,borderRadius:6,overflow:'hidden',backgroundColor:'#E2E8F7'},
  progressHint:{fontSize:11,fontWeight:'600',color:'#526181',flexShrink:1},
  sectionLabel:{fontSize:10,fontWeight:'800',letterSpacing:1.5,color:'#69758D',marginTop:7,marginBottom:-4,paddingHorizontal:4},
  statIcon:{width:28,height:28,borderRadius:10,alignItems:'center',justifyContent:'center'},
  signOutAction:{minHeight:48,flexDirection:'row',gap:8,justifyContent:'center',alignItems:'center'},signOutText:{fontSize:13,fontWeight:'600',color:C.muted},

  quickRow:{flexDirection:'row',gap:10},quick:{flex:1,flexDirection:'row',alignItems:'center',gap:10,padding:12,borderRadius:18,backgroundColor:'#fff',borderWidth:1,borderColor:'#E2E8F5'},quickTitle:{fontSize:14.5,fontWeight:'900',color:C.ink},
  metricsSection:{padding:11,gap:8,backgroundColor:'#FFFFFF',borderRadius:18,borderWidth:1,borderColor:'#E9EDF6'},profileActions:{borderRadius:18,paddingHorizontal:12,paddingBottom:8,gap:3,backgroundColor:'#FFFFFF',borderWidth:1,borderColor:'#E9EDF6'},socialRow:{flexDirection:'row',flexWrap:'nowrap',alignItems:'center'},socialButton:{flex:1,minWidth:0,minHeight:44,justifyContent:'center',paddingHorizontal:2},socialLabel:{color:'#4A5972',fontSize:11,textAlign:'center'},socialCount:{fontWeight:'900'},
  row: {flexDirection: 'row', gap: 10, marginTop: 4},
  avatarRing:{width:70,height:70,borderRadius:35,borderWidth:4,borderColor:'#FFFFFF',alignItems:'center',justifyContent:'center',backgroundColor:'#6076B8'},
  heroName:{fontSize:26,fontWeight:'800',letterSpacing:-.7,color:C.navy,flexShrink:1},
  rankText:{color:'#53617B',fontSize:12,fontWeight:'700'},
  syncChip: {flexDirection: 'row', alignItems: 'center', gap: 8, minHeight: 44, paddingHorizontal: 14, borderRadius: 16, backgroundColor: 'transparent', borderWidth: 0},
  syncText: {flex: 1, color: C.ink, fontSize: 13, fontWeight: '700'},
  syncRow: {flexDirection:'row',gap:8,alignItems:'center',borderTopWidth:1,borderTopColor:'#EDF0F6',paddingTop:12},
  refreshBtn: {flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, width:44, minHeight: 44, borderRadius: 14, backgroundColor: C.soft, borderWidth: 1, borderColor: C.line},
  refreshBtnBusy: {opacity: 0.7},
  authRow: {flexDirection: 'row', gap: 10},
  authBtn: {flex: 1, minHeight: 46, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7},
  authPrimary: {backgroundColor: '#fff', borderBottomWidth: 2, borderBottomColor: '#cfdcf5'},
  authGhost: {backgroundColor:'#F8F9FC',borderWidth:1,borderColor:'#E6EAF3'},
  authText: {fontSize: 14, fontWeight: '800', color: C.ink},
  heroHint: {color: C.muted, fontSize: 12, lineHeight: 17},
  between: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10},
  grid: {flexDirection:'row',gap:10},
  verify: {gap: 10, padding: 14, borderRadius: 18, backgroundColor: '#FFF7E6', borderWidth: 1.5, borderColor: '#FCD34D'},
  verifyTitle: {fontSize: 15.5, fontWeight: '900', color: '#7C2D12'},
  stat: {flex:1,minWidth:0,paddingVertical:7,paddingHorizontal:2,alignItems:'center',gap:3,backgroundColor:'#F4F6FC',borderRadius:13},
  statValue: {fontSize:18,fontWeight:'800',letterSpacing:-.6,fontVariant:['tabular-nums'],color:C.navy},
  statLabel: {fontSize:10,fontWeight:'600',color:'#68758C',textAlign:'center'},
  groupStack: {gap:10},
  group: {borderWidth:1,borderColor:'#E6E7F0',borderRadius:20,backgroundColor:'#FFFFFF',overflow:'hidden'},
  groupHead: {minHeight:76,paddingHorizontal:16,paddingVertical:14,flexDirection:'row',alignItems:'center',gap:13},
  groupIcon: {width:42,height:42,borderRadius:14,alignItems:'center',justifyContent:'center',backgroundColor:'#F1F3FA'},
  groupBody: {padding:8,paddingBottom:16,gap:8,backgroundColor:'#F8FAFD',borderRadius:16},
  bars: {flexDirection: 'row', gap: 8, height: 88, alignItems: 'flex-end'},
  barCol: {flex: 1, alignItems: 'center', gap: 6, height: '100%'},
  barSlot: {flex: 1, width: '100%', justifyContent: 'flex-end', alignItems: 'center'},
  bar: {width: '72%', maxWidth: 30, borderRadius: 9},
  barLabel: {fontSize: 11, color: C.muted, fontWeight: '700'},
  linkRow: {flexDirection: 'row', alignItems: 'center', gap: 4, minHeight: 44},
  link: {fontSize: 14, color: C.accent, fontWeight: '800'},
  path: {flexDirection: 'row', alignItems: 'center', paddingVertical: 4},
  pathLine: {flex: 1, height: 3, borderRadius: 3, backgroundColor: '#D3DFEE', marginHorizontal: 4},
  node: {width: 44, height: 44, borderRadius: 22, borderWidth: 2, borderColor: '#CBD8E8', backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center'},
  reviewRow: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10, borderRadius: 14, backgroundColor: C.soft},
  smallCta: {minHeight: 40, paddingHorizontal: 14, borderRadius: 14, backgroundColor: C.accent, justifyContent: 'center'},
  smallCtaText: {color: '#fff', fontWeight: '800', fontSize: 13},
  rowTitle: {fontSize:15,fontWeight:'700',letterSpacing:-.2,color:C.navy},
  caption: {fontSize:12,lineHeight:19,color:'#68758C'},
  referralBox: {marginTop: 10, padding: 12, borderRadius: 14, backgroundColor: '#FFF8E6', borderWidth: 1.5, borderColor: '#F5D67B', gap: 8},
  referralLabel: {fontSize: 13, fontWeight: '800', color: C.navy},
  fine: {fontSize: 11, lineHeight: 16, color: '#5C7189'},
  versionRow: {flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, flexWrap: 'wrap'},
  versionPill: {flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#fff', borderWidth: 1, borderColor: '#DCE8F5', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4},
  versionDot: {width: 8, height: 8, borderRadius: 4, backgroundColor: C.accent},
  versionText: {fontSize: 11, fontWeight: '900', color: C.navy, letterSpacing: 0.3},
  attempt: {flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 6},
  scorePill: {paddingVertical: 6, paddingHorizontal: 12, borderRadius: 999},
  scoreText: {fontSize: 13, fontWeight: '900'},
  badges: {flexDirection: 'row', flexWrap: 'wrap', gap: 10},
  badge: {flexBasis: '30%', flexGrow: 1, alignItems: 'center', gap: 5, paddingVertical: 10, paddingHorizontal: 6, borderRadius: 16, backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#DCE8F5'},
  badgeText: {fontSize: 11, fontWeight: '800', color: C.navy, textAlign: 'center'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 8},
  recentChip: {minHeight: 40, paddingHorizontal: 14, justifyContent: 'center', borderRadius: 14, backgroundColor: C.soft, borderWidth: 1, borderColor: '#D3E6FB', maxWidth: 180},
  recentText: {fontSize: 14, fontWeight: '800', color: C.accent},
  settingRow: {padding: 10, minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 13, borderRadius: 16},
  settingDivider: {borderBottomWidth: 1, borderBottomColor: '#EAF2FB'},
});
