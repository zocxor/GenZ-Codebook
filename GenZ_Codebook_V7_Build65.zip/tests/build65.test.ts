import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {communityError} from '../shared/communityErrors';
const read = (f: string) => readFileSync(f, 'utf8');
const screen = read('src/MessagingScreen.tsx');

test('Build 65: no message requests anywhere in the app screens', () => {
  assert.doesNotMatch(screen, /Requests \(|tab==='requests'|setTab\('requests'\)|Message request|Request sent|Request declined|[Aa]cceptance|Accept this request/);
  assert.doesNotMatch(screen, /call\('respond-request'/, 'the app no longer asks anyone to accept');
  assert.match(screen, /type InboxTab='personal'\|'group';/);
  assert.match(screen, /Everyone can send you private messages/);
});

test('Build 65: messaging a person opens an active conversation at once', () => {
  assert.match(screen, /const result=await act\('request',\{uid:profile\.uid\}\);/);
  assert.match(screen, /status:'active',unread:0/);
  assert.match(screen, /const messageLabel='Message';/);
});

test('Build 65: the composer has a + button, an icon-only attachment tray and a text bar with the emoji inside it', () => {
  assert.doesNotMatch(screen, /label="Attach photo"[^\n]*\n?[^\n]*label="Attach file"[^\n]*<\/View>\}\s*\{codeOpen/, 'the wide text chips are gone');
  assert.match(screen, /accessibilityLabel=\{tray\?'Close attachment options':'Add attachment'\}/);
  const tray = screen.slice(screen.indexOf('<View style={s.tray}'), screen.indexOf('<View style={s.composeRow}>'));
  for (const icon of ['image-outline', 'document-outline', 'book-outline']) assert.ok(tray.includes(`icon="${icon}"`), icon);
  const trayButton = screen.slice(screen.indexOf('function TrayButton'), screen.indexOf('function TypingLine'));
  assert.doesNotMatch(trayButton, /<Text/, 'icons only, no text labels');
  assert.match(trayButton, /accessibilityLabel=\{label\}/, 'screen readers still hear what each icon does');
  const row = screen.slice(screen.indexOf('<View style={s.composeRow}>'), screen.indexOf('text.length>1300'));
  assert.ok(row.indexOf('Add attachment') < row.indexOf('accessibilityLabel="Message"') && row.indexOf('accessibilityLabel="Message"') < row.indexOf('Add smile emoji') && row.indexOf('Add smile emoji') < row.indexOf('Send message'), 'order: +, text bar, emoji, send');
  assert.doesNotMatch(screen, /Free messaging ·/, 'no extra text line under the composer');
});

test('Build 65: Report user and Block user are in every personal chat, and shown when a stranger writes first', () => {
  assert.match(screen, /label="Report, block or mute"/);
  assert.match(screen, /label="Report user"/);
  assert.match(screen, /label="Block user"/);
  assert.match(screen, /messaging\('report-user',\{uid:row\.peerId,reason\}\)/);
  assert.match(screen, /messaging\('block',\{uid:row\.peerId,blocked:true\}\)\.then\(onBack/);
  assert.match(screen, /Don’t know this person\? You can report or block them any time\./);
  assert.match(screen, /feed\.rows\.some\(m=>m\.senderId!==uid\)&&!feed\.rows\.some\(m=>m\.senderId===uid\)/, 'shown only while they have written and you have not replied');
});

test('Build 65: the Inbox has a + button for a new message or group, and new messages offer friends without a search', () => {
  assert.match(screen, /accessibilityLabel=\{plus\?'Close new message menu':'Start a new message or group'\}/);
  assert.match(screen, /accessibilityLabel="New message"[\s\S]*?setMode\('find'\)/);
  assert.match(screen, /accessibilityLabel="New group"[\s\S]*?setMode\('create'\)/);
  assert.match(screen, /function FriendsList/);
  assert.match(screen, /messaging\('connections',\{uid,list/);
  assert.match(screen, /suggestions=\{<FriendsList/);
  assert.match(screen, /startWithPerson/);
});

test('Build 65: the Inbox tab no longer adds a second status-bar gap under the app header', () => {
  assert.match(screen, /edges=\{embedded\?\['left','right'\]:undefined\}/);
  assert.match(read('App.tsx'), /<MessagingScreen embedded /);
  assert.doesNotMatch(read('src/CommunityScreen.tsx'), /<MessagingScreen embedded/, 'the full-screen version keeps its top inset');
});

test('Build 65: a failed upload shows the server’s own reason; generic network errors keep the generic text', () => {
  const specific = {code: 'functions/unavailable', message: 'Photo and file sharing is not available yet. You can still send text messages.'};
  assert.equal(communityError(specific), specific.message);
  const generic = 'Could not reach the Community service. Check your connection and try again.';
  assert.equal(communityError({code: 'functions/unavailable', message: 'unavailable'}), generic);
  assert.equal(communityError({code: 'functions/deadline-exceeded', message: 'deadline-exceeded'}), generic);
  assert.equal(communityError({code: 'functions/unavailable', message: ''}), generic);
});

test('Build 65: the backend logs why an upload failed and opens chats directly', () => {
  const attachments = read('functions/src/chatAttachments.ts'), messaging = read('functions/src/messaging.ts');
  assert.match(attachments, /logger\.error\('chat attachment upload failed'/);
  assert.match(attachments, /Photo and file sharing is not available yet/);
  assert.match(messaging, /Build 65: no message requests/);
  assert.match(messaging, /status:'active',roles:\{\}/);
  assert.match(messaging, /legacyPending/);
});
