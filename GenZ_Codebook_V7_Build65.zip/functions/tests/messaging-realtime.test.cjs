// Official emulator integration: real SDK listeners, rules, callable router and pagination.
const {test}=require('node:test'),assert=require('node:assert/strict'),{readFileSync}=require('node:fs');
const {initializeTestEnvironment,assertFails}=require('@firebase/rules-unit-testing');
const client=require('firebase/firestore');
const {initializeApp,deleteApp}=require('firebase-admin/app'),{getFirestore,Timestamp}=require('firebase-admin/firestore');
const {messagingAction}=require('../lib/messaging');
const {communityFeature}=require('../lib/communityEndpoints');
function observe(ref,predicate){return new Promise((resolve,reject)=>{let stop=()=>{},timer=setTimeout(()=>{stop();reject(new Error('Realtime listener timed out'));},15000);stop=client.onSnapshot(ref,s=>{if(predicate(s)){clearTimeout(timer);stop();resolve(s);}},e=>{clearTimeout(timer);stop();reject(e);});});}
test('messaging emulator: callable route, two-client delivery, unread/read receipts, pagination and membership revocation',async()=>{
 const env=await initializeTestEnvironment({projectId:'demo-genz-feature-core',firestore:{rules:readFileSync(require.resolve('../../firebase/firestore.rules'),'utf8')}});
 const app=initializeApp({projectId:'demo-genz-feature-core'}),db=getFirestore(app);
 const a='realtime-a',b='realtime-b',x='realtime-outsider',auth=uid=>({uid,token:{email_verified:true}});
 const call=(uid,command,data={})=>messagingAction(db,{command,...data},auth(uid));
 try{
  for(const uid of [a,b,x]){await db.doc('users/'+uid).set({status:'active'});await db.doc('publicProfiles/'+uid).set({name:uid,avatar:0});}
  const alice=env.authenticatedContext(a,{email_verified:true}).firestore(),bob=env.authenticatedContext(b,{email_verified:true}).firestore(),stranger=env.authenticatedContext(x,{email_verified:true}).firestore();
  const {id}=await communityFeature.run({auth:auth(a),data:{action:'messaging',command:'request',uid:b}});
  const messageQuery=client.query(client.collection(bob,'conversations',id,'messages'),client.where('createdAt','>=',client.Timestamp.fromMillis(0)),client.orderBy('createdAt','desc'),client.limit(40));
  const arrived=observe(messageQuery,s=>s.docs.some(d=>d.id==='live-first')),unread=observe(client.doc(bob,'users',b,'inbox',id),s=>s.get('unread')===1);
  await call(a,'send',{conversationId:id,text:'Live message 😊',requestId:'live-first'});await Promise.all([arrived,unread]);
  await assertFails(client.getDoc(client.doc(stranger,'conversations',id,'messages','live-first')));
  const receipt=observe(client.doc(alice,'conversations',id,'receipts',b),s=>!!s.get('readAt'));await call(b,'read',{conversationId:id});await receipt;
  assert.equal((await client.getDoc(client.doc(bob,'users',b,'inbox',id))).get('unread'),0);
  const batch=db.batch();for(let i=0;i<85;i++)batch.set(db.doc(`conversations/${id}/messages/page-${String(i).padStart(3,'0')}`),{senderId:a,name:a,text:'Page '+i,createdAt:Timestamp.fromMillis(Date.now()+i+10),removed:false});await batch.commit();
  const first=await client.getDocs(messageQuery),second=await client.getDocs(client.query(messageQuery,client.startAfter(first.docs.at(-1))));assert.equal(first.size,40);assert.equal(second.size,40);assert.equal(new Set([...first.docs,...second.docs].map(d=>d.id)).size,80);
  const group=await call(a,'create-group',{name:'Realtime group',description:'',privacy:'private',requestId:'live-group'});await call(a,'invite',{conversationId:group.id,uid:b});await call(b,'respond-invite',{conversationId:group.id,accept:true});
  const membership=client.doc(bob,'conversations',group.id);await client.getDoc(membership);await call(a,'group-member',{conversationId:group.id,uid:b,role:'remove'});await assertFails(client.getDoc(membership));
 }finally{await env.cleanup();await deleteApp(app);}
});
