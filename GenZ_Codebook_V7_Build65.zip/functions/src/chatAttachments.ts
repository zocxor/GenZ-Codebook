import {isUtf8} from 'node:buffer';
import {createHash} from 'node:crypto';
import {Timestamp,type Firestore} from 'firebase-admin/firestore';
import {getStorage} from 'firebase-admin/storage';
import {HttpsError} from 'firebase-functions/v2/https';
import {logger} from 'firebase-functions/v2';

import {CHAT_ATTACHMENT_LIMIT,CHAT_ATTACHMENT_DAYS,CHAT_FILE_TYPES,chatFileType} from './validation/chatAttachments';

const RETENTION=CHAT_ATTACHMENT_DAYS*86400000;
const expiryJobs='chatAttachmentExpiry';
const bucket=()=>getStorage().bucket('gen-z-code-55caf.firebasestorage.app');
const digest=(value:Buffer|string)=>createHash('sha256').update(value).digest('hex');
const status=(error:unknown)=>(error as {code?:number})?.code;

const frameMarkers=new Set([0xc0,0xc1,0xc2]);
function supportedDimensions(bytes:Buffer):boolean {
 let offset=2;
 while(offset+4<bytes.length&&bytes[offset++]===0xff){
  while(bytes[offset]===0xff)offset++;
  const marker=bytes[offset++]!;
  if(marker===0xda||marker===0xd9||offset+2>bytes.length)return false;
  const segment=bytes.readUInt16BE(offset);
  if(segment<2||offset+segment>bytes.length)return false;
  if(frameMarkers.has(marker)){
   if(segment<8||bytes[offset+2]!==8)return false;
   const height=bytes.readUInt16BE(offset+3),width=bytes.readUInt16BE(offset+5);
   return height>0&&height<=1280&&width>0&&width<=1280;
  }
  offset+=segment;
 }
 return false;
}

function decode(value:unknown):Buffer {
 if(typeof value!=='string'||value.length>Math.ceil(CHAT_ATTACHMENT_LIMIT/3)*4||!(/^[A-Za-z0-9+/]+={0,2}$/).test(value)){
  throw new HttpsError('invalid-argument','Choose an attachment under 1 MB.');
 }
 const bytes=Buffer.from(value,'base64');
 if(!bytes.length||bytes.length>=CHAT_ATTACHMENT_LIMIT)throw new HttpsError('invalid-argument','Choose an attachment under 1 MB.');
 return bytes;
}

export function decodeChatPhoto(value:unknown):Buffer {
 const bytes=decode(value);
 if(bytes.length<5||bytes[0]!==0xff||bytes[1]!==0xd8||bytes[2]!==0xff||bytes.at(-2)!==0xff||bytes.at(-1)!==0xd9||!supportedDimensions(bytes)){
  throw new HttpsError('invalid-argument','Choose a JPEG photo under 1 MB with sides of up to 1,280 pixels.');
 }
 return bytes;
}

function isOfficePackage(bytes:Buffer,required:string):boolean {
 if(bytes.length<22||bytes.readUInt32LE(0)!==0x04034b50)return false;
 const end=bytes.lastIndexOf(Buffer.from([80,75,5,6]));
 if(end<0||end+22>bytes.length||end+22+bytes.readUInt16LE(end+20)!==bytes.length)return false;
 const entries=bytes.readUInt16LE(end+10),offset=bytes.readUInt32LE(end+16);
 if(!entries||entries>2048||offset+bytes.readUInt32LE(end+12)!==end)return false;
 let pos=offset,total=0,hasTypes=false,hasDocument=false;
 for(let index=0;index<entries;index++){
  if(pos+46>end||bytes.readUInt32LE(pos)!==0x02014b50||(bytes.readUInt16LE(pos+8)&1))return false;
  const size=bytes.readUInt16LE(pos+28);
  const next=pos+46+size+bytes.readUInt16LE(pos+30)+bytes.readUInt16LE(pos+32);
  if(next>end)return false;
  const entry=bytes.toString('utf8',pos+46,pos+46+size);
  if(entry.toLowerCase().endsWith('vbaproject.bin'))return false;
  total+=bytes.readUInt32LE(pos+24);
  if(total>50_000_000)return false;
  hasTypes ||= entry==='[Content_Types].xml';
  hasDocument ||= entry===required;
  pos=next;
 }
 return pos===end&&hasTypes&&hasDocument;
}

export function decodeChatFile(name:unknown,value:unknown){
 if(typeof name!=='string'||name.length>120||name!==name.trim()||!name.includes('.')
   ||/[/\\:*?"<>|\x00-\x1f\x7f\u202a-\u202e\u2066-\u2069]/u.test(name)){
  throw new HttpsError('invalid-argument','Choose a file with a valid name.');
 }
 const format=chatFileType(name);
 if(!format)throw new HttpsError('invalid-argument','Choose a PDF, Word, Excel, PowerPoint, or text file.');
 const bytes=decode(value);
 const officeEntry={docx:'word/document.xml',xlsx:'xl/workbook.xml',pptx:'ppt/presentation.xml'} as const;
 const valid=format==='pdf'?bytes.subarray(0,5).toString('ascii')==='%PDF-'
  :format==='txt'?(!bytes.includes(0)&&isUtf8(bytes))
  :isOfficePackage(bytes,officeEntry[format]);
 if(!valid)throw new HttpsError('invalid-argument','The file contents do not match its extension.');
 return {name,bytes,contentType:CHAT_FILE_TYPES[format]};
}

function attachmentPath(cid:string,uid:string,mid:string){
 return 'chat-attachments/'+digest(JSON.stringify([cid,uid,mid]));
}

export const chatAttachments={
 async save(db:Firestore,cid:string,uid:string,mid:string,bytes:Buffer,now:number,contentType='image/jpeg'){
  const path=attachmentPath(cid,uid,mid),sha=digest(Buffer.concat([Buffer.from(contentType+'\0'),bytes])),job=db.doc(expiryJobs+'/'+digest(path));
  try{await job.create({path,sha,expiresAt:Timestamp.fromMillis(now+RETENTION)});}
  catch(error){if(status(error)!==6)throw error;}
  const record=await job.get(),expiresAt=record.get('expiresAt')?.toMillis();
  if(record.get('sha')!==sha||!(expiresAt>now))throw new HttpsError('failed-precondition','Pick the attachment again to start a new upload.');
  const file=bucket().file(path);
  try{
   await file.save(bytes,{resumable:false,contentType,preconditionOpts:{ifGenerationMatch:0}});
  }catch(error){
   if(status(error)===412)return expiresAt as number;
   // Build 65: record WHY in the Cloud Functions log (404 = the bucket does not exist / Storage is not set up, 403 = missing permission).
   logger.error('chat attachment upload failed',{bucket:bucket().name,code:status(error),message:(error as Error)?.message});
   await job.delete().catch(()=>undefined);
   throw new HttpsError('unavailable',status(error)===404||status(error)===403?'Photo and file sharing is not available yet. You can still send text messages.':'Attachment upload could not complete. Try again.');
  }
  return expiresAt as number;
 },
 async read(cid:string,uid:string,mid:string){
  try{
   const [bytes]=await bucket().file(attachmentPath(cid,uid,mid)).download();
   return bytes.toString('base64');
  }catch(error){
   if(status(error)===404)throw new HttpsError('not-found','This attachment is no longer available.');
   throw new HttpsError('unavailable','Attachment could not load. Try again.');
  }
 },
};

export async function purgeExpiredChatAttachments(db:Firestore,now=Date.now()){
 const jobs=await db.collection(expiryJobs).where('expiresAt','<=',Timestamp.fromMillis(now)).limit(200).get();
 const failed=[];
 for(let start=0;start<jobs.docs.length;start+=10){
  const batch=await Promise.allSettled(jobs.docs.slice(start,start+10).map(async job=>{
   await bucket().file(job.get('path')).delete({ignoreNotFound:true});
   await job.ref.delete();
  }));
  failed.push(...batch.filter(result=>result.status==='rejected'));
 }
 if(failed.length)throw new Error(`Could not expire ${failed.length} chat attachments`);
}
