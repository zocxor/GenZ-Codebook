import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const read = (f: string) => readFileSync(f, 'utf8');

// Google Play UGC policy: apps with 1:1 messaging and public profiles must let people report users, not only content.
test('report user: profile ⋯ menu offers Report user with reasons, separate from Block, hidden on your own profile', () => {
  // src/ugc.ts pulls in Firebase at import time, so read the list from source.
  const reasons = read('src/ugc.ts').match(/export const USER_REPORT_REASONS = \[(.*?)\] as const;/)?.[1] ?? '';
  for (const r of ['Harassment or bullying', 'Spam or scam', 'Child safety concern', 'Other']) assert.ok(reasons.includes(`'${r}'`), r);
  const screen = read('src/MessagingScreen.tsx');
  assert.match(screen, /\{person\.uid!==me&&<ProfileAction colors=\{colors\} label="Report user"/);
  assert.match(screen, /label="Block private messages"/, 'blocking stays a separate, clearly labelled action');
  assert.match(screen, /messaging\('report-user',\{uid:person\.uid,reason\}\)/);
  assert.match(screen, /They aren’t told who reported them\./);
});

test('report user: server handler, staff-only review with restrict/dismiss, and admin queue rendering', () => {
  const server = read('functions/src/messaging.ts');
  assert.match(server, /if\(action==='report-user'\)\{/);
  assert.match(server, /kind:'user',reporterId:uid,reportedUid:other/);
  assert.match(server, /actor\.messagingRestricted===true&&action!=='report-user'/, 'a restricted member can still report');
  assert.match(server, /if\(r\.kind==='user'\)\{/);
  const admin = read('admin/src/pages/Messaging.tsx');
  assert.match(admin, /r\.kind==='user'\?/);
  assert.match(admin, /Reported member/);
  assert.match(admin, /act\('admin-report',\{target:r\.id,restrict:true\}\)/);
});

test('privacy policy covers public profiles, follows and member reports', () => {
  const policy = read('admin/site/privacy.html');
  for (const text of ['Public profile: your nickname', 'Follows: who you follow and who follows you', 'The reported person is not told who reported them', 'Effective 19 November 2026']) assert.ok(policy.includes(text), text);
});

test('targeted announcements: only active notices for everyone or addressed to me, de-duplicated and tagged personal', async () => {
  const {normalizeAnnouncements} = await import('../src/announcementFeed');
  const ts = (n: number) => ({toMillis: () => n});
  const docs = [
    {id: 'all1', data: {title: 'Everyone', body: 'x', audience: 'all', active: true, createdAt: ts(100)}},
    {id: 'me1', data: {title: 'Just me', body: 'y', audience: 'users', recipients: ['me', 'sue'], active: true, createdAt: ts(300)}},
    {id: 'me1', data: {title: 'Just me', body: 'y', audience: 'users', recipients: ['me', 'sue'], active: true, createdAt: ts(300)}},
    {id: 'other', data: {title: 'Not me', body: 'z', audience: 'users', recipients: ['sue'], active: true, createdAt: ts(400)}},
  ];
  const rows = normalizeAnnouncements(docs, 'me');
  assert.deepEqual(rows.map(r => [r.id, !!r.personal]), [['me1', true], ['all1', false]]);
  assert.deepEqual(normalizeAnnouncements(docs).map(r => r.id), ['all1'], 'without a uid only everyone-notices');
  assert.match(read('src/NotificationsScreen.tsx'), /fetchAnnouncements\(user\.uid\)/);
  assert.match(read('src/NotificationsScreen.tsx'), /FOR YOU/);
  const rules = read('firebase/firestore.rules');
  assert.match(rules, /\(signedIn\(\) && request\.auth\.uid in resource\.data\.recipients\)/);
  assert.match(rules, /request\.resource\.data\.recipients\.size\(\) <= 500/);
});
