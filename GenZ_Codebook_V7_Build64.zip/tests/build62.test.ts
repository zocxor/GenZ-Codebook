import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync, readdirSync} from 'node:fs';
import {termCopyText} from '../src/termCopy';
import {normalizeAnnouncements, unreadAnnouncements, badgeText} from '../src/announcementFeed';

const read = (f: string) => readFileSync(f, 'utf8');
const term = {expression: 'rizz', full: 'charisma', meaning: 'Natural charm, especially when flirting.', example: 'He has so much rizz.', reply: 'Teach me your ways.', category: 'Social', language: 'English'};

test('codes copy: code, code + meaning and all details are plain, paste-ready text', () => {
  assert.equal(termCopyText(term, 'code'), 'rizz');
  assert.equal(termCopyText(term, 'meaning'), 'rizz (charisma): Natural charm, especially when flirting.');
  assert.equal(termCopyText(term, 'all', 'Social & internet'), [
    'rizz (charisma)',
    'Meaning: Natural charm, especially when flirting.',
    'Example: “He has so much rizz.”',
    'Reply: “Teach me your ways.”',
    'Social & internet · English',
  ].join('\n'));
  // Same long form as the code is not repeated; empty optional fields are skipped.
  assert.equal(termCopyText({expression: ' LOL ', full: 'lol', meaning: ' Laughing out loud '}, 'meaning'), 'LOL: Laughing out loud');
  assert.equal(termCopyText({expression: 'brb', full: 'be right back', meaning: ''}, 'all'), 'brb (be right back)');
});

test('codes copy: search shows a Top match copy bar and the detail page opens with copy at the top', () => {
  const dict = read('src/DictionaryScreen.tsx');
  assert.match(dict, /const top=deferred\.trim\(\)\?rows\[0\]:undefined/, 'top match only while searching');
  assert.match(dict, /TOP MATCH/);
  assert.match(dict, /<TermCopyBar term=\{top\}\/>/);
  assert.match(dict, /Details & meaning/, 'the top match opens the full code page');
  const detail = read('src/TermDetail.tsx');
  const copyAt = detail.indexOf('<TermCopyBar term={t}/>');
  assert.ok(copyAt > 0 && copyAt < detail.indexOf('The simple meaning'), 'copy bar sits above the meaning card');
  const bar = read('src/TermCopyBar.tsx');
  assert.match(bar, /Clipboard\.setStringAsync\(termCopyText\(/);
  assert.match(bar, /\['code','meaning','all'\]/);
  assert.match(bar, /kinds\.filter\(k=>k!=='all'\)\.map\(button\)\}<\/View>\n  \{button\('all'\)\}/, 'two equal buttons, then full-width Copy all details');
});

test('announcements: only active all-audience notices with text, newest first', () => {
  const ts = (n: number) => ({toMillis: () => n});
  const rows = normalizeAnnouncements([
    {id: 'a', data: {title: 'Old', body: 'x', audience: 'all', active: true, createdAt: ts(100)}},
    {id: 'b', data: {title: 'New', body: 'y', audience: 'all', active: true, createdAt: ts(300)}},
    {id: 'c', data: {title: 'Off', body: 'z', audience: 'all', active: false, createdAt: ts(400)}},
    {id: 'd', data: {title: '', body: 'no title', audience: 'all', active: true, createdAt: ts(500)}},
    {id: 'e', data: {title: 'Staff', body: 'w', audience: 'staff', active: true, createdAt: ts(600)}},
  ]);
  assert.deepEqual(rows.map(r => r.id), ['b', 'a']);
  assert.equal(unreadAnnouncements(rows, 0), 2);
  assert.equal(unreadAnnouncements(rows, 100), 1);
  assert.equal(unreadAnnouncements(rows, 300), 0);
  assert.equal(badgeText(0), '');
  assert.equal(badgeText(3), '3');
  assert.equal(badgeText(12), '9+');
});

test('announcements: the bell shows the unseen count and opening Notifications marks them seen', () => {
  const app = read('App.tsx');
  assert.match(app, /useAnnouncementBadge\(user\?\.emailVerified\?user\.uid:undefined\)/);
  assert.match(app, /unread=\{announcements\.unread\}/);
  assert.match(app, /if\(sheet==='notifications'\)announcements\.markSeen\(\)/);
  const header = read('src/AppHeader.tsx');
  assert.match(header, /badgeText\(unread\)/);
  assert.match(header, /new \$\{unread===1\?'announcement':'announcements'\}/, 'screen readers hear the count');
  const screen = read('src/NotificationsScreen.tsx');
  assert.match(screen, /fetchAnnouncements\(user\.uid\)/);
  assert.match(screen, /item\.at>newSince/, 'unseen items are tagged NEW');
  // The app's list query must keep matching the Firestore read rule (audience == 'all' && active == true).
  const lib = read('src/announcements.ts');
  assert.match(lib, /where\('audience','==','all'\),where\('active','==',true\)/);
  assert.match(lib, /where\('recipients','array-contains',uid\)/, 'Build 63: notices addressed to this user');
  const rules = read('firebase/firestore.rules');
  assert.match(rules, /signedIn\(\) && resource\.data\.audience == 'all' && resource\.data\.active == true/);
});

test('private messaging: every command the app sends has a server handler', () => {
  const server = read('functions/src/messaging.ts');
  const handled = new Set([...server.matchAll(/action==='([a-z0-9-]+)'/g)].map(m => m[1]));
  const files = ['App.tsx', ...readdirSync('src').filter(f => /\.tsx?$/.test(f)).map(f => `src/${f}`)];
  const sent = new Set<string>();
  for (const f of files) {
    const src = read(f);
    for (const m of src.matchAll(/\bmessaging\('([a-z0-9-]+)'/g)) sent.add(m[1]!);
    if (f === 'src/MessagingScreen.tsx') for (const m of src.matchAll(/\b(?:call|act|onCall)\('([a-z0-9-]+)'/g)) sent.add(m[1]!);
  }
  assert.ok(sent.size >= 20, `found ${sent.size} client messaging commands`);
  for (const c of sent) assert.ok(handled.has(c), `app sends messaging command '${c}' but functions/src/messaging.ts has no handler`);
});
