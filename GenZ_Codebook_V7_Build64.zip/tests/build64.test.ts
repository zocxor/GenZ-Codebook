import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const read = (f: string) => readFileSync(f, 'utf8');

test('nav bar: no light fade strip above the dock (it showed as a blurry line over dark screens)', () => {
  const nav = read('src/NavBar.tsx');
  assert.doesNotMatch(nav, /colors=\{\['#F3F6FE00', C\.bg\]\}/);
  assert.doesNotMatch(nav, /fade: \{position: 'absolute'/);
  assert.match(nav, /<View style=\{s\.wrap\} accessibilityRole="tablist">/, 'the dock itself is unchanged');
});

test('profile Slangs / Codes / Posts cards: brighter fills only on the dark profile; light keeps the approved tiles', () => {
  const p = read('src/SocialProfile.tsx');
  for (const t of ["from:'#46118D',to:'#26084E'", "from:'#06558D',to:'#062553'", "from:'#8F1D2C',to:'#420B17'"]) assert.ok(p.includes(t), `light ${t}`);
  for (const t of ["darkFrom:'#6E45C9',darkTo:'#3B1F7A'", "darkFrom:'#2F67C2',darkTo:'#16386F'", "darkFrom:'#B23A48',darkTo:'#6B1A26'"]) assert.ok(p.includes(t), `dark ${t}`);
  assert.match(p, /colors=\{colors\.dark\?\[item\.darkFrom,item\.darkTo\]:\[item\.from,item\.to\]\}/);
  assert.match(p, /activityIconChip/);
  // No outline on just the selected card (it looked like a stray white line on Codes); the tab bar shows the open tab.
  assert.match(p, /style=\{\[styles\.activityCard,colors\.dark&&styles\.activityCardDark\]\}>/);
  assert.match(p, /accessibilityState=\{\{selected:tab===item\.label\}\}/);
});

test('profile: highlighted Get Premium (gold) and Buy Credits (blue) under Credits; Premium opens the shop at Premium', () => {
  const p = read('src/ProfileDashboard.tsx'), app = read('App.tsx'), shop = read('src/TokenShopScreen.tsx');
  assert.doesNotMatch(p, /<Row title="Buy Credits &amp; Premium"/, 'the plain settings row is replaced');
  assert.match(p, /colors=\{\['#FFE07A','#F5B82E','#E39A12'\]\}/);
  assert.match(p, /premium\?'Premium active':'Get Premium'/);
  assert.match(p, /accessibilityLabel="Buy Credits" onPress=\{\(\)=>onOpen\('shop'\)\}/);
  assert.match(app, /onPremium=\{\(\)=>\{setShopFocus\('premium'\);openSheet\('shop'\);\}\}/);
  assert.match(app, /<TokenShopScreen tokens=\{state\.tokens\} focus=\{shopFocus\}/);
  assert.match(app, /if\(sheet!=='shop'\)setShopFocus\(undefined\)/, 'other ways in open the shop at the top');
  assert.match(shop, /<View onLayout=\{e=>premiumLaidOut\(e\.nativeEvent\.layout\.y\)\}><SectionHeader eyebrow="SUBSCRIPTION" title="Premium"\/><\/View>/);
});
