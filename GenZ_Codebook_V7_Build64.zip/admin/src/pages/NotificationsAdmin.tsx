import React, {useEffect, useState} from 'react';
import {Timestamp, collection, doc, getDoc, getDocs, limit, orderBy, query, serverTimestamp, where} from 'firebase/firestore/lite';
import {db, newBatch, addAudit, errorMessage} from '../firebase';
import {useSession} from '../App';
import {Card, Notice, Field} from '../ui';
import {classifyUserSearch} from '../lib/userSearch';
import {MAX_RECIPIENTS, CUSTOM_DAYS, addRecipient, announcementPayload, audienceSummary, customLabel, customRecipients, type AudienceMode, type CustomKind, type Recipient} from '../lib/notifyAudience';

type SentNotice = {id: string; title: string; body: string; at: string; label: string; count: number};

const MODES: {id: AudienceMode; label: string; hint: string}[] = [
  {id: 'all', label: 'All users', hint: 'Everyone who is signed in with a verified e-mail.'},
  {id: 'selected', label: 'Selected users', hint: `Pick people by user code, e-mail or user ID (up to ${MAX_RECIPIENTS}).`},
  {id: 'custom', label: 'Custom group', hint: 'Recently active or recently joined users, optionally one app version.'},
];

/** Resolve one search to accounts: user code → owner, user ID → that account, e-mail → up to 10 prefix matches. */
async function findUsers(raw: string): Promise<Recipient[]> {
  const found = classifyUserSearch(raw);
  if (found.kind === 'invalid') throw new Error('Enter a user code (GZ…), an e-mail address or a user ID.');
  if (found.kind === 'referral') {
    const ref = await getDoc(doc(db, 'referrals', found.code));
    const uid = ref.exists() ? String((ref.data() as {uid?: unknown}).uid ?? '') : '';
    if (!uid || !(await getDoc(doc(db, 'users', uid))).exists()) throw new Error('No account with that user code.');
    return [{uid, label: found.code}];
  }
  const byEmail = async (prefix: string) => {
    const snap = await getDocs(query(collection(db, 'directory'), where('email', '>=', prefix), where('email', '<=', prefix + ''), limit(10)));
    return snap.docs.map(d => ({uid: d.id, label: String(d.data().email ?? d.id)}));
  };
  if (found.kind === 'userId') {
    if ((await getDoc(doc(db, 'users', found.id))).exists()) return [{uid: found.id, label: found.id}];
    const rows = await byEmail(found.id.toLowerCase());
    if (!rows.length) throw new Error('No account with that user ID or e-mail.');
    return rows;
  }
  const rows = await byEmail(found.prefix);
  if (!rows.length) throw new Error('No account with that e-mail.');
  return rows;
}

export default function NotificationsAdmin() {
  const admin = useSession();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<{kind: 'ok' | 'error'; text: string} | null>(null);
  const [history, setHistory] = useState<SentNotice[]>([]);
  const [confirmed, setConfirmed] = useState(false);
  const [mode, setMode] = useState<AudienceMode>('all');
  // Selected users
  const [search, setSearch] = useState(''), [matches, setMatches] = useState<Recipient[]>([]), [picked, setPicked] = useState<Recipient[]>([]), [pickNote, setPickNote] = useState('');
  // Custom group
  const [kind, setKind] = useState<CustomKind>('active'), [days, setDays] = useState<number>(7), [version, setVersion] = useState('');
  const [group, setGroup] = useState<{uids: string[]; matched: number; capped: boolean; label: string} | null>(null);

  const recipients = mode === 'selected' ? picked.map(p => p.uid) : mode === 'custom' ? group?.uids ?? [] : [];
  const label = mode === 'custom' ? group?.label ?? customLabel(kind, days, version) : mode === 'selected' ? `Selected users (${picked.length})` : 'All users';
  const summary = audienceSummary(mode, recipients.length, label);
  const unconfirm = () => setConfirmed(false);

  const reload = async () => {
    try {
      const data = await getDocs(query(collection(db, 'adminAnnouncements'), orderBy('createdAt', 'desc'), limit(20)));
      setHistory(data.docs.map(d => {
        const v = d.data();
        return {id: d.id, title: String(v.title ?? ''), body: String(v.body ?? ''), at: v.createdAt?.toDate?.().toLocaleString?.() ?? 'Recent',
          label: String(v.audienceLabel ?? (v.audience === 'all' ? 'All users' : 'Selected users')), count: Array.isArray(v.recipients) ? v.recipients.length : 0};
      }));
    } catch (e) {setStatus({kind: 'error', text: errorMessage(e)});}
  };
  useEffect(() => {void reload();}, []);

  const lookUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!search.trim()) return;
    setBusy(true); setPickNote(''); setMatches([]);
    try {
      const rows = await findUsers(search);
      if (rows.length === 1) {const r = addRecipient(picked, rows[0]!); setPicked(r.list); setPickNote(r.error ?? `${rows[0]!.label} added.`); setSearch(''); unconfirm();}
      else setMatches(rows);
    } catch (err) {setPickNote(err instanceof Error ? err.message : errorMessage(err));} finally {setBusy(false);}
  };
  const pick = (r: Recipient) => {const next = addRecipient(picked, r); setPicked(next.list); setPickNote(next.error ?? `${r.label} added.`); setMatches(m => m.filter(x => x.uid !== r.uid)); unconfirm();};

  const findGroup = async () => {
    setBusy(true); setStatus(null); setGroup(null); unconfirm();
    try {
      const field = kind === 'active' ? 'lastActiveAt' : 'createdAt', now = Date.now();
      // Uses the existing (status, lastActiveAt|createdAt DESC) indexes. Newest 1,000 are checked; up to 500 are sent.
      const snap = await getDocs(query(collection(db, 'users'), where('status', '==', 'active'), where(field, '>=', Timestamp.fromMillis(now - days * 86_400_000)), orderBy(field, 'desc'), limit(1000)));
      const rows = snap.docs.map(d => {const v = d.data(); return {uid: d.id, status: String(v.status ?? ''), appVersion: typeof v.appVersion === 'string' ? v.appVersion : '', at: v[field]?.toMillis?.() ?? 0};});
      const result = customRecipients(rows, {days, version, now});
      setGroup({...result, label: customLabel(kind, days, version)});
    } catch (e) {setStatus({kind: 'error', text: errorMessage(e)});} finally {setBusy(false);}
  };

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmed) return;
    const payload = announcementPayload({title, body, mode, recipients, label});
    if (!payload.ok) {setStatus({kind: 'error', text: payload.error}); return;}
    setBusy(true); setStatus(null);
    try {
      const b = newBatch();
      const ref = doc(collection(db, 'adminAnnouncements'));
      const auditId = addAudit(b, admin.uid, admin.role, 'notification.send', `adminAnnouncements/${ref.id}`, `In-app announcement to ${summary}: ${payload.data.title.slice(0, 90)}`.slice(0, 300));
      b.set(ref, {...payload.data, active: true, createdAt: serverTimestamp(), createdBy: admin.uid, lastAuditId: auditId});
      await b.commit();
      setStatus({kind: 'ok', text: `Announcement published to ${summary}. They see a red badge on the bell (app Build 62 or newer; refreshed when they open or return to the app, and every 15 minutes) and the message under Notifications → Announcements.`});
      setTitle(''); setBody(''); setConfirmed(false);
      await reload();
    } catch (err) {setStatus({kind: 'error', text: errorMessage(err)});} finally {setBusy(false);}
  };

  const ready = confirmed && !!title.trim() && !!body.trim() && (mode === 'all' || recipients.length > 0);
  return <div className="stack">
    {status && <Notice kind={status.kind} onClose={() => setStatus(null)}>{status.text}</Notice>}
    <Card title="Send an in-app notification" subtitle="Super Admin only · to all users, selected users or a custom group" index={0}>
      <Notice kind="info">These are in-app announcements, not Android push notifications. No SMS, e-mail or system notification is sent.</Notice>
      <form onSubmit={e => void send(e)} className="stack">
        <div className="field"><span>Send to</span>
          <div className="row wrap" role="radiogroup" aria-label="Send to">
            {MODES.map(m => <button key={m.id} type="button" role="radio" aria-checked={mode === m.id} className={`btn ${mode === m.id ? 'primary' : ''}`} onClick={() => {setMode(m.id); unconfirm();}}>{m.label}</button>)}
          </div>
          <small className="muted">{MODES.find(m => m.id === mode)!.hint}</small>
        </div>

        {mode === 'selected' && <div className="note stack" style={{padding: 14}}>
          <div className="row wrap" style={{alignItems: 'flex-end'}}>
            <Field label="Find a person"><input value={search} onChange={e => setSearch(e.target.value)} placeholder="GZABC123, name@example.com or user ID" onKeyDown={e => {if (e.key === 'Enter') void lookUp(e);}} /></Field>
            <button type="button" className="btn" disabled={busy || !search.trim()} onClick={e => void lookUp(e)}>{busy ? 'Searching…' : 'Add'}</button>
          </div>
          {!!pickNote && <small className="muted" role="status">{pickNote}</small>}
          {matches.length > 0 && <div className="stack"><small className="muted">Several accounts match — choose:</small>{matches.map(m => <div key={m.uid} className="row" style={{justifyContent: 'space-between'}}><span>{m.label} <small className="muted">· {m.uid}</small></span><button type="button" className="btn" onClick={() => pick(m)}>Add</button></div>)}</div>}
          <div className="row wrap" aria-label="Selected people">
            {picked.length === 0 ? <small className="muted">Nobody selected yet.</small> : picked.map(p => <span key={p.uid} className="pill pill-info">{p.label} <button type="button" className="link" aria-label={`Remove ${p.label}`} onClick={() => {setPicked(list => list.filter(x => x.uid !== p.uid)); unconfirm();}}>✕</button></span>)}
          </div>
          <small className="muted">{picked.length} of {MAX_RECIPIENTS} selected</small>
        </div>}

        {mode === 'custom' && <div className="note stack" style={{padding: 14}}>
          <div className="row wrap" style={{alignItems: 'flex-end'}}>
            <Field label="Who"><select value={kind} onChange={e => {setKind(e.target.value as CustomKind); setGroup(null); unconfirm();}}><option value="active">Active in the last…</option><option value="joined">Joined in the last…</option></select></Field>
            <Field label="Days"><select value={days} onChange={e => {setDays(Number(e.target.value)); setGroup(null); unconfirm();}}>{CUSTOM_DAYS.map(d => <option key={d} value={d}>{d === 1 ? '1 day' : `${d} days`}</option>)}</select></Field>
            <Field label="App version (optional)"><input value={version} maxLength={20} onChange={e => {setVersion(e.target.value); setGroup(null); unconfirm();}} placeholder="e.g. 1.0.1" /></Field>
            <button type="button" className="btn" disabled={busy} onClick={() => void findGroup()}>{busy ? 'Finding…' : 'Find matching users'}</button>
          </div>
          {group && <small className="muted" role="status">{group.matched === 0 ? 'No active accounts match. Try a longer window or remove the version.' : `${group.label}: ${group.matched} ${group.matched === 1 ? 'user' : 'users'} match${group.capped ? ` — the newest ${MAX_RECIPIENTS} will receive it` : ''}.`}</small>}
        </div>}

        <Field label="Notification title"><input required maxLength={100} value={title} onChange={e => {setTitle(e.target.value); unconfirm();}} placeholder="Important update" /></Field>
        <Field label="Message"><textarea required maxLength={500} rows={4} value={body} onChange={e => {setBody(e.target.value); unconfirm();}} placeholder="Write your announcement here…" /></Field>
        <div className="card" style={{padding: 14}}><strong>Preview</strong> <span className="pill">To: {mode === 'all' ? 'All users' : summary}</span><h3 style={{margin: '8px 0 4px'}}>{title.trim() || 'Your notification title'}</h3><p className="muted" style={{whiteSpace: 'pre-wrap'}}>{body.trim() || 'Your message will appear here.'}</p></div>
        <label className="row"><input type="checkbox" checked={confirmed} disabled={mode !== 'all' && recipients.length === 0} onChange={e => setConfirmed(e.target.checked)} /> I confirm sending this announcement to {summary}.</label>
        <button className="btn primary" disabled={busy || !ready} type="submit">{busy ? 'Publishing…' : 'Publish notification'}</button>
      </form>
    </Card>
    <Card title="Recent announcements" subtitle="Latest 20 published messages · read-only history" index={1}>
      {history.length === 0 ? <p className="muted">No announcements sent yet.</p> : history.map(item => <div key={item.id} style={{padding: '12px 0', borderBottom: '1px solid var(--line, #ddd)'}}><strong>{item.title}</strong> <span className="pill">{item.label}{item.count ? ` · ${item.count}` : ''}</span><p className="muted">{item.body}</p><small className="muted">{item.at}</small></div>)}
      <button className="btn" type="button" onClick={() => void reload()}>Refresh history</button>
    </Card>
  </div>;
}
