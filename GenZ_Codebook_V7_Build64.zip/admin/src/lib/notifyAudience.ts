/**
 * Who an admin in-app announcement goes to (Build 63). Pure — no Firebase — and unit-tested.
 *
 *  - all:      every signed-in, verified user (audience 'all', no recipient list)
 *  - selected: people the Super Admin picks one by one (user code, e-mail or user ID)
 *  - custom:   a group built from account fields: active in / joined in the last N days,
 *              optionally only one app version
 *
 * Selected and custom both store audience 'users' with an explicit `recipients` list of
 * user IDs, so each person can only read announcements addressed to them (Firestore rules).
 */
export type AudienceMode = 'all' | 'selected' | 'custom';
export type CustomKind = 'active' | 'joined';
export type Recipient = {uid: string; label: string};

/** Hard cap per announcement; matches firestore.rules (recipients.size() <= 500). */
export const MAX_RECIPIENTS = 500;
export const CUSTOM_DAYS = [1, 7, 30, 90] as const;
const UID_RE = /^[A-Za-z0-9_-]{6,128}$/;

export function customLabel(kind: CustomKind, days: number, version = ''): string {
  const window = days === 1 ? 'the last day' : `the last ${days} days`;
  const base = kind === 'active' ? `Active in ${window}` : `Joined in ${window}`;
  const v = version.trim();
  return (v ? `${base} · app ${v}` : base).slice(0, 80);
}

/** Add a picked person once; refuses beyond the cap. */
export function addRecipient(list: Recipient[], next: Recipient): {list: Recipient[]; error?: string} {
  if (!UID_RE.test(next.uid)) return {list, error: 'That account ID is not valid.'};
  if (list.some(r => r.uid === next.uid)) return {list, error: `${next.label} is already selected.`};
  if (list.length >= MAX_RECIPIENTS) return {list, error: `You can select up to ${MAX_RECIPIENTS} people per announcement.`};
  return {list: [...list, next]};
}

type UserLite = {uid: string; status?: string; appVersion?: string; at?: number};

/** Custom group from rows already fetched newest-first; returns the IDs (capped) and how many matched. */
export function customRecipients(rows: UserLite[], opts: {days: number; version?: string; now: number}): {uids: string[]; matched: number; capped: boolean} {
  const cutoff = opts.now - opts.days * 86_400_000, v = (opts.version ?? '').trim();
  const seen = new Set<string>(), uids: string[] = [];
  let matched = 0;
  for (const r of rows) {
    if (!UID_RE.test(r.uid) || seen.has(r.uid)) continue;
    if (r.status !== undefined && r.status !== 'active') continue;
    if (typeof r.at !== 'number' || r.at < cutoff) continue;
    if (v && (r.appVersion ?? '') !== v) continue;
    seen.add(r.uid); matched++;
    if (uids.length < MAX_RECIPIENTS) uids.push(r.uid);
  }
  return {uids, matched, capped: matched > uids.length};
}

/** Validated Firestore payload fields (without timestamps / audit), or an error to show. */
export function announcementPayload(input: {title: string; body: string; mode: AudienceMode; recipients: string[]; label: string}):
  {ok: true; data: {title: string; body: string; audience: 'all' | 'users'; audienceLabel: string; recipients?: string[]}} | {ok: false; error: string} {
  const title = input.title.trim().slice(0, 100), body = input.body.trim().slice(0, 500);
  if (!title || !body) return {ok: false, error: 'Add a title and a message.'};
  if (input.mode === 'all') return {ok: true, data: {title, body, audience: 'all', audienceLabel: 'All users'}};
  const recipients = [...new Set(input.recipients)].filter(u => UID_RE.test(u));
  if (!recipients.length) return {ok: false, error: input.mode === 'selected' ? 'Select at least one person.' : 'Find matching users first — this group is empty.'};
  if (recipients.length > MAX_RECIPIENTS) return {ok: false, error: `Up to ${MAX_RECIPIENTS} people per announcement.`};
  const label = (input.label.trim() || (input.mode === 'selected' ? 'Selected users' : 'Custom group')).slice(0, 80);
  return {ok: true, data: {title, body, audience: 'users', audienceLabel: label, recipients}};
}

/** Human summary for the confirm line and history ("All users", "3 selected users", "Active in the last 7 days (120 users)"). */
export function audienceSummary(mode: AudienceMode, count: number, label: string): string {
  if (mode === 'all') return 'all signed-in users';
  if (mode === 'selected') return `${count} selected ${count === 1 ? 'user' : 'users'}`;
  return `${label} (${count} ${count === 1 ? 'user' : 'users'})`;
}
