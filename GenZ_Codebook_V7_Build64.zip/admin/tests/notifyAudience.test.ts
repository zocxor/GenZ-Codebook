import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {MAX_RECIPIENTS, addRecipient, announcementPayload, audienceSummary, customLabel, customRecipients} from '../src/lib/notifyAudience';

test('all users: no recipient list is stored', () => {
  const p = announcementPayload({title: ' Hi ', body: ' New codes ', mode: 'all', recipients: ['ignored-uid'], label: ''});
  assert.deepEqual(p, {ok: true, data: {title: 'Hi', body: 'New codes', audience: 'all', audienceLabel: 'All users'}});
});

test('selected users: unique valid IDs, at least one, at most 500', () => {
  assert.equal(announcementPayload({title: 'a', body: 'b', mode: 'selected', recipients: [], label: ''}).ok, false);
  const p = announcementPayload({title: 'a', body: 'b', mode: 'selected', recipients: ['userAAAA1', 'userAAAA1', 'bad id!', 'userBBBB2'], label: 'Selected users (2)'});
  assert.ok(p.ok && p.data.audience === 'users');
  assert.deepEqual(p.ok && p.data.recipients, ['userAAAA1', 'userBBBB2']);
  const tooMany = Array.from({length: MAX_RECIPIENTS + 1}, (_, i) => `user${String(i).padStart(6, '0')}`);
  assert.equal(announcementPayload({title: 'a', body: 'b', mode: 'selected', recipients: tooMany, label: ''}).ok, false);
  let list = [{uid: 'userAAAA1', label: 'a@x.com'}];
  assert.match(addRecipient(list, {uid: 'userAAAA1', label: 'a@x.com'}).error ?? '', /already selected/);
  list = addRecipient(list, {uid: 'userBBBB2', label: 'GZABC123'}).list;
  assert.equal(list.length, 2);
});

test('custom group: window, active status and optional app version; capped at 500', () => {
  const now = Date.UTC(2026, 10, 19), day = 86_400_000;
  const rows = [
    {uid: 'recent0001', status: 'active', appVersion: '1.0.1', at: now - day},
    {uid: 'recent0002', status: 'active', appVersion: '1.0.0', at: now - 3 * day},
    {uid: 'oldone0003', status: 'active', appVersion: '1.0.1', at: now - 40 * day},
    {uid: 'suspend004', status: 'suspended', appVersion: '1.0.1', at: now - day},
  ];
  assert.deepEqual(customRecipients(rows, {days: 7, now}).uids, ['recent0001', 'recent0002']);
  assert.deepEqual(customRecipients(rows, {days: 7, version: '1.0.1', now}).uids, ['recent0001']);
  const many = Array.from({length: 600}, (_, i) => ({uid: `bulk${String(i).padStart(6, '0')}`, status: 'active', at: now}));
  const big = customRecipients(many, {days: 1, now});
  assert.equal(big.uids.length, MAX_RECIPIENTS); assert.equal(big.matched, 600); assert.equal(big.capped, true);
  assert.equal(customLabel('active', 7), 'Active in the last 7 days');
  assert.equal(customLabel('joined', 1, '1.0.1'), 'Joined in the last day · app 1.0.1');
  assert.equal(audienceSummary('selected', 1, ''), '1 selected user');
});

test('the admin page offers All / Selected / Custom and writes the validated payload with an audit entry', () => {
  const page = readFileSync(new URL('../src/pages/NotificationsAdmin.tsx', import.meta.url), 'utf8');
  for (const t of ["id: 'all'", "id: 'selected'", "id: 'custom'", 'announcementPayload(', "'notification.send'", 'classifyUserSearch(']) assert.ok(page.includes(t), t);
});
