import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {parsePref, resolveTheme, THEME_PREFS} from '../src/theme';
const read = (f: string) => readFileSync(new URL(`../${f}`, import.meta.url), 'utf8');

test('theme preference: only dark / light / system are accepted, anything else means system', () => {
  assert.deepEqual([...THEME_PREFS], ['dark', 'light', 'system']);
  for (const v of ['dark', 'light', 'system']) assert.equal(parsePref(v), v);
  for (const v of [null, undefined, '', 'blue', 'DARK', 7, {}]) assert.equal(parsePref(v), 'system');
});

test('system follows the operating system; explicit choices ignore it', () => {
  assert.equal(resolveTheme('system', true), 'dark');
  assert.equal(resolveTheme('system', false), 'light');
  assert.equal(resolveTheme('dark', false), 'dark');
  assert.equal(resolveTheme('light', true), 'light');
});

test('no flash: the pre-paint script is an external file (CSP forbids inline) and uses the same key and values', () => {
  const html = read('index.html'), init = read('public/theme-init.js');
  assert.match(html, /<script src="\/admin\/theme-init\.js"><\/script>/);
  assert.doesNotMatch(html, /<script>[^<]/, 'no inline script');
  assert.ok(html.indexOf('theme-init.js') < html.indexOf('/src/main.tsx'), 'runs before the app');
  assert.match(init, /genz-admin-theme/);
  assert.match(init, /prefers-color-scheme: dark/);
  assert.match(read('src/theme.ts'), /THEME_KEY = 'genz-admin-theme'/);
});

test('liquid glass: both themes define the same tokens; light uses warm ivory and ink', () => {
  const css = read('src/theme.css');
  const light = css.slice(css.indexOf(':root[data-theme="light"]{'), css.indexOf(':root[data-theme="dark"]{'));
  const dark = css.slice(css.indexOf(':root[data-theme="dark"]{'), css.indexOf(':root{font-family'));
  for (const hex of ['#F5F0E8', '#201C25', '#494350', '#51429A', '#FFFFFF', '#FBF7F0']) assert.ok(light.toUpperCase().includes(hex), `light ${hex}`);
  for (const hex of ['#0A1020', '#FAFCFF', '#D4DFF1']) assert.ok(dark.toUpperCase().includes(hex), `dark ${hex}`);
  assert.doesNotMatch(css, /#00E5FF|#D946EF|#050817|neon|cyber/i, 'no neon or cyberpunk colours');
  const tokens = (block: string) => new Set([...block.matchAll(/(--[a-z0-9-]+):/g)].map(m => m[1]));
  const d = tokens(dark), l = tokens(light);
  assert.deepEqual([...d].filter(t => !l.has(t)), [], 'every dark token exists in light');
  assert.deepEqual([...l].filter(t => !d.has(t)), [], 'every light token exists in dark');
});

test('welcome bar stays compact and keeps all its information', () => {
  const css = read('src/theme.css'), dash = read('src/pages/Dashboard.tsx');
  assert.match(css, /\.banner\{[^}]*min-height:112px/);
  for (const text of ['Welcome back, {name}', '{email} · {ROLE_LABELS[role]}', 'Platform status: Healthy', 'Registered users', 'logo128']) assert.ok(dash.includes(text), text);
});

test('switcher: three radios in the top header; charts use theme variables; reduced motion respected', () => {
  const sw = read('src/ThemeSwitcher.tsx'), app = read('src/App.tsx'), ui = read('src/ui.tsx');
  assert.ok(sw.indexOf("id: 'light'") < sw.indexOf("id: 'dark'") && sw.indexOf("id: 'dark'") < sw.indexOf("id: 'system'"), 'order: Light, Dark, System');
  assert.match(sw, /role="radiogroup"/);
  assert.match(app, /<ThemeSwitcher \/>/);
  assert.doesNotMatch(ui, /#1769F5|#7654F6|#64748B|#E3E9F5/, 'no hard-coded chart colours left');
  assert.match(read('src/main.tsx'), /import '\.\/theme\.css'/);
  assert.match(read('src/theme.css'), /prefers-reduced-motion:reduce/);
});

test('Build 62: dark mode uses the owner palette as liquid glass; light mode is untouched', () => {
  const css = read('src/theme.css');
  const at = css.indexOf('Build 62 — Dark mode only');
  assert.ok(at > 0, 'Build 62 block exists');
  const block = css.slice(css.lastIndexOf('/*', at));
  for (const hex of ['#155E70', '#008082', '#FFAA1D', '#FFDB43', '#FF7F52', '#EC634A']) assert.ok(block.toUpperCase().includes(hex), `palette ${hex}`);
  // Every selector in the block is dark-scoped (light mode keeps the Build 59 royal/sky palette).
  const rules = block.replace(/\/\*[\s\S]*?\*\//g, '').replace(/@(supports|media)[^{]*\{/g, '').match(/(^|})\s*([^{}@]+)\{/g) ?? [];
  for (const r of rules) {
    const sel = r.replace(/^}?\s*/, '').replace(/\{$/, '').trim();
    if (!sel || /^\d|^from|^to/.test(sel)) continue;
    for (const part of sel.split(',')) assert.match(part.trim(), /^(:root|html)\[data-theme="dark"\]/, `not dark-scoped: ${part.trim()}`);
  }
  assert.match(block, /backdrop-filter:blur\(24px\) saturate\(175%\)/, 'frosted glass cards');
  assert.match(block, /--glass-edge:linear-gradient\(135deg/, 'gradient rim');
  assert.match(block, /prefers-reduced-transparency:reduce/, 'solid fallback when transparency is reduced');
  assert.match(block, /--on-warm:#2A1204/, 'dark text on the amber→coral gradient for contrast');
  assert.ok(css.slice(0, at).includes('--bg:#E8F6FF'), 'Build 59 light tokens still present');
});

test('Build 63: Send notifications is highlighted in the sidebar and reachable from the Dashboard (Super Admin)', () => {
  const app = read('src/App.tsx'), dash = read('src/pages/Dashboard.tsx'), css = read('src/theme.css');
  assert.match(app, /\{id: 'notifications', label: 'Send notifications'/);
  assert.ok(app.indexOf("id: 'notifications'") < app.indexOf("id: 'users'"), 'second item, right after Dashboard');
  assert.match(app, /p\.id === 'notifications' \? 'nav-feature' : ''/);
  assert.match(dash, /can\(role, 'notifications\.send'\) && <a className="btn banner-cta" href="#notifications">/);
  assert.match(css, /\.side nav a\.nav-feature:not\(\.active\)\{/);
  assert.match(css, /:root\[data-theme="dark"\] \.side nav a\.nav-feature:not\(\.active\)\{/);
});

test('Build 63: Daily Code calendar keeps status colours in both themes (green published, amber pending, grey past)', () => {
  const css = read('src/theme.css');
  // Day cells are <button class="btn feature-date is-…">, so the status rules must out-rank the glass-button rules.
  assert.match(css, /:root\[data-theme\] \.feature-calendar \.btn\.feature-date\.is-published\{background:#86EFAC;border-color:#16A34A/);
  assert.match(css, /:root\[data-theme\] \.feature-calendar \.btn\.feature-date\.is-past\{background:#EEF0F4/);
  assert.match(css, /:root\[data-theme="dark"\] \.feature-calendar \.btn\.feature-date\.is-published\{background:linear-gradient\(145deg,rgba\(34,197,94/);
  assert.match(css, /:root\[data-theme="dark"\] \.btn:not\(\.primary\):not\(\.ghost\):not\(\.danger\):not\(\.feature-date\)\{/, 'dark glass buttons skip calendar days');
  assert.match(read('src/pages/CommunityWorkflow.tsx'), /className=\{`btn feature-date is-\$\{status\}`\}/);
});

test('Build 63 dark: KPI cards use the warm palette with dark text; every card gets the warm top highlight', () => {
  const css = read('src/theme.css');
  const at = css.lastIndexOf('Build 63 — Dark: KPI cards');
  assert.ok(at > 0);
  const block = css.slice(at);
  for (const t of ['--k-blue:linear-gradient(150deg,#FFE47A', '--k-rose:linear-gradient(150deg,#FF9070 0%,#EC634A', '--k-ink:#2A1204', '--card-accent:linear-gradient(90deg,#FFDB43']) assert.ok(block.includes(t), t);
  assert.match(block, /:root\[data-theme="dark"\] \.card\{\n  background:var\(--card-accent\) top\/100% 3px no-repeat padding-box/);
  assert.doesNotMatch(block.replace(/\/\*[\s\S]*?\*\//g, ''), /(^|\})\s*\.(card|stat)\b/, 'dark only');
});
