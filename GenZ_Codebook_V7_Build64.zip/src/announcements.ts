/**
 * Admin in-app announcements (Build 61 sender in the admin portal → Notifications).
 *
 * Build 62 adds the missing "you have something new" signal: the header bell
 * shows how many announcements arrived since the user last opened
 * Notifications. "Seen" is a per-account timestamp kept on this device only —
 * nothing is written to Firestore, and announcement documents stay immutable.
 * These are in-app notices; no Android system push is sent.
 */
import {useCallback,useEffect,useState} from 'react';
import {AppState} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import {normalizeAnnouncements,unreadAnnouncements,type Announcement} from './announcementFeed';
export {badgeText,normalizeAnnouncements,unreadAnnouncements,type Announcement} from './announcementFeed';

const SEEN_KEY='genz.announcements.seenAt.v1:';
const REFRESH_MS=15*60*1000;

/** Signed-in, verified users only (matches the Firestore read rules). Never throws.
 *  Two queries: notices for everyone, and (Build 63) notices addressed to this user. Either may fail alone. */
export async function fetchAnnouncements(uid?:string):Promise<Announcement[]>{
 try{
  const [{collection,query,where,getDocs,limit},{cloudDb}]=await Promise.all([import('firebase/firestore/lite'),import('./firebase/app')]);
  const col=collection(cloudDb(),'adminAnnouncements');
  const [everyone,mine]=await Promise.all([
   getDocs(query(col,where('audience','==','all'),where('active','==',true),limit(40))).then(s=>s.docs,()=>[]),
   uid?getDocs(query(col,where('recipients','array-contains',uid),limit(40))).then(s=>s.docs,()=>[]):Promise.resolve([]),
  ]);
  return normalizeAnnouncements([...everyone,...mine].map(d=>({id:d.id,data:d.data()})),uid);
 }catch{return [];}
}

/** Bell badge: unseen announcement count, refreshed on open, on app resume and every 15 minutes. */
export function useAnnouncementBadge(uid?:string){
 const [rows,setRows]=useState<Announcement[]>([]),[seenAt,setSeenAt]=useState<number|null>(null);
 const refresh=useCallback(()=>{if(uid)void fetchAnnouncements(uid).then(setRows);},[uid]);
 useEffect(()=>{
  setRows([]);setSeenAt(null);if(!uid)return;let live=true;
  void AsyncStorage.getItem(SEEN_KEY+uid).then(raw=>{if(live)setSeenAt(Number(raw)||0);},()=>{if(live)setSeenAt(0);});
  const load=()=>void fetchAnnouncements(uid).then(r=>{if(live)setRows(r);});
  load();
  const sub=AppState.addEventListener('change',s=>{if(s==='active')load();});
  const timer=setInterval(()=>{if(AppState.currentState==='active')load();},REFRESH_MS);
  return()=>{live=false;sub.remove();clearInterval(timer);};
 },[uid]);
 const newest=rows[0]?.at??0;
 /** Marks everything loaded so far as seen (server timestamps, so device clock skew can't hide a new one). */
 const markSeen=useCallback(()=>{
  if(!uid||seenAt===null||newest<=seenAt)return;
  setSeenAt(newest);void AsyncStorage.setItem(SEEN_KEY+uid,String(newest)).catch(()=>{});
 },[uid,seenAt,newest]);
 return {rows,seenAt:seenAt??0,newest,unread:seenAt===null?0:unreadAnnouncements(rows,seenAt),markSeen,refresh};
}
