import React,{useEffect,useRef,useState} from 'react';
import {View,Text,Pressable,StyleSheet,AccessibilityInfo} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import type {Term} from './content';
import {categoryLabels} from './content';
import {C,Icon,IconName} from './ui';
import {termCopyText,termCopyLabels,termCopyNotes,TermCopyKind} from './termCopy';

const kinds:TermCopyKind[]=['code','meaning','all'];
const icons:Record<TermCopyKind,IconName>={code:'copy-outline',meaning:'document-text-outline',all:'documents-outline'};

/** One-tap copy for a dictionary entry: the code, the code + meaning, or every detail.
 *  Layout is fixed at every phone width: two equal buttons, then a full-width primary. */
export default function TermCopyBar({term:t}:{term:Term}){
 const [copied,setCopied]=useState<TermCopyKind|null>(null),[error,setError]=useState('');
 const timer=useRef<ReturnType<typeof setTimeout>|null>(null);
 useEffect(()=>()=>{if(timer.current)clearTimeout(timer.current);},[]);
 useEffect(()=>{setCopied(null);setError('');},[t.id]);
 const copy=async(kind:TermCopyKind)=>{
  if(timer.current)clearTimeout(timer.current);
  try{await Clipboard.setStringAsync(termCopyText(t,kind,categoryLabels[t.category]));setError('');setCopied(kind);AccessibilityInfo.announceForAccessibility?.(termCopyNotes[kind]);}
  catch{setCopied(null);setError('Couldn’t copy on this device. Long-press the text to select it instead.');}
  timer.current=setTimeout(()=>setCopied(null),2200);
 };
 const button=(k:TermCopyKind)=>{const done=copied===k,primary=k==='all';return <Pressable key={k} accessibilityRole="button" accessibilityLabel={`${termCopyLabels[k]}: ${t.expression}`} accessibilityState={{selected:done}} onPress={()=>void copy(k)} hitSlop={4} style={({pressed})=>[s.btn,primary?s.primary:s.half,done&&s.done,pressed&&{opacity:.85,transform:[{translateY:1}]}]}>
   <Icon name={done?'checkmark-circle':icons[k]} size={16} color={done||primary?'#fff':C.accent}/>
   <Text numberOfLines={1} style={[s.text,(primary||done)&&{color:'#fff'}]}>{done?'Copied':termCopyLabels[k]}</Text>
  </Pressable>;};
 return <View style={s.wrap}>
  <View style={s.row}>{kinds.filter(k=>k!=='all').map(button)}</View>
  {button('all')}
  {!!error&&<Text accessibilityRole="alert" style={s.error}>{error}</Text>}
 </View>;
}
const s=StyleSheet.create({
 wrap:{gap:8},
 row:{flexDirection:'row',gap:8},
 half:{flex:1,minWidth:0},
 btn:{flexDirection:'row',alignItems:'center',justifyContent:'center',gap:6,minHeight:42,paddingHorizontal:10,borderRadius:21,backgroundColor:C.soft,borderWidth:1,borderColor:'#d6e8fb'},
 primary:{backgroundColor:C.accent,borderColor:C.accent},
 done:{backgroundColor:C.success,borderColor:C.success},
 text:{fontSize:12.5,fontWeight:'800',color:C.accent,flexShrink:1},
 error:{fontSize:12,lineHeight:18,color:C.warn},
});
