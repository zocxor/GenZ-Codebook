/** Pure helpers for admin in-app announcements (no React / Firebase), unit-tested in tests/build62.test.ts. */
/** personal: sent to this user only (selected users / custom group, Build 63), not to everyone. */
export type Announcement={id:string;title:string;body:string;at:number;personal?:boolean};

/** Pure: keep valid, active notices for everyone or addressed to `uid`; de-duplicated, newest first, max 20. */
export function normalizeAnnouncements(docs:{id:string;data:Record<string,any>}[],uid?:string):Announcement[]{
 const seen=new Set<string>(),out:Announcement[]=[];
 for(const {id,data:v} of docs){
  if(seen.has(id)||v?.active!==true)continue;
  const personal=v?.audience==='users'&&!!uid&&Array.isArray(v?.recipients)&&v.recipients.includes(uid);
  if(v?.audience!=='all'&&!personal)continue;
  const title=String(v?.title??'').trim(),body=String(v?.body??'').trim();
  if(!title||!body)continue;
  seen.add(id);
  out.push({id,title,body,at:typeof v?.createdAt?.toMillis==='function'?Number(v.createdAt.toMillis())||0:0,...(personal?{personal:true}:{})});
 }
 return out.sort((a,b)=>b.at-a.at||a.id.localeCompare(b.id)).slice(0,20);
}
/** Pure: how many announcements are newer than the last time Notifications was opened. */
export function unreadAnnouncements(rows:Announcement[],seenAt:number):number{return rows.filter(r=>r.at>seenAt).length;}
/** Pure: bell badge text — nothing at 0, "9+" above 9. */
export function badgeText(n:number):string{return n<=0?'':n>9?'9+':String(n);}
