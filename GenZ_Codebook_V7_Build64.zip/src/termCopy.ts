import type {Term} from './content';

/** What the user can copy from a dictionary entry (Codes search + "Inside the code"). */
export type TermCopyKind = 'code' | 'meaning' | 'all';

export const termCopyLabels: Record<TermCopyKind, string> = {code: 'Copy code', meaning: 'Copy meaning', all: 'Copy all details'};
export const termCopyNotes: Record<TermCopyKind, string> = {code: 'Code copied', meaning: 'Code and meaning copied', all: 'All details copied'};

const clean = (v: unknown) => (typeof v === 'string' ? v.trim() : '');

/**
 * Plain text for the clipboard. Pure so it is tested without React Native.
 * - code: just the expression ("rizz")
 * - meaning: "rizz (charisma): Natural charm …"
 * - all: expression, long form, meaning, example, reply and category on separate lines
 */
export function termCopyText(t: Pick<Term, 'expression' | 'full' | 'meaning'> & Partial<Pick<Term, 'example' | 'reply' | 'category' | 'language'>>, kind: TermCopyKind, categoryLabel?: string): string {
  const expression = clean(t.expression);
  if (kind === 'code') return expression;
  const full = clean(t.full);
  const meaning = clean(t.meaning);
  const head = full && full.toLowerCase() !== expression.toLowerCase() ? `${expression} (${full})` : expression;
  if (kind === 'meaning') return meaning ? `${head}: ${meaning}` : head;
  const lines = [head];
  if (meaning) lines.push(`Meaning: ${meaning}`);
  const example = clean(t.example);
  if (example) lines.push(`Example: “${example}”`);
  const reply = clean(t.reply);
  if (reply) lines.push(`Reply: “${reply}”`);
  const meta = [clean(categoryLabel), clean(t.language)].filter(Boolean).join(' · ');
  if (meta) lines.push(meta);
  return lines.join('\n');
}
