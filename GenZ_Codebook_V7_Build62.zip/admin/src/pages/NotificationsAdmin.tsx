import React, {useEffect, useState} from 'react';
import {collection, doc, getDocs, limit, orderBy, query, serverTimestamp} from 'firebase/firestore/lite';
import {db, newBatch, addAudit, errorMessage} from '../firebase';
import {useSession} from '../App';
import {Card, Notice, Field} from '../ui';

type SentNotice = {id: string; title: string; body: string; at: string};

export default function NotificationsAdmin() {
  const admin = useSession();
  const [title,setTitle] = useState('');
  const [body,setBody] = useState('');
  const [busy,setBusy] = useState(false);
  const [status,setStatus] = useState<{kind: 'ok' | 'error'; text: string} | null>(null);
  const [history,setHistory] = useState<SentNotice[]>([]);
  const [confirmed,setConfirmed] = useState(false);

  const reload = async () => {
    try {
      const data = await getDocs(query(collection(db,'adminAnnouncements'),orderBy('createdAt','desc'),limit(20)));
      setHistory(data.docs.map(d => ({id:d.id,title:String(d.data().title ?? ''),body:String(d.data().body ?? ''),at:d.data().createdAt?.toDate?.().toLocaleString?.() ?? 'Recent'})));
    } catch (e) {setStatus({kind:'error',text:errorMessage(e)});}
  };
  useEffect(()=>{void reload();},[]);
  const send = async (e:React.FormEvent) => {
    e.preventDefault();
    if (!confirmed || !title.trim() || !body.trim()) return;
    setBusy(true);setStatus(null);
    try {
      const b = newBatch();
      const ref = doc(collection(db,'adminAnnouncements'));
      const auditId = addAudit(b,admin.uid,admin.role,'notification.send',`adminAnnouncements/${ref.id}`,`In-app announcement: ${title.trim().slice(0,90)}`);
      b.set(ref,{title:title.trim().slice(0,100),body:body.trim().slice(0,500),audience:'all',active:true,createdAt:serverTimestamp(),createdBy:admin.uid,lastAuditId:auditId});
      await b.commit();
      setStatus({kind:'ok',text:'Announcement published. Signed-in users with app Build 62 or newer see a red badge on the bell (refreshed when they open or return to the app, and every 15 minutes), and the message under Notifications → Announcements.'});
      setTitle('');setBody('');setConfirmed(false);
      await reload();
    } catch(e) {setStatus({kind:'error',text:errorMessage(e)});} finally {setBusy(false);}
  };
  return <div className="stack">
    {status&&<Notice kind={status.kind} onClose={()=>setStatus(null)}>{status.text}</Notice>}
    <Card title="Send an in-app notification" subtitle="Super Admin only · displayed in the Notifications screen for signed-in users" index={0}>
      <Notice kind="info">These are in-app announcements, not Android push notifications. No SMS, e-mail or system notification is sent.</Notice>
      <form onSubmit={e=>void send(e)} className="stack">
        <Field label="Notification title"><input required maxLength={100} value={title} onChange={e=>{setTitle(e.target.value);setConfirmed(false);}} placeholder="Important update" /></Field>
        <Field label="Message"><textarea required maxLength={500} rows={4} value={body} onChange={e=>{setBody(e.target.value);setConfirmed(false);}} placeholder="Write your announcement here…" /></Field>
        <div className="card" style={{padding:14}}><strong>Preview</strong><h3 style={{margin:'8px 0 4px'}}>{title.trim()||'Your notification title'}</h3><p className="muted" style={{whiteSpace:'pre-wrap'}}>{body.trim()||'Your message will appear here.'}</p></div>
        <label className="row"><input type="checkbox" checked={confirmed} onChange={e=>setConfirmed(e.target.checked)}/> I confirm sending this announcement to all signed-in users.</label>
        <button className="btn primary" disabled={busy||!confirmed||!title.trim()||!body.trim()} type="submit">{busy?'Publishing…':'Publish notification'}</button>
      </form>
    </Card>
    <Card title="Recent announcements" subtitle="Latest 20 published messages · read-only history" index={1}>
      {history.length===0?<p className="muted">No announcements sent yet.</p>:history.map(item=><div key={item.id} style={{padding:'12px 0',borderBottom:'1px solid var(--line, #ddd)'}}><strong>{item.title}</strong><p className="muted">{item.body}</p><small className="muted">{item.at}</small></div>)}
      <button className="btn" type="button" onClick={()=>void reload()}>Refresh history</button>
    </Card>
  </div>;
}
