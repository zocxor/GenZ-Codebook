/** Pure helpers for admin in-app announcements (no React / Firebase), unit-tested in tests/build62.test.ts. */
export type Announcement={id:string;title:string;body:string;at:number};

/** Pure: keep only valid, active, all-audience notices, newest first, max 20. */
export function normalizeAnnouncements(docs:{id:string;data:Record<string,any>}[]):Announcement[]{
 return docs.map(({id,data:v})=>({id,title:String(v?.title??'').trim(),body:String(v?.body??'').trim(),at:typeof v?.createdAt?.toMillis==='function'?Number(v.createdAt.toMillis())||0:0,active:v?.active===true&&v?.audience==='all'}))
  .filter(v=>v.active&&v.title&&v.body).map(({active:_a,...v})=>v)
  .sort((a,b)=>b.at-a.at||a.id.localeCompare(b.id)).slice(0,20);
}
/** Pure: how many announcements are newer than the last time Notifications was opened. */
export function unreadAnnouncements(rows:Announcement[],seenAt:number):number{return rows.filter(r=>r.at>seenAt).length;}
/** Pure: bell badge text — nothing at 0, "9+" above 9. */
export function badgeText(n:number):string{return n<=0?'':n>9?'9+':String(n);}
