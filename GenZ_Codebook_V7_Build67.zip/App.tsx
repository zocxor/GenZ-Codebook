import AccountTokens,{DailyRewardButton} from './src/AccountTokens';
import {useDailyReward} from './src/dailyReward';
import {BACKEND_URL} from './src/backend';
import {SPARK_MODE} from './shared/deployment';
import {watchRewardedAd} from './src/ads';
import React,{useEffect,useMemo,useRef,useState,Suspense,lazy} from 'react';
import {View,Text,TextInput,ScrollView,Pressable,StyleSheet,Modal,BackHandler,AppState,Animated,Linking,Platform,Alert} from 'react-native';
import {SafeAreaProvider,SafeAreaView} from 'react-native-safe-area-context';
import {LinearGradient} from 'expo-linear-gradient';
import {StatusBar} from 'expo-status-bar';
import {confirmAction,C,Glass,Icon,IconName,Button,RoundIcon,Chip,Mark,BrandLogo,BrandWordmark,AnimatedSplash,BrandAvatar,CompanyFooter,LiquidHero,IconTile,PressableCard,FadeIn,ProgressBar} from './src/ui';
import {Term,contentRevision,onContentChange,termsById} from './src/content';
import {decode,warmIndex} from './src/engine';
import {view,totalXP,exportLearning,streak} from './src/profile';
import {Action,setUsePhoto,toggleSaved,setOnboarded,setLanguage,setQuizCategory,setProfileDetails,recordAnswer,recordRound,recordView,recordSearch,newAttemptId,unlockLevelWithTokens,unlockLevelByAd,earnTokens,setTokenBalance,creditReferrals} from './src/learning';
import {stages,unlockedIn,Stage} from './src/games';
import DictionaryScreen from './src/DictionaryScreen';
import TermDetail from './src/TermDetail';
import {quizRound,levelStages,localDay,quizPoolCount} from './src/discovery';
import {dueTerms,reviewRound} from './src/reviewQueue';
import ErrorBoundary from './src/ErrorBoundary';
import {MotionPreferences,useReducedMotion} from './src/motion';
import {ContributionScreen,DailyCodeAdmin,DailyCodeBanner,useDailyCode} from './src/ContributionScreens';
import {DAILY_EDITORS,fetchStaffRole} from './src/staff';
import ProfileDashboard,{PlayProgress} from './src/ProfileDashboard';
import NavBar,{NavItem} from './src/NavBar';
import {useAvatarPhoto,pickAndSavePhoto,removePhoto,forgetPhoto} from './src/avatarPhoto';
import {repository,bootServices,startCloud,useLearningState,useStorageHealth,useSyncStatus,useAccountUser,useAuthPhase} from './src/services';
import AppHeader from './src/AppHeader';
import {useAnnouncementBadge} from './src/announcements';
import EncodePanel from './src/EncodePanel';
import {getSharePhoto,publishPublicProfile,setSharePhoto,usePublicAbout,type PublicAbout} from './src/publicProfile';
import {useConversion,AD_BONUS} from './src/conversions';
import {useEligibleBalance} from './src/ContributionScreens';
import {refreshCommunity} from './src/contentSync';
import SuggestBanner,{CreateCodeBanner} from './src/SuggestBanner';
import PlayHub from './src/PlayHub';
import CommunityScreen from './src/CommunityScreen';
import {interpretMessage} from './src/messageInterpretation';
import MessagingScreen from './src/MessagingScreen';
import {useInbox,type ConnectionList} from './src/messaging';
import {useKeyboardVisible} from './src/KeyboardDock';
import AdRewardButton from './src/AdRewardButton';
import NotificationsScreen from './src/NotificationsScreen';
import MySuggestionsScreen from './src/MySuggestionsScreen';
import DashboardScreen from './src/DashboardScreen';
import AchievementsScreen from './src/AchievementsScreen';
import SettingsScreen from './src/SettingsScreen';
import AboutScreen from './src/AboutScreen';
import {initAds, setAdsDisabled} from './src/ads';
import SupportAdButton from './src/SupportAdButton';
import {initBilling, disposeBilling} from './src/billing';
import {fetchSubscription, reconcileSubscriptions, onSubscriptionEvent} from './src/subscription';
import {isPremiumActive} from './shared/subscriptions';
import {recordMigrationTxn, fetchTokenWallet} from './src/tokenLedger';
import {publishLeaderboard} from './src/tokensSync';
import {handleReferralDeepLink, ensureReferralCode, reconcileReferralCredits} from './src/referral';
const AccountScreen=lazy(()=>import('./src/AccountScreen'));
const ThreatShieldScreen=lazy(()=>import('./src/ThreatShieldScreen'));
const TokenShopScreen=lazy(()=>import('./src/TokenShopScreen'));
const WalletScreen=lazy(()=>import('./src/WalletScreen'));
const Forms=lazy(()=>import('./src/SubmitForms').then(m=>({default:m.FormHost})));
type Tab='Decode'|'Words'|'Community'|'Inbox'|'Play'|'You';
type Sheet='login'|'edit'|'privacy'|'guide'|'export'|'feedback'|'suggest'|'report'|'wallet'|'shop'|'daily'|'notifications'|'dashboard'|'achievements'|'settings'|'about'|'my-suggestions'|'daily-apply'|'daily-history'|'my-posts'|'verification'|null;
const nav:NavItem<Tab>[]=[{name:'Decode',label:'Home',icon:'home-outline',activeIcon:'home'},{name:'Words',label:'Codebook',icon:'book-outline',activeIcon:'book'},{name:'Community',icon:'chatbubbles-outline',activeIcon:'chatbubbles'},{name:'Inbox',icon:'mail-outline',activeIcon:'mail'},{name:'Play',icon:'game-controller-outline',activeIcon:'game-controller'}];
const avatars:IconName[]=['planet','rocket','headset','happy','flash','flower','hardware-chip','game-controller','musical-notes','trophy','paw','camera'];
const sheetTitles:Record<Exclude<Sheet,null>,string>={login:'Your account',edit:'Make it yours',privacy:'Threat Shield',export:'Your learning data',guide:'Codebook guide',feedback:'Send feedback',suggest:'Add / Create Your Own Code',report:'Report an entry',wallet:'Your wallet',shop:'Buy Credits',daily:'Daily reward',notifications:'Notifications',dashboard:'Learning Dashboard',achievements:'Achievements',settings:'Settings',about:'About','my-suggestions':'My suggestions','daily-apply':'Daily Code Display','daily-history':'My Daily Code applications','my-posts':'My Posts','verification':'Verified Badge'};
const SAVE_ERROR='Couldn’t save on this device, so that change wasn’t applied. Check available storage and try again.';
function Title({small,title,description}:{small?:string;title:string;description?:string}){return <View style={s.titleGroup}>{small&&<Text style={s.eyebrow}>{small}</Text>}<Text style={s.title}>{title}</Text>{description&&<Text style={s.body}>{description}</Text>}</View>}
function Badge({icon,text}:{icon:IconName;text:string}){return <View style={s.inline}><Icon name={icon} size={15} color={C.teal}/><Text style={s.caption}>{text}</Text></View>}
export default function App(){return <ErrorBoundary><MotionPreferences><GenZCode/></MotionPreferences></ErrorBoundary>;}
function GenZCode(){
 const state=useLearningState(),health=useStorageHealth(),sync=useSyncStatus(),user=useAccountUser(),authPhaseNow=useAuthPhase();
 const announcements=useAnnouncementBadge(user?.emailVerified?user.uid:undefined);
 // One Credit balance everywhere: the server-verified account balance for the signed-in user.
 const headerCredits=useEligibleBalance(BACKEND_URL&&user?user.uid:undefined);
 const [booted,setBooted]=useState(false),[rev,setRev]=useState(contentRevision);
 useEffect(()=>{void bootServices().finally(()=>setBooted(true));return onContentChange(()=>setRev(v=>v+1));},[]);
 const p=useMemo(()=>view(state),[state,rev]);
 const [error,setError]=useState(''),[tab,setTab]=useState<Tab>('Decode');
 const [conversationOpen,setConversationOpen]=useState(false);
 const communityTyping=useKeyboardVisible()&&(tab==='Community'||tab==='Inbox');
 const [findPeople,setFindPeople]=useState(false);
 const [profileConnections,setProfileConnections]=useState<ConnectionList>();
 const privateInbox=useInbox(user?.uid,!!user?.emailVerified);
 const [text,setText]=useState(''),[result,setResult]=useState<ReturnType<typeof decode>|null>(null),[homeMode,setHomeMode]=useState<'decode'|'encode'>('decode');
 const [detail,setDetail]=useState<Term|null>(null),[sheet,setSheet]=useState<Sheet>(null),[editName,setEditName]=useState(''),[editAvatar,setEditAvatar]=useState(0),[stage,setStage]=useState<Stage|null>(null),[qi,setQi]=useState(0),[choice,setChoice]=useState<number|null>(null),[score,setScore]=useState(0),[finished,setFinished]=useState(false);
 const [accountMode,setAccountMode]=useState<'signin'|'create'>('signin');
 const [accountSignOut,setAccountSignOut]=useState(false);
 // Build 62: bell badge for admin announcements. Capture the old "seen" time so the sheet can tag NEW items, then mark seen while it is open.
 const [noticeSince,setNoticeSince]=useState(0);
 // Build 64: profile → Get Premium opens the shop at Premium; any other way in opens it at the top.
 const [shopFocus,setShopFocus]=useState<'premium'|undefined>();
 useEffect(()=>{if(sheet!=='shop')setShopFocus(undefined);},[sheet]);
 const openNotifications=()=>{setNoticeSince(announcements.seenAt);announcements.refresh();setSheet('notifications');};
 useEffect(()=>{if(sheet==='notifications')announcements.markSeen();},[sheet,announcements.markSeen]);
 const [savedRequest,setSavedRequest]=useState(0),[dictionaryEpoch,setDictionaryEpoch]=useState(0),[deleting,setDeleting]=useState(false),[detailError,setDetailError]=useState(''),[formTerm,setFormTerm]=useState<{id:string;expression:string}|null>(null),[suggestion,setSuggestion]=useState('');
 const attemptId=useRef('');
 const [hiddenAnswer,setHiddenAnswer]=useState<number|null>(null),[hintBusy,setHintBusy]=useState(false),[hintMessage,setHintMessage]=useState('');
 const hintSession=useRef(0),hintPending=useRef(false);
 useEffect(()=>{hintSession.current++;setHiddenAnswer(null);setHintMessage('');setHintBusy(false);},[stage?.id,qi,finished]);
 const rewardedHint=async()=>{
   if(hintPending.current||!stage||choice!==null||hiddenAnswer!==null)return;
   const session=hintSession.current,question=stage.questions[qi]!;
   hintPending.current=true;setHintBusy(true);setHintMessage('');
   try{
     const earned=await watchRewardedAd(()=>session===hintSession.current,'hint');
     if(session!==hintSession.current)return;
     if(earned){setHiddenAnswer(question.answers.findIndex((_,index)=>index!==question.correct));setHintMessage('One wrong answer removed.');}
     else setHintMessage('No hint earned. You can continue answering normally or try again later.');
   }finally{hintPending.current=false;if(session===hintSession.current)setHintBusy(false);}
 };
 const dailyPopupShown=useRef(false);
 // Give balance changes visual feedback using opacity on Android Fabric.
 const reduceMotion=useReducedMotion();
 const pageOpacity=useRef(new Animated.Value(1)).current;
 useEffect(()=>{
   pageOpacity.setValue(reduceMotion?1:0.9);
   if(reduceMotion)return;
   const animation=Animated.timing(pageOpacity,{toValue:1,duration:170,useNativeDriver:true});
   animation.start();
   return()=>animation.stop();
 },[tab,reduceMotion,pageOpacity]);
 const tokenOpacity=useRef(new Animated.Value(1)).current;
 const prevBalanceRef=useRef<number|null>(null);
 useEffect(()=>{
   const previous=prevBalanceRef.current;
   prevBalanceRef.current=state.tokens.balance;
   if(reduceMotion){tokenOpacity.setValue(1);return;}
   if(previous===null||previous===state.tokens.balance)return;
   const animation=Animated.sequence([
     Animated.timing(tokenOpacity,{toValue:0.7,duration:100,useNativeDriver:true}),
     Animated.timing(tokenOpacity,{toValue:1,duration:200,useNativeDriver:true}),
   ]);
   animation.start();
   return()=>animation.stop();
 },[state.tokens.balance,tokenOpacity,reduceMotion]);
 const photo=useAvatarPhoto();
 const [sharePhoto,setSharePhotoState]=useState(false);
 useEffect(()=>{void getSharePhoto().then(setSharePhotoState);},[]);
 const [editUsePhoto,setEditUsePhoto]=useState(false),[photoBusy,setPhotoBusy]=useState(false),[photoMsg,setPhotoMsg]=useState('');
 const choosePhoto=async()=>{setPhotoBusy(true);setPhotoMsg('');try{const r=await pickAndSavePhoto();if(r.ok)setEditUsePhoto(true);else if(r.message)setPhotoMsg(r.message);}catch{setPhotoMsg('Couldn’t open or save that photo. Please try another one.');}finally{setPhotoBusy(false);}};
 // Ready after local learning data loads or the startup time budget expires. The splash
 // used to also wait for the stored data to finish loading, which defeated
 // that time-box — a slow read left the app on the splash for 9s+. Storage
 // now catches up in the background (the UI updates via subscription) and a
 // real read failure is shown by the Recovery banner below, not by the splash.
 const ready=booted,storageReady=health.status==='ready';
 // Use the hydrated profile when registering the nickname for discovery.
 useEffect(()=>{
   if(!user||!storageReady)return;
   let active=true;
   void getSharePhoto().then(on=>{
     if(active)return publishPublicProfile({name:p.name,avatar:p.avatar,photo:on&&p.usePhoto?photo:null});
   }).catch(()=>{});
   return()=>{active=false;};
 },[user?.uid,user?.emailVerified,storageReady]);
 const dailyCode=useDailyCode(ready&&p.onboarded&&(tab==='Decode'||tab==='Words'));
 // Super Admins and Content Managers get edit / remove icons on today's running Daily Code (the server checks the role again).
 const [dailyEditor,setDailyEditor]=useState(false);
 useEffect(()=>{if(!user){setDailyEditor(false);return;}let alive=true;void fetchStaffRole(user.uid).then(r=>{if(alive)setDailyEditor(!!r&&DAILY_EDITORS.includes(r));});return()=>{alive=false;};},[user]);
 const dailyAdmin=dailyEditor&&!!BACKEND_URL&&!dailyCode.loading&&!dailyCode.fallback?<DailyCodeAdmin entry={dailyCode}/>:undefined;
 const due=dueTerms(p);
 const dayStreak=streak(state.days);
 const quizCategory=state.prefs.quizCategory;
 /** Persist first; the UI updates only after the write is confirmed. */
 const act=(a:Action,onError:(m:string)=>void=setError)=>repository.mutate(a).then(()=>true,(cause:unknown)=>{onError(cause instanceof RangeError?cause.message:SAVE_ERROR);return false;});
 // Profile refresh: force a cloud sync (pulls the latest profile, saved words,
 // progress and scores) and re-read the server wallet, applying its balance
 // locally when it differs — the same wallet repair the sign-in effect runs.
 // Signed out, or before cloud starts, this is a safe no-op.
 const refreshProfile=()=>{if(SPARK_MODE){void startCloud().then(c=>c.engine.requestSync(true));return;}void startCloud().then(async c=>{c.engine.requestSync(true);const uid=c.getUser()?.uid;if(!uid)return;try{const w=await fetchTokenWallet(uid);if(w&&w.balance!==state.tokens.balance)void act(setTokenBalance(w.balance));}catch{}}).catch(()=>{});};
 const deleteLocalData=async()=>{setDeleting(true);try{await repository.clear();forgetPhoto();setText('');setResult(null);setSheet(null);setDetail(null);setStage(null);setDictionaryEpoch(v=>v+1);setError('');}catch{setError('Deletion failed. Existing data may remain. Retry from Threat Shield.');}finally{setDeleting(false);}};
 useEffect(()=>{const sub=AppState.addEventListener('change',status=>{if(status!=='active'){setText('');setResult(null);}});return()=>sub.remove();},[]);
 // Leaderboard (opt-in): publish your game XP/level (ranking) and Credits whenever they change. Best-effort and throttled inside publishLeaderboard.
 const leaderXp=useMemo(()=>totalXP(p.best),[p.best]);
 const leaderCredits=BACKEND_URL?headerCredits.balance:state.tokens.balance;
 useEffect(()=>{if(!state.tokens.leaderboard||!user||leaderCredits===null)return;void publishLeaderboard(p.name,{xp:leaderXp,credits:leaderCredits});},[leaderXp,leaderCredits,state.tokens.leaderboard,user,p.name]);
 // Google Play Billing (Android): connect once the app is ready, load the seven
 // packages, and reconcile any owned purchase that never got credited. A purchase
 // credits the local balance through onCredit only after its ledger write (src/billing.ts).
 // Deferred until ready so billing init never slows the first paint.
 useEffect(()=>{if(!ready)return;const timer=setTimeout(()=>{void initBilling({onCredit: amount => {if(!SPARK_MODE)void act(earnTokens(amount));}}).catch(()=>{});},900);return()=>{clearTimeout(timer);disposeBilling();};},[ready]);
 // Ads SDK: deferred until the app is ready and the first screen is painted, so
 // its initialization never slows startup. The interstitial is preloaded by initAds.
 useEffect(()=>{if(!ready)return;const t=setTimeout(()=>{try{initAds();}catch{/* ads must never crash the app */}},300);return()=>clearTimeout(t);},[ready]);
 // Build the search/decoder index after the first paint (it used to block startup).
 useEffect(()=>{if(!ready)return;const t=setTimeout(()=>{try{warmIndex();}catch{}},1200);return()=>clearTimeout(t);},[ready]);
 // Daily reward popup: once per app session, when the main page (Decode) is
 // showing and today's reward has not been collected yet, open the Daily
 // reward sheet. The Decode tab also has a Collect button, so dismissing the
 // popup never blocks the reward.
 // One daily reward for the whole app (src/dailyReward.ts): the pop-up shows only while today's reward is still open.
 const dailyReward=useDailyReward();
 useEffect(()=>{if(!ready||!p.onboarded||tab!=='Decode'||sheet!==null||dailyPopupShown.current)return;if(!dailyReward.known||dailyReward.done)return;const timer=setTimeout(()=>{dailyPopupShown.current=true;setSheet('daily');},1400);return()=>clearTimeout(timer);},[ready,p.onboarded,tab,sheet,dailyReward.known,dailyReward.done]);
 // One-time migration + drift repair: a pre-ledger local balance gets an
 // opening entry in the account's ledger, and the local balance is synced to
 // the server wallet when they differ (the ledger is the record).
 useEffect(()=>{if(SPARK_MODE||!user)return;void recordMigrationTxn(user.uid,state.tokens.balance);void fetchTokenWallet(user.uid).then(w=>{if(w&&w.balance!==state.tokens.balance)void act(setTokenBalance(w.balance));});},[user]);
 // Signed-in users never see the Welcome screen. If Firebase reports a
 // session but the device has not been onboarded yet — sign-in just
 // finished and the sheet was dismissed, or a storage failure lost the
 // flag — finish onboarding and open Decode. The login sheet is exempt so
 // a signed-in user can still open it to manage the account (sign out /
 // delete) without being yanked away mid-task. (Fixes the post-sign-in
 // return to Welcome: the sheet's back button used to close it while
 // onboarded was still false.)
 useEffect(()=>{if(!ready||!user||p.onboarded||sheet!==null)return;void act(setOnboarded).then(()=>{setSheet(null);go('Decode');});},[ready,user,p.onboarded,sheet]);
 // Premium subscription: read the backend-written entitlement and turn ads
 // off while it is active. Runs on sign-in and whenever a subscription
 // event fires (subscribe / restore / reconcile). A missing or expired
 // subscription leaves ads on.
 useEffect(()=>{
   if(!user){setAdsDisabled(false);return;}
   let cancelled=false;
   const refresh=()=>{void fetchSubscription().then(s=>{if(!cancelled)setAdsDisabled(isPremiumActive(s));});};
   refresh();
   void reconcileSubscriptions().then(n=>{if(n>0)refresh();});
   const off=onSubscriptionEvent(e=>{if(e.kind==='subscribed'||e.kind==='already-subscribed'||e.kind==='restored')refresh();});
   return()=>{cancelled=true;off();};
 },[user]);
 useEffect(()=>{const h=BackHandler.addEventListener('hardwareBackPress',()=>{if(detail){setDetail(null);return true;}if(sheet){setSheet(null);return true;}if(stage){setStage(null);return true;}if(tab!=='Decode'){setTab('Decode');return true;}return false;});return()=>h.remove();},[detail,sheet,stage,tab]);
 // ---------- REFERRAL (see src/referral.ts) ----------
 // A referral deep link (genzcode://referral?code=GZXXXXXX) stores its code
 // in memory; the sign-up form pre-fills it. This listener touches nothing
 // else — no auth, boot, or navigation logic lives here.
 useEffect(()=>{
   void Linking.getInitialURL().then(u=>{if(u)handleReferralDeepLink(u);}).catch(()=>{});
   const sub=Linking.addEventListener('url',e=>{handleReferralDeepLink(e.url);});
   return()=>sub.remove();
 },[]);
 // A friend who joined with this user's referral code pays +100 into this
 // user's ledger; reconcile it into the local balance (and the server
 // wallet, so the next login's wallet re-read keeps it) on sign-in.
 // Idempotent — already-credited friends are skipped in creditReferrals.
 // Runs on sign-in only (deps [user]): the balance/credited values are read
 // from the closure at sign-in time, so a later token spend does not
 // re-trigger a ledger read. The code is also registered here, so a friend
 // can claim it even if this user never opened the You tab.
 useEffect(()=>{if(!user)return;void ensureReferralCode(user.uid).catch(()=>{});!SPARK_MODE&&void reconcileReferralCredits(user.uid,state.tokens.credited,state.tokens.balance).then(fresh=>{if(fresh.length)void act(creditReferrals(fresh));});},[user]);
 // A locked level: the user may pass the previous one, spend points, or (their choice) watch a rewarded ad.
 const lockedLevel=(g:Stage)=>{
   const msg='Pass the previous level or unlock it for 50 learning points from Play → Game progress & achievements.';
   if(Platform.OS!=='android'){setError(msg);return;}
   Alert.alert('This level is locked','Pass the previous level, or watch a short ad to unlock it now. Totally optional.',[{text:'Not now',style:'cancel'},{text:'Watch ad',onPress:()=>{void watchRewardedAd(()=>true,'unlock').then(ok=>{if(ok){void act(unlockLevelByAd(g.id)).then(done=>{if(done)start(g);});}else setError('No ad was available, so nothing was unlocked. You can still pass the previous level.');});}}]);
 };
 const openDetail=(t:Term)=>{setDetailError('');setDetail(t);void act(recordView(t.id),()=>{});};
 const start=(g:Stage)=>{setStage(g);setQi(0);setChoice(null);setScore(0);setFinished(false);attemptId.current=newAttemptId();};
 const answer=(index:number)=>{if(!stage||choice!==null)return;setChoice(index);const q=stage.questions[qi]!;const correct=index===q.correct;if(correct)setScore(v=>v+1);void act(recordAnswer(q.termId,correct));};
 const next=()=>{if(!stage||choice===null)return;if(qi+1>=stage.questions.length){void act(recordRound(stage.id,score,stage.questions.length,attemptId.current));setFinished(true);}else{setQi(v=>v+1);setChoice(null);}};
 // All levels: the 4 hand-written intro stages, then the 30 generated levels
 // (3 tracks x 10). Computed once; each level is seeded from its own id.
 // Generated levels are built the first time Play opens (not during the first paint).
 const [visited,setVisited]=useState<ReadonlySet<Tab>>(()=>new Set<Tab>(['Decode']));
 const allStages=useMemo(()=>visited.has('Play')?[...stages,...levelStages()]:stages,[visited]);
 const complete=allStages.filter(g=>p.best[g.id]!==undefined).length;const xp=totalXP(p.best);
 const publicAbout=usePublicAbout(user?.uid);
 const [editAbout,setEditAbout]=useState<PublicAbout>({});
 const openProfile=()=>{setEditAbout(publicAbout);setEditName(p.name);setEditAvatar(p.avatar);setEditUsePhoto(!!p.usePhoto&&!!photo);setPhotoMsg('');setSheet('edit');};
 // Load the code for the sheets people open most a few seconds after start, so they open instantly.
 useEffect(()=>{if(!ready)return;const t=setTimeout(()=>{void Promise.allSettled([import('./src/WalletScreen'),import('./src/TokenShopScreen'),import('./src/SubmitForms'),import('./src/AccountScreen')]);},2500);return()=>clearTimeout(t);},[ready]);
 const openSheet=(x:Exclude<Sheet,null>)=>{if(x==='login'){setAccountMode('signin');setAccountSignOut(false);}setSheet(x);};
 const openAccount=(mode:'signin'|'create')=>{setAccountMode(mode);setAccountSignOut(false);setSheet('login');};
 // Sign out (You page and the profile page): opens the account sheet at the usual sign-out choice.
 const openSignOut=()=>{setAccountMode('signin');setAccountSignOut(true);setSheet('login');};
 const decodeConv=useConversion('decode');
 const [decodeBusy,setDecodeBusy]=useState(false),[decodeNeedsAd,setDecodeNeedsAd]=useState(false);
 /** Decode: free daily allowance first, then the admin-set Credit price, charged only when something was decoded. */
 const decodeNow=()=>{
   if(decodeBusy)return;
   if(!text.trim()){setError('Type a message or tap an example to get started.');return;}
   setError('');setDecodeNeedsAd(false);
   const r=decode(text);
   setDecodeBusy(true);
   void decodeConv.spend(r.recognized>0,cost=>new Promise<boolean>(res=>confirmAction('Decode for Credits?',`You’ve used today’s free decodes. This one costs ${cost} Credits, charged only because codes were found.`,()=>res(true),`Pay ${cost} Credits`,()=>res(false))))
     .then(p=>{if(p.ok)setResult(r);else{setError(p.message);setDecodeNeedsAd(!!p.needsAd);}})
     .finally(()=>setDecodeBusy(false));
 };
 const go=(t:Tab,find=false,connections?:ConnectionList)=>{setProfileConnections(connections);setFindPeople(find);setTab(t);setError('');setVisited(v=>v.has(t)?v:new Set([...v,t]));if(t==='Words')void refreshCommunity();};
 const suggest=(q='')=>{setSuggestion(q);openSheet('suggest');};
 const openTermById=(id:string)=>{const t=termsById.get(id);if(t){setSheet(null);openDetail(t);}};
 // Login-first entry (2026-11-08): the welcome screen's entry buttons open the
 // sign-in sheet instead of entering the app, so the login is the first
 // interface. After sign-up or sign-in, onContinue opens Decode; the
 // profile is opened manually from the You tab.
 const onboard=(t:Tab)=>{void act(setOnboarded).then(()=>go(t));};
 const recent=useMemo(()=>state.recent.map(r=>termsById.get(r.id)).filter((t):t is Term=>!!t),[state.recent,rev]);
 const modalPage=(heading:string,children:React.ReactNode,onClose:()=>void,tint?:readonly [string,string,...string[]])=><LinearGradient colors={tint??['#FAFBFF',C.bg]} start={tint?{x:0,y:0}:undefined} end={tint?{x:1,y:1}:undefined} style={s.fill}><SafeAreaView style={s.fill}><View style={s.modalBar}><RoundIcon name="arrow-back" label="Go back" onPress={onClose}/><Text style={s.modalTitle}>{heading}</Text><AdRewardButton compact/></View><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.modalContent}>{children}<CompanyFooter/></ScrollView></SafeAreaView></LinearGradient>;
 const loadingCard=<Glass><Text style={s.body}>Opening…</Text></Glass>;
 return <SafeAreaProvider><LinearGradient colors={['#FAFBFF',C.bg,'#EAF0FE']} style={s.fill}><StatusBar style="dark"/><View pointerEvents="none" style={s.backgroundOrb}/><View pointerEvents="none" style={s.backgroundOrb2}/><SafeAreaView style={s.fill}>
 {ready&&(health.status==='read-only'||health.status==='error')&&<View style={{paddingHorizontal:22,gap:8}}><Text accessibilityRole="alert" style={s.caption}>Recovery mode · saved data couldn’t be read, so nothing has been overwritten. New progress is temporary until it can be read.</Text><Button light title="Retry loading saved data" icon="refresh-outline" disabled={deleting} onPress={()=>void repository.load()}/></View>}
 {ready&&storageReady&&health.outcome==='reset-corrupt'&&health.quarantined>0&&<View style={[s.error,{marginBottom:6}]}><Icon name="information-circle-outline" size={18}/><Text style={[s.caption,{flex:1}]}>Some saved data was damaged and couldn’t be read. It was set aside, not deleted, and the app started fresh. See Threat Shield for details.</Text></View>}
 {!ready?<View style={s.loading}><AnimatedSplash/></View>:!p.onboarded?<ScrollView contentContainerStyle={s.welcome} bounces={false} showsVerticalScrollIndicator={false}>
 <View style={s.welcomeTop}><AdRewardButton/></View>
 <FadeIn><LiquidHero style={s.welcomeHeroCard}><Mark large/><Text style={s.welcomeHeroName}>GenZ Codebook</Text><Text style={s.welcomeHeroTagline}>Decode GenZ language — slang, abbreviations, terms and more, in one place.</Text><Text style={s.welcomeHeroEyebrow}>YOUR INTERNET LANGUAGE SIDEKICK</Text><Text style={s.welcomeHeroTitle}>Speak internet.{"\n"}<Text style={{color:'#7DD3FC'}}>Stay you.</Text></Text></LiquidHero></FadeIn>
 <FadeIn delay={120}><View style={s.welcomeFeatures}>
   <View style={s.welcomeFeature}><IconTile icon="scan-outline" from={C.accent} to={C.blue} size={40} iconSize={20}/><Text style={s.welcomeFeatureTitle}>Decode</Text><Text style={s.welcomeFeatureBody}>Understand any chat</Text></View>
   <View style={s.welcomeFeature}><IconTile icon="book-outline" from={C.purple} to="#a855f7" size={40} iconSize={20}/><Text style={s.welcomeFeatureTitle}>Words</Text><Text style={s.welcomeFeatureBody}>Learn &amp; explore</Text></View>
   <View style={s.welcomeFeature}><IconTile icon="game-controller-outline" from="#059669" to="#10b981" size={40} iconSize={20}/><Text style={s.welcomeFeatureTitle}>Play</Text><Text style={s.welcomeFeatureBody}>Learn with games</Text></View>
 </View></FadeIn>
 <FadeIn delay={240}><View style={s.welcomeActions}><Button title="Get Started" icon="arrow-forward" onPress={()=>openAccount('create')}/><Button title="Sign in" icon="log-in-outline" light onPress={()=>openAccount('signin')}/><View style={s.trustRow}><Badge icon="shield-checkmark-outline" text="Private by default"/><Badge icon="wifi-outline" text="Works offline"/></View><Pressable accessibilityRole="button" onPress={()=>openAccount('signin')} style={s.textButton}><Icon name="game-controller-outline" color={C.blue} size={20}/><Text style={s.link}>Or start with a quick game</Text><Icon name="arrow-forward" color={C.blue} size={17}/></Pressable><CompanyFooter/></View></FadeIn>
 </ScrollView>:<>
 {!communityTyping&&!(tab==='Inbox'&&conversationOpen)&&<AppHeader phase={authPhaseNow} credits={headerCredits.balance} reduceMotion={reduceMotion}
   caption={tab==='Decode'?'A little context. A lot more clarity.':tab==='Words'?'Your pocket codebook.':tab==='Community'?'One room. Everyone chatting.':tab==='Inbox'?'Personal messages & private groups.':tab==='Play'?'Small games. Big “aha” moments.':'Make yourself at home.'}
   avatar={<BrandAvatar index={p.avatar} size={36} photo={p.usePhoto?photo:null}/>}
   onCredits={()=>setSheet('wallet')} onNotifications={openNotifications} unread={announcements.unread} onProfile={()=>go('You')} onSignIn={()=>openAccount('signin')}/>}
 {!!error&&<Pressable accessibilityRole="button" onPress={()=>setError('')} style={s.error}><Icon name="information-circle-outline" size={18}/><Text accessibilityRole="alert" style={[s.caption,{flex:1}]}>{error} Tap to dismiss.</Text></Pressable>}
 <Animated.View style={[s.fill,{opacity:pageOpacity}]}>
 <ScrollView keyboardShouldPersistTaps="handled" style={{display:tab==='Decode'?'flex':'none'}} contentContainerStyle={s.content}>
 <DailyCodeBanner entry={dailyCode} admin={dailyAdmin} onApply={BACKEND_URL?()=>setSheet('daily-apply'):undefined}/>
 {!!BACKEND_URL&&<View style={s.wrap}><Chip label="My applications" icon="list-outline" onPress={()=>setSheet('daily-history')}/></View>}
 <View accessibilityRole="tablist" style={s.modeSwitch}>{(['decode','encode'] as const).map(m=><Pressable key={m} accessibilityRole="tab" accessibilityState={{selected:homeMode===m}} onPress={()=>setHomeMode(m)} style={[s.modeTab,homeMode===m&&s.modeTabOn]}><Icon name={m==='decode'?'scan':'code-slash'} size={17} color={homeMode===m?'#fff':C.accent}/><Text style={[s.modeText,homeMode===m&&{color:'#fff'}]}>{m==='decode'?'Decode':'Encode'}</Text></Pressable>)}</View>
 {homeMode==='encode'&&<EncodePanel onDecode={value=>{setText(value);setResult(decode(value));setHomeMode('decode');}}/>}
 {homeMode==='decode'&&<>
 <FadeIn delay={60}><Glass><View style={s.inline}><IconTile icon="chatbox-ellipses-outline" from={C.accent} to={C.purple} size={44} iconSize={22}/><Text style={s.rowTitle}>Your message</Text></View><TextInput accessibilityLabel="Message to decode" multiline maxLength={2000} value={text} onChangeText={v=>{setText(v);setResult(null);}} placeholder="e.g. lowkey cooked rn 😭" placeholderTextColor={C.muted} style={s.message} textAlignVertical="top"/><Button title={decodeBusy?'Working…':decodeConv.left>0||decodeConv.cost===0?'Decode message':`Decode · ${decodeConv.cost} Credits`} icon="scan" disabled={decodeBusy} onPress={decodeNow}/><Text style={s.convLabel}>{decodeConv.label}</Text>{decodeNeedsAd&&<Button light title={`Watch an optional ad · +${AD_BONUS} free decodes`} icon="play-circle-outline" onPress={()=>void decodeConv.watchForBonus().then(m=>{setError(m);setDecodeNeedsAd(false);})}/>}<View style={s.between}><Badge icon="lock-closed-outline" text="Stays on this device"/><Pressable accessibilityRole="button" accessibilityLabel="Clear message and analysis" onPress={()=>{setText('');setResult(null);}} style={s.clear}><Icon name="trash-outline" color={C.muted} size={16}/><Text style={s.caption}>Clear</Text></Pressable></View></Glass></FadeIn>
 {!result?<><Text style={s.label}>Not sure what to try?</Text><View style={s.wrap}>{['What is your 20?','no cap fr','kya scene hai?'].map(example=><Chip key={example} label={example} icon="sparkles-outline" onPress={()=>{setText(example);setResult(decode(example));}}/>)}</View><Pressable accessibilityRole="button" onPress={()=>go('Play')} style={s.gameTeaser}><View style={s.gameTeaserIcon}><Icon name="game-controller" color="#fff" size={27}/></View><View style={{flex:1,gap:4}}><Text style={s.rowTitle}>Got 60 seconds?</Text><Text style={s.caption}>Crack five codes in Chat starter.</Text></View><Icon name="arrow-forward-circle" color={C.blue} size={28}/></Pressable><Text style={s.fine}>Avoid personal information. Messages clear when you leave the app.</Text></>:<>
 {result.recognized>0&&<Glass><Badge icon="chatbox-ellipses-outline" text="Possible meaning"/><Text selectable style={s.definition}>{interpretMessage(result.segments)}</Text></Glass>}
 <View style={s.between}><Text style={s.sectionTitle}>Here’s the breakdown</Text><Badge icon="checkmark-circle-outline" text={`${result.recognized} found`}/></View>{result.recognized===0?<Glass><Icon name="help-circle-outline" color={C.blue} size={32}/><Text style={s.rowTitle}>No recognized expression in this message yet.</Text><Text style={s.body}>Try a shorter phrase or search the library.</Text><Button title="Open dictionary" icon="book-outline" light onPress={()=>go('Words')}/><Button title="Suggest a missing word" icon="add-circle-outline" onPress={()=>suggest()}/></Glass>:result.segments.filter(x=>x.term).map((part,i)=><PressableCard key={i} onPress={()=>openDetail(part.term!)} label={`Open ${part.term!.expression}`}><View style={s.inline}><View style={s.expressionBubble}><Text style={s.expressionText}>{part.text}</Text></View><View style={{flex:1,gap:4}}><Text style={s.rowTitle}>{part.term!.full}</Text><Text style={s.caption}>{part.term!.meaning}</Text><Text style={s.fine}>{part.term!.status} · tap for context</Text></View><Icon name="chevron-forward" size={18} color={C.blue}/></View></PressableCard>)}
 <Glass><Badge icon="text-outline" text="Literal expansion"/><Text selectable style={s.definition}>{result.plain}</Text><Text style={s.caption}>Possible meanings, not a certainty. Unmatched text stays as written.</Text></Glass><Glass><Badge icon="return-down-forward-outline" text="A neutral reply"/><Text selectable style={s.definition}>“Could you explain what you mean?”</Text><Text style={s.caption}>Pick words that fit your conversation.</Text></Glass></>}
 </>}
 <CreateCodeBanner onPress={()=>suggest()}/>
 <FadeIn><Glass><View style={s.inline}><IconTile icon="gift-outline" from="#f5b301" to={C.gold} size={44} iconSize={22}/><View style={{flex:1}}><Text style={s.rowTitle}>Daily reward</Text><Text style={s.caption}>{dailyReward.done?'Collected — come back tomorrow.':dailyReward.account?'+10 Credits and +10 learning points, once a day.':'Free 10 learning points, once a day.'}</Text></View></View><DailyRewardButton/></Glass></FadeIn>
 <CompanyFooter/>
 </ScrollView>
 <View style={{flex:1,display:tab==='Words'?'flex':'none'}}>{visited.has('Words')&&<DictionaryScreen key={dictionaryEpoch} dailyCode={<DailyCodeBanner entry={dailyCode} compact tone="gold" admin={dailyAdmin} onApply={BACKEND_URL?()=>setSheet('daily-apply'):undefined}/>} language={p.language} onLanguage={language=>void act(setLanguage(language))} saved={p.saved} savedRequest={savedRequest} onSelect={openDetail} searches={state.searches} recent={recent} onSearch={q=>void act(recordSearch(q),()=>{})} onSuggest={q=>suggest(q)}/>}</View>
 {tab==='Inbox'&&<MessagingScreen embedded onConversationChange={setConversationOpen} initialFind={findPeople} initialConnections={profileConnections} onClose={()=>go(findPeople||profileConnections?'You':'Community')} onSignIn={()=>openAccount('signin')}/>}
 <View style={{flex:1,display:tab==='Community'?'flex':'none'}}>{visited.has('Community')&&<CommunityScreen active={tab==='Community'} nickname={p.name} onSignIn={()=>openAccount('signin')} onOpenShop={()=>setSheet('shop')} onOpenDaily={()=>setSheet('daily')} onGoToPlay={()=>go('Play')} onMyPosts={()=>setSheet('my-posts')} tokens={state.tokens} leaderStats={{xp:leaderXp,credits:leaderCredits??0}} onTokensAction={a=>void act(a)}/>}</View>
 <ScrollView style={{display:tab==='Play'?'flex':'none'}} contentContainerStyle={s.contentCompact}>
 {tab==='Play'&&<PlayProgress state={state} profile={p} onOpen={openSheet}
 onSavedWords={()=>{setSavedRequest(v=>v+1);void act(setLanguage('All'));go('Words');}} onOpenTerm={openDetail}
 onReview={()=>{const g=reviewRound(p);if(g)start(g);}} onUnlockLevel={stageId=>void act(unlockLevelWithTokens(stageId))}/>}
 {visited.has('Play')&&<PlayHub xp={xp} completed={complete} stages={allStages} best={p.best} unlockedLevels={state.tokens.unlockedLevels} category={quizCategory} due={due.length} onCategory={value=>void act(setQuizCategory(value))} onQuiz={(category,daily)=>start(quizRound(category,daily?localDay():undefined))} onStart={(game,available)=>available?start(game):lockedLevel(game)} onReview={()=>{const game=reviewRound(p);if(game)start(game);}}/>}
 <CompanyFooter/>
 </ScrollView>
 <ScrollView style={{display:tab==='You'?'flex':'none'}} contentContainerStyle={s.content}>
 {visited.has('You')&&<ProfileDashboard active={tab==='You'} onFindPeople={()=>go('Inbox',true)} onMessages={()=>go('Inbox')} onConnections={list=>go('Inbox',false,list)} messageCount={privateInbox.unread+privateInbox.requests} credits={headerCredits.balance} about={publicAbout} profile={p} sync={sync} signedInEmail={user?.email??null} onEdit={openProfile} onOpen={openSheet} onAccount={openAccount} onSignOut={user?openSignOut:undefined} onSavedWords={()=>{setSavedRequest(v=>v+1);void act(setLanguage('All'));go('Words');}} onRefresh={refreshProfile} onPremium={()=>{setShopFocus('premium');openSheet('shop');}}/>}
 </ScrollView></Animated.View>
 {!communityTyping&&<NavBar items={nav.map(n=>({...n,badge:n.name==='Inbox'?privateInbox.unread+privateInbox.requests:n.name==='Play'?due.length:undefined}))} active={tab} onSelect={go}/>}
 </>}
 <Modal visible={!!detail} animationType={reduceMotion?"none":"fade"} onRequestClose={()=>setDetail(null)}>{detail&&modalPage('Inside the code',<TermDetail key={detail.id} term={detail} saved={p.saved.includes(detail.id)} saveError={detailError} onSave={()=>{setDetailError('');void act(toggleSaved(detail.id),setDetailError);}} onReport={()=>{setFormTerm({id:detail.id,expression:detail.expression});setDetail(null);openSheet('report');}}/>,()=>setDetail(null))}</Modal>
 <Modal visible={sheet!==null} animationType={reduceMotion?"none":"fade"} onRequestClose={()=>setSheet(null)}>{sheet&&modalPage(sheetTitles[sheet],<>
 {sheet==='login'&&<Suspense fallback={<Glass><Text style={s.body}>Opening your account…</Text></Glass>}><AccountScreen key={accountMode+(accountSignOut?'-signout':'')} initialMode={accountMode} startSignOut={accountSignOut} onContinue={()=>{void act(setOnboarded).then(()=>{setSheet(null);go('Decode');});}} onTokensEarned={amount=>void act(earnTokens(amount))}/></Suspense>}
 {(sheet==='daily-apply'||sheet==='daily-history'||sheet==='my-posts'||sheet==='verification')&&<ContributionScreen key={sheet} mode={sheet} onSignIn={()=>openAccount('signin')} onSuggest={()=>suggest()} onGetCredits={()=>setSheet('wallet')}/>}
 {sheet==='privacy'&&<Suspense fallback={loadingCard}><ThreatShieldScreen deleting={deleting} onOpenAccount={()=>openSheet('login')} onExport={()=>openSheet('export')} onDeleteLocal={()=>void deleteLocalData()} onClearMessage={()=>{setText('');setResult(null);setSheet(null);}}/></Suspense>}
 {(sheet==='feedback'||sheet==='suggest'||sheet==='report')&&<Suspense fallback={loadingCard}><Forms key={sheet+suggestion} kind={sheet} term={formTerm} initialTerm={suggestion} nickname={p.name} onSignIn={()=>openSheet('login')} onOpenTerm={openTermById} onOpenShop={()=>setSheet('shop')} onOpenDaily={()=>setSheet('daily')} tokens={state.tokens} onTokensAction={a=>void act(a)}/></Suspense>}
 {sheet==='export'&&<><Title title="Your learning, in your hands." description="Select and copy this JSON to keep a record. It contains your nickname, saves, scores, review progress and history on this device — never your messages, e-mail or password."/><Glass><Text selectable style={s.caption}>{exportLearning(state)}</Text></Glass></>}
 {sheet==='wallet'&&<Suspense fallback={loadingCard}><WalletScreen tokens={state.tokens} onTokensAction={a=>void act(a)} onOpenShop={()=>setSheet('shop')}/></Suspense>}
 {sheet==='shop'&&<Suspense fallback={loadingCard}><TokenShopScreen tokens={state.tokens} focus={shopFocus} onSignIn={()=>openSheet('login')} onOpenWallet={()=>setSheet('wallet')}/></Suspense>}
 {sheet==='daily'&&<><AccountTokens reward={false}/><Title title="Your daily reward is here." description={dailyReward.account?'+10 Credits and +10 learning points, once a day.':'Free learning points, once a day.'}/><Glass><View style={s.inline}><IconTile icon="gift-outline" from="#f5b301" to={C.gold} size={44} iconSize={22}/><View style={{flex:1}}><Text style={s.rowTitle}>{dailyReward.account?'+10 Credits · +10 points':'+10 learning points'}</Text><Text style={s.caption}>{dailyReward.done?'Collected for today — come back tomorrow.':'Free, once a day. No ad, no purchase.'}</Text></View></View><DailyRewardButton/></Glass><Glass><View style={s.inline}><IconTile icon="flame" from="#f97316" to="#f59e0b" size={44} iconSize={22}/><View style={{flex:1}}><Text style={s.rowTitle}>{dayStreak.current} day streak</Text><Text style={s.caption}>{dayStreak.current>=7?'A full week — keep it going.':`Come back daily to reach a 7-day streak. Best: ${dayStreak.best} days.`}</Text></View></View><ProgressBar value={Math.min(dayStreak.current,7)/7} color="#f59e0b"/></Glass><Button title="Maybe later" icon="close-outline" light onPress={()=>setSheet(null)}/></>}
 {sheet==='notifications'&&<NotificationsScreen state={state} newSince={noticeSince} onClose={()=>setSheet(null)}/>}
 {sheet==='my-suggestions'&&<MySuggestionsScreen tokens={state.tokens} nickname={p.name} onTokensAction={a=>void act(a)} onSignIn={()=>openAccount('signin')} onOpenShop={()=>setSheet('shop')} onClose={()=>setSheet(null)}/>}
 {sheet==='dashboard'&&<DashboardScreen state={state} profile={p} onClose={()=>setSheet(null)} onPlay={()=>{setSheet(null);go('Play');}} onReview={()=>{setSheet(null);const g=reviewRound(p);if(g)start(g);}}/>}
 {sheet==='achievements'&&<AchievementsScreen state={state} profile={p} onClose={()=>setSheet(null)}/>}
 {sheet==='settings'&&<SettingsScreen onClose={()=>setSheet(null)} onOpen={openSheet} onAccount={openAccount} onOpenAbout={()=>setSheet('about')} signedInEmail={user?.email??null} language={p.language} onLanguageChange={language=>void act(setLanguage(language))}/>}
 {sheet==='about'&&<AboutScreen onClose={()=>setSheet(null)}/>}
 {sheet==='edit'&&<><Title title="A profile that feels like you." description="Add your own photo or choose an icon, then pick a nickname. No personal details needed."/><Glass><Text style={s.label}>Your picture</Text><View style={s.wrap}><Pressable accessibilityRole="button" accessibilityLabel={photo?'Use my photo':'Upload a profile photo'} accessibilityState={{selected:editUsePhoto,busy:photoBusy}} disabled={photoBusy} onPress={()=>{if(photo)setEditUsePhoto(true);else void choosePhoto();}} style={[s.avatarChoice,{backgroundColor:'transparent'},editUsePhoto&&s.avatarChosen]}>{photo?<BrandAvatar photo={photo} size={59}/>:<View style={s.photoAdd}><Icon name={photoBusy?'hourglass-outline':'camera-outline'} size={24} color={C.blue}/></View>}{editUsePhoto&&<View style={s.avatarTick}><Icon name="checkmark" size={13} color={C.blue}/></View>}</Pressable>{avatars.map((a,i)=><Pressable key={a} accessibilityRole="button" accessibilityLabel={`Choose ${i===0?'GenZ Codebook profile':a} avatar`} accessibilityState={{selected:!editUsePhoto&&editAvatar===i}} onPress={()=>{setEditAvatar(i);setEditUsePhoto(false);}} style={[s.avatarChoice,{backgroundColor:'transparent'},!editUsePhoto&&editAvatar===i&&s.avatarChosen]}><BrandAvatar index={i} size={59}/>{!editUsePhoto&&editAvatar===i&&<View style={s.avatarTick}><Icon name="checkmark" size={13} color={C.blue}/></View>}</Pressable>)}</View>
 <View style={s.photoActions}><Button light title={photoBusy?'Opening photos…':photo?'Upload a new photo':'Upload a photo'} icon="image-outline" disabled={photoBusy} onPress={()=>void choosePhoto()}/>{!!photo&&<Button light title="Remove photo" icon="trash-outline" disabled={photoBusy} onPress={()=>void removePhoto().then(()=>{setEditUsePhoto(false);return act(setUsePhoto(false));}).catch(()=>setPhotoMsg('Couldn’t remove the photo. Please try again.'))}/>}</View>
 {!!photoMsg&&<Text accessibilityRole="alert" style={s.caption}>{photoMsg}</Text>}{!!user&&<Pressable accessibilityRole="switch" accessibilityState={{checked:sharePhoto&&editUsePhoto}} disabled={!editUsePhoto||!photo} onPress={()=>setSharePhotoState(v=>!v)} style={[s.shareRow,(!editUsePhoto||!photo)&&{opacity:.5}]}><Icon name={sharePhoto&&editUsePhoto?'checkbox':'square-outline'} size={22} color={C.accent}/><Text style={[s.caption,{flex:1}]}>Show my photo on my posts and comments</Text></Pressable>}
 <Text style={s.fine}>{sharePhoto&&editUsePhoto&&user?'A small copy of your photo (96 px) is shown beside your community posts and comments. Turn this off to remove it.':'We use the centre of your photo as a circle. It stays on this device unless you choose to show it on your posts. Your avatar icon and nickname appear beside your posts.'}</Text>
 <Text style={s.label}>Your nickname</Text><TextInput accessibilityLabel="Profile nickname" value={editName} onChangeText={setEditName} maxLength={24} placeholder="Code Explorer" style={s.nameInput}/>{!!user&&([
  ['bio','Bio',280],['location','Location',60],['interests','Interests',120],['favoriteCategories','Favorite categories',100],
 ] as const).map(([key,label,maxLength])=><View key={key} style={{gap:6}}>
  <Text style={s.label}>{label}</Text>
  <TextInput accessibilityLabel={label} value={editAbout[key]??''} onChangeText={value=>setEditAbout(prev=>({...prev,[key]:value}))}
   maxLength={maxLength} multiline={key==='bio'} placeholder="Optional · shown on your profile" style={s.nameInput}/>
 </View>)}<Button title="Save my profile" icon="checkmark-circle-outline" onPress={()=>void act(setProfileDetails(editName,editAvatar)).then(ok=>ok&&act(setUsePhoto(editUsePhoto&&!!photo))).then(ok=>{if(!ok)return;void setSharePhoto(sharePhoto);if(user)void publishPublicProfile({name:editName,avatar:editAvatar,photo:sharePhoto&&editUsePhoto?photo:null,about:editAbout}).catch(()=>setError('Your local profile was saved. Public details could not sync. Check your connection and keep contact links out of your profile fields.'));setSheet(null);})}/></Glass>{!!user&&<Glass><Text style={s.label}>Your account</Text><Text style={s.caption} numberOfLines={1}>{user.email??'Signed in'}</Text><Button light title="Sign out" icon="log-out-outline" onPress={openSignOut}/></Glass>}</>}
 {sheet==='guide'&&<>
 <Title title="Learn the Codebook"/>
 <Glass><Text style={s.sectionTitle}>Types of expressions</Text>{[
  ['Slang','Informal words and expressions','Rizz, No Cap, Bet'],
  ['Code','Words, numbers or symbols used as shorthand','247 = I’m eating'],
  ['Code Word','A custom word with an agreed meaning','Eatzy = I’m eating'],
  ['Numeric Code','Numbers that stand for an activity or message','505 = Enjoying food'],
 ].map(([type,use,example])=><View key={type} style={{gap:3}}><Text style={s.rowTitle}>{type}</Text><Text style={s.body}>{use}</Text><Text style={s.caption}>{example}</Text></View>)}
 <Text style={s.caption}>Custom codes only work when the people using them agree on the meaning.</Text></Glass>
 {[
  {icon:'book-outline' as IconName,title:'1. Explore',body:'Open Codebook and search for a word or number. Read the example and check how the meaning changes by context.'},
  {icon:'scan-outline' as IconName,title:'2. Decode in context',body:'Paste a message on Home. Read its possible meaning, then check the breakdown for alternate meanings of unfamiliar terms.'},
  {icon:'code-slash-outline' as IconName,title:'3. Try encoding',body:'Write a plain-language message. Review the whole coded sentence and tap highlighted codes to see any alternatives.'},
  {icon:'bookmark-outline' as IconName,title:'4. Save and review',body:'Bookmark useful expressions. Find them under You → My saved words and practise them again in Play.'},
  {icon:'game-controller-outline' as IconName,title:'5. Practise',body:'Try a quiz or the daily review in Play. Use the explanations to learn why each answer fits.'},
 ].map(v=><Glass key={v.title}><Icon name={v.icon} size={27} color={C.blue}/><Text style={s.sectionTitle}>{v.title}</Text><Text style={s.body}>{v.body}</Text></Glass>)}
 <Button title="Open Codebook" icon="book-outline" onPress={()=>{setSheet(null);go('Words');}}/>
 </>}
 </>,()=>setSheet(null),sheet==='login'&&!user?['#E9F0FF','#F3EEFF','#E6F7FF']:undefined)}</Modal>
 <Modal visible={!!stage} animationType={reduceMotion?"none":"slide"} onRequestClose={()=>setStage(null)}>{stage&&modalPage(stage.name,finished?<><View style={s.finishHero}><View style={s.trophy}><Icon name={score>=3?'trophy':'bulb'} size={58} color="#b17a23"/></View><Text style={s.title}>{stage.id==='review'?'Review complete!':score===stage.questions.length?'Code cracked!':score>=3?'Level cleared!':'Every try teaches you.'}</Text><Text style={s.score}>{score}<Text style={{fontSize:24,color:C.muted}}> / {stage.questions.length}</Text></Text><Text style={s.body}>{stage.id==='review'?'Your next review is scheduled. Come back when words are due.':stage.id.startsWith('shuffle-')||stage.id.startsWith('daily-')?'Keep exploring. A fresh round is waiting.':score>=3?'Your next challenge is ready.':'Try again. Three correct answers unlock the next level.'}</Text></View><Glass><Badge icon="flash-outline" text={stage.id==='review'?'Review schedule updated':`Best score: ${p.best[stage.id]??0}%`}/><Text style={s.caption}>XP reflects your best result, so you can replay without pressure.</Text></Glass>{score>=3&&stage.id!=='review'&&<SupportAdButton/>}<Button title="Back to levels" icon="map-outline" onPress={()=>{setStage(null);go('Play');}}/><Button title="Play again" icon="refresh-outline" light onPress={()=>start(stage)}/></>:<>
 <View style={s.between}><Badge icon="game-controller-outline" text={`QUESTION ${qi+1} OF ${stage.questions.length}`}/><Badge icon="checkmark-circle-outline" text={`${score} correct`}/></View><ProgressBar value={(qi+1)/stage.questions.length} color={C.accent}/><Glass><View style={[s.levelIcon,{backgroundColor:stage.color}]}><Icon name={stage.icon} color="#fff" size={26}/></View><Text style={s.question}>{stage.questions[qi]!.prompt}</Text><View style={s.replyBox}><Text style={s.definition}>{stage.questions[qi]!.context}</Text></View></Glass>
 {stage.questions[qi]!.answers.map((a,i)=>{const show=choice!==null;const correct=i===stage.questions[qi]!.correct;if(i===hiddenAnswer)return null;return <Pressable key={`${qi}-${i}`} disabled={show||hintBusy} accessibilityRole="button" accessibilityState={{selected:choice===i,disabled:show||hintBusy}} onPress={()=>answer(i)} style={[s.answer,show&&correct&&s.correct,show&&choice===i&&!correct&&s.incorrect]}><View style={s.answerLetter}><Text style={s.rowTitle}>{String.fromCharCode(65+i)}</Text></View><Text style={[s.body,{flex:1,color:C.ink}]}>{a}</Text>{show&&<Icon name={correct?'checkmark-circle':choice===i?'close-circle':'ellipse-outline'} color={correct?'#00634d':choice===i?'#a23842':C.muted}/>}</Pressable>})}
 {Platform.OS==='android'&&choice===null&&hiddenAnswer===null&&<Button light title={hintBusy?'Loading optional ad…':'Watch ad · remove one wrong answer'} icon="bulb-outline" disabled={hintBusy} onPress={()=>void rewardedHint()}/>}
 {!!hintMessage&&<Text accessibilityLiveRegion="polite" style={s.caption}>{hintMessage}</Text>}
 {choice!==null&&<Glass style={{backgroundColor:choice===stage.questions[qi]!.correct?'#e2f5ed':'#fff2eb'}}><Badge icon={choice===stage.questions[qi]!.correct?'checkmark-circle-outline':'bulb-outline'} text={choice===stage.questions[qi]!.correct?'Nice. You got the context.':'Good one to remember.'}/><Text accessibilityRole="alert" style={s.body}>{stage.questions[qi]!.why}</Text><Button title={qi+1===stage.questions.length?'See my result':'Next question'} icon="arrow-forward" onPress={next}/></Glass>}
 </>,()=>setStage(null))}</Modal>
 </SafeAreaView></LinearGradient></SafeAreaProvider>;
}
const s=StyleSheet.create({
 shareRow:{flexDirection:'row',alignItems:'center',gap:10,minHeight:44,paddingVertical:6},
 convLabel:{fontSize:12.5,fontWeight:'800',color:'#6D28D9'},
 modeSwitch:{flexDirection:'row',backgroundColor:'#fff',borderRadius:16,padding:4,gap:4,borderWidth:1,borderColor:'#E2E8F5'},modeTab:{flex:1,minHeight:42,borderRadius:12,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:6},modeTabOn:{backgroundColor:C.accent},modeText:{fontWeight:'900',fontSize:14,color:C.accent},fill:{flex:1},headerSignIn:{flexDirection:'row',alignItems:'center',gap:6,minHeight:40,paddingHorizontal:14,borderRadius:14,backgroundColor:C.blue,borderBottomWidth:2,borderBottomColor:'#1647bd'},headerSignInText:{color:'#fff',fontWeight:'800',fontSize:13},tokenPill:{flexDirection:'row',alignItems:'center',gap:5,minHeight:40,maxWidth:220,paddingHorizontal:12,borderRadius:14,borderWidth:1,borderColor:'#ffe9a8',shadowColor:'#f5b301',shadowOffset:{width:0,height:2},shadowOpacity:.45,shadowRadius:6,elevation:4},tokenPillText:{fontSize:14,fontWeight:'900',color:'#8a5a00',flexShrink:1},photoAdd:{width:59,height:59,borderRadius:30,borderWidth:2,borderStyle:'dashed',borderColor:'#9db6e6',backgroundColor:'#eef4ff',alignItems:'center',justifyContent:'center'},photoActions:{gap:10},backgroundOrb:{position:'absolute',width:320,height:320,borderRadius:200,backgroundColor:'rgba(126,225,243,.22)',top:100,right:-170},backgroundOrb2:{position:'absolute',width:350,height:350,borderRadius:200,backgroundColor:'rgba(167,197,255,.2)',bottom:30,left:-200},loading:{...StyleSheet.absoluteFillObject,backgroundColor:'#FFF4FF',alignItems:'center',justifyContent:'center'},welcome:{flexGrow:1,padding:16,paddingTop:8,gap:16,maxWidth:520,width:'100%',alignSelf:'center',justifyContent:'flex-start'},welcomeTop:{flexDirection:'row',justifyContent:'flex-end',alignItems:'center'},welcomeHero:{alignItems:'center',gap:16},welcomeHeroCard:{borderRadius:24,padding:20,alignItems:'center',gap:12,overflow:'hidden',shadowColor:'#101A3A',shadowOffset:{width:0,height:8},shadowOpacity:.25,shadowRadius:16,elevation:5},welcomeHeroName:{fontSize:24,fontWeight:'900',letterSpacing:-.5,color:'#fff',textAlign:'center'},welcomeHeroTagline:{fontSize:15,lineHeight:22,color:'rgba(255,255,255,.85)',textAlign:'center',maxWidth:340},welcomeHeroEyebrow:{fontSize:10,fontWeight:'800',letterSpacing:1.6,color:'#7DD3FC',textAlign:'center'},welcomeHeroTitle:{fontSize:40,lineHeight:46,fontWeight:'900',letterSpacing:-1.5,textAlign:'center',color:'#fff'},welcomeTagline:{fontSize:15,lineHeight:22,color:C.muted,textAlign:'center',maxWidth:340},welcomeFeatures:{flexDirection:'row',gap:12},welcomeFeature:{flex:1,alignItems:'center',gap:6,backgroundColor:'rgba(255,255,255,.8)',borderWidth:1,borderColor:'#fff',borderRadius:20,paddingVertical:12,paddingHorizontal:8},welcomeFeatureIcon:{width:48,height:48,borderRadius:16,backgroundColor:C.blue,alignItems:'center',justifyContent:'center'},welcomeFeatureTitle:{fontSize:15,fontWeight:'800',color:C.ink},welcomeFeatureBody:{fontSize:12,lineHeight:16,color:C.muted,textAlign:'center'},welcomeHeader:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',gap:12},brand:{fontSize:21,fontWeight:'900',letterSpacing:-.7,color:C.ink},signIn:{flexDirection:'row',gap:5,alignItems:'center',minHeight:48},heroArt:{height:230,alignItems:'center',justifyContent:'center',marginTop:5},iconPedestal:{transform:[{rotate:'-8deg'}],marginTop:8},floatPill:{position:'absolute',zIndex:2,backgroundColor:'rgba(255,255,255,.88)',borderWidth:1.5,borderColor:'#fff',padding:14,borderRadius:21,flexDirection:'row',gap:9,alignItems:'center',shadowColor:'#4671a9',shadowOffset:{width:0,height:6},shadowOpacity:.14,shadowRadius:12,elevation:5},pillWord:{fontSize:23,fontWeight:'800',color:C.ink},artDot:{width:15,height:15,borderRadius:6,backgroundColor:'#77cfc5',position:'absolute',left:45,bottom:22,transform:[{rotate:'20deg'}]},center:{alignItems:'center',gap:18},eyebrow:{fontSize:10,fontWeight:'800',letterSpacing:1.6,color:C.blue},welcomeTitle:{fontSize:46,lineHeight:53,fontWeight:'900',letterSpacing:-2,textAlign:'center',color:C.ink},welcomeBody:{fontSize:17,lineHeight:26,color:C.muted,textAlign:'center'},welcomeActions:{gap:17,paddingBottom:10},trustRow:{flexDirection:'row',flexWrap:'wrap',alignItems:'center',justifyContent:'center',gap:17},inline:{flexDirection:'row',alignItems:'center',gap:9},link:{fontSize:14,color:C.blue,fontWeight:'700'},textButton:{minHeight:44,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:8},caption:{fontSize:12,lineHeight:18,color:C.muted},body:{fontSize:15,lineHeight:23,color:C.muted},fine:{fontSize:11,lineHeight:17,color:'#5c7189'},header:{paddingHorizontal:20,paddingVertical:6,gap:4,flexShrink:0,backgroundColor:'#FAFBFF',borderBottomWidth:1,borderBottomColor:C.line},headerRow:{flexDirection:'row',alignItems:'center',gap:8},headerBrand:{flex:1,minWidth:0},headerCaption:{color:C.muted,fontSize:11,lineHeight:14,includeFontPadding:false},avatarSmall:{height:44,width:44,borderRadius:22,borderWidth:2,borderColor:'#fff',justifyContent:'center',alignItems:'center'},content:{padding:16,gap:14,paddingBottom:30,maxWidth:580,width:'100%',alignSelf:'center'},contentCompact:{padding:16,gap:12,paddingBottom:24,maxWidth:580,width:'100%',alignSelf:'center'},titleGroup:{gap:9},title:{fontSize:32,lineHeight:38,fontWeight:'900',letterSpacing:-1.2,color:C.ink},miniIcon:{width:40,height:40,borderRadius:14,backgroundColor:'#e3eeff',alignItems:'center',justifyContent:'center',borderTopWidth:1,borderTopColor:'#fff'},rowTitle:{fontSize:16,fontWeight:'800',color:C.ink},message:{backgroundColor:'#e7eff8',borderRadius:19,padding:16,minHeight:118,borderWidth:1,borderColor:'#bdcfe4',borderBottomColor:'#fff',fontSize:19,lineHeight:28,color:C.ink},between:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:10},clear:{minHeight:44,flexDirection:'row',gap:5,alignItems:'center'},label:{fontSize:14,color:C.ink,fontWeight:'800'},wrap:{flexDirection:'row',flexWrap:'wrap',gap:9},gameTeaser:{padding:17,backgroundColor:'rgba(255,255,255,.66)',borderRadius:23,borderWidth:1.5,borderColor:'#fff',flexDirection:'row',alignItems:'center',gap:13,marginTop:4},gameTeaserIcon:{width:49,height:49,borderRadius:17,backgroundColor:'#3769dc',alignItems:'center',justifyContent:'center',borderTopWidth:2,borderTopColor:'#8ba9fb',borderBottomWidth:3,borderBottomColor:'#164bc3'},sectionTitle:{fontSize:20,fontWeight:'800',letterSpacing:-.4,color:C.ink},resultRow:{backgroundColor:'rgba(255,255,255,.78)',borderRadius:20,padding:16,borderWidth:1,borderColor:'#fff',flexDirection:'row',alignItems:'center',gap:14},expressionBubble:{minWidth:52,maxWidth:110,backgroundColor:'#dce9ff',padding:11,borderRadius:15,alignItems:'center'},expressionText:{fontSize:19,fontWeight:'800',color:C.blue},definition:{fontSize:18,lineHeight:27,color:C.ink,fontWeight:'600'},search:{flexDirection:'row',alignItems:'center',gap:12,padding:9,paddingLeft:17,borderRadius:22,backgroundColor:'rgba(255,255,255,.8)',borderWidth:1.5,borderColor:'#fff'},searchInput:{flex:1,fontSize:16,color:C.ink,minHeight:44},wordRow:{flexDirection:'row',alignItems:'center',padding:15,borderRadius:21,backgroundColor:'rgba(255,255,255,.75)',gap:14,borderWidth:1,borderColor:'#fff'},wordTile:{width:47,height:47,backgroundColor:'#e4effd',borderRadius:16,alignItems:'center',justifyContent:'center'},wordTitle:{fontSize:20,fontWeight:'800',color:C.ink},xpCard:{flexDirection:'row',alignItems:'center',justifyContent:'space-between'},xpIcon:{backgroundColor:'#2c70df',padding:12,borderRadius:18},stars:{flexDirection:'row',gap:4},levelCard:{borderRadius:25,shadowColor:'#46709f',shadowOffset:{width:0,height:6},shadowOpacity:.13,shadowRadius:10,elevation:4},gameModeRow:{flexDirection:'row',gap:12},modeTile:{flex:1,alignItems:'center',gap:8,backgroundColor:C.soft,borderWidth:1,borderColor:'#d6e8fb',borderRadius:16,paddingVertical:14,paddingHorizontal:6},modeTitle:{fontSize:15,fontWeight:'800',color:C.navy,textAlign:'center'},playCard:{gap:14},reviewRow:{padding:12},reviewBtn:{minHeight:44,paddingHorizontal:16,borderRadius:14,backgroundColor:C.accent,alignItems:'center',justifyContent:'center',borderBottomWidth:2,borderBottomColor:'#1344b8'},reviewBtnText:{fontSize:14,fontWeight:'800',color:'#fff'},decodeHero:{borderRadius:22,padding:18,gap:6,overflow:'hidden',shadowColor:'#101A3A',shadowOffset:{width:0,height:8},shadowOpacity:.25,shadowRadius:16,elevation:5},decodeEyebrow:{fontSize:10,fontWeight:'800',letterSpacing:1.8,color:'rgba(255,255,255,.75)'},decodeTitle:{fontSize:28,lineHeight:34,fontWeight:'900',letterSpacing:-1,color:'#fff'},decodeSub:{fontSize:14,lineHeight:20,color:'rgba(255,255,255,.82)'},levelInner:{padding:12,borderRadius:22,borderWidth:1.5,borderTopColor:'#fff',borderLeftColor:'#fff',borderRightColor:'#d4e2f2',borderBottomColor:'#b6cae2',borderBottomWidth:3,flexDirection:'row',alignItems:'center',gap:10},levelIcon:{height:48,width:48,borderRadius:16,alignItems:'center',justifyContent:'center',borderTopWidth:2,borderTopColor:'rgba(255,255,255,.6)',borderBottomWidth:3,borderBottomColor:'rgba(0,0,0,.18)',overflow:'hidden'},levelShine:{position:'absolute',top:0,left:0,right:0,height:18,backgroundColor:'rgba(255,255,255,.16)',borderBottomLeftRadius:15,borderBottomRightRadius:15},levelTitle:{fontSize:17,fontWeight:'900',color:C.ink,letterSpacing:-.5},profileHero:{alignItems:'center',paddingVertical:28},avatarLarge:{width:104,height:104,borderRadius:52,borderWidth:3,borderColor:'#fff',alignItems:'center',justifyContent:'center',shadowColor:'#4777b5',shadowOpacity:.18,shadowRadius:15,shadowOffset:{width:0,height:6},elevation:5},profileName:{fontSize:25,fontWeight:'900',color:C.ink},stats:{flexDirection:'row',gap:12},stat:{flex:1,backgroundColor:'rgba(255,255,255,.65)',borderRadius:23,padding:17,alignItems:'center',gap:7,borderWidth:1,borderColor:'#fff'},statNumber:{fontSize:24,fontWeight:'900',color:C.ink},badges:{flexDirection:'row',gap:8},achievement:{flex:1,alignItems:'center',gap:7},medal:{width:58,height:58,borderRadius:22,backgroundColor:'#ffefca',borderWidth:2,borderTopColor:'#fff6df',borderColor:'#dec99c',alignItems:'center',justifyContent:'center'},badgeText:{fontSize:11,fontWeight:'700',color:C.ink,textAlign:'center'},settingRow:{padding:14,minHeight:70,flexDirection:'row',alignItems:'center',gap:13},nav:{flexDirection:'row',backgroundColor:'rgba(246,251,255,.94)',borderTopWidth:1,borderTopColor:'#fff',padding:8,gap:6},navTab:{flex:1,alignItems:'center',justifyContent:'center',paddingVertical:10,gap:4,minHeight:64,borderRadius:20},navSelected:{backgroundColor:'#dceaff',borderWidth:1,borderTopColor:'#fff',borderColor:'#ccddf2'},navLabel:{fontSize:11,color:C.muted},navDot:{height:3,width:13,backgroundColor:C.blue,borderRadius:3},modalBar:{padding:18,flexDirection:'row',alignItems:'center',gap:12},modalTitle:{flex:1,fontSize:18,fontWeight:'800',color:C.ink},modalContent:{padding:22,gap:20,maxWidth:580,width:'100%',alignSelf:'center',paddingBottom:40},termHero:{paddingVertical:6,gap:16},termHuge:{fontSize:60,fontWeight:'900',color:C.blue,letterSpacing:-2},detailTitle:{fontSize:28,fontWeight:'800',color:C.ink},replyBox:{padding:16,gap:8,borderRadius:18,backgroundColor:'#e6f0fb',borderWidth:1,borderTopColor:'#c2d5e9',borderColor:'#d4e2f0'},unavailable:{minHeight:58,borderRadius:17,backgroundColor:'#e9eff5',padding:14,flexDirection:'row',alignItems:'center',gap:10},disabledLabel:{flex:1,color:C.muted,fontSize:16,fontWeight:'700'},avatarChoice:{width:69,height:69,borderRadius:35,borderWidth:3,borderColor:'transparent',alignItems:'center',justifyContent:'center'},avatarChosen:{borderColor:'#fff',outlineColor:C.blue,outlineWidth:2},avatarTick:{position:'absolute',bottom:-2,right:-2,borderRadius:10,backgroundColor:'#fff',padding:3},nameInput:{minHeight:56,borderRadius:17,borderWidth:1,borderColor:'#bccfe6',padding:16,fontSize:17,color:C.ink,backgroundColor:'#e7f0fb'},track:{height:8,borderRadius:8,backgroundColor:'#cbdcf0',overflow:'hidden'},fillTrack:{height:8,backgroundColor:C.blue,borderRadius:8},question:{fontSize:26,fontWeight:'900',lineHeight:34,color:C.ink,letterSpacing:-.6},answer:{flexDirection:'row',alignItems:'center',gap:12,minHeight:68,padding:14,backgroundColor:'rgba(255,255,255,.8)',borderWidth:1.5,borderColor:'#fff',borderBottomWidth:3,borderBottomColor:'#c4d6eb',borderRadius:21},answerLetter:{width:34,height:34,borderRadius:12,backgroundColor:'#e4edfa',alignItems:'center',justifyContent:'center'},correct:{backgroundColor:'#e1f5e9',borderColor:'#77bb95'},incorrect:{backgroundColor:'#fff0ee',borderColor:'#d0a09c'},finishHero:{alignItems:'center',gap:20,paddingVertical:16},trophy:{height:114,width:114,borderRadius:40,backgroundColor:'#fff0c5',borderWidth:3,borderColor:'#fff9e8',alignItems:'center',justifyContent:'center'},score:{fontSize:74,fontWeight:'900',color:C.blue},error:{marginHorizontal:20,padding:12,borderRadius:13,backgroundColor:'#fff1cf',flexDirection:'row',gap:9}});
