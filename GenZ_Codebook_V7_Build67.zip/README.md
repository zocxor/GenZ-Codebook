# Build 67 — Create Code help link, maintenance recovery, and stricter Community reaction privacy. Version 1.0.3. See [the V7 upgrade report](docs/V7_UPGRADE_REPORT.md).

# Build 66 — Chat keyboard insets, compact Inbox and Community controls, searchable emoji and message interpretation. Version 1.0.2. See [the V7 upgrade report](docs/V7_UPGRADE_REPORT.md).

# Build 65 — Direct messaging (no requests), WhatsApp-style + attachment tray, block and report in every chat, + on the Inbox, photo-error diagnostics. Version 1.0.1. See [the V7 upgrade report](docs/V7_UPGRADE_REPORT.md).

# Build 64 — Removes the blurry line above the bottom navigation; natural-tone Slangs / Codes / Posts cards on the dark profile; highlighted Get Premium and Buy Credits buttons. Includes Builds 62–63. Version 1.0.1.

# Build 63 — Report user on profiles; privacy policy covers profiles and followers; admin notifications to all, selected users or a custom group; highlighted Send notifications; Daily Code calendar colours restored; banner logo fixed. Version 1.0.1.

# Build 62 — Fixes the APK test failure; Codes search Top match with Copy code / meaning / all details; bell badge for admin announcements; messaging verified; admin Dark mode in the teal–amber Liquid Glass palette. Version 1.0.1.

# Build 60 — Implemented three coloured Slangs / Codes / Posts count cards on owner and public profiles. Version 1.0.1.

# Build 59 — Admin portal Light: royal blue and sky blue; Dark: dark teal and teal. Version 1.0.1.

# Build 57 — Minimal profile code copy/link icons for owner and public views. Version 1.0.1.

# Build 56 — Horizontal public-profile activity tabs. Version 1.0.1.

# Build 55 — Liquid Glass admin and compact profile actions. Version 1.0.1.

# Build 46 — Premium profile cards, refined progress and aligned settings. Version 1.1.0.

# Build 45 — Private Inbox, personal message requests and private group chat. Version 1.1.0. See [Messaging implementation and release steps](docs/BUILD45_MESSAGING.md).

# Build 44 — Packaging repair: restore all 12 admin/src/lib source modules omitted from the Build 43 ZIP. UI changes unchanged.

# Build 43 — Dictionary post selector, reference-style profile layout, and accessible admin sign-in colours. Version 1.0.1.

> **Updating this project? Read [docs/PROJECT_GUIDE.md](docs/PROJECT_GUIDE.md) first** — project map, rules, build/deploy steps, Play products and how to deliver an update.

# Build 42 — Admin portal Claymorphism redesign (Light, Dark, System) and Community Posts header layout. Version 1.0.1. See **[the V7 upgrade report](docs/V7_UPGRADE_REPORT.md)**.

# Build 40 — GenZ Codebook V7 (version 1.0.1)

Ads are now skippable and optional: the only automatic one is a close-able ad when deleting your own post; a skippable “support us” ad is offered after a cleared level, and “watch an ad to unlock” on locked levels. See **[the V7 upgrade report](docs/V7_UPGRADE_REPORT.md)**.

# Build 39 — GenZ Codebook V7

Light futuristic sign-in page, colourful level icons and avatars, automatic sync and sign-out, a safer Threat Shield view, one shared daily reward, an ad when deleting a post, and today’s Daily Code actions in the admin portal. Includes Builds 37–38. See **[the V7 upgrade report](docs/V7_UPGRADE_REPORT.md)**.

# Build 38 — GenZ Codebook V7

Admin edit / replace / remove for today’s Daily Code, Sign out on the You and profile pages, clearer “send a new verification link”, futuristic login buttons. Includes Build 37 (Google Play purchases on). See **[the V7 upgrade report](docs/V7_UPGRADE_REPORT.md)**.

# Build 37 — GenZ Codebook V7

Google Play Credit packs and Premium switched on, with server verification and three purchase fixes (one subscription per account, plan changes, pending payments). See **[the V7 upgrade report](docs/V7_UPGRADE_REPORT.md)**.

# Build 36 — GenZ Codebook V7

Fixes the 30-second startup, the admin Credit grant error reporting, the Daily Code Confirm button and scheduling list, chatroom sign-in recognition and slow likes. Adds Encode Message, the V7 header and post cards, a paid-community switch (chat 30/day, post 50, code 150), admin Credit deductions, Stay connected links and the browser favicon. Read **[the V7 upgrade report](docs/V7_UPGRADE_REPORT.md)** for root causes, measurements, test results, deployment order and what is still open. Earlier notes below are historical.

# Build 29 — Firebase Blaze backend

The active backend is now Firebase Cloud Functions in `us-central1` for project `gen-z-code-55caf`. No VPS or purchased domain is needed. The existing `web.app` site stays in place. Read [Build 29 setup and validation](docs/BUILD29_BLAZE.md). Earlier build notes below are historical.

Deploy **Actions → Deploy Firebase → community** for account tokens, grants, ad rewards, Daily Code scheduling and cleanup. Creating codes, Community Posts and Chat remain free. One-time Play checkout is still disabled until its separate credentials/catalog have been tested. Rebuild Android after deploying the backend.

# Build 28 — Firebase Spark + VPS backend

Keep Firebase Authentication, Firestore, Hosting and free contributions on Spark, within free quotas. The VPS runs secure account-token payments, verified ad rewards, Daily Code scheduling and optional Play purchase verification. Creating codes, community posts and chat are free; admins can pause publishing or require review.

Start with [VPS setup](docs/VPS_SETUP.md) and [implementation/testing report](docs/BUILD28_REPORT.md). The API URL is deliberately empty until your server is online. Paid actions remain unavailable until configured. Deploy Firebase using **Actions → Deploy Firebase → spark**; this target does not deploy Cloud Functions. Rebuild the APK after configuring the API URL. Earlier notes below describe historical builds and pricing.

# GenZ Codebook 1.0.0

## UI v5

The Android app uses React Native Animated for tab fades, progress feedback and the navigation indicator. The admin portal uses Motion for React for page transitions and live dashboard cards. Both follow the user's reduced-motion preference. The message decoder continues to use the bundled dictionary and runs locally.

## Community and Daily Code

[Implementation, deployment and test report](docs/COMMUNITY_FEATURES_REPORT.md).

## Build 27 · Publishing controls and token payments

Publishing is immediate by default. Admins can switch codes and posts to approval required or paused. Create a dictionary code for 150 account tokens, post for 25, or buy a 30-token UTC daily Chat Pass.

Rewarded ads add 10 device tokens. Signed-in users receive usable account tokens through the verified AdMob callback after deployment. See [the Build 26 report](docs/BUILD26_REPORT.md) for setup and migration limits.

Chat uses a compact room with a keyboard-aware composer. The profile groups learning, wallet, contribution and account details. See [Community Posts deployment](docs/ADMIN_PORTAL.md#community-posts-deployment) to activate posting and verified token checks.

## Daily Code picker and liquid-glass cards

The admin portal can schedule a selected dictionary word or auto-pick an entry. The updated dark hero cards appear in the Android build. See [Daily Code scheduling](docs/ADMIN_PORTAL.md#daily-code-scheduling) for deployment.

The token shop lists one-time packs and shows live Google Play prices when verification and pricing are configured. Checkout is blocked in builds with an empty purchase verification URL. Existing Premium subscribers can still manage their subscription in Wallet. Words and Decode share the same Daily Code, with a compact application shortcut on Words.

## Build Android and deploy Firebase from GitHub

1. Extract the source archive and commit its contents at the root of your existing repository. The root should contain `package.json`, `android/`, `firebase.json` and `.github/workflows/`. Include hidden files. Keep the existing repository so its Actions secrets remain available.
2. Open **Actions → Android APK → Run workflow**. Use the default arm64 setting for a typical Android phone. When the build succeeds, download **genz-code-apk** under **Artifacts** and extract `app-internal.apk`. The artifact report shows version name **1.0.0** and version code **26**.
3. If you also need to publish the web pages, open **Actions → Deploy Firebase → Run workflow** and choose **admin-portal**. This uses the existing `FIREBASE_SERVICE_ACCOUNT` Actions secret to publish Hosting for `gen-z-code-55caf`. Select **everything** only when you also intend to deploy Firestore rules, indexes and Cloud Functions. The functions use Node.js 22 and still require the existing Firebase billing setup and Play service-account secret.

The manual workflows can use one source ZIP as a fallback when the source is absent at the repository root. GitHub still needs the updated workflow files committed under `.github/workflows/`. The extracted source takes priority if both are present.

For Android, install the new APK over the previous internal build if Android accepts the signing certificate. Sign in, check that **Decode** opens, dismiss the daily reward if it appears, then force-stop and reopen to check session restoration. Also test one incorrect password and Google sign-in if it is configured. See [Android build and crash-log instructions](docs/BUILD_APK.md).

## 0.8.0 upgrade notes

Data persistence rebuilt at the root, cloud sync, Secure Engine + Threat Shield, Firestore security rules, admin portal with CMS, elegant profile dashboard, profile photo, upgraded navigation bar. **Start with [the implementation report](docs/UPGRADE_0.8_REPORT.md)** — it lists what was verified and what was not (Firestore rules tests and device QA are still required).

- Admin/Firebase setup: [docs/ADMIN_PORTAL.md](docs/ADMIN_PORTAL.md) · Retention: [docs/DATA_RETENTION.md](docs/DATA_RETENTION.md) · Play Data safety: [docs/PLAY_DATA_SAFETY.md](docs/PLAY_DATA_SAFETY.md)
- **APK:** see [docs/BUILD_APK.md](docs/BUILD_APK.md) (GitHub Actions workflow or local Android Studio)
- **Play Billing (Library 9.1):** Google Play stopped accepting Billing Library 7 for new apps and updates on 31 Aug 2026 (extension to 1 Nov 2026, now past), so billing is on `react-native-iap` 15.6.2 + `react-native-nitro-modules` 0.36.5, which bundles Billing Library 9.1.0 via the OpenIAP google library. The 15.x rewrite has no amazon/play store flavor dimension, so `android/app/build.gradle` sets no `missingDimensionStrategy`. The old `patches/react-native-iap+12.16.4.patch` (`currentActivity` fix) and `patch-package` are gone — the 15.x native code is a Nitro rewrite and does not contain that file. See [docs/PLAY_PRODUCTION_READINESS.md](docs/PLAY_PRODUCTION_READINESS.md) for the full Play checklist.
- App: `npm ci && npm run typecheck && npm test` · Rules: `npm run test:rules` (Java 21 + firebase-tools) · Scan: `npm run security:scan`
- Portal: `cd admin && npm ci && npm test && npm run build` (hosting: `firebase deploy --only hosting`)
- Browser e2e: see [tests-e2e/README.md](tests-e2e/README.md) (needs `npm i -D playwright`)
- Release bundles: always `--clear` the Metro cache and never set `EXPO_PUBLIC_FIREBASE_EMULATOR_HOST`.

The 8,584-entry library and SQLite export are unchanged. The sections below are the earlier release notes.

# GenZ Codebook — branding update 0.7.0

New glossy logo, launcher icon, welcome branding and profile assets are integrated. See [branding usage and verification](docs/BRANDING_0.7.md). This source is based on the attached 0.5.0 ZIP; historical release notes below describe that baseline. No 0.7 APK has been assembled. Regional content expansion remains pending.

# GenZ Codebook

A glassy, skeuomorphic Android-first dictionary, chat decoder and learning app. Current source revision: **0.5.0**.

## Available in source

- Offline search across 8,584 attributed references, explicit search button, numeric/emoji/phrase matching, category and content-language filters.
- On-device message decoder, saved terms, local profile, four authored stages, daily/shuffle quizzes and scheduled word review.
- Protected local persistence, retry/recovery, data deletion and validated local-learning export.
- New Firebase email account screen: sign-up/sign-in, reset, verification, sign-out and deletion using the supplied project. Native sessions use encrypted SecureStore when available; web sessions are memory-only.
- Community chat room (Community tab): one shared room, by nickname; messages are screened for abuse before sending and can be reported; moderators hide messages from the admin portal. The room is for token holders — you need tokens (balance above zero) to get in and use it, earned by watching an ad, playing quizzes, or buying a package. Every message costs 10 tokens, shown in the composer before you send and deducted only after the message is accepted; the Send button is disabled when the balance is too low. Only signed-in users with a verified e-mail and an active account can post. The composer sits in a KeyboardAvoidingView and scrolls to the latest message when the keyboard opens, so the text box is never hidden. The token balance shows in the header on every page (tap it to open the Wallet).
- Code Tokens (You tab): earn tokens by playing quizzes, visiting daily, collecting the daily reward (+10, once a day — a popup on first open and a Collect button on the main page), watching a rewarded ad, or getting a suggested word accepted; spend them to suggest words (20 tokens each; free for staff), send a community message (10 tokens each), or unlock a quiz level early. A Super Admin can also send tokens to any active user from the admin portal (Users → open a user → "Send tokens"). The header token pill is an animated gold gradient that pops whenever the balance changes. An opt-in public leaderboard (nickname + tokens) sits at the top of the Community screen. Earned tokens live on this device only and do not sync. Bought tokens are recorded in the account's permanent transaction history (Wallet) before they are credited, so a purchase can never be credited twice.
- Buy Tokens + Wallet (You tab): seven consumable token packages sold through Google Play Billing (`react-native-iap` 15.6.2, Billing Library 9.1.0) — prices come from Play Console, shown in the user's Play country and currency. Purchases are verified locally and recorded in the Firestore ledger under the Google Play order ID; pending, cancelled and failed purchases are never credited.
- Google AdMob: one banner at the bottom of the Suggest a word sheet and the Community screen, plus a full-screen interstitial when opening either one (at most once a minute). A rewarded ad is available from the Suggest form for +10 tokens. All three ad unit IDs are configured (banner, interstitial and rewarded); new units may take up to an hour to start showing ads, and dev builds use Google's test ads for all three formats. Ads are non-personalised.

## Honest status

This source is **not a complete production release**. Firebase public configuration connectivity passed, but live account flows and native secure persistence require device verification and provider configuration. Google sign-in is unavailable because OAuth configuration is absent. Cloud progress, backend/CMS, AI, community moderation, public web deployment and full curriculum remain unfinished. Billing is implemented (Google Play Billing, seven token packages) but is **not operational until a real test purchase completes and the correct tokens are credited**. Most imported content still needs individual editorial review; the numeric category has 162 entries, not 500.

See [Firebase setup](docs/FIREBASE_SETUP.md), [security review](docs/FIREBASE_SECURITY_0.5.md), and [current validation](docs/VALIDATION_0.5.md). The accompanying APK is **0.5.0-internal**, test-signed for ARM64 Android 7+. Its signature, package identity, manifest and content were verified. It is not a production release or a device-test certification.

## Develop

`npm ci` → `npm run typecheck` → `npm test` → `npm run start`.

`npm run export:android` validates Android JavaScript bundling; it does not generate an APK.

With JDK 17, Android SDK 36, build-tools 35.0.0 and NDK 27.1.12297006 installed: `cd android && ./gradlew assembleInternal -PreactNativeArchitectures=arm64-v8a`. The maintained native project preserves app identity and signing guards; do not blindly overwrite it with Expo prebuild. SecureStore autolinks as an Expo module. Backups remain disabled.

Production release requires owner-controlled signing variables and completed evidence in `production-readiness.json`; run `npm run release:check` before `./gradlew bundleRelease`. The bundled debug keystore is only for internal test installs. See [handoff](docs/PRODUCTION_HANDOFF.md) for the remaining roadmap.

---

GenZ Codebook is a **ZTechX** product. © 2026 Zocxorian Technologies. All rights reserved.
