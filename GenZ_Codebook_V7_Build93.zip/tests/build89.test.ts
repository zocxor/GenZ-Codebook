import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {listedAfterClear, visibleAfterClear, walletClearedKey} from '../src/historyClear';
const read = (f: string) => readFileSync(f, 'utf8');

test('profile header icons have no white circle behind them', () => {
  const profile = read('src/SocialProfile.tsx');
  const icon = profile.slice(profile.indexOf('export function ProfileIcon'), profile.indexOf('export function ProfileAction'));
  assert.match(icon, /containerColor="transparent"/);
  assert.doesNotMatch(icon, /containerColor=\{colors\.soft\}/);
});

test('wallet Clear history hides older rows on this phone only, per account', () => {
  const rows = [{id: 'a', createdAt: 100}, {id: 'b', createdAt: 200}, {id: 'c', createdAt: 300}];
  assert.deepEqual(visibleAfterClear(rows, 0).map(r => r.id), ['a', 'b', 'c'], 'never cleared: everything listed');
  assert.deepEqual(visibleAfterClear(rows, 200).map(r => r.id), ['c'], 'cleared at 200: only newer rows');
  assert.equal(listedAfterClear(0, 150), false, 'an entry without a time stays hidden after a clear');
  assert.notEqual(walletClearedKey('u1'), walletClearedKey('u2'));
  assert.equal(walletClearedKey(undefined), 'genz.wallet.clearedAt.guest');
});

test('wallet Clear history never deletes or writes the Credit ledger', () => {
  const helper = read('src/historyClear.ts'), wallet = read('src/WalletScreen.tsx');
  for (const src of [helper, wallet]) assert.doesNotMatch(src, /deleteDoc|writeBatch|updateDoc|setDoc|tokenLedger['"]\s*,/);
  assert.match(wallet, /visibleAfterClear\(txns, clearedAt\)/);
  assert.match(wallet, /accessibilityLabel="Clear transaction history"/);
  assert.match(wallet, /accessibilityLabel="Show full transaction history"/);
  assert.match(wallet, /confirmAction\('Clear transaction history\?'/);
});

test('Codes page offers Clear history for recent searches and recently viewed', () => {
  const screen = read('src/DictionaryScreen.tsx'), app = read('App.tsx');
  assert.match(screen, /accessibilityLabel="Clear recent searches and recently viewed words"/);
  assert.match(screen, /confirmAction\('Clear search history\?'/);
  assert.match(app, /onClearHistory=\{\(\)=>void act\(clearBrowsingHistory\)\}/);
});

test('ads: Google\'s own reason is shown when no ad arrives, and the wallet button is never silent', () => {
  const ads = read('src/ads.tsx'), button = read('src/AdRewardButton.tsx'), wallet = read('src/WalletScreen.tsx');
  assert.match(ads, /export function adUnavailableText\(\)/);
  assert.match(ads, /AdEventType\.ERROR, e => \{noteAdError\(e\); finish\(\);\}/, 'rewarded load errors are recorded');
  assert.match(ads, /lastAdProblem = '';\n  rewardedActive = true;/, 'reset for every attempt');
  assert.match(button, /Alert\.alert\('No reward yet',adUnavailableText\(\)\)/);
  assert.match(wallet, /else Alert\.alert\('No reward yet', adUnavailableText\(\)\)/);
  // AdMob IDs are unchanged.
  assert.match(ads, /ADMOB_APP_ID = 'ca-app-pub-9776667186789824~9376759074'/);
  assert.match(ads, /REWARDED_AD_UNIT_ID = 'ca-app-pub-9776667186789824\/4151797642'/);
});

test('app-ads.txt lists both publisher IDs for the AdMob account migration (Build 93)', () => {
  const lines = read('app-ads.txt').trim().split('\n');
  assert.deepEqual(lines, [
    'google.com, pub-9776667186789824, DIRECT, f08c47fec0942fa0',
    'google.com, pub-3671059371301996, DIRECT, f08c47fec0942fa0',
  ]);
  // Both are real 16-digit publisher IDs with the standard cert ID; the old 15-digit misread must never return.
  assert.doesNotMatch(read('app-ads.txt'), /pub-977667186789824/);
});
