import React,{useEffect,useState} from 'react';
import {Card,Notice} from '../ui';
import {runFeature} from './CommunityWorkflow';
type Row=Record<string,any>;
export default function Messaging(){
 const [stats,setStats]=useState<Row>({}),[reports,setReports]=useState<Row[]>([]),[groups,setGroups]=useState<Row[]>([]),[error,setError]=useState(''),[notice,setNotice]=useState(''),[busy,setBusy]=useState(false),[target,setTarget]=useState('');
 const [reportedAttachment,setReportedAttachment]=useState<{id:string;data:string;fileName:string|null}|null>(null);
 const openAttachment=async(id:string)=>{
  setBusy(true);setError('');setReportedAttachment(null);
  try{
   const response=await runFeature({action:'messaging',command:'admin-attachment',target:id});
   const data=(response as any).data||response;
   if(typeof data.data!=='string')throw new Error('Reported attachment unavailable.');
   setReportedAttachment({id,data:data.data,fileName:data.fileName??null});
  }catch(e){setError(e instanceof Error?e.message:'Reported attachment unavailable.');}
  finally{setBusy(false);}
 };
 const load=async()=>{setReportedAttachment(null);setBusy(true);setError('');try{const result=await runFeature({action:'messaging',command:'admin-summary'});const data=(result as any).data||result;setStats(data.stats||{});setReports(data.reports||[]);setGroups(data.groups||[]);}catch(e){setError(e instanceof Error?e.message:'Messaging moderation could not load.');}finally{setBusy(false);}};
 useEffect(()=>{void load();},[]);
 const act=async(command:string,data:Row)=>{setBusy(true);setError('');try{await runFeature({action:'messaging',command,...data});setNotice('Action completed and audit logged.');await load();}catch(e){setError(e instanceof Error?e.message:'Action failed.');}finally{setBusy(false);}};
 return <div className="stack">{error&&<Notice kind="error">{error}</Notice>}{notice&&<Notice kind="info">{notice}</Notice>}<button className="btn" onClick={()=>void load()} disabled={busy}>{busy?'Loading…':'Refresh'}</button><Card title="Messaging overview"><dl className="grid-dl">{Object.entries({personalConversations:'Personal conversations',activeGroups:'Active groups',totalMessages:'Messages sent',totalReports:'Reported messages',pendingReports:'Pending user reports',reportedUsers:'Reported users'}).map(([key,label])=><React.Fragment key={key}><dt>{label}</dt><dd>{Number(stats[key]||0).toLocaleString()}</dd></React.Fragment>)}</dl><p className="muted">Private conversations are not browsable. Only individual reported messages are visible here. All actions require a moderation role and are audit logged.</p></Card>
 <Card title="Pending message reports">{!reports.length?<p className="muted">No pending reports.</p>:reports.map(r=><div className="note" key={r.id} style={{marginBottom:12}}><strong>{r.reason}</strong><p>Sender: {r.senderName||'Community member'} · user ID: {r.reportedUid}</p><blockquote>{r.text}</blockquote>
 {r.attachment&&<button className="btn" disabled={busy} onClick={()=>reportedAttachment?.id===r.id?setReportedAttachment(null):void openAttachment(r.id)}>{reportedAttachment?.id===r.id?'Close attachment':'View reported attachment'}</button>}
 {reportedAttachment&&reportedAttachment.id===r.id&&(reportedAttachment.fileName?<a className="btn" download={reportedAttachment.fileName} href={'data:application/octet-stream;base64,'+reportedAttachment.data}>Download {reportedAttachment.fileName}</a>:<img alt="Reported chat photo" style={{display:'block',maxWidth:'100%',maxHeight:400,marginTop:8}} src={'data:image/jpeg;base64,'+reportedAttachment.data}/>)}
 {r.note&&<p>{r.note}</p>}<div className="row"><button className="btn primary" disabled={busy} onClick={()=>{if(window.confirm('Remove this reported message for all participants?'))void act('admin-report',{target:r.id,remove:true});}}>Remove message</button><button className="btn" disabled={busy} onClick={()=>void act('admin-report',{target:r.id,remove:false})}>Dismiss</button><button className="btn" disabled={busy} onClick={()=>{if(window.confirm('Restrict private messaging for this reported user?'))void act('admin-restrict',{target:r.reportedUid,restricted:true});}}>Restrict sender</button></div></div>)}</Card>
 <Card title="Group moderation"><p className="muted">Group metadata only; no private messages.</p>{groups.map(g=><div className="note" key={g.id} style={{marginBottom:8}}><strong>{g.name}</strong><p>{g.memberCount} members · {g.status}</p>{g.status==='active'&&<button className="btn" disabled={busy} onClick={()=>{if(window.confirm('Close this group and stop new messages?'))void act('admin-close-group',{target:g.id});}}>Close group</button>}</div>)}</Card>
 <Card title="User messaging restrictions"><label>User ID<input aria-label="User ID for messaging restriction" value={target} onChange={e=>setTarget(e.target.value)} maxLength={128}/></label><div className="row"><button className="btn" disabled={busy||!target.trim()} onClick={()=>{if(window.confirm('Restrict this user’s private messaging?'))void act('admin-restrict',{target:target.trim(),restricted:true});}}>Restrict messaging</button><button className="btn" disabled={busy||!target.trim()} onClick={()=>void act('admin-restrict',{target:target.trim(),restricted:false})}>Restore messaging</button></div><p className="muted">Existing account suspension controls also prevent private messaging.</p></Card></div>;
}
