/** Theme preference store: Dark, Light or System. Applied through <html data-theme>, so switching
 *  never re-renders pages or touches forms, filters or any other state. The matching pre-paint
 *  script is public/theme-init.js. */
import {useSyncExternalStore} from 'react';

export type ThemePref = 'dark' | 'light' | 'system';
export type ThemeResolved = 'dark' | 'light';
export const THEME_KEY = 'genz-admin-theme';
export const THEME_PREFS: readonly ThemePref[] = ['dark', 'light', 'system'];

export const parsePref = (value: unknown): ThemePref => (value === 'dark' || value === 'light' || value === 'system' ? value : 'system');
export const resolveTheme = (pref: ThemePref, systemDark: boolean): ThemeResolved => (pref === 'dark' || (pref === 'system' && systemDark) ? 'dark' : 'light');

const query = typeof window !== 'undefined' && typeof window.matchMedia === 'function' ? window.matchMedia('(prefers-color-scheme: dark)') : null;
const listeners = new Set<() => void>();
function readStored(): ThemePref {
  try {return parsePref(localStorage.getItem(THEME_KEY));} catch {return 'system';}
}
let pref: ThemePref = readStored();

function apply(): void {
  if (typeof document === 'undefined') return;
  const resolved = resolveTheme(pref, !!query?.matches);
  const root = document.documentElement;
  root.setAttribute('data-theme', resolved);
  root.setAttribute('data-theme-pref', pref);
  root.style.colorScheme = resolved;
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', resolved === 'dark' ? '#050817' : '#F3F7FF');
}
function emit(): void {
  apply();
  listeners.forEach(f => {try {f();} catch {/* ignore */}});
}
/** Save and apply a preference. A storage failure (private mode) still applies it for this visit. */
export function setThemePref(next: ThemePref): void {
  pref = parsePref(next);
  try {localStorage.setItem(THEME_KEY, pref);} catch {/* not persisted */}
  emit();
}
query?.addEventListener?.('change', () => {if (pref === 'system') emit();});            // follow the operating system live
if (typeof window !== 'undefined') window.addEventListener('storage', e => {if (e.key === THEME_KEY) {pref = readStored(); emit();}});   // other tabs
apply();

const subscribe = (f: () => void) => {listeners.add(f); return () => {listeners.delete(f);};};
export function useThemePref(): ThemePref {return useSyncExternalStore(subscribe, () => pref, () => 'system');}
