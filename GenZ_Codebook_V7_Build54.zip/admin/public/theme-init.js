/* Runs before first paint (external file: the portal CSP forbids inline scripts).
   Applies the saved theme (dark / light / system) so there is no flash of the wrong theme. */
(function () {
  try {
    var pref = localStorage.getItem('genz-admin-theme');
    if (pref !== 'dark' && pref !== 'light' && pref !== 'system') pref = 'system';
    var dark = pref === 'dark' || (pref === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    var root = document.documentElement;
    root.setAttribute('data-theme', dark ? 'dark' : 'light');
    root.setAttribute('data-theme-pref', pref);
    root.style.colorScheme = dark ? 'dark' : 'light';
  } catch (e) {
    document.documentElement.setAttribute('data-theme', 'light');
  }
})();
