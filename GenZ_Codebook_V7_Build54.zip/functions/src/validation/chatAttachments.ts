export const CHAT_ATTACHMENT_LIMIT = 1_000_000;
export const CHAT_ATTACHMENT_DAYS = 29;

export const CHAT_FILE_TYPES = {
  pdf: 'application/pdf',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  txt: 'text/plain',
} as const;

export function chatFileType(name: string): keyof typeof CHAT_FILE_TYPES | undefined {
  const ext = name.split('.').at(-1)?.toLowerCase();
  return ext && Object.prototype.hasOwnProperty.call(CHAT_FILE_TYPES, ext) ? ext as keyof typeof CHAT_FILE_TYPES : undefined;
}
