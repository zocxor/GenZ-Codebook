/**
 * GenZ Codebook backend — secure Google Play purchase verification.
 *
 * Firebase Cloud Functions (2nd gen), Node 22. One HTTPS endpoint:
 *   POST /verifyPurchase   (see README.md for the deploy steps)
 *
 * Why this exists: the app must never credit tokens based solely on a
 * client-side success. The client only *asks* this endpoint to verify a
 * purchase; this function is the only place that decides whether tokens move.
 *
 * Flow (every step must pass before any token moves):
 *  1. Authenticate the caller with a Firebase ID token (Authorization:
 *     Bearer <token>). The uid from the token is the account that gets
 *     credited — the caller cannot choose another account.
 *  2. Validate the body: productId (must be one of the seven catalog
 *     products), orderId and purchaseToken (non-empty strings).
 *  3. Call the Google Play Developer API (purchases.products.get) with a
 *     Google service account. Verify:
 *       - the purchase exists for package com.genzmode.app,
 *       - the productId matches the catalog product,
 *       - purchaseState == 0 (PURCHASED). A pending purchase (2) or a
 *         cancelled purchase (1) is rejected and never credited.
 *     The token quantity comes from the server-side catalog for that
 *     productId — never from the client — so the purchased product always
 *     matches the expected token quantity.
 *  4. Atomically credit, exactly once, in a single Firestore transaction:
 *       - Read processedTokens/{purchaseToken}. If it exists, this token
 *         was already processed: return verified + duplicate, credit
 *         nothing again. The purchaseToken is the unique transaction
 *         identifier; the orderId is never the sole duplicate guard.
 *       - Otherwise create processedTokens/{purchaseToken} + the ledger
 *         entry users/{uid}/tokenLedger/order-{orderId} + update the
 *         wallet users/{uid}/tokenWallet/wallet, all in the same
 *         transaction. Either all three land or none do.
 *  5. Return {verified: true, duplicate, tokens, balanceAfter}. The client
 *     then updates its local balance and consumes the purchase
 *     (finishTransaction, isConsumable) so the package can be bought again.
 *
 * Failure handling (safe retries):
 *  - Play API unreachable / 5xx / rate-limited: 502 with retryable: true
 *    and NOTHING written. The client does not consume, so the next
 *    reconcile (app start, wallet open, Restore) retries the same token.
 *  - Play says the purchase does not exist (404/410) or is not purchased:
 *    200 with verified: false. Nothing is written and the client does not
 *    consume, so a transient Play-side issue can still be retried.
 *  - A retry of the same purchaseToken after a successful credit returns
 *    verified + duplicate: true with the original tokens/balanceAfter.
 *
 * Credentials: the Play service account JSON lives ONLY in the Firebase
 * secret PLAY_SERVICE_ACCOUNT_JSON (set with
 * `firebase functions:secrets:set`). It is never in this repo, never in
 * the app, and never in the AAB. The Firebase Admin SDK uses the
 * Functions runtime service account (no key file needed).
 *
 * Deploying needs the Firebase Blaze (pay-as-you-go) plan — Cloud
 * Functions do not run on the free Spark plan. See README.md.
 */

import * as admin from 'firebase-admin';
import {onRequest} from 'firebase-functions/v2/https';
import {defineSecret} from 'firebase-functions/params';
import {google} from 'googleapis';

if(!admin.apps.length)admin.initializeApp();
const db = admin.firestore();

// The Google service account JSON for the Play Developer API, stored as a
// Firebase secret. Create it in Google Cloud Console, grant it access in
// Play Console > Setup > API access, then:
//   firebase functions:secrets:set PLAY_SERVICE_ACCOUNT_JSON
// (paste the whole JSON file contents). Never commit it.
const playServiceAccountJson = defineSecret('PLAY_SERVICE_ACCOUNT_JSON');

const PACKAGE_NAME = 'com.genzmode.app';
const MAX_BALANCE = 1_000_000;
// Order IDs and purchase tokens are used as Firestore document IDs.
const SAFE_ORDER_ID = /^[^/\s]{1,200}$/;
const SAFE_TOKEN = /^[^/\s]{1,500}$/;

// Server-side catalog: the single source of truth for product -> tokens.
// The client sends the productId; the token amount always comes from here.
const CATALOG: Record<string, number> = {
  tokens_1000: 1000,
  tokens_2500: 2500,
  tokens_5000: 5000,
  tokens_10000: 10000,
  tokens_25000: 25000,
  tokens_50000: 50000,
  tokens_100000: 100000,
};

type VerifyOk = {verified: true; duplicate: boolean; tokens: number; balanceAfter: number};
type VerifyNo = {verified: false; reason: string; retryable: boolean};

function badRequest(res: import('express').Response, reason: string): void {
  res.status(400).json({verified: false, reason, retryable: false} satisfies VerifyNo);
}

export const verifyPurchaseHandler=async(req:import('express').Request,res:import('express').Response)=>{
    if (req.method !== 'POST') {
      res.status(405).json({verified: false, reason: 'Method not allowed', retryable: false} satisfies VerifyNo);
      return;
    }

    // 1. Authenticate the caller. The uid from the token is the account
    // that gets credited; the caller cannot credit another account.
    const authHeader = req.get('Authorization') ?? '';
    const idToken = authHeader.startsWith('Bearer ') ? authHeader.slice('Bearer '.length).trim() : '';
    if (!idToken) {
      res.status(401).json({verified: false, reason: 'Missing Firebase ID token', retryable: false} satisfies VerifyNo);
      return;
    }
    let uid: string;
    try {
      const decoded = await admin.auth().verifyIdToken(idToken);
      uid = decoded.uid;
    } catch {
      res.status(401).json({verified: false, reason: 'Invalid Firebase ID token', retryable: false} satisfies VerifyNo);
      return;
    }

    // 2. Validate the body.
    const body = (req.body ?? {}) as Record<string, unknown>;
    const productId = typeof body.productId === 'string' ? body.productId : '';
    const clientOrderId = typeof body.orderId === 'string' ? body.orderId : '';
    const purchaseToken = typeof body.purchaseToken === 'string' ? body.purchaseToken : '';
    if (!productId || !(productId in CATALOG)) {
      badRequest(res, 'Unknown product');
      return;
    }
    // Both values become Firestore document IDs: no slashes, bounded length.
    if (!SAFE_ORDER_ID.test(clientOrderId) || !SAFE_TOKEN.test(purchaseToken)) {
      badRequest(res, 'Missing orderId or purchaseToken');
      return;
    }
    const tokens = CATALOG[productId] as number;

    // 3. Verify with the Google Play Developer API.
    let playPurchase: {purchaseState?: number; consumptionState?: number; orderId?: string | null; productId?: string | null};
    try {
      const saJson = playServiceAccountJson.value();
      if (!saJson) throw new Error('PLAY_SERVICE_ACCOUNT_JSON secret is not set');
      const credentials = JSON.parse(saJson) as {client_email?: string; private_key?: string};
      if (!credentials.client_email || !credentials.private_key) {
        throw new Error('PLAY_SERVICE_ACCOUNT_JSON is not a service account JSON');
      }
      const auth = new google.auth.GoogleAuth({
        credentials,
        scopes: ['https://www.googleapis.com/auth/androidpublisher'],
      });
      const androidpublisher = google.androidpublisher({version: 'v3', auth});
      const resp = await androidpublisher.purchases.products.get({
        packageName: PACKAGE_NAME,
        productId,
        token: purchaseToken,
      });
      playPurchase = resp.data as typeof playPurchase;
    } catch (e) {
      // Play unreachable, 5xx, rate limit, or a bad/expired token: do NOT
      // credit, do NOT consume. The client retries via reconcile.
      const status = (e as {code?: number; response?: {status?: number}})?.response?.status
        ?? (e as {code?: number})?.code;
      const notFound = status === 404 || status === 410;
      res.status(notFound ? 200 : 502).json({
        verified: false,
        reason: notFound
          ? 'Google Play has no purchase for this token'
          : 'Google Play verification is unavailable right now',
        retryable: !notFound,
      } satisfies VerifyNo);
      return;
    }

    // purchaseState: 0 = purchased, 1 = canceled, 2 = pending.
    // Only a completed purchase (0) is ever credited.
    if (playPurchase.purchaseState !== 0) {
      res.status(200).json({
        verified: false,
        reason: playPurchase.purchaseState === 2
          ? 'Purchase is still pending with Google Play'
          : 'Purchase is not in the PURCHASED state',
        retryable: playPurchase.purchaseState === 2,
      } satisfies VerifyNo);
      return;
    }
    // The token must belong to the pack the app named (Play reports it when available).
    if (typeof playPurchase.productId === 'string' && playPurchase.productId && playPurchase.productId !== productId) {
      res.status(200).json({verified: false, reason: 'This purchase is for a different Credit pack', retryable: false} satisfies VerifyNo);
      return;
    }
    // Google Play's own order ID is the record; the app's value is only a fallback.
    const orderId = typeof playPurchase.orderId === 'string' && SAFE_ORDER_ID.test(playPurchase.orderId) ? playPurchase.orderId : clientOrderId;

    // 4. Atomically credit, exactly once. The purchaseToken is the unique
    // transaction identifier: processedTokens/{purchaseToken} is created in
    // the same transaction as the ledger entry and the wallet update, so a
    // retry (or a second device, or a replayed request) can never credit
    // the same token twice.
    try {
      const result = await db.runTransaction(async tx => {
        const tokenRef = db.collection('processedTokens').doc(purchaseToken);
        const tokenSnap = await tx.get(tokenRef);
        if (tokenSnap.exists) {
          const d = tokenSnap.data() as {tokens?: number; balanceAfter?: number} | undefined;
          return {
            verified: true,
            duplicate: true,
            tokens: typeof d?.tokens === 'number' ? d.tokens : tokens,
            balanceAfter: typeof d?.balanceAfter === 'number' ? d.balanceAfter : 0,
          } satisfies VerifyOk;
        }
        const walletRef = db.doc(`users/${uid}/tokenWallet/wallet`);
        const walletSnap = await tx.get(walletRef);
        const w = (walletSnap.exists ? walletSnap.data() : null) as
          | {balance?: number; earnedTotal?: number; purchasedTotal?: number; spentTotal?: number}
          | null;
        const balance = typeof w?.balance === 'number' ? w.balance : 0;
        const earnedTotal = typeof w?.earnedTotal === 'number' ? w.earnedTotal : 0;
        const purchasedTotal = typeof w?.purchasedTotal === 'number' ? w.purchasedTotal : 0;
        const spentTotal = typeof w?.spentTotal === 'number' ? w.spentTotal : 0;
        const balanceAfter = balance + tokens;
        if (balanceAfter > MAX_BALANCE) {
          throw new Error('BALANCE_CAP');
        }
        const now = admin.firestore.FieldValue.serverTimestamp();
        tx.set(tokenRef, {uid, orderId, productId, tokens, balanceAfter, createdAt: now});
        tx.set(db.doc(`users/${uid}/tokenLedger/order-${orderId}`), {
          type: 'purchase',
          amount: tokens,
          balanceAfter,
          ref: orderId,
          productId,
          purchaseToken,
          createdAt: now,
        });
        tx.set(walletRef, {
          balance: balanceAfter,
          earnedTotal,
          purchasedTotal: purchasedTotal + tokens,
          spentTotal,
          updatedAt: now,
        });
        return {verified: true, duplicate: false, tokens, balanceAfter} satisfies VerifyOk;
      });
      res.status(200).json(result);
    } catch (e) {
      if ((e as Error)?.message === 'BALANCE_CAP') {
        res.status(200).json({verified: false, reason: 'Credit balance would exceed the maximum', retryable: false} satisfies VerifyNo);
        return;
      }
      // Transaction contention / Firestore error: nothing was written.
      // Retryable — the client reconciles and tries again.
      res.status(502).json({verified: false, reason: 'Verification could not be completed right now', retryable: true} satisfies VerifyNo);
    }
  };
export const verifyPurchase=onRequest(  {secrets: [playServiceAccountJson], region: 'us-central1', timeoutSeconds: 60, memory: '256MiB'},verifyPurchaseHandler);

/* ==========================================================================
 * Premium subscriptions — verifySubscription + RTDN.
 *
 * Two more endpoints live here alongside verifyPurchase:
 *   POST /verifySubscription  (HTTPS, Firebase ID-token auth)
 *   rtdnHandler               (Cloud Pub/Sub, topic genz-codebook-rtdn)
 *
 * The subscription catalog is the single source of truth for product ->
 * base plan -> tokens per billing period. The client sends the productId;
 * the token amount always comes from here, never from the client.
 *
 * Entitlement (users/{uid}/subscription/current) is written ONLY by this
 * backend. The client reads it to decide premium status (ad-free + the
 * period token grant). Premium is active while the state is ACTIVE,
 * CANCELED (keeps access until the paid period ends) or IN_GRACE_PERIOD
 * and the expiry time is in the future.
 *
 * Token grant (idempotent): the period's tokens are granted once per
 * billing period, keyed by the order ID. The latest successful order ID
 * from Play (lineItems[].latestSuccessfulOrderId) is stored as
 * lastTokenGrantOrderId; a renewal brings a NEW order ID, so it grants
 * again, while a retry of the same order ID grants nothing.
 *
 * RTDN: Google publishes subscription lifecycle events (purchase, renewal,
 * cancellation, expiry, revocation, grace period, hold, pause, restart) to
 * a Cloud Pub/Sub topic. This backend subscribes to that topic and, for
 * every event, re-reads the CURRENT subscription state from Play
 * (subscriptionsv2.get) and updates the entitlement from that authoritative
 * state. The notification type itself is only a trigger — the state always
 * comes from Play, so a missed or duplicate message cannot corrupt the
 * entitlement. To map a purchaseToken to a user, verifySubscription stores
 * subscriptionTokens/{purchaseToken} = {uid, productId}.
 * ========================================================================== */

import {onMessagePublished} from 'firebase-functions/v2/pubsub';

const RTDN_TOPIC = 'genz-codebook-rtdn';

// Server-side subscription catalog: product -> base plan -> tokens per period.
const SUBSCRIPTION_CATALOG: Record<string, {basePlanId: string; tokensPerPeriod: number}> = {
  premium_monthly: {basePlanId: 'monthly', tokensPerPeriod: 10000},
  premium_yearly: {basePlanId: 'yearly', tokensPerPeriod: 200000},
};

/** States that count as premium (while the period is unexpired). */
const PREMIUM_STATES = new Set([
  'SUBSCRIPTION_STATE_ACTIVE',
  'SUBSCRIPTION_STATE_CANCELED',
  'SUBSCRIPTION_STATE_IN_GRACE_PERIOD',
]);

type SubVerifyOk = {verified: true; duplicate: boolean; productId: string; tokens: number; expiryTime: string; state: string};
type SubVerifyNo = {verified: false; reason: string; retryable: boolean};

type PlaySubLineItem = {
  productId?: string | null;
  expiryTime?: string | null;
  autoRenewingPlan?: {autoRenewEnabled?: boolean | null} | null;
  offerDetails?: {basePlanId?: string | null} | null;
  latestSuccessfulOrderId?: string | null;
};

type PlaySubscription = {
  subscriptionState?: string | null;
  acknowledgementState?: string | null;
  lineItems?: PlaySubLineItem[] | null;
  latestOrderId?: string | null;
  startTime?: string | null;
};

/** A purchase token is linked to the first account that verified it; other accounts are refused. */
class SubscriptionOwnedElsewhere extends Error {}
const OTHER_ACCOUNT = 'This Premium subscription is already linked to another GenZ Codebook account. Sign in with that account to use it.';

/** Build an authenticated Play Developer API client from the secret. */
function playClient(): ReturnType<typeof google.androidpublisher> {
  const saJson = playServiceAccountJson.value();
  if (!saJson) throw new Error('PLAY_SERVICE_ACCOUNT_JSON secret is not set');
  const credentials = JSON.parse(saJson) as {client_email?: string; private_key?: string};
  if (!credentials.client_email || !credentials.private_key) {
    throw new Error('PLAY_SERVICE_ACCOUNT_JSON is not a service account JSON');
  }
  const auth = new google.auth.GoogleAuth({
    credentials,
    scopes: ['https://www.googleapis.com/auth/androidpublisher'],
  });
  return google.androidpublisher({version: 'v3', auth});
}

/**
 * Fetch the current subscription state from Play and write the entitlement
 * + period token grant for `uid`, atomically and idempotently. Returns the
 * subscription details, or null when Play has no such subscription (it was
 * revoked/refunded — the entitlement is then cleared).
 */
async function syncSubscriptionFromPlay(
  purchaseToken: string,
  uid: string,
): Promise<{productId: string; state: string; expiryTime: string; tokensGranted: number; premium: boolean} | null> {
  // One subscription, one account: a second account (for example another
  // sign-in on the same phone, which sees the same Google Play purchase)
  // must not get the entitlement or the period Credits again.
  const mapRef = db.doc(`subscriptionTokens/${purchaseToken}`);
  const mappedUid = ((await mapRef.get()).data() as {uid?: string} | undefined)?.uid;
  if (typeof mappedUid === 'string' && mappedUid && mappedUid !== uid) throw new SubscriptionOwnedElsewhere(OTHER_ACCOUNT);
  const androidpublisher = playClient();
  let sub: PlaySubscription;
  try {
    const resp = await androidpublisher.purchases.subscriptionsv2.get({
      packageName: PACKAGE_NAME,
      token: purchaseToken,
    });
    sub = resp.data as PlaySubscription;
  } catch (e) {
    const status = (e as {code?: number; response?: {status?: number}})?.response?.status
      ?? (e as {code?: number})?.code;
    // Play has no such subscription (revoked/refunded/unknown token):
    // clear the entitlement so premium turns off.
    if (status === 404 || status === 410) {
      const subRef = db.doc(`users/${uid}/subscription/current`);
      await db.runTransaction(async tx => {
        // A different subscription of this account that is still active (for
        // example after a plan change) keeps its entitlement.
        if (activeOtherToken((await tx.get(subRef)).data(), purchaseToken)) return;
        tx.set(subRef, {
          productId: '',
          basePlanId: '',
          purchaseToken,
          state: 'SUBSCRIPTION_STATE_EXPIRED',
          expiryTime: new Date(0).toISOString(),
          autoRenewing: false,
          acknowledged: true,
          lastOrderId: '',
          lastTokenGrantOrderId: '',
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        }, {merge: true});
      });
      return null;
    }
    throw e;
  }

  const state = sub.subscriptionState ?? 'SUBSCRIPTION_STATE_UNSPECIFIED';
  const lineItem = (sub.lineItems ?? []).find(li => li.productId && li.productId in SUBSCRIPTION_CATALOG) ?? (sub.lineItems ?? [])[0];
  if (!lineItem?.productId || !(lineItem.productId in SUBSCRIPTION_CATALOG)) {
    return null;
  }
  const productId = lineItem.productId;
  const catalog = SUBSCRIPTION_CATALOG[productId] as {basePlanId: string; tokensPerPeriod: number};
  const expiryTime = lineItem.expiryTime ?? new Date(0).toISOString();
  const autoRenewing = lineItem.autoRenewingPlan?.autoRenewEnabled ?? false;
  const basePlanId = lineItem.offerDetails?.basePlanId ?? catalog.basePlanId;
  const orderId = lineItem.latestSuccessfulOrderId ?? sub.latestOrderId ?? '';
  const isPremium = PREMIUM_STATES.has(state) && Date.parse(expiryTime) > Date.now();

  // Acknowledge server-side if Play says it is still pending. The client
  // also acknowledges; this is the safety net so a subscription is never
  // refunded after 3 days because an acknowledgement was missed.
  let acknowledged = sub.acknowledgementState === 'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED';
  if (!acknowledged) {
    try {
      await androidpublisher.purchases.subscriptions.acknowledge({
        packageName: PACKAGE_NAME,
        subscriptionId: productId,
        token: purchaseToken,
      });
      acknowledged = true;
    } catch {/* the client acknowledges too; reconcile retries */}
  }

  // Atomically: entitlement doc + token-token mapping + (once per order)
  // the period token grant (ledger + wallet). A retry of the same order ID
  // grants nothing again.
  let tokensGranted = 0;
  await db.runTransaction(async tx => {
    const subRef = db.doc(`users/${uid}/subscription/current`);
    const [subSnap, mapSnap] = await Promise.all([tx.get(subRef), tx.get(mapRef)]);
    const owner = (mapSnap.data() as {uid?: string} | undefined)?.uid;
    if (typeof owner === 'string' && owner && owner !== uid) throw new SubscriptionOwnedElsewhere(OTHER_ACCOUNT);
    const prev = (subSnap.exists ? subSnap.data() : null) as
      | {lastTokenGrantOrderId?: string; lastOrderId?: string; purchaseToken?: string; state?: string; expiryTime?: string}
      | null;
    // An inactive token must not overwrite another token's active entitlement
    // (after an upgrade, the old token's "expired" notice arrives later).
    const keepOther = !isPremium && activeOtherToken(prev, purchaseToken);
    const walletRef = db.doc(`users/${uid}/tokenWallet/wallet`);
    const grantRef = db.doc(`users/${uid}/tokenLedger/sub-${orderId || 'none'}`);
    const canGrant = isPremium && orderId !== '';
    const [walletSnap,grantSnap] = canGrant ? await Promise.all([tx.get(walletRef),tx.get(grantRef)]) : [null,null];
    const alreadyGrantedForOrder = canGrant && (prev?.lastTokenGrantOrderId === orderId || grantSnap?.exists === true);
    const now = admin.firestore.FieldValue.serverTimestamp();
    if (!keepOther) tx.set(subRef, {
      productId,
      basePlanId,
      purchaseToken,
      state,
      expiryTime,
      autoRenewing,
      acknowledged,
      lastOrderId: orderId,
      lastTokenGrantOrderId: alreadyGrantedForOrder ? prev?.lastTokenGrantOrderId ?? '' : orderId,
      updatedAt: now,
    });
    tx.set(mapRef, {uid, productId, updatedAt: now});
    if (walletSnap && !alreadyGrantedForOrder) {
      const w = (walletSnap.exists ? walletSnap.data() : null) as
        | {balance?: number; earnedTotal?: number; purchasedTotal?: number; spentTotal?: number}
        | null;
      const balance = typeof w?.balance === 'number' ? w.balance : 0;
      const earnedTotal = typeof w?.earnedTotal === 'number' ? w.earnedTotal : 0;
      const purchasedTotal = typeof w?.purchasedTotal === 'number' ? w.purchasedTotal : 0;
      const spentTotal = typeof w?.spentTotal === 'number' ? w.spentTotal : 0;
      const tokens = catalog.tokensPerPeriod;
      const balanceAfter = balance + tokens;
      if (balanceAfter <= MAX_BALANCE) {
        tx.create(grantRef, {
          type: 'subscription',
          amount: tokens,
          balanceAfter,
          ref: orderId,
          productId,
          purchaseToken,
          createdAt: now,
        });
        tx.set(walletRef, {
          balance: balanceAfter,
          earnedTotal: earnedTotal + tokens,
          purchasedTotal,
          spentTotal,
          updatedAt: now,
        });
        tokensGranted = tokens;
      }
    }
  });
  return {productId, state, expiryTime, tokensGranted, premium: isPremium};
}

/** True when the stored entitlement belongs to a different purchase token that is still premium. */
function activeOtherToken(cur: {purchaseToken?: string; state?: string; expiryTime?: string} | null | undefined, purchaseToken: string): boolean {
  return !!cur?.purchaseToken && cur.purchaseToken !== purchaseToken
    && PREMIUM_STATES.has(cur.state ?? '') && Date.parse(cur.expiryTime ?? '') > Date.now();
}

export const verifySubscriptionHandler=async(req:import('express').Request,res:import('express').Response)=>{
    if (req.method !== 'POST') {
      res.status(405).json({verified: false, reason: 'Method not allowed', retryable: false} satisfies SubVerifyNo);
      return;
    }
    const authHeader = req.get('Authorization') ?? '';
    const idToken = authHeader.startsWith('Bearer ') ? authHeader.slice('Bearer '.length).trim() : '';
    if (!idToken) {
      res.status(401).json({verified: false, reason: 'Missing Firebase ID token', retryable: false} satisfies SubVerifyNo);
      return;
    }
    let uid: string;
    try {
      const decoded = await admin.auth().verifyIdToken(idToken);
      uid = decoded.uid;
    } catch {
      res.status(401).json({verified: false, reason: 'Invalid Firebase ID token', retryable: false} satisfies SubVerifyNo);
      return;
    }
    const body = (req.body ?? {}) as Record<string, unknown>;
    const productId = typeof body.productId === 'string' ? body.productId : '';
    const purchaseToken = typeof body.purchaseToken === 'string' ? body.purchaseToken : '';
    if (!productId || !(productId in SUBSCRIPTION_CATALOG)) {
      res.status(400).json({verified: false, reason: 'Unknown subscription product', retryable: false} satisfies SubVerifyNo);
      return;
    }
    if (!SAFE_TOKEN.test(purchaseToken)) {
      res.status(400).json({verified: false, reason: 'Missing purchaseToken', retryable: false} satisfies SubVerifyNo);
      return;
    }
    try {
      const synced = await syncSubscriptionFromPlay(purchaseToken, uid);
      if (!synced) {
        res.status(200).json({verified: false, reason: 'Google Play has no active subscription for this purchase', retryable: false} satisfies SubVerifyNo);
        return;
      }
      if (!synced.premium) {
        const pending = synced.state === 'SUBSCRIPTION_STATE_PENDING';
        res.status(200).json({verified: false, retryable: pending, reason: pending
          ? 'Payment is pending in Google Play. Premium starts once it completes.'
          : 'This Premium subscription is not active in Google Play.'} satisfies SubVerifyNo);
        return;
      }
      // Duplicate = nothing new was granted for this billing period (the
      // order was already credited). The sync is idempotent, so re-verifying
      // on every app start is safe.
      const duplicate = synced.tokensGranted === 0;
      res.status(200).json({
        verified: true,
        duplicate,
        productId: synced.productId,
        tokens: synced.tokensGranted,
        expiryTime: synced.expiryTime,
        state: synced.state,
      } satisfies SubVerifyOk);
    } catch (e) {
      if (e instanceof SubscriptionOwnedElsewhere) {
        res.status(200).json({verified: false, reason: OTHER_ACCOUNT, retryable: false} satisfies SubVerifyNo);
        return;
      }
      const status = (e as {code?: number; response?: {status?: number}})?.response?.status
        ?? (e as {code?: number})?.code;
      const notFound = status === 404 || status === 410;
      res.status(notFound ? 200 : 502).json({
        verified: false,
        reason: notFound
          ? 'Google Play has no subscription for this purchase'
          : 'Google Play verification is unavailable right now',
        retryable: !notFound,
      } satisfies SubVerifyNo);
    }
  };
export const verifySubscription=onRequest(  {secrets: [playServiceAccountJson], region: 'us-central1', timeoutSeconds: 60, memory: '256MiB'},verifySubscriptionHandler);

/**
 * Real-time Developer Notifications (RTDN). Google publishes subscription
 * lifecycle events to the Cloud Pub/Sub topic `genz-codebook-rtdn`; this
 * function receives them, looks up the user by purchaseToken, and re-syncs
 * the entitlement from Play. Setup (manual, once — see functions/README.md):
 *  1. Create the Pub/Sub topic `genz-codebook-rtdn` in Google Cloud.
 *  2. Grant google-play-developer-notifications@system.gserviceaccount.com
 *     the Pub/Sub Publisher role on that topic.
 *  3. In Play Console > Monetize > Monetization setup > Real-time developer
 *     notifications, set the topic to
 *     projects/gen-z-code-55caf/topics/genz-codebook-rtdn.
 * The notification type is only a trigger — the entitlement always comes
 * from a fresh subscriptionsv2.get, so a duplicate or out-of-order message
 * cannot corrupt it.
 */
export const rtdnHandler = onMessagePublished(
  {topic: RTDN_TOPIC, region: 'us-central1', secrets: [playServiceAccountJson], timeoutSeconds: 60, memory: '256MiB'},
  async event => {
    let payload: unknown;
    try {
      const raw = Buffer.from(event.data.message.data ?? '', 'base64').toString('utf8');
      payload = JSON.parse(raw) as unknown;
    } catch {
      return;
    }
    const notif = (payload as {subscriptionNotification?: {purchaseToken?: string; notificationType?: number}})?.subscriptionNotification;
    const purchaseToken = typeof notif?.purchaseToken === 'string' ? notif.purchaseToken : '';
    if (!purchaseToken) return;
    // Map the purchaseToken to the account (written by verifySubscription).
    const tokenSnap = await db.doc(`subscriptionTokens/${purchaseToken}`).get();
    const uid = (tokenSnap.data() as {uid?: string} | undefined)?.uid;
    if (!uid) return;
    try {
      await syncSubscriptionFromPlay(purchaseToken, uid);
    } catch (e) {
      if (e instanceof SubscriptionOwnedElsewhere) return;
      // Throw so Pub/Sub retries the message (at-least-once delivery).
      // The sync is idempotent, so a retry is safe.
      throw e;
    }
  },
);

// Community fees and moderation run with the Admin SDK. Firebase callable
// authentication supplies the verified identity, never a client-supplied UID.
export {communityFeature, publishDailyCodes, cleanupContributions} from './communityEndpoints';

export {admobReward} from './adRewards';
