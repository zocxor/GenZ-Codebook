const {test}=require('node:test'),assert=require('node:assert/strict');
const {initializeApp,deleteApp}=require('firebase-admin/app');
const {getFirestore}=require('firebase-admin/firestore');
const {chatAttachments,purgeExpiredChatAttachments}=require('../lib/chatAttachments');

test('private attachment storage keeps retries idempotent and removes expired objects',async()=>{
 assert.ok(process.env.FIRESTORE_EMULATOR_HOST&&process.env.FIREBASE_STORAGE_EMULATOR_HOST,'Use both Firebase emulators.');
 const app=initializeApp({projectId:'demo-genz-code'});
 const db=getFirestore(app);
 try{
  const bytes=Buffer.from('ffd8ffc0000b080001000101011100ffd9','hex'),now=Date.now(),ttl=29*86400000;
  const ids=['photo-chat','photo-sender','photo-message'];
  const expires=await chatAttachments.save(db,...ids,bytes,now);
  assert.equal(expires,now+ttl);
  assert.equal(await chatAttachments.save(db,...ids,bytes,now+10),expires);
  await assert.rejects(chatAttachments.save(db,...ids,Buffer.from('different bytes'),now+10),{code:'failed-precondition'});
  assert.equal(await chatAttachments.read(...ids),bytes.toString('base64'));
  const textIds=['file-chat','file-sender','file-message'];
  await chatAttachments.save(db,...textIds,Buffer.from('Test attachment.'),now,'text/plain');
  assert.equal(await chatAttachments.read(...textIds),Buffer.from('Test attachment.').toString('base64'));
  await purgeExpiredChatAttachments(db,expires-1);
  assert.equal(await chatAttachments.read(...ids),bytes.toString('base64'));
  await purgeExpiredChatAttachments(db,expires);
  await assert.rejects(chatAttachments.read(...ids),{code:'not-found'});
  await assert.rejects(chatAttachments.read(...textIds),{code:'not-found'});
 }finally{await deleteApp(app);}
});
