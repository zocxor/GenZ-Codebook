import React,{useRef,useState} from 'react';
import {StyleSheet,Text,View} from 'react-native';
import {showSupportAd,useSupportAdReady} from './ads';
import {Button,C,Glass,Icon} from './ui';

/**
 * Optional "support us" ad. Appears only while a skippable ad is loaded (Android, never with
 * Premium), shows nothing automatically, and disappears after the user watched one.
 * Skipping or ignoring it costs nothing and locks nothing.
 */
export default function SupportAdButton({onDone}:{onDone?:()=>void}) {
  const ready=useSupportAdReady();
  const [busy,setBusy]=useState(false),[thanks,setThanks]=useState(false);
  const pending=useRef(false);
  const watch=async()=>{
    if(pending.current)return;
    pending.current=true;setBusy(true);
    try{if(await showSupportAd())setThanks(true);}
    finally{pending.current=false;setBusy(false);onDone?.();}
  };
  if(thanks)return <Text accessibilityLiveRegion="polite" style={s.thanks}>Thank you for supporting GenZ Codebook 💙</Text>;
  if(!ready&&!busy)return null;
  return <Glass>
    <View style={s.row}><Icon name="heart-outline" size={22} color={C.blue}/><Text style={s.title}>Support GenZ Codebook</Text></View>
    <Text style={s.caption}>Optional: one short ad you can skip. Nothing is locked if you don’t.</Text>
    <Button light title={busy?'Opening ad…':'Watch a short ad'} icon="play-circle-outline" disabled={busy} onPress={()=>void watch()}/>
  </Glass>;
}
const s=StyleSheet.create({
  row:{flexDirection:'row',alignItems:'center',gap:8},
  title:{fontSize:16,fontWeight:'800',color:C.ink},
  caption:{fontSize:12,lineHeight:18,color:C.muted},
  thanks:{fontSize:13,fontWeight:'700',color:C.muted,textAlign:'center'},
});
