import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import * as IntentLauncher from 'expo-intent-launcher';
import {Platform} from 'react-native';
import * as Sharing from 'expo-sharing';
import {CHAT_ATTACHMENT_LIMIT,CHAT_FILE_TYPES,chatFileType} from '../shared/chatAttachments';
import * as Picker from 'expo-image-picker';
import * as Manipulator from 'expo-image-manipulator';

const bytes=(base64:string)=>Math.floor(base64.replace(/=+$/,'').length*3/4);

export async function pickChatPhoto():Promise<string|null>{
 const result=await Picker.launchImageLibraryAsync({mediaTypes:['images'],allowsMultipleSelection:false,exif:false});
 if(result.canceled)return null;
 const photo=result.assets[0];
 if(!photo||!photo.width||!photo.height||(photo.fileSize??0)>25_000_000){
  throw new Error('Choose an image under 25 MB.');
 }
 const resize=photo.width>=photo.height
  ?{width:Math.min(photo.width,1280)}:{height:Math.min(photo.height,1280)};
 let jpeg='';
 for(const compress of [0.8,0.65,0.5]){
  const image=await Manipulator.manipulateAsync(photo.uri,[{resize}],{compress,format:Manipulator.SaveFormat.JPEG,base64:true});
  jpeg=image.base64??'';
  if(jpeg&&bytes(jpeg)<=500_000)return jpeg;
 }
 if(jpeg&&bytes(jpeg)<CHAT_ATTACHMENT_LIMIT)return jpeg;
 throw new Error('This photo is still over 1 MB after compression. Choose a smaller image.');
}

export type ChatFile={name:string;data:string};

export async function pickChatFile():Promise<ChatFile|null>{
 const result=await DocumentPicker.getDocumentAsync({type:Object.values(CHAT_FILE_TYPES),multiple:false,copyToCacheDirectory:true});
 if(result.canceled)return null;
 const file=result.assets[0];
 if(!file)return null;
 try{
  if(!chatFileType(file.name)||(file.name.length>120))throw new Error('Choose a PDF, Word, Excel, PowerPoint, or text file with a short name.');
  const info=await FileSystem.getInfoAsync(file.uri);
  if(!info.exists||!info.size||info.size>=CHAT_ATTACHMENT_LIMIT)throw new Error('Choose a nonempty file under 1 MB.');
  const data=await FileSystem.readAsStringAsync(file.uri,{encoding:FileSystem.EncodingType.Base64});
  if(!data||bytes(data)>=CHAT_ATTACHMENT_LIMIT)throw new Error('Choose a nonempty file under 1 MB.');
  return {name:file.name,data};
 }finally{
  if(FileSystem.cacheDirectory&&file.uri.startsWith(FileSystem.cacheDirectory)){
   await FileSystem.deleteAsync(file.uri,{idempotent:true}).catch(()=>{});
  }
 }
}

export async function openChatFile(file:ChatFile){
 const format=chatFileType(file.name);
 if(!format||!file.data||!FileSystem.cacheDirectory){
  throw new Error('This file cannot be opened on this device.');
 }
 const cache=FileSystem.cacheDirectory+'private-chat-files/';
 await FileSystem.makeDirectoryAsync(cache,{intermediates:true}).catch(()=>{});
 const now=Date.now();
 for(const name of await FileSystem.readDirectoryAsync(cache)){
  if(/^\d{13}-/.test(name)&&now-Number(name.slice(0,13))>3600000){
   await FileSystem.deleteAsync(cache+name,{idempotent:true}).catch(()=>{});
  }
 }
 const folder=cache+now+'-'+Math.random().toString(36).slice(2)+'/';
 const uri=folder+encodeURIComponent(file.name);
 await FileSystem.makeDirectoryAsync(folder,{intermediates:true});
 try{
  await FileSystem.writeAsStringAsync(uri,file.data,{encoding:FileSystem.EncodingType.Base64});
  const mimeType=CHAT_FILE_TYPES[format];
  if(Platform.OS==='android'){
   try{
    await IntentLauncher.startActivityAsync('android.intent.action.VIEW',{
     data:await FileSystem.getContentUriAsync(uri),flags:1,type:mimeType,
    });
    return;
   }catch{/* Let the user choose a share target if Android has no viewer. */}
  }
  if(!(await Sharing.isAvailableAsync()))throw new Error('No app is available to open this file.');
  await Sharing.shareAsync(uri,{mimeType,dialogTitle:'Open or share attachment'});
 }finally{
  // Give the system share target time to read the handed-off file.
  setTimeout(()=>void FileSystem.deleteAsync(folder,{idempotent:true}).catch(()=>{}),300000);
 }
}
