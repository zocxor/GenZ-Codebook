import React, {type ReactNode} from 'react';
import {StyleSheet, Text, View} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {Icon} from './ui';

export function ProfileIdentity({premium,children}:{premium:boolean;children:ReactNode}) {
  return <LinearGradient colors={premium?['#FFF8D9','#F3CE73','#FFEEB4']:['#FAF8FF','#EDE6FA','#F4F0FF']}
    start={{x:0,y:0}} end={{x:1,y:1}} style={styles.identity}>
    {premium&&<View style={styles.ticket}>
      <Icon name="ticket-outline" size={16} color="#634100"/>
      <Text style={styles.ticketText}>Premium · Golden Ticket</Text>
    </View>}
    {children}
  </LinearGradient>;
}

const styles=StyleSheet.create({
  identity:{alignItems:'center',gap:12,paddingHorizontal:16,paddingVertical:19},
  ticket:{flexDirection:'row',alignItems:'center',gap:6,backgroundColor:'#FFF6D9',borderColor:'#B98B39',borderWidth:1,borderRadius:14,paddingHorizontal:10,paddingVertical:4},
  ticketText:{color:'#634100',fontSize:11,fontWeight:'800'},
});
