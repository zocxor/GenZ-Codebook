import {SPARK_MODE} from '../shared/deployment';
import React,{useEffect,useRef,useState} from 'react';
import {Image,Keyboard,Modal,Platform,Pressable,ScrollView,Share,StyleSheet,Text,TextInput,View,useWindowDimensions} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import * as Clipboard from 'expo-clipboard';
import {BrandAvatar,Button,C,Chip,Glass,LiquidHero,Icon,RoundIcon,confirmAction,type IconName} from './ui';
import {useEligibleBalance} from './ContributionScreens';
import {KeyboardDock,useKeyboardVisible} from './KeyboardDock';
import AdRewardButton from './AdRewardButton';
import {errorOf,feature,interactions,ms,policy,requestKey,savedPosts,watchComments,watchPosts,type FeedFilter,type FeatureRow} from './communityFeatures';
import {reportPost} from './communityPosts';
import {useAccountUser,useAuthPhase} from './services';
import {useReducedMotion} from './motion';
import {VerifiedBadge,useBadges} from './VerifiedBadge';
import {usePublicProfiles,type PublicProfile} from './publicProfile';
import {screenPost} from '../shared/chat';
import {showSupportAd} from './ads';
import {REPORT_REASONS} from './ugc';
import {useBlocked,blockUser,ensureCommunityRules} from './safety';
import {usePublishingMode} from './publishing';
import {useAppConfig} from './appConfig';
import {confirm as confirmTap,isOn,prune,rollback,shownCount,tap,type OptimisticMap} from './optimistic';
import {LinearGradient} from 'expo-linear-gradient';
import {search} from './engine';
import {onContentChange, termsById, type Term} from './content';
import {CONTENT_NOTICE} from '../shared/publishing';

const filters:FeedFilter[]=['Latest','Trending','Code Words','Slangs'];
const nameOf=(row:FeatureRow)=>row.name||'Code Explorer';
const dateOf=(row:FeatureRow)=>ms(row.createdAt)?new Date(ms(row.createdAt)).toLocaleDateString(undefined,{month:'short',day:'numeric'}):'';
const avatarPalette:[string,string][]=[['#FF9A62','#F2547D'],['#7C5CFF','#3BA4FF'],['#16C2A3','#3B82F6'],['#F59E0B','#EF4444'],['#A855F7','#EC4899'],['#06B6D4','#6366F1']];
const avatarColors=(uid?:string):[string,string]=>avatarPalette[[...(uid??'x')].reduce((a,c)=>a+c.charCodeAt(0),0)%avatarPalette.length]!;
const copyText=(row:FeatureRow)=>row.term?`${row.term}: ${row.meaning??''}`:row.text??'';

// Kept between visits: switching Chat → Posts used to rebuild the feed from empty, so the cards
// showed "Loading posts…" and every heart looked un-liked until the likes reloaded (~3 s).
// The last feed per filter and the user's likes/saves now show instantly; live data refreshes them.
const feedCache=new Map<FeedFilter,FeatureRow[]>();
let mineCache:{uid:string;liked:Set<string>;saved:Set<string>}|null=null;
function rememberMine(uid:string|undefined,type:'like'|'save',id:string,value:boolean){
  if(!uid||mineCache?.uid!==uid)return;
  const key=type==='like'?'liked':'saved',next=new Set(mineCache[key]);
  if(value)next.add(id);else next.delete(id);
  mineCache={...mineCache,[key]:next};
}

export interface PostsHeaderBridge {options:boolean;setOptions:(v:boolean|((x:boolean)=>boolean))=>void;run:{current:()=>void};setDisabled:(v:boolean)=>void}
/** `bridge` lets the Community heading row own the Post Slang and ⋮ buttons (same row as the title). */
export default function CommunityPostsPanel({active,onSignIn,onHistory,visibleBalance,bridge}:{active:boolean;onSignIn:()=>void;onHistory:()=>void;visibleBalance:number;bridge:PostsHeaderBridge}) {
  const uid=useAccountUser()?.uid, phase=useAuthPhase();
  const posting=usePublishingMode('post');
  const paid=useAppConfig().paidCommunity;
  const accountCredits=useEligibleBalance(paid&&active?uid:undefined);
  const {options,setOptions}=bridge;
  const [filter,setFilter]=useState<FeedFilter>('Latest'),[showSaved,setShowSaved]=useState(false);
  const [rows,setRows]=useState<FeatureRow[]>(()=>feedCache.get('Latest')??[]),[savedRows,setSavedRows]=useState<FeatureRow[]>([]);
  const [liked,setLiked]=useState<Set<string>>(()=>uid&&mineCache?.uid===uid?mineCache.liked:new Set()),[saved,setSaved]=useState<Set<string>>(()=>uid&&mineCache?.uid===uid?mineCache.saved:new Set());
  const [notice,setNotice]=useState(''),[loading,setLoading]=useState(()=>!feedCache.has('Latest')),[refresh,setRefresh]=useState(0);
  const [mode,setMode]=useState<'create'|'comments'|'report'|null>(null),[selected,setSelected]=useState<FeatureRow|null>(null);
  const [menu,setMenu]=useState('');
  const pending=useRef(new Set<string>());
  const blocked=useBlocked();
  const visible=(showSaved?savedRows:rows).filter(r=>!blocked.has(r.uid));
  const verified=useBadges(active?visible.map(r=>r.uid):[]);
  const profiles=usePublicProfiles(active?visible.map(r=>r.uid):[]);
  const reduced=useReducedMotion();
  const narrow=useWindowDimensions().width<400;
  useEffect(()=>{
    if(!active)return;
    const cached=feedCache.get(filter);
    setRows(cached??[]);setLoading(!cached);setNotice('');
    return watchPosts(filter,data=>{feedCache.set(filter,data);setRows(data);setLoading(false);},()=>{setNotice('Could not load posts. Check your connection and retry.');setLoading(false);});
  },[filter,active,refresh]);
  useEffect(()=>{
    let mounted=true;
    const cached=uid&&mineCache?.uid===uid?mineCache:null;
    setLiked(cached?cached.liked:new Set());setSaved(cached?cached.saved:new Set());setShowSaved(false);
    if(uid&&active)void interactions(uid).then(r=>{mineCache={uid,liked:r.liked,saved:r.saved};if(mounted){setLiked(r.liked);setSaved(r.saved);}},()=>{});
    return ()=>{mounted=false;};
  },[uid,active]);
  useEffect(()=>{
    if(!showSaved||!active)return;
    let live=true;
    void savedPosts(saved).then(r=>{if(live)setSavedRows(r);});
    return ()=>{live=false;};
  },[showSaved,active,saved,refresh]);
  const signed=(fn:()=>void)=>{if(uid)fn();else if(phase==='restoring')setNotice('Checking your account… try again in a moment.');else onSignIn();};
  bridge.run.current=()=>signed(()=>void ensureCommunityRules().then(ok=>{if(ok)setMode('create');}));
  const postBlocked=posting.mode===null||posting.mode==='paused';
  useEffect(()=>{bridge.setDisabled(postBlocked);},[postBlocked]);   // eslint-disable-line react-hooks/exhaustive-deps
  const act=(key:string,task:()=>Promise<void>)=>{
    if(pending.current.has(key))return;
    pending.current.add(key);
    void task().catch(e=>setNotice(errorOf(e))).finally(()=>pending.current.delete(key));
  };
  // Instant like/save: the tap shows immediately, the server write runs in the
  // background, rapid taps collapse into one final state, and a rejected write
  // rolls back with a message. (Previously the UI waited for a Firestore
  // transaction plus the next feed snapshot: 2–3 s per tap.)
  const [likeOpt,setLikeOpt]=useState<OptimisticMap>({}),[saveOpt,setSaveOpt]=useState<OptimisticMap>({});
  const inFlight=useRef(new Set<string>());
  useEffect(()=>{setLikeOpt(m=>prune(m,Object.fromEntries(rows.map(r=>[r.id,r.likeCount]))));},[rows]);
  const send=(row:FeatureRow,type:'like'|'save',value:boolean)=>{
    const key=type+row.id,setOpt=type==='like'?setLikeOpt:setSaveOpt,setConfirmed=type==='like'?setLiked:setSaved;
    inFlight.current.add(key);
    void feature(type+'-post',{id:row.id,enabled:value}).then(()=>{
      rememberMine(uid,type,row.id,value);
      setConfirmed(prev=>{const next=new Set(prev);if(value)next.add(row.id);else next.delete(row.id);return next;});
      let resend:boolean|null=null;
      setOpt(m=>{const r=confirmTap(row.id,value,m);resend=r.resend;return type==='save'&&r.resend===null?rollback(row.id,r.map):r.map;});
      inFlight.current.delete(key);
      if(resend!==null)send(row,type,resend);
    },e=>{
      inFlight.current.delete(key);
      setOpt(m=>rollback(row.id,m));
      setNotice(errorOf(e));
    });
  };
  const toggle=(row:FeatureRow,type:'like'|'save')=>signed(()=>{
    const key=type+row.id,confirmed=type==='like'?liked:saved,map=type==='like'?likeOpt:saveOpt,setOpt=type==='like'?setLikeOpt:setSaveOpt;
    const r=tap(row.id,row.likeCount,confirmed,map,inFlight.current.has(key));
    setOpt(r.map);
    if(r.send)send(row,type,r.desired);
    if(type==='save')setNotice(r.desired?'Saved to your collection.':'Removed from saved posts.');
  });
  const open=(next:'comments'|'report',row:FeatureRow)=>{setMenu('');setSelected(row);setMode(next);};
  return <View style={{flex:1}}>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.feed}>
      {options&&<Glass style={{padding:10,gap:7}}><View style={s.actions}>{filters.map(f=><Chip key={f} label={f} selected={!showSaved&&filter===f} onPress={()=>{setShowSaved(false);setFilter(f);setOptions(false);}}/>)}</View><View style={s.actions}><Chip label="Saved" icon="bookmark-outline" selected={showSaved} onPress={()=>signed(()=>{setShowSaved(v=>!v);setOptions(false);})}/><Chip label="My Posts" icon="albums-outline" onPress={()=>signed(onHistory)}/></View></Glass>}
      {!!posting.error&&<Text accessibilityRole="alert" style={s.body}>{posting.error}</Text>}
      {posting.mode==='paused'&&<Text style={s.body}>Posting is temporarily paused by the administrator.</Text>}
      {accountCredits.error&&<View style={s.actions}><Text style={[s.body,{flex:1}]}>{accountCredits.error}</Text><Chip label="Retry" onPress={accountCredits.reload}/></View>}
      {!!notice&&<Text accessibilityRole="alert" style={s.body}>{notice}</Text>}
      {!showSaved&&notice.startsWith('Could not load')&&<Button light title="Retry feed" onPress={()=>setRefresh(x=>x+1)}/>}
      {loading&&!showSaved&&<Text style={s.body}>Loading posts…</Text>}
      {(!loading||showSaved)&&!visible.length&&<Glass><Text style={s.title}>{showSaved?'No saved posts yet':'No posts in this view'}</Text><Text style={s.body}>{showSaved?'Save a useful word from the feed to find it here.':'Share a code or slang to start the conversation.'}</Text></Glass>}
      {visible.map(row=>{
        const isLiked=isOn(row.id,liked,likeOpt),isSaved=isOn(row.id,saved,saveOpt),likes=shownCount(row.id,row.likeCount,likeOpt);
        return <Glass key={row.id} style={s.card}>
        <View style={s.cardRow}>
          <AuthorAvatar uid={row.uid} name={nameOf(row)} profile={profiles.get(row.uid)} size={42}/>
          <View style={{flex:1,gap:6,minWidth:0}}>
            <View style={s.row}>
              <View style={[s.row,{flex:1,minWidth:0,gap:5}]}><Text style={s.author} numberOfLines={1}>{nameOf(row)}</Text><VerifiedBadge verified={verified.has(row.uid)} tier={verified.tier(row.uid)}/><Text style={s.time} numberOfLines={1}>· {dateOf(row)}</Text></View>
              <Pressable accessibilityRole="button" accessibilityLabel="Post options" accessibilityState={{expanded:menu===row.id}} hitSlop={8} onPress={()=>setMenu(menu===row.id?'':row.id)} style={s.more}><Icon name="ellipsis-vertical" size={18} color={C.ink}/></Pressable>
            </View>
            {menu===row.id&&<View style={s.actions}>{uid===row.uid?
              <Chip label="Remove my post" icon="trash-outline" onPress={()=>confirmAction('Remove this post?', 'It will no longer be public.',()=>act(row.id,async()=>{
                // The delete starts at once; a skippable full-screen ad (close X) opens meanwhile.
                // Nothing waits on it: no ad loaded or Premium = no ad, the post is still removed.
                setMenu('');
                const removing=feature('delete-post',{id:row.id});
                removing.catch(()=>{});   // the error is shown after the ad (await below)
                await showSupportAd();
                await removing;
                setNotice('Post removed.');
              }))}/>:
              <><Chip label="Report" icon="flag-outline" onPress={()=>signed(()=>open('report',row))}/><Chip label={`Block ${nameOf(row)}`} icon="ban-outline" onPress={()=>blockUser(row.uid,nameOf(row),ok=>{if(ok){setMenu('');setNotice(`${nameOf(row)} is blocked. Unblock in Settings → Blocked users.`);}})}/></>}</View>}
            {!!row.term&&<View style={s.actions}>
              <LinearGradient colors={['#8B3FE0','#4B3BDB']} start={{x:0,y:0}} end={{x:1,y:1}} style={s.termChip}><Icon name="layers" size={14} color="#fff"/><Text selectable style={s.term}>{row.term}</Text></LinearGradient>
              {!!row.category&&<Text style={s.category}># {row.category}</Text>}
            </View>}
            <Text selectable style={s.meaning}>{row.term?<Text style={s.meaningLabel}>Meaning: </Text>:null}{row.meaning??row.text}</Text>
            {!!row.example&&<Text selectable style={s.body}>Example: {row.example}</Text>}
          </View>
        </View>
        <View style={s.engage}>
          <Pressable accessibilityRole="button" accessibilityLabel={`${isLiked?'Unlike':'Like'} · ${likes} likes`} accessibilityState={{selected:isLiked}} hitSlop={6} onPress={()=>toggle(row,'like')} style={s.stat}><Icon name={isLiked?'heart':'heart-outline'} size={21} color={isLiked?'#F0283C':C.ink}/><Text style={s.statText}>{likes.toLocaleString()}</Text></Pressable>
          <Pressable accessibilityRole="button" accessibilityLabel={`Comments · ${row.commentCount??0}`} hitSlop={6} onPress={()=>open('comments',row)} style={s.stat}><Icon name="chatbubble-outline" size={19} color={C.ink}/><Text style={s.statText}>{(row.commentCount??0).toLocaleString()}</Text></Pressable>
          <View style={{flex:1}}/>
          <Action compact={narrow} icon={isSaved?'bookmark':'bookmark-outline'} label={isSaved?'Saved':'Save'} selected={isSaved} onPress={()=>toggle(row,'save')}/>
          <Action compact={narrow} icon="copy-outline" label="Copy" onPress={()=>act('copy',async()=>{await Clipboard.setStringAsync(copyText(row));setNotice('Copied word and meaning.');})}/>
          <Action compact={narrow} icon="share-social-outline" label="Share" onPress={()=>act('share',async()=>{
            if(Platform.OS==='web'){await Clipboard.setStringAsync(copyText(row));setNotice('Copied for sharing.');}
            else await Share.share({message:copyText(row)+'\n\nvia GenZ Codebook'});
          })}/>
        </View>
      </Glass>;})}
    </ScrollView>
    <Modal visible={mode!==null} animationType={reduced?'none':'slide'} onRequestClose={()=>setMode(null)}>
      {mode&&<SafeAreaView style={s.screen}>
        <KeyboardDock>
          <View style={s.bar}><RoundIcon name="arrow-back" label="Close" onPress={()=>setMode(null)}/><Text style={[s.title,{flex:1}]}>{mode==='create'?'Create post':mode==='report'?'Report post':'Comments'}</Text><AdRewardButton compact/></View>
          {mode==='create'?<Composer uid={uid} postingMode={posting.mode} visibleBalance={visibleBalance} onDone={status=>{setMode(null);setNotice(status==='approved'?'Your post is live.':status==='pending'?'Submitted for review. Track it in My Posts.':'Check My Posts for the current status.');accountCredits.reload();}}/>:selected&&
            <PostThread key={selected.id+mode} row={selected} report={mode==='report'} uid={uid} onDone={()=>{setMode(null);setNotice('Report sent.');}}/>}
        </KeyboardDock>
      </SafeAreaView>}
    </Modal>
  </View>;
}

/** Author picture: shared photo, else chosen avatar icon, else a coloured initial. */
function AuthorAvatar({uid,name,profile,size}:{uid?:string;name:string;profile?:PublicProfile;size:number}){
  if(profile?.photo)return <Image source={{uri:profile.photo}} accessibilityIgnoresInvertColors style={{width:size,height:size,borderRadius:size*.33}}/>;
  if(profile)return <BrandAvatar index={profile.avatar} size={size}/>;
  return <LinearGradient colors={avatarColors(uid)} start={{x:0,y:0}} end={{x:1,y:1}} style={[s.avatar,{width:size,height:size,borderRadius:size*.33}]}><Text style={[s.avatarText,{fontSize:size*.4}]}>{name.charAt(0).toUpperCase()}</Text></LinearGradient>;
}
function Action({icon,label,selected,onPress,compact=false}:{icon:IconName;label:string;selected?:boolean;onPress:()=>void;compact?:boolean}) {
  return <Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityState={{selected}} hitSlop={4} style={[s.action,compact&&s.actionIcon,selected&&s.on]} onPress={onPress}>
    <Icon name={icon} size={compact?17:15} color={selected?C.purple:C.ink}/>{!compact&&<Text style={s.actionText} numberOfLines={1}>{label}</Text>}
  </Pressable>;
}

function Composer({uid,visibleBalance,postingMode,onDone}:{uid?:string;visibleBalance:number;postingMode:'open'|'review'|'paused'|null;onDone:(status?:string)=>void}) {
  const [query,setQuery]=useState(''),[selected,setSelected]=useState<Term|null>(null);
  const [,setRevision]=useState(0);
  useEffect(()=>onContentChange(()=>{setRevision(v=>v+1);setSelected(null);}),[]);
  const matches=query.trim()?search(query).filter(t=>t.expression.length<=30&&t.meaning.length<=200&&t.example.length<=200).slice(0,8):[];
  const term=selected?.expression??'', meaning=selected?.meaning??'', example=selected?.example??'';
  const [category,setCategory]=useState('');
  const [error,setError]=useState(''),[busy,setBusy]=useState(false);
  const busyRef=useRef(false), key=useRef(requestKey()), scroller=useRef<ScrollView>(null);
  const paid=useAppConfig().paidCommunity;
  const credit=useEligibleBalance(paid?uid:undefined);
  const positions=useRef<Record<string,number>>({});
  const focused=useRef('');
  const keyboardOpen=useKeyboardVisible();
  const keepFieldVisible=()=>{
    const y=positions.current[focused.current];
    if(y!==undefined)scroller.current?.scrollTo({y:Math.max(0,y-8),animated:false});
  };
  useEffect(()=>{if(keyboardOpen)keepFieldVisible();},[keyboardOpen]);
  const update=(fn:(v:string)=>void)=>(v:string)=>{key.current=requestKey();setError('');fn(v);};

  const ready=!!selected&&termsById.get(selected.id)===selected&&!!term.trim()&&!!meaning.trim()&&!!category&&(postingMode==='open'||postingMode==='review');
  const canPay=!paid||(credit.balance!==null&&credit.balance>=policy.postFee);
  const send=async()=>{
    if(!ready||!canPay||busyRef.current)return;
    const check=screenPost([term,meaning,example].filter(Boolean).join('\n'));
    if(!check.ok){setError(check.message);return;}
    busyRef.current=true;setBusy(true);setError('');
    try {const result=await feature('create-post',{term,meaning,example,category,requestId:key.current});onDone(result.status);}
    catch(e){
      setError(errorOf(e));
      if((e as {code?:string})?.code==='functions/failed-precondition')credit.reload();
    }
    finally {busyRef.current=false;setBusy(false);}
  };
  return <>
    <ScrollView ref={scroller} contentContainerStyle={s.feed} keyboardShouldPersistTaps="handled" onLayout={()=>{if(keyboardOpen)keepFieldVisible();}}>
      <Glass>
        <Text style={s.title}>Share a Codebook word</Text>
        <Text style={s.body}>{postingMode==='review'?'New posts currently require administrator approval.':!paid?'Posting is free. Search and select a dictionary entry.':'Your post is published immediately after payment.'}</Text>
        <Text style={s.author}>Search the Codebook dictionary</Text>
        <TextInput accessibilityLabel="Search dictionary" placeholder="Search a code, slang or meaning…" placeholderTextColor={C.muted} value={query} maxLength={120} editable={!busy}
          onChangeText={value=>{setQuery(value);setSelected(null);key.current=requestKey();setError('');}} style={s.input}/>
        {!selected&&!!query.trim()&&<View accessibilityLiveRegion="polite" style={{gap:6}}>
          {matches.length?matches.map(item=><Pressable key={item.id} accessibilityRole="button" accessibilityLabel={`Select ${item.expression}`} disabled={busy} onPress={()=>{setSelected(item);setQuery(item.expression);setCategory(item.category==='Chat'||item.category==='Numbers'?'Code Word':item.category==='Social'?'Slang':'General Term');key.current=requestKey();setError('');}} style={s.dictionaryResult}>
            <Text style={s.author}>{item.expression}</Text><Text style={s.body} numberOfLines={2}>{item.meaning}</Text>
          </Pressable>):<Text style={s.body}>No matching shareable codes. Try another word or submit a dictionary suggestion.</Text>}
        </View>}
        {selected&&<View style={s.dictionaryResult}>
          <Text style={s.author}>Selected: {term}</Text>
          <Text selectable style={s.meaning}>{meaning}</Text>
          {!!example&&<Text selectable style={s.body}>Example: {example}</Text>}
          <Text style={s.body}>Filled from the dictionary. Search again to choose a different code.</Text>
        </View>}
        <Text style={s.author}>Category</Text>
        <View style={s.actions}>{policy.postCategories.map(c=><Chip key={c} label={c} selected={category===c} onPress={()=>{if(!busy)update(setCategory)(c);}}/>)}</View>
        <Text style={s.body}>{!paid?'Free submission.':'Posting costs '+policy.postFee+' Credits.'} {postingMode==='review'?'Your post will wait for review.':'Your post goes live immediately.'}</Text>
        <Text style={s.body}>{CONTENT_NOTICE}</Text>
        {paid&&credit.balance!==null&&credit.balance<policy.postFee&&<Text style={s.body}>This device shows {visibleBalance.toLocaleString()} Credits. Posting uses Credits from verified ads, purchases, referrals or admin grants. Signed-in ad rewards become usable after verification. Older device Credits remain available for offline learning.</Text>}
      </Glass>
    </ScrollView>
    <View style={s.footer}>
      {!!error&&<Text accessibilityRole="alert" style={s.body}>{error}</Text>}
      {credit.error?<><Text accessibilityRole="alert" style={s.body}>{credit.error}</Text>{!keyboardOpen&&<Text style={s.body}>{visibleBalance.toLocaleString()} Credits shown on this device · Account credits unconfirmed</Text>}<Button light title="Retry balance check" onPress={credit.reload}/></>:<>
        <Text accessibilityLiveRegion="polite" style={s.body}>{!paid?'Free posting':credit.balance===null?'Checking your Credits…':`Eligible credits: ${credit.balance.toLocaleString()} · Cost: ${policy.postFee}`}</Text>
        <Button title={busy?'Submitting…':credit.balance!==null&&!canPay?'Not enough Credits':!paid?'Post Slang · Free':`Post · ${policy.postFee} Credits`} icon="paper-plane-outline" disabled={!ready||!canPay||busy}
          onPress={()=>{Keyboard.dismiss();confirmAction('Confirm post?',!paid?`Publish “${term}” for free?`:`Submit “${term}” for ${policy.postFee} Credits. The fee is non-refundable.`,()=>void send(),'Submit');}}/>
      </>}
    </View>
  </>;
}

export function PostThread({row,report,uid,onDone}:{row:FeatureRow;report:boolean;uid?:string;onDone:()=>void}) {
  const [rows,setRows]=useState<FeatureRow[]>([]),[value,setValue]=useState(''),[reason,setReason]=useState('');
  const [error,setError]=useState(''),[busy,setBusy]=useState(false);
  const lock=useRef(false);
  const blocked=useBlocked();
  const shown=rows.filter(r=>!blocked.has(r.uid));
  const badges=useBadges(shown.map(r=>r.uid));
  const profiles=usePublicProfiles(shown.map(r=>r.uid));
  useEffect(()=>{if(!report)return watchComments(row.id,setRows,()=>setError('Could not load comments.'));},[row.id,report]);
  const send=async()=>{
    if(lock.current)return;
    lock.current=true;setBusy(true);setError('');
    try {
      if(report){const result=await reportPost(row.id,reason,value);if(!result.ok)throw new Error(result.message);onDone();}
      else {if(!(await ensureCommunityRules()))return;await feature('comment-post',{id:row.id,text:value});setValue('');}
    } catch(e){setError(errorOf(e));}
    finally {lock.current=false;setBusy(false);}
  };
  return <>
    <ScrollView contentContainerStyle={s.feed} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>{row.term??'Community post'}</Text>
      {report?<View style={s.actions}>{REPORT_REASONS.map(r=><Chip key={r} label={r} selected={reason===r} onPress={()=>setReason(r)}/>)}</View>:
        shown.length?shown.map(r=>r.status==='removed'?<Text key={r.id} style={s.body}>Comment removed</Text>:<Glass key={r.id}><View style={s.row}><AuthorAvatar uid={r.uid} name={r.name??'Code Explorer'} profile={profiles.get(r.uid)} size={26}/><Text style={s.author}>{nameOf(r)}</Text><VerifiedBadge verified={badges.has(r.uid)} tier={badges.tier(r.uid)}/><Text style={[s.body,{flex:1}]}>{dateOf(r)}</Text>{!!uid&&r.uid!==uid&&<Pressable accessibilityRole="button" accessibilityLabel={`Block ${nameOf(r)}`} hitSlop={8} onPress={()=>blockUser(r.uid,nameOf(r))}><Icon name="ban-outline" size={16} color={C.muted}/></Pressable>}</View><Text style={s.meaning}>{r.text}</Text></Glass>):
          <Text style={s.body}>No comments yet.</Text>}
    </ScrollView>
    <View style={s.footer}>
      {!!error&&<Text accessibilityRole="alert" style={s.body}>{error}</Text>}
      {uid?<><TextInput accessibilityLabel={report?'Report details':'Your comment'} value={value} onChangeText={setValue} maxLength={report?300:200} multiline style={s.input}/>
        <Button title={report?'Send report':'Add comment'} disabled={busy||(report?!reason:!value.trim())} onPress={()=>void send()}/></>:
        <Text style={s.body}>Sign in to join the discussion.</Text>}
    </View>
  </>;
}

const s=StyleSheet.create({
  dictionaryResult:{padding:12,gap:5,borderRadius:12,borderWidth:1,borderColor:C.line,backgroundColor:C.soft},
  toolbar:{flexDirection:'row',alignItems:'center',gap:7},newPost:{minHeight:40,paddingHorizontal:10,borderRadius:12,backgroundColor:C.accent,flexDirection:'row',alignItems:'center',gap:3},newPostText:{fontSize:13,fontWeight:'800',color:'#fff'},
  feed:{padding:14,gap:12,paddingBottom:22,maxWidth:620,width:'100%',alignSelf:'center'},actions:{flexDirection:'row',flexWrap:'wrap',gap:6},
  row:{flexDirection:'row',alignItems:'center',gap:7},title:{fontSize:20,fontWeight:'900',color:C.ink},author:{fontSize:14,fontWeight:'800',color:C.ink},
  body:{fontSize:13,lineHeight:18,color:C.muted},meaning:{fontSize:14.5,lineHeight:20,color:C.ink},meaningLabel:{fontWeight:'800'},avatar:{width:42,height:42,borderRadius:14,alignItems:'center',justifyContent:'center'},avatarText:{fontWeight:'900',color:'#fff',fontSize:17},
  card:{padding:12,gap:0},cardRow:{flexDirection:'row',gap:10,alignItems:'flex-start'},time:{fontSize:12.5,color:C.muted,flexShrink:1},more:{width:30,height:30,alignItems:'center',justifyContent:'center',borderRadius:10},
  termChip:{flexDirection:'row',alignItems:'center',gap:6,borderRadius:12,paddingHorizontal:10,paddingVertical:5},engage:{flexDirection:'row',alignItems:'center',gap:6,marginTop:8,paddingLeft:2},stat:{flexDirection:'row',alignItems:'center',gap:4,minHeight:36,paddingRight:8},statText:{fontWeight:'800',fontSize:14,color:C.ink},
  callout:{padding:13,borderRadius:16,flexDirection:'row',gap:8,alignItems:'center'},calloutTitle:{fontSize:15,fontWeight:'900',color:'#fff'},cost:{backgroundColor:'#FFE2A1',color:'#63400C',padding:6,borderRadius:9,fontWeight:'800',overflow:'hidden'},
  term:{color:'#fff',fontWeight:'900',fontSize:16},
  category:{color:'#E11D61',backgroundColor:'#FFE4EE',fontWeight:'800',fontSize:12.5,paddingHorizontal:10,paddingVertical:6,borderRadius:12,overflow:'hidden'},
  action:{minHeight:34,paddingHorizontal:9,flexDirection:'row',alignItems:'center',gap:4,borderRadius:17,backgroundColor:'#E3EAFB'},actionText:{fontWeight:'800',fontSize:12,color:C.ink},on:{backgroundColor:'#EBE2FF'},actionIcon:{width:36,paddingHorizontal:0,justifyContent:'center'},
  screen:{flex:1,backgroundColor:C.bg},bar:{padding:10,paddingHorizontal:14,flexDirection:'row',alignItems:'center',gap:12,borderBottomWidth:1,borderBottomColor:C.line},
  footer:{padding:10,paddingHorizontal:14,gap:5,backgroundColor:'#fff',borderTopWidth:1,borderTopColor:C.line},input:{backgroundColor:'#fff',borderColor:C.line,borderWidth:1,borderRadius:12,padding:9,color:C.ink,minHeight:42},
});
