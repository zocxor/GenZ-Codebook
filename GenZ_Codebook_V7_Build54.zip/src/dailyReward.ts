/**
 * One daily reward, shared by every screen (Home card, daily pop-up, You page, Wallet).
 *
 * Signed in: one tap collects +10 Credits on the account (server, once per UTC day — the
 * receipt users/{uid}/tokenLedger/daily-YYYY-MM-DD) and the +10 learning points on this device.
 * Signed out: +10 learning points on this device, once per local day.
 *
 * "Collected" is one shared state: when any button collects, every other button shows
 * "Collected today" at once; on start each button checks the server receipt, so a reward
 * collected on another screen or device can't be offered again.
 */
import {useEffect, useSyncExternalStore} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {BACKEND_URL} from './backend';
import {repository, useAccountUser, useLearningState} from './services';
import {collectDailyReward} from './learning';
import {localDay} from './discovery';
import {feature} from './communityFeatures';

const KEY = 'genz.dailyReward.v1';
export const utcDay = (t = Date.now()) => new Date(t).toISOString().slice(0, 10);

const collected = new Set<string>();   // `${uid}:${utcDay}`
const known = new Set<string>();       // keys whose server receipt was checked
let busyKey: string | null = null;
let version = 0, loaded = false;
const listeners = new Set<() => void>();
const emit = () => {version++; listeners.forEach(f => f());};
const subscribe = (f: () => void) => {listeners.add(f); load(); return () => {listeners.delete(f);};};
function load() {
  if (loaded) return;
  loaded = true;
  void AsyncStorage.getItem(KEY).then(raw => {
    const v = raw ? JSON.parse(raw) : null;
    if (Array.isArray(v)) {for (const k of v) if (typeof k === 'string') {collected.add(k); known.add(k);} emit();}
  }).catch(() => {});
}
function mark(key: string) {
  known.add(key);
  if (collected.has(key)) {emit(); return;}
  collected.add(key);
  emit();
  void AsyncStorage.setItem(KEY, JSON.stringify([...collected].slice(-14))).catch(() => {});
}
const checks = new Map<string, Promise<void>>();
/** Ask the server once per account and day whether today's receipt exists. */
function checkServer(uid: string, day: string) {
  const key = `${uid}:${day}`;
  if (known.has(key) || checks.has(key)) return;
  checks.set(key, (async () => {
    try {
      const [{doc, getDoc}, {cloudDb}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
      const snap = await getDoc(doc(cloudDb(), 'users', uid, 'tokenLedger', `daily-${day}`));
      if (snap.exists()) mark(key); else {known.add(key); emit();}
    } catch {known.add(key); emit();}   // offline: offer the button; the server still refuses a second credit
    finally {checks.delete(key);}
  })());
}

export type DailyReward = {account: boolean; done: boolean; known: boolean; busy: boolean; collect: () => Promise<string>};

export function useDailyReward(): DailyReward {
  const user = useAccountUser(), state = useLearningState();
  useSyncExternalStore(subscribe, () => version);
  const account = !!user && !!BACKEND_URL;
  const day = utcDay();
  const key = user ? `${user.uid}:${day}` : '';
  useEffect(() => {if (account && user) checkServer(user.uid, day);}, [account, user?.uid, day]);
  const localDone = state.tokens.lastDailyCollect === localDay();
  const done = account ? collected.has(key) : localDone;
  const busy = account && busyKey === key;
  const collect = async (): Promise<string> => {
    if (done || busy) return '';
    if (!account) {
      await repository.mutate(collectDailyReward);
      return '+10 learning points collected. Come back tomorrow for more.';
    }
    busyKey = key; emit();
    try {
      const r = await feature('daily-reward');
      mark(key);
      if (!localDone) await repository.mutate(collectDailyReward).catch(() => {});
      return r.duplicate ? 'Today’s reward is already collected. A new one is ready after midnight UTC.' : '+10 Credits and +10 learning points collected. Come back tomorrow for more.';
    } finally {busyKey = null; emit();}
  };
  return {account, done, known: !account || known.has(key) || collected.has(key), busy, collect};
}
