/**
 * Futuristic sign-in / sign-up look for the account sheet, in the app's light colours (V8).
 *  - AuthHero: the welcome banner (light holographic gradient, glowing orbs, logo, feature chips).
 *  - AuthCard: frosted card with a soft gradient frame for the form.
 *  - AuthPortal: light "holo" panel with a neon gradient frame and a slow light sweep.
 *    Google keeps its OFFICIAL button (Google's branding rules; the owner asked for its original
 *    colours) inside a neon ring; the e-mail option is a matching neon tile.
 *  - NeonButton: the glowing gradient button for Sign in / Create account / Send reset.
 *  - NeonSwitch: the outlined pill that switches between Sign in and Create account.
 * The light sweep respects the system "reduce motion" setting.
 */
import React, {useEffect, useRef} from 'react';
import {Animated, Easing, Image, Pressable, StyleSheet, Text, View} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {GoogleSigninButton} from '@react-native-google-signin/google-signin';
import {Icon, type IconName} from './ui';
import {useReducedMotion} from './motion';

const NEON = ['#22D3EE', '#6366F1', '#A855F7', '#EC4899'] as const;
const SOFT = ['#F8FAFF', '#EEF2FF', '#F6F0FF'] as const;

/** Welcome banner: light holographic gradient, glowing orbs, the logo and what the app offers. */
export function AuthHero({mode}: {mode: 'signin' | 'create' | 'reset'}) {
  const reduced = useReducedMotion();
  const float = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (reduced) return;
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(float, {toValue: 1, duration: 3200, easing: Easing.inOut(Easing.sin), useNativeDriver: true}),
      Animated.timing(float, {toValue: 0, duration: 3200, easing: Easing.inOut(Easing.sin), useNativeDriver: true}),
    ]));
    loop.start();
    return () => loop.stop();
  }, [reduced, float]);
  const drift = (d: number) => ({transform: [{translateY: float.interpolate({inputRange: [0, 1], outputRange: [0, d]})}]});
  const head = mode === 'create' ? 'Join the code crew.' : mode === 'reset' ? 'Let’s get you back in.' : 'Welcome back.';
  const sub = mode === 'create' ? 'Decode every chat, play the Daily Five and meet the community. It takes a minute.' : mode === 'reset' ? 'We’ll e-mail you a secure link to choose a new password.' : 'Your saved words, levels and Credits are waiting for you.';
  return <LinearGradient colors={['#DCE7FF', '#EEE6FF', '#DDF5FF']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.hero}>
    <Animated.View pointerEvents="none" style={[p.orb, {backgroundColor: 'rgba(99,102,241,.22)', width: 170, height: 170, top: -60, right: -40}, drift(10)]} />
    <Animated.View pointerEvents="none" style={[p.orb, {backgroundColor: 'rgba(34,211,238,.24)', width: 130, height: 130, bottom: -50, left: -30}, drift(-8)]} />
    <Animated.View pointerEvents="none" style={[p.orb, {backgroundColor: 'rgba(236,72,153,.14)', width: 80, height: 80, top: 30, left: '55%'}, drift(6)]} />
    <View style={p.heroRow}>
      <View style={p.logoRing}><Image source={require('../assets/brand/genz-code-glossy.png')} resizeMode="contain" accessible={false} style={{width: 46, height: 46}} /></View>
      <View style={{flex: 1, gap: 2}}>
        <Text style={p.heroEyebrow}>GENZ CODEBOOK</Text>
        <Text accessibilityRole="header" style={p.heroTitle}>{head}</Text>
      </View>
    </View>
    <Text style={p.heroSub}>{sub}</Text>
    {mode !== 'reset' && <View style={p.chips}>
      {([['scan', 'Decode', '#3B82F6', '#6366F1'], ['game-controller', 'Play', '#8B5CF6', '#EC4899'], ['people', 'Community', '#06B6D4', '#3B82F6']] as [IconName, string, string, string][]).map(([icon, label, a, b]) =>
        <View key={label} style={p.chip}><LinearGradient colors={[a, b]} style={p.chipIcon}><Icon name={icon} size={12} color="#fff" /></LinearGradient><Text style={p.chipText}>{label}</Text></View>)}
    </View>}
  </LinearGradient>;
}

/** Frosted form card with a soft gradient frame. */
export function AuthCard({children}: {children: React.ReactNode}) {
  return <LinearGradient colors={['#BFDBFE', '#C7D2FE', '#E9D5FF']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.cardFrame}>
    <View style={p.card}>{children}</View>
  </LinearGradient>;
}

/** Light panel with the two sign-in options side by side. */
export function AuthPortal({mode, busy, onGoogle, onEmail}: {mode: 'signin' | 'create'; busy: boolean; onGoogle: () => void; onEmail: () => void}) {
  const reduced = useReducedMotion();
  const sweep = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (reduced) return;
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(sweep, {toValue: 1, duration: 2600, easing: Easing.inOut(Easing.quad), useNativeDriver: true}),
      Animated.delay(1800),
      Animated.timing(sweep, {toValue: 0, duration: 0, useNativeDriver: true}),
    ]));
    loop.start();
    return () => loop.stop();
  }, [reduced, sweep]);
  const create = mode === 'create';
  return <LinearGradient colors={NEON} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.frame}>
    <LinearGradient colors={SOFT} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.panel}>
      {!reduced && <Animated.View pointerEvents="none" style={[p.sweep, {transform: [{translateX: sweep.interpolate({inputRange: [0, 1], outputRange: [-140, 420]})}, {rotate: '18deg'}]}]}>
        <LinearGradient colors={['rgba(255,255,255,0)', 'rgba(255,255,255,.85)', 'rgba(255,255,255,0)']} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={StyleSheet.absoluteFill} />
      </Animated.View>}
      <View style={p.head}>
        <View style={p.dot} />
        <Text style={p.eyebrow}>{create ? 'JOIN WITH' : 'SIGN IN WITH'}</Text>
        <View style={{flex: 1}} />
        <Icon name="shield-checkmark" size={13} color="#6366F1" />
        <Text style={p.secure}>SECURE</Text>
      </View>
      <Text style={p.title}>{create ? 'Choose how to join' : 'Choose how to sign in'}</Text>
      <View style={p.row}>
        <LinearGradient colors={NEON} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.ring}>
          <GoogleSigninButton accessibilityLabel={create ? 'Sign up with Google' : 'Sign in with Google'} style={{width: '100%', height: 48}} size={GoogleSigninButton.Size.Standard} color={GoogleSigninButton.Color.Light} disabled={busy} onPress={onGoogle} />
        </LinearGradient>
        <Pressable accessibilityRole="button" accessibilityLabel={create ? 'Sign up with your e-mail address' : 'Sign in with your e-mail address'} disabled={busy} onPress={onEmail} style={({pressed}) => [{flex: 1}, pressed && {transform: [{scale: .97}]}]}>
          <LinearGradient colors={NEON} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={[p.ring, {flex: 0}]}>
            <LinearGradient colors={['#FFFFFF', '#EEF2FF']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.emailTile}>
              <LinearGradient colors={['#22D3EE', '#A855F7']} style={p.emailIcon}><Icon name="mail" size={15} color="#fff" /></LinearGradient>
              <Text style={p.emailText}>E-mail</Text>
            </LinearGradient>
          </LinearGradient>
        </Pressable>
      </View>
      <View style={p.orRow}>
        <LinearGradient colors={['rgba(99,102,241,0)', 'rgba(99,102,241,.55)']} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={p.orLine} />
        <Text style={p.orText}>or type your e-mail below</Text>
        <LinearGradient colors={['rgba(168,85,247,.55)', 'rgba(168,85,247,0)']} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={p.orLine} />
      </View>
    </LinearGradient>
  </LinearGradient>;
}

/** Glowing gradient action button (Sign in with e-mail / Create account / Send reset). */
export function NeonButton({title, icon, disabled = false, onPress}: {title: string; icon: IconName; disabled?: boolean; onPress: () => void}) {
  return <Pressable accessibilityRole="button" accessibilityState={{disabled}} disabled={disabled} onPress={onPress} style={({pressed}) => [p.glow, disabled && {shadowOpacity: 0, elevation: 0}, pressed && {transform: [{scale: .98}]}]}>
    <LinearGradient colors={disabled ? ['#CBD5E1', '#CBD5E1'] : ['#3B82F6', '#4F46E5', '#8B5CF6']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.neonButton}>
      <LinearGradient colors={['rgba(255,255,255,.28)', 'rgba(255,255,255,0)']} style={p.shine} pointerEvents="none" />
      <Icon name={icon} size={20} color="#fff" />
      <Text style={p.neonText}>{title}</Text>
      <View style={p.arrow}><Icon name="arrow-forward" size={16} color="#fff" /></View>
    </LinearGradient>
  </Pressable>;
}

/** Outlined neon pill that switches between Sign in and Create account. */
export function NeonSwitch({prompt, action, disabled = false, onPress}: {prompt: string; action: string; disabled?: boolean; onPress: () => void}) {
  return <Pressable accessibilityRole="button" accessibilityLabel={`${prompt} ${action}`} disabled={disabled} onPress={onPress} style={({pressed}) => [{alignSelf: 'stretch'}, pressed && {opacity: .85}]}>
    <LinearGradient colors={NEON} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={p.switchRing}>
      <View style={p.switchInner}>
        <Text style={p.switchPrompt}>{prompt} </Text><Text style={p.switchAction}>{action}</Text>
        <Icon name="chevron-forward" size={15} color="#7C3AED" />
      </View>
    </LinearGradient>
  </Pressable>;
}

const p = StyleSheet.create({
  hero: {borderRadius: 26, padding: 18, gap: 10, overflow: 'hidden', borderWidth: 1.5, borderColor: 'rgba(255,255,255,.95)', shadowColor: '#4F46E5', shadowOpacity: .16, shadowRadius: 18, shadowOffset: {width: 0, height: 10}, elevation: 5},
  orb: {position: 'absolute', borderRadius: 999},
  heroRow: {flexDirection: 'row', alignItems: 'center', gap: 12},
  logoRing: {width: 62, height: 62, borderRadius: 22, backgroundColor: 'rgba(255,255,255,.75)', borderWidth: 1.5, borderColor: '#fff', alignItems: 'center', justifyContent: 'center', shadowColor: '#6366F1', shadowOpacity: .25, shadowRadius: 10, shadowOffset: {width: 0, height: 4}, elevation: 4},
  heroEyebrow: {fontSize: 11, fontWeight: '900', letterSpacing: 2, color: '#4F46E5'},
  heroTitle: {fontSize: 26, lineHeight: 31, fontWeight: '900', color: '#0D1736', letterSpacing: -.6},
  heroSub: {fontSize: 14, lineHeight: 20, color: '#33416B'},
  chips: {flexDirection: 'row', flexWrap: 'wrap', gap: 7},
  chip: {flexDirection: 'row', alignItems: 'center', gap: 5, paddingVertical: 4, paddingLeft: 4, paddingRight: 9, borderRadius: 999, backgroundColor: 'rgba(255,255,255,.72)', borderWidth: 1, borderColor: '#fff'},
  chipIcon: {width: 20, height: 20, borderRadius: 10, alignItems: 'center', justifyContent: 'center'},
  chipText: {fontSize: 11.5, fontWeight: '800', color: '#1E2A55'},
  cardFrame: {borderRadius: 24, padding: 1.5, shadowColor: '#4F46E5', shadowOpacity: .12, shadowRadius: 16, shadowOffset: {width: 0, height: 8}, elevation: 4},
  card: {borderRadius: 22.5, backgroundColor: 'rgba(255,255,255,.96)', padding: 14, gap: 10},
  frame: {borderRadius: 20, padding: 1.5},
  panel: {borderRadius: 18.5, padding: 14, gap: 12, overflow: 'hidden'},
  sweep: {position: 'absolute', top: -40, bottom: -40, width: 70, left: 0},
  head: {flexDirection: 'row', alignItems: 'center', gap: 7},
  dot: {width: 8, height: 8, borderRadius: 4, backgroundColor: '#22D3EE', shadowColor: '#22D3EE', shadowOpacity: .9, shadowRadius: 6, shadowOffset: {width: 0, height: 0}, elevation: 4},
  eyebrow: {fontSize: 11, fontWeight: '900', letterSpacing: 2, color: '#4F46E5'},
  secure: {fontSize: 10, fontWeight: '900', letterSpacing: 1.4, color: '#6366F1'},
  title: {fontSize: 18, fontWeight: '900', color: '#0D1736', letterSpacing: -.2},
  row: {flexDirection: 'row', gap: 10, alignItems: 'center'},
  ring: {flex: 1, borderRadius: 10, padding: 2},
  emailTile: {height: 48, borderRadius: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9},
  emailIcon: {width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center'},
  emailText: {fontSize: 15, fontWeight: '800', color: '#3730A3', letterSpacing: .3},
  orRow: {flexDirection: 'row', alignItems: 'center', gap: 8},
  orLine: {flex: 1, height: 1.5, borderRadius: 1},
  orText: {fontSize: 11.5, fontWeight: '700', color: '#6366F1', letterSpacing: .3},
  glow: {borderRadius: 16, shadowColor: '#7C3AED', shadowOpacity: .45, shadowRadius: 14, shadowOffset: {width: 0, height: 6}, elevation: 8},
  neonButton: {minHeight: 56, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, paddingHorizontal: 48, overflow: 'hidden'},
  shine: {position: 'absolute', left: 0, right: 0, top: 0, height: '50%'},
  neonText: {fontSize: 16.5, fontWeight: '900', color: '#fff', letterSpacing: .3, flexShrink: 1},
  arrow: {position: 'absolute', right: 12, width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,.22)'},
  switchRing: {borderRadius: 999, padding: 1.5},
  switchInner: {minHeight: 46, borderRadius: 999, backgroundColor: '#fff', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 14},
  switchPrompt: {fontSize: 14, color: '#475569', fontWeight: '600'},
  switchAction: {fontSize: 14, color: '#6D28D9', fontWeight: '900'},
});
