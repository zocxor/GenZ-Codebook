import React,{useState} from 'react';
import {LinearGradient} from 'expo-linear-gradient';
import {Pressable,Text,View} from 'react-native';
import {useAccountUser} from './services';
import {useEligibleBalance} from './ContributionScreens';
import {errorOf} from './communityFeatures';
import {useDailyReward} from './dailyReward';
import {BACKEND_URL} from './backend';
import {C,Glass,Icon,Button} from './ui';

/** Highlighted gold daily reward button. Every copy of it shares one "collected today" state (src/dailyReward.ts). */
export function DailyRewardButton({onCollected}:{onCollected?:()=>void}){
  const reward=useDailyReward();
  const [note,setNote]=useState('');
  const collect=async()=>{
    if(reward.busy||reward.done)return;setNote('');
    try{const msg=await reward.collect();if(msg)setNote(msg);onCollected?.();}
    catch(e){setNote(errorOf(e));}
  };
  const waiting=!reward.known;
  const label=reward.busy?'Collecting…':reward.done?'Collected today':waiting?'Checking today’s reward…':reward.account?'Daily reward · +10 Credits':'Daily reward · +10 points';
  return <View style={{gap:6}}>
    <Pressable accessibilityRole="button" accessibilityLabel={reward.done?'Daily reward collected':reward.account?'Collect your daily reward, 10 Credits':'Collect your daily reward, 10 learning points'} accessibilityState={{disabled:reward.busy||reward.done||waiting}} disabled={reward.busy||reward.done||waiting} onPress={()=>void collect()} style={({pressed})=>[{borderRadius:16,overflow:'hidden'},pressed&&{opacity:.9,transform:[{scale:.99}]}]}>
      <LinearGradient colors={reward.done?['#D1FAE5','#A7F3D0']:['#F5B82E','#E08E0B']} start={{x:0,y:0}} end={{x:1,y:1}} style={{minHeight:54,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:10,paddingHorizontal:14,opacity:waiting?.75:1}}>
        <Icon name={reward.done?'checkmark-circle':'gift'} size={22} color={reward.done?'#065F46':'#3D2600'}/>
        <Text style={{fontSize:16,fontWeight:'900',color:reward.done?'#065F46':'#3D2600'}}>{label}</Text>
      </LinearGradient>
    </Pressable>
    {!!note&&<Text accessibilityLiveRegion="polite" style={{color:C.muted,fontSize:13,textAlign:'center'}}>{note}</Text>}
  </View>;
}

export default function AccountTokens({compact=false,onOpen,reward=true}:{compact?:boolean;onOpen?:()=>void;/** Show the daily reward button inside the card. */reward?:boolean}){
  const user=useAccountUser(),credit=useEligibleBalance(BACKEND_URL?user?.uid:undefined);
  if(!BACKEND_URL||!user)return null;
  if(compact)return <Pressable accessibilityRole="button" accessibilityLabel={'Credits '+(credit.balance??'unavailable')+'. Open wallet.'} onPress={onOpen} style={{minHeight:44,paddingHorizontal:9,borderRadius:15,backgroundColor:'#FFE39A',flexDirection:'row',alignItems:'center',gap:4}}><Icon name="star" color="#785100" size={16}/><Text style={{fontWeight:'900',color:'#593D00',fontSize:13}}>{credit.balance===null?'—':credit.balance.toLocaleString()}</Text></Pressable>;
  return <Glass><View style={{flexDirection:'row',alignItems:'center',gap:6}}><Icon name="wallet-outline" color={C.accent}/><Text style={{fontSize:18,fontWeight:'800',color:C.navy}}>Credits: {credit.balance===null?'—':credit.balance.toLocaleString()}</Text></View><Text style={{color:C.muted}}>Credits pay for chat, posts, new words, Daily Code Display and badges. Learning points are separate and come from games.</Text>{credit.error&&<><Text accessibilityRole="alert" style={{color:C.muted}}>{credit.error}</Text><Button light title="Retry account balance" onPress={credit.reload}/></>}{reward&&<DailyRewardButton onCollected={credit.reload}/>}</Glass>;
}
