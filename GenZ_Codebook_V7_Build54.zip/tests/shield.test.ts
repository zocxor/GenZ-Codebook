import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {shieldZones, type ShieldCheck} from '../src/shield/status';

const pass = (id: string): ShieldCheck => ({id, title: 'x', state: 'pass', detail: 'x'});
const all = ['storage', 'integrity', 'account', 'session', 'signin-attempts', 'transport', 'messages', 'sync'].map(pass);

test('Threat Shield groups the protections into four areas that only say Protected', () => {
  const zones = shieldZones(all);
  assert.deepEqual(zones.map(z => [z.id, z.status, z.label]), [['account', 'protected', 'Protected'], ['device', 'protected', 'Protected'], ['backup', 'protected', 'Protected'], ['privacy', 'protected', 'Protected']]);
  for (const z of zones) assert.equal(z.tip, undefined, 'no technical detail is shown when all is well');
});

test('an area needs attention when any of its checks does, with one simple action', () => {
  const checks = all.map(c => c.id === 'account' ? {...c, state: 'attention' as const, action: 'verify-email' as const} : c.id === 'storage' ? {...c, state: 'attention' as const, action: 'retry-storage' as const} : c);
  const z = Object.fromEntries(shieldZones(checks).map(x => [x.id, x]));
  assert.deepEqual([z.account!.status, z.account!.action, z.account!.label], ['attention', 'verify-email', 'Action needed']);
  assert.match(z.account!.tip!, /Verify your e-mail/);
  assert.deepEqual([z.device!.status, z.device!.action], ['attention', 'retry-storage']);
  assert.equal(z.privacy!.status, 'protected');
});

test('signed out: account and backup show as off with a sign-in action', () => {
  const checks = all.map(c => c.id === 'account' || c.id === 'sync' ? {...c, state: 'info' as const, action: 'sign-in' as const} : c.id === 'session' ? {...c, state: 'n/a' as const} : c);
  const z = Object.fromEntries(shieldZones(checks).map(x => [x.id, x]));
  assert.deepEqual([z.account!.status, z.account!.label, z.backup!.status, z.backup!.label], ['off', 'Not signed in', 'off', 'Off']);
});

test('the Threat Shield screen no longer lists the individual protections', () => {
  const screen = readFileSync('src/ThreatShieldScreen.tsx', 'utf8');
  assert.doesNotMatch(screen, /checks\.map\(/, 'individual checks are not rendered');
  assert.match(screen, /shieldZones\(checks\)/);
  assert.match(screen, /individual protections aren’t listed/);
  assert.doesNotMatch(screen, /one banner/, 'storage notes match the app (no banner ads)');
});
