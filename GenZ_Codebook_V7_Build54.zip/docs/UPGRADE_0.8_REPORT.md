# GenZ Codebook 0.8.0 — Implementation report

Date: 5 November 2026 · Source baseline: 0.7.0 (branding) on the 0.5.0 codebase · Package `com.genzmode.app`, versionCode 8.

**Bottom line.** The data-saving defects are fixed at the root and verified in a browser across close/reopen, corruption and offline scenarios. Cloud sync, account deletion, the Secure Engine/Threat Shield layer, Firestore security rules, the admin portal and CMS are implemented. **Not yet verified:** the Firestore rules and every Firestore-backed path (no Firestore emulator could be downloaded in the build environment), and the native Android build on a device (no Android SDK there). The app is **not yet Google Play ready**; section 15 lists exactly what remains.

---

## 1. Existing architecture discovered

- Expo SDK 54 / React Native 0.81 (new architecture, Hermes), maintained native `android/` project with signing guards; `App.tsx` as a single orchestrator.
- Content: 8,584 bundled entries in `src/data/library.json` (+ SQLite export), pure search/decoder engine.
- Local data: **one unversioned JSON blob** in AsyncStorage (`genz-code-v2`), written by a `useEffect` on every state change.
- Backend: Firebase project `gen-z-code-55caf`, **Authentication only** (email/password, JS SDK, SecureStore session persistence). Firestore/Storage rules were deny-all and not deployed. No sync, CMS, admin portal or server code.
- Implemented ✅: dictionary, decoder, 4 levels + shuffle/daily quizzes, spaced review, saves, local profile, email accounts, export, local deletion. Partial ⚠️: persistence (see §3), privacy screen (static text). Missing ❌: history/recent/attempts/streaks, cloud sync, admin, CMS, security events, retention policy, web deletion page.

## 2. Storage problems identified

1. Unknown term IDs silently dropped on load (`parseProfile`), then overwritten by the next autosave.
2. UI updated before persistence; write failures only showed a generic banner while the UI kept showing unsaved data.
3. A corrupt record put the app into permanent read-only "recovery mode" (all progress temporary) with no backup or way out except deleting everything.
4. No schema version or migration path.
5. No cloud backup and `allowBackup=false` → any uninstall/reinstall lost everything.
6. Quiz category, recently viewed, search history, round history and streaks were not persisted at all.
7. `App.tsx` ran a full 8,584-entry search on every render for an unused variable, slowing every state change (including saves).
8. On web, `Alert`-based confirmations were no-ops, so "Delete my local data" did nothing.

## 3. Root causes of data-saving failures (what testers most likely saw)

- **Reinstalling between differently signed builds.** Internal builds are signed with the debug key; your new production key is a different certificate, so Android refuses to update — you must uninstall, and with backups disabled and no cloud copy all learning data is lost. *Fix:* cloud sync for signed-in users; uninstall behaviour is explained in the app (Threat Shield, account screen). Plan the certificate switch before external testers rely on their data.
- **Silent destructive filtering (#1)** made saves disappear permanently whenever content IDs changed. *Fix:* records are preserved by ID format and only hidden in the UI (`src/profile.ts`), verified by test.
- **Optimistic, unconfirmed writes (#2).** *Fix:* `LearningRepository.mutate()` writes first and publishes to the UI only after the write resolves; on failure the state is unchanged and the user is told.
- **Corruption lock-out (#3).** *Fix:* checksum + backup slot + quarantine (see §6).

## 4. Files and components modified / added

Modified (upgraded in place, same screens and design): `App.tsx` (wired to the repository; You tab → dashboard; privacy sheet → Threat Shield), `src/profile.ts` (schema v3), `src/storage.ts` (durable store), `src/engine.ts` + `src/content.ts` (rebuildable index, content overlay), `src/reviewQueue.ts`, `src/AccountScreen.tsx`, `src/DictionaryScreen.tsx`, `src/TermDetail.tsx`, `src/ui.tsx`, `src/auth/client.ts`, `src/auth/policy.ts`, `firebase/firestore.rules`, `firebase.json`, `AndroidManifest.xml`, `app.json`, `build.gradle`, `package.json`, scripts, CI, tests.

Added — app: `src/learning.ts` (pure transitions), `src/repository.ts`, `src/services.ts`, `src/sync/{engine,merge,firestoreCloud}.ts`, `src/secure/{config,logger,events,integrity,session}.ts` (Secure Engine), `src/shield/{loginGuard,status}.ts` + `src/ThreatShieldScreen.tsx` (Threat Shield), `src/contentSync.ts`, `src/ugc.ts`, `src/SubmitForms.tsx`, `src/ProfileDashboard.tsx`, `src/NavBar.tsx`, `src/avatarPhoto.ts`, `src/firebase/app.ts`, `shared/contentSchema.ts`.
Added — backend/portal: `firebase/firestore.indexes.json`, `firebase/rules-tests/rules.test.mjs`, `admin/` (portal + public privacy/deletion pages), `tests-e2e/`, docs (`ADMIN_PORTAL.md`, `DATA_RETENTION.md`, `PLAY_DATA_SAFETY.md`, this report), `.github/dependabot.yml`.

UI requests during the session: **elegant profile dashboard** (hero with rank/XP, streak/XP/saved/mastered tiles, 7-day activity, learning path, recent rounds, badges, recently viewed — all from real data); **profile photo upload** (system photo picker → square crop → 320 px JPEG, device-only); **navigation bar** upgraded to a floating dock in the existing colours with a real review-due badge, plus a fix for the badge/content overlap you spotted.

## 5. New dependencies

| Package | Where | Why | Note |
|---|---|---|---|
| `expo-image-picker` ~17.0.11 | app (native) | Profile photo | **Requires a native rebuild.** Its CAMERA/storage permissions are stripped in the manifest |
| `expo-image-manipulator` ~14.0.8 | app (native) | Crop/downscale photo | Native rebuild |
| `firebase/firestore/lite` | app | Sync, content delivery, submissions | Already inside `firebase`; REST-only Lite build chosen to limit size |
| `@firebase/rules-unit-testing` 6.0.0 | dev | Rules tests | |
| `vite` 7, `react` 19.1, `firebase` 13.1, `qrcode` 1.5.4 | `admin/` only | Portal | gRPC override 1.14.5 (same as the app) → 0 advisories |

Android JS bundle: 6.26 MB → 6.81 MB (+0.55 MB, +8.8%).

## 6. Database changes

**Local (device):** `genz-code-v3` = `{v, savedAt, sum (FNV-1a), data}`; `genz-code-v3.bak` = previous good write (committed in the same AsyncStorage `multiSet` transaction); `genz-code-quarantine.<ts>` (max 3) for unreadable records; separate keys for security log, login guard, content overlay cache and profile photo.
**Firestore (new):** `users/{uid}` (no e-mail), `users/{uid}/sync/{profile|saved|progress|scores}`, `users/{uid}/limits/{ugc|sec}`, `users/{uid}/supportNotes/*`, `directory/{uid}` (e-mail, restricted), `admins/{uid}`, `auditLogs/*` (TTL 365 d), `securityEvents/*` (TTL 90 d), `config/app`, `content/{id}` + `versions/{n}`, `publishedContent/{id}` (public), `submissions/*`, `reports/*`, `feedback/*`. Indexes and TTL in `firebase/firestore.indexes.json`.
**Sync model:** per-record last-writer-wins with a hybrid logical clock, tombstones for removals, watermarks for bulk resets, monotonic best scores, bounded unions for attempts/days. Each domain syncs through a server transaction (read → merge → write only if changed); a domain is marked clean only when the server confirmed it and no newer local change arrived.

## 7. Data migration requirements

Automatic on first launch of 0.8.0: v2 (`genz-code-v2`) or v1 (`genz-mode-v1`) → v3, preserving order of saves, scores, review progress, name, avatar and language; legacy keys are removed **only after** the v3 write is confirmed (tested). No server migration (all collections are new). Owner steps: see `docs/ADMIN_PORTAL.md` (rules test → deploy rules/indexes/hosting → TOTP MFA → first Super Admin).

## 8. Admin portal functionality implemented

Sign-in with **mandatory TOTP two-step verification** (enrolment flow included), per-tab session, 30-minute idle sign-out, denied attempts logged. **Dashboard** from live aggregation queries: registered/DAU/WAU/MAU/new users, suspended, learning activity, retention (D1/D7/D30, defined on screen), app-version share, slang DB stats, pending suggestions/open reports/feedback & average rating, security events. **Users:** search (UID; e-mail prefix for PII roles), status filter, sort, pagination, detail with learning stats and quiz history, suspend/reactivate with reason, support notes, deletion processing. **CMS:** all 8,584 bundled entries browsable/searchable/filterable; create/edit with validation and duplicate detection; draft → review → publish; archive; immutable version history with rollback; CSV/JSON import (validation, sanitisation, in-file and library duplicate detection, drafts only); CSV/JSON export with formula-injection protection; published entries reach the app without an APK update. **Moderation:** suggestions → CMS drafts, reports resolve/dismiss, feedback triage. **Audit & security logs**, **Admins & roles** (5 roles, no self-edit), **Settings** (UGC kill switch, content-delivery switch).

## 9. Security controls implemented

Secure Engine: redacting logger (silent in production), shared input validation, integrity checksums, secure-storage session (existing SecureStore), session expiry handling on foreground, security-event recording (minimised, rate-limited, 90-day TTL), secure config (no secrets; emulator flag ignored by native release builds). Threat Shield: persistent sign-in throttle (3 free attempts, then 30 s doubling to 15 min), 8 real status checks with "passed / applicable" summary, privacy controls (search history opt-in, clear history, resets, export, delete local data, account deletion). Server: deny-by-default rules with ownership checks, MFA-gated RBAC, rules-enforced audit logging, schema/size validation, server-time stamps, rate limits, suspension enforcement, public/draft separation. Hosting: strict CSP, HSTS, frame-ancestors none, no-referrer, Permissions-Policy. Android: CAMERA/RECORD_AUDIO/storage/media permissions removed, cleartext and backups disabled.

## 10–11. Security findings (threat model) and resolution status

| # | Threat | Sev. | Component | Impact | Mitigation | Status | Verification |
|---|---|---|---|---|---|---|---|
| 1 | Cross-user data access (IDOR) | Critical | Firestore | Read/alter others' learning data | Owner-only rules on `users/{uid}/**`; uid from token | Implemented | Rules test written, **not executed** |
| 2 | Unauthorised admin access | Critical | Portal, rules | Full data/content control | Role doc + active flag + **MFA claim** checked server-side; no self-role edits | Implemented | Portal gate fails closed (browser test); rules **not executed** |
| 3 | Admin actions without accountability | High | Rules | Undetectable abuse | Audit entry required in the same batch (actor/target/time) | Implemented | Rules test **not executed** |
| 4 | Self-reactivation / status tampering | High | Rules | Bypass suspension | Owner cannot change `status`; tombstone blocks recreation | Implemented | Rules test **not executed**; sync engine blocks (unit test ✅) |
| 5 | Data loss on content updates | High | Local storage | Permanent loss of saves | Preserve unknown IDs | **Resolved** | Unit + browser tests ✅ |
| 6 | Corrupt local record locks app | High | Local storage | All progress temporary | Checksum, backup, quarantine | **Resolved** | Unit + browser tests ✅ |
| 7 | Brute-force / credential stuffing | High | Auth | Account takeover | Firebase server throttling; client guard; non-enumerating errors; owner: enumeration protection | Implemented (client) / owner config | Auth-emulator test ✅ |
| 8 | Malicious imported/submitted content | High | CMS, app | XSS in portal, broken app, formula injection | Shared schema, control/bidi stripping, HTML/script rejection, React-escaped rendering, CSV cell neutralising, app re-validates published data | Implemented | Unit tests ✅ |
| 9 | Session theft | Medium | App | Account misuse | SecureStore session, token revalidation, sign-out clears session; portal session per tab + idle timeout | Implemented | Partially (web); **native not device-tested** |
| 10 | API abuse / spam | Medium | Firestore | Cost, junk data | Rules rate limits, account-active checks, kill switch | Implemented | Rules **not executed**; App Check **not configured** |
| 11 | Sensitive data in logs | Medium | App/portal | PII leakage | Redacting logger, no prod console, events carry no PII | Implemented | Unit-level + scan ✅ |
| 12 | Account enumeration | Medium | Auth | Target discovery | Generic errors; owner must enable enumeration protection | Partial (owner) | Browser test ✅ (generic message) |
| 13 | Excessive permissions | Medium | Android | Privacy/Play rejection | Explicit removals | Implemented | Static scan ✅; merged manifest **not built** |
| 14 | Dependency vulnerabilities | Medium | npm | Supply chain | Overrides, CI audit, Dependabot | App: 0 high/critical (11 moderate, 1 low Expo/Metro chain); portal: 0 | `npm audit` ✅ |
| 15 | Trojan-Source / hidden characters | Low | Source | Review bypass | Scanner check | Implemented | Planted-sample test ✅ |
| 16 | Release built with emulator config | Medium | Build | Broken/insecure release | Native builds ignore the flag; release gate fails if set; `--clear` | **Resolved** (found during testing) | Bundle grep ✅ |
| 17 | Bots without App Check | Medium | Backend | Abuse at scale | Rules limits only | **Open** | — |
| 18 | Profile photo exposure | Low | App | Personal image leak | Device-only, never uploaded, deleted with local data | Implemented | Browser test ✅ |

No critical/high finding is known to be *open in the code*; however #1–#4 and #10 are **unverified until the rules tests run**, so they must be treated as open for release purposes.

## 12–13. Tests performed and results

| Suite | Result |
|---|---|
| App unit tests (`npm test`) — storage, migration, corruption, sync merge/convergence/offline/account switching/suspension/deletion, streaks, existing domain tests | **47/47 pass** (was 26) |
| Admin unit tests — CMS merge, duplicate detection, import validation/sanitising, CSV, IDs, retention maths, RBAC matrix | **8/8 pass** |
| Browser: persistence (save → close/reopen, profile edit, corruption recovery, quarantine, local deletion) | **18/18 pass** |
| Browser: profile photo (pick, 320×320 crop, persists, not in synced record, deletion) | **8/8 pass** |
| Browser + **Firebase Auth emulator**: sign-up, offline sync honesty, sign-out choices, wrong password, throttle persistence, Threat Shield flag, safe deletion, re-auth | **15/15 pass** |
| Browser: admin portal under production CSP, public pages, fail-closed gate | **10/10 pass** |
| TypeScript (app + portal) | Pass |
| Android Hermes bundle (`expo export --clear`) | Pass |
| Security scan (79 files) + planted-sample check | 0 findings; detector verified |
| `npm audit` | App 0 high/critical; portal 0 |
| **Firestore rules tests (18)** | **Written, not executed** — emulator binary not downloadable here |
| **Firestore integration** (sync adapter, content delivery, submissions, portal data) | **Not executed** against Firestore |
| **APK build / device tests** (restart, force-stop, reboot, update, account switching, offline) | **Not performed** — no Android SDK/device here |
| Performance (startup, memory, jank) | Not measured on device; bundle +8.8%, cloud start deferred until after first render |

Bugs found and fixed by these tests: sign-out left the form in "Create account" mode; nav badge covered the icon and content was cut at the dock; emulator flag could survive in Metro's cache.

## 14. Remaining limitations (exact next actions)

1. **Run `npm run test:rules`** (Java 21 + firebase-tools) and fix any failure before deploying rules. Then exercise sync/CMS against the emulator (`firebase emulators:start --only auth,firestore` + the emulator web build).
2. **Build and install on a device:** `cd android && ./gradlew assembleInternal -PreactNativeArchitectures=arm64-v8a` (new native modules), then run the device checklist in §13; verify merged permissions with `aapt dump permissions`.
3. Enable Identity Platform TOTP MFA, enumeration protection, TTL, backups; bootstrap the first Super Admin (docs/ADMIN_PORTAL.md).
4. No Cloud Functions: disabling sign-in and deleting Auth accounts for admin-processed requests are console steps.
5. App Check not configured. Google sign-in not configured. No NetInfo: reconnection is detected by retry back-off (5 s → 15 min) and app foreground.
6. Not implemented (no fake settings shown): notifications, dark theme, user-created collections (saved words cover favourites/bookmarks), cross-device profile photo.
7. Dashboard "active users" counts signed-in accounts only (no analytics SDK by design).
8. Privacy policy has publisher placeholders; content editorial review of imported entries is still outstanding.

## 15. Google Play readiness

**Not ready.** Blocking: rules tests + Firestore integration test; signed release build and physical-device QA; publisher identity, support e-mail and completed privacy policy; Data safety form (draft in `PLAY_DATA_SAFETY.md`); console security configuration (MFA, enumeration protection, App Check recommended); content editorial review; signing-certificate migration plan for existing testers. Ready: account deletion in-app and on the web, permission minimisation, encrypted transport, deletion/retention design, release gate scripts.


---

## Addendum — 0.8.1 (5 November 2026, after first device install)

Feedback from installing the first APK, and what changed:

| Issue | Cause | Fix | Verified |
|---|---|---|---|
| Crop screen's confirm button invisible | Native crop activity's toolbar hidden under the status bar on edge-to-edge Android | Native crop screen removed; the centre square is cropped automatically (already implemented) | Browser photo test 8/8; native picker not device-tested |
| No visible sign-in | Only reachable via the You tab rows | **Sign in** button beside the avatar in the header (all tabs); **Sign in / Create account** buttons in the profile card | Browser screenshots |
| "Try signing in or resetting password" on sign-up | That email already had an account (Firebase `email-already-in-use`) | Form switches to Sign in with the email kept and a clear message; new accounts get the verification email automatically | Auth-emulator test 17/17 |
| APK ~40 MB | Two CPU architectures, uncompressed native libraries, 1254 px brand images | arm64-only APK, compressed native libraries, images resized (−2.9 MB) | Size to be confirmed in the CI log |
| "Sync needs attention" | Firestore created in production mode (deny-all); rules not published | **Deploy Firebase** workflow (rules tested first) | Depends on the deploy run |
| Admin portal location | Web-only by design | Deployed by the same workflow; admin = UID in `admins` + TOTP | Depends on the deploy run |
| Need AAB | — | `beta` build type signed with the upload key; versionCode 100 + run number | Depends on secrets + CI run |

## Addendum — 0.8.2 (6 November 2026)

- Removed `USE_BIOMETRIC` / `USE_FINGERPRINT` (declared by `expo-secure-store` for optional biometric unlock, which the app never uses); the security scan and the APK check now fail if they return.
- Play AAB job checks the upload keystore before building and reports a wrong password, missing alias (listing the aliases found) or a bad base64 copy in plain words.
- The first 0.8.1 CI run built the APK successfully; its red X came from an outdated version-code check in the older workflow file.

## Addendum — 0.8.3 (6 November 2026): instant community words, clearer errors, content delivery fix

Feedback: "Suggest a word" failed with "Couldn't send that right now"; suggestions should go online and into the app's list automatically; the button should be easy to find; data didn't come back after clearing the app and signing in again.

| Item | Root cause / design | Change | Verified |
|---|---|---|---|
| Suggestion failed | Firestore security rules were never published (the database is deny-all), so every cloud write is refused. The old message hid the reason | Each failure now names its cause: server not set up (`server-setup`), offline, wait N s, restricted account, e-mail not verified, or the backend code. **Deploy Firebase** must be run once | Browser e2e against emulators |
| Data not restored after clearing / reinstalling | Same cause: sync was never able to write, so the cloud copy was empty | Sync shows "Cloud backup isn't switched on yet…" instead of a vague error; after Deploy Firebase, sign-in restores saved words | e2e: save → backed up → wipe → sign in → restored |
| Suggestions published automatically | Requested | New `communityWords` collection: published instantly, shown with a **Community** label, searchable and decodable; one per word; verified e-mail + 60 s limit + no links/e-mails/phone numbers (rules); duplicates of dictionary words refused; word filter sends sensitive words to moderators; moderators hide/restore (audited); owner switch in Settings | Rules tests written (6 new); app e2e 18/18 (emulator without rules); unit tests 52/52 |
| Suggest a word hard to find | Only at the end of an 8,500-row list | Highlighted banner under the Words search bar, on the Decode tab, on the You tab, and for searches with no result | Screenshots |
| **Published content never reached fresh installs** (found while testing) | The first download used an empty document-ID cursor, which the Firestore SDK rejects; the error was swallowed | First page starts at the beginning; failures are now logged | e2e: editor-published entry appears on a fresh install |

Not verified here: the new rules on the official emulator (they run automatically in **Deploy Firebase** before anything is published; a failure blocks the deploy), and device QA of 0.8.3.

## Addendum — 0.8.4 (6 November 2026): exact reason when the server refuses

Device report on 0.8.3: "The server didn't accept this … (code: permission-denied)" when publishing a word.

- **Cause:** the Firestore security rules were still not published, so the database refused every request. The first request when adding a word (reading the public `config/app` flags) was refused, and 0.8.3 showed that as a generic permission error.
- **Reproduced:** `tests-e2e/server-not-set-up.mjs` starts a stand-in Firestore that refuses everything, as the real one does before rules are published. 0.8.4 now says "security rules haven't been published (code: rules-missing)", and sync says "Cloud backup isn't switched on yet". 3/3 checks.
- **Other refusals are named too:** older rules without community words (`rules-outdated`); and, if the final write is refused, the app checks why: e-mail not verified on the server, inactive account, within a minute of the last word, switched off by the team, or the word content (`refused:…`).
- If sync and a suggestion create the account record at the same moment, the second one now re-reads the record instead of failing.
- **The fix itself is on the server:** publish `firebase/firestore.rules` (Firebase console → Firestore → Rules → Publish, or the Deploy Firebase workflow, which also runs the rules tests). The installed 0.8.3 app works once the rules are published; rebuilding to 0.8.4 only improves the messages.
- Happy path re-checked: `tests-e2e/community.mjs` 18/18; unit tests 52/52.

## Addendum — 0.8.5 (6 November 2026): admin portal without the paid upgrade

The Firebase console offered the Identity Platform upgrade (needed for authenticator-app codes) only as a paid plan, and the owner chose to skip it.

- Rules: admin access needs an `admins` record, `active: true` and a **verified e-mail**. Two-step verification is enforced only when the console-only document `config/security.adminMfaRequired` is `true` (no app or portal can write it). Rules tests updated: password-only admin allowed by default, unverified admin refused, and with the switch on, password-only admin refused.
- Portal: a verified admin goes straight in. An unverified one gets a "Verify your e-mail" screen. Authenticator setup appears only when the switch is on. The audit log records which way each sign-in happened.
- Verified with emulators (`tests-e2e/admin-community.mjs`, 8/8): password sign-in, unverified admin stopped, Community words hide/restore with matching audit entries, instant-publishing switch saved.
- Trade-off: admin accounts are protected by password and verified e-mail only. Use a long, unique password, and switch two-step on if the project moves to a paid plan.
- **CI fix:** the rules-test command passed a folder (`node --test firebase/rules-tests/`). Node 22 tries to load that folder as a module and fails in about 30 ms, so the rules tests had never actually run in any workflow. Every workflow and `npm run test:rules` now name the file (`firebase/rules-tests/rules.test.mjs`). Reproduced locally on Node 22.

## Addendum — 0.8.6 (6 November 2026): deploy on the free (Spark) plan

The first real Deploy Firebase run passed the rules tests and compiled the rules, then stopped: *"Project gen-z-code-55caf has billing disabled"* while creating the TTL policies (`fieldOverrides` on `expireAt`). Firestore TTL needs a billing account.

- TTL policies removed from `firestore.indexes.json` (composite indexes stay).
- Rules: a Super Admin may delete `auditLogs` / `securityEvents` entries **only after `expireAt`**; nothing else changes, and audit entries still cannot be edited. New audit action `logs.purge`. New rules test.
- Portal: **Audit & security → Delete expired entries** (Super Admin), batches of 400. The clean-up is logged. Emulator e2e: only expired entries removed, current ones kept, and the clean-up logged (`tests-e2e/admin-community.mjs`, 9/9).
- Privacy policy and DATA_RETENTION updated: the 90/365-day limits are met by this monthly clean-up instead of automatic TTL.

## Addendum — 0.8.7 (6 November 2026): dashboard on a fresh project

First sign-in to the deployed portal: the Dashboard **Users** card showed "A required Firestore index or precondition is missing".

- Its counts combined a status filter with a date range, and its totals combined a filter with sum/average. Firestore needs composite indexes for those, and the ones deployed did not match (and new indexes take minutes to build).
- Now each Users-card query uses a single field, which Firestore indexes automatically. Deleted-account tombstones have no activity, sign-up or stats fields, so they are still excluded. Activity counts can include suspended accounts, which is labelled.
- Any remaining missing-index error now says so plainly and shows Firestore's own **create this index** link, or says the index is still building.
- Emulator e2e: dashboard Users card loads (`tests-e2e/admin-community.mjs`, 10/10).

## Addendum — 0.8.8 (6 November 2026): publisher identity

- `shared/brand.ts` holds the identity once: **GenZ Codebook**, a **ZTechX** product, **© 2026 Zocxorian Technologies. All rights reserved.** The year becomes a range automatically from 2027.
- App: the footer "A ZTechX product / © 2026 Zocxorian Technologies. All rights reserved." appears on the start (welcome) page, the Decode, Words, Play and You tabs, and every sheet (account, Threat Shield, suggest a word, word details, quiz). The loading screen says "by ZTechX".
- Admin portal: the same line on the sign-in card and in the sidebar. Public pages (home, privacy policy, account deletion) have the footer, and the privacy policy names the publisher as Zocxorian Technologies (ZTechX). The business address and support e-mail placeholders remain.
- `package.json` author set for the app and the portal.
- Browser check: footer present on every surface listed above, 13/13.

## Addendum — 0.8.9 (6 November 2026): contact details

- Support e-mail **zocxoriantechnologies@gmail.com** and address **Zpr, Rahim Yar Khan, Punjab, Pakistan** in `shared/brand.ts`.
- App: **You → Contact support** opens the e-mail app addressed to support. Threat Shield lists the privacy contact.
- Privacy policy completed (no PUBLISHER placeholders): publisher name and address, privacy e-mail, 12-month review of suggestions and reports, no separate backups, 13+ audience (not directed at children), Google Cloud processing and transfers. The deletion page gives the support e-mail. Every public page footer shows the address and e-mail.
- Play Console must match: contact e-mail, privacy policy URL, deletion URL, target audience 13+.
