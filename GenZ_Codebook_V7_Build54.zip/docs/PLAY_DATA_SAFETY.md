# Google Play — Data safety form mapping (Build 49)

Prepared from the code in this repository. The publisher must review and submit it; Google holds the publisher responsible for accuracy. Re-check after adding any SDK.

**Does the app collect or share user data?** Yes, collects (only when the user creates an account or sends content). No data is shared with third parties (Firebase acts as a service provider/processor, which Play does not count as sharing).

**Is data encrypted in transit?** Yes (HTTPS/TLS only; `usesCleartextTraffic="false"`).
**Can users request deletion?** Yes — in-app (My account → Delete account and cloud data) and on the web: `https://gen-z-code-55caf.web.app/delete-account.html` (enter this URL in Play Console → App content → Data deletion).

| Play data type | Collected? | Required/optional | Purposes | Notes |
|---|---|---|---|---|
| Personal info → Email address | Yes | Optional (account only) | Account management | Firebase Auth + support directory |
| Personal info → User IDs | Yes | Optional | Account management, Fraud prevention/security | Firebase uid on account record, submissions, security events |
| Photos and videos → Photos | **Yes** | Optional | App functionality | Optional private chat attachments and opt-in public profile thumbnails leave the device. |
| Files and docs → Files and docs | **Yes** | Optional | App functionality | A file and its filename are collected when the user sends a private attachment. |
| Messages → Other in-app messages | Yes | Optional | App functionality | Text and captions sent in Inbox and Community chat. Decoder input stays on-device. |
| App activity → App interactions | Yes | Optional | App functionality, Analytics | Saved words, scores, review schedule synced to the account; last-active day + summary counts for aggregate usage |
| App activity → Other user-generated content | Yes | Optional | App functionality | Word suggestions, content reports, published community words |
| App info and performance → Other app performance data | No | — | — | No crash/analytics SDK |
| App activity → Other actions (feedback) | Yes | Optional | App functionality | Rating + message |
| Device or other IDs | No | — | — | No advertising ID or device ID collected |
| Messages (decoder input) | **No** | — | — | Processed on device only, never stored or sent |
| Financial info → Purchase history | Yes (Build 37+) | Optional (only when buying) | App functionality, Fraud prevention/security | Google Play order ID, product, amount and purchase token stored on the account to add Credits/Premium once. Card details are handled by Google Play only |
| Location, Contacts, Audio, Calendar, Health, other Financial info | No | — | — | Permissions explicitly removed in the manifest |

**Security practices to declare:** data encrypted in transit; users can request deletion. Do **not** claim an independent security review unless one is completed (this repository contains a code review, not a third-party audit).

**Permissions in the merged manifest (expected):** `INTERNET` only for dangerous/normal permissions declared by the app. CAMERA, RECORD_AUDIO, READ/WRITE_EXTERNAL_STORAGE and READ_MEDIA_IMAGES are removed with `tools:node="remove"`; verify with `aapt dump permissions` on the release build because `expo-image-picker` declares some of them.
