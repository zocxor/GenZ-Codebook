import React,{useEffect,useState} from 'react';
import {Modal,Pressable,StyleSheet,Text,View} from 'react-native';
import {collection,getDocs,onSnapshot,query,where} from 'firebase/firestore';
import {cloudDbLive} from './firebase/app';
import {ms,savedPosts,type FeatureRow} from './communityFeatures';
import type {PublicAbout} from './publicProfile';
import {SafeAreaView} from 'react-native-safe-area-context';
import {KeyboardDock} from './KeyboardDock';
import {PostThread} from './CommunityPostsPanel';
import {useBlocked} from './safety';
import {useAccountUser} from './services';
import {C,Icon} from './ui';

type Tab='Posts'|'Slangs'|'Codes'|'Likes received'|'Liked';
type ProfileEntry=FeatureRow&{dictionary?:boolean};
type Count={label:string;value?:number;action?:()=>void;expanded?:boolean};

export function useProfileColors(){
 const [dark,setDark]=useState(false);
 return {dark,toggle:()=>setDark(v=>!v),bg:dark?C.navy:C.bg,ink:dark?C.bg:C.ink,muted:dark?'#BCCAE5':C.muted,
  line:dark?'#354769':C.line,accent:dark?'#A9BFFF':C.accent,soft:dark?'#1C2E55':C.soft};
}
export type ProfileColors=ReturnType<typeof useProfileColors>;

export function ProfileIcon({label,name,onPress,colors}:{label:string;name:React.ComponentProps<typeof Icon>['name'];onPress:()=>void;colors:ProfileColors}){
 return <Pressable style={styles.icon} accessibilityRole="button" accessibilityLabel={label} onPress={onPress}><Icon name={name} size={20} color={colors.ink}/></Pressable>;
}

export function ProfileAction({label,onPress,colors,primary,disabled}:{label:string;onPress:()=>void;colors:ProfileColors;primary?:boolean;disabled?:boolean}){
 return <Pressable accessibilityRole="button" disabled={disabled} onPress={onPress}
  style={({pressed})=>[styles.action,{backgroundColor:primary?C.blue:colors.soft,borderColor:primary?C.blue:colors.line,opacity:disabled?.65:pressed?.8:1}]}>
  <Text style={{color:primary?'#fff':colors.ink,fontWeight:'800',textAlign:'center'}}>{label}</Text>
 </Pressable>;
}

export function SocialProfile({uid,owner=false,colors,followers,following,likes,onConnections,credits,onWallet,about}:{uid?:string;owner?:boolean;colors:ProfileColors;followers?:number;following?:number;likes?:number;onConnections?:(list:'followers'|'following')=>void;credits?:number|null;onWallet?:()=>void;about?:PublicAbout}){
 const viewer=useAccountUser();
 const blocked=useBlocked();
 const [thread,setThread]=useState<{row:FeatureRow;report:boolean}|null>(null);
 const [expanded,setExpanded]=useState(false);
 const [tab,setTab]=useState<Tab|null>(null);
 const [posts,setPosts]=useState<FeatureRow[]|null>(null);
 const [dictionary,setDictionary]=useState<ProfileEntry[]|null>(null);
 const [dictionaryError,setDictionaryError]=useState(false);
 const [liked,setLiked]=useState<FeatureRow[]|null>(null);
 const [postError,setPostError]=useState(false),[likedError,setLikedError]=useState(false);
 const [retry,setRetry]=useState(0),[visible,setVisible]=useState(12);
 useEffect(()=>{
  if(!uid)return;
  return onSnapshot(query(collection(cloudDbLive(),'communityPosts'),where('uid','==',uid),where('status','==','approved'),where('hidden','==',false)),
   snapshot=>{setPostError(false);setPosts(snapshot.docs.map(d=>({...d.data(),id:d.id}) as FeatureRow).sort((a,b)=>ms(b.createdAt)-ms(a.createdAt)));},
   ()=>setPostError(true));
 },[uid,retry]);
 useEffect(()=>{
  if(!uid)return;
  return onSnapshot(query(collection(cloudDbLive(),'communityWords'),where('uid','==',uid),where('status','==','live')),
   snapshot=>{
    setDictionaryError(false);
    setDictionary(snapshot.docs.map(d=>({...d.data(),id:d.id,dictionary:true}) as ProfileEntry));
   },()=>setDictionaryError(true));
 },[uid,retry]);
 useEffect(()=>{
  if(!owner||!uid||tab!=='Liked')return;
  let active=true;
  setLiked(null);setLikedError(false);
  void getDocs(query(collection(cloudDbLive(),'communityPostLikes'),where('uid','==',uid)))
   .then(snapshot=>savedPosts(snapshot.docs.map(d=>String(d.get('postId')))))
   .then(rows=>{if(active)setLiked(rows.sort((a,b)=>ms(b.createdAt)-ms(a.createdAt)));},()=>{if(active)setLikedError(true);});
  return ()=>{active=false;};
 },[owner,uid,tab,retry]);
 const slangs=posts?.filter(row=>row.category==='Slang');
 const codes=posts&&dictionary?[...posts.filter(row=>row.category==='Code Word'),...dictionary].sort((a,b)=>ms(b.createdAt)-ms(a.createdAt)):null;
 const received=tab==='Likes received'?posts?.filter(row=>(row.likeCount??0)>0)
  .sort((a,b)=>(b.likeCount??0)-(a.likeCount??0)):undefined;
 const rows:ProfileEntry[]|undefined=(tab==='Likes received'?received:tab==='Liked'?liked:tab==='Slangs'?slangs:tab==='Codes'?codes:posts)?.filter(row=>!blocked.has(row.uid));
 const error=tab==='Liked'?likedError:postError||(tab==='Codes'&&dictionaryError);
 const select=(next:Tab)=>{setVisible(12);setTab(current=>current===next?null:next);};
 const counts=(items:Count[])=><View style={[styles.row,styles.divider,{borderColor:colors.line}]}>{items.map(({label,value,action,expanded})=>{
  const body=<><Text style={[styles.number,{color:colors.ink}]}>{value?.toLocaleString()??'—'}</Text><Text style={{color:colors.muted,textAlign:'center'}}>{label}</Text></>;
  return action?<Pressable key={label} accessibilityRole="button" accessibilityState={{expanded}} onPress={action} style={[styles.stat,expanded&&{backgroundColor:colors.soft}]}>{body}</Pressable>:<View key={label} style={styles.stat}>{body}</View>;
 })}</View>;
 return <>
  {uid&&blocked.has(uid)&&!owner?<Text style={{color:colors.muted}}>This member’s activity is hidden.</Text>:<>
  {counts([{label:'Followers',value:followers,action:onConnections&&(()=>onConnections('followers'))},
    {label:'Following',value:following,action:onConnections&&(()=>onConnections('following'))},
    {label:'Likes',value:posts?.reduce((sum,post)=>sum+(post.likeCount??0),0)??likes,action:()=>select('Likes received'),expanded:tab==='Likes received'}])}
  {counts([{label:'Slangs',value:slangs?.length,action:()=>select('Slangs'),expanded:tab==='Slangs'},{label:'Codes',value:codes?.length,action:()=>select('Codes'),expanded:tab==='Codes'},{label:'Posts',value:posts?.length,action:()=>select('Posts'),expanded:tab==='Posts'}])}
  {about&&(about.bio||about.interests||about.favoriteCategories)&&<View>
   <Pressable accessibilityRole="button" accessibilityState={{expanded}} onPress={()=>setExpanded(v=>!v)}
    style={[styles.credits,{paddingHorizontal:0}]}>
    <Text style={{color:colors.ink,fontWeight:'800',flex:1}}>About</Text>
    {!!about.interests&&<Text numberOfLines={1} style={{color:colors.muted,flexShrink:1}}>{about.interests}</Text>}
    <Icon name={expanded?'chevron-up':'chevron-down'} size={16} color={colors.muted}/>
   </Pressable>
   {expanded&&<View style={{gap:6,paddingBottom:10}}>
    {!!about.bio&&<Text style={{color:colors.ink}}>{about.bio}</Text>}
    {!!about.interests&&<Text style={{color:colors.muted}}>Interests · {about.interests}</Text>}
    {!!about.favoriteCategories&&<Text style={{color:colors.muted}}>Favorite categories · {about.favoriteCategories}</Text>}
   </View>}
  </View>}
  {owner&&onWallet&&<Pressable accessibilityRole="button" onPress={onWallet} style={[styles.credits,{backgroundColor:colors.dark?'#403428':'#FFF2CF'}]}>
   <Icon name="wallet-outline" size={17} color={colors.dark?'#FFE3A2':C.goldDeep}/>
   <Text style={{color:colors.dark?'#FFE3A2':C.goldDeep,fontWeight:'800',flex:1}}>Credits</Text>
   <Text style={{color:colors.dark?'#FFE3A2':C.goldDeep,fontWeight:'800'}}>{credits?.toLocaleString()??'—'}</Text>
  </Pressable>}
  {!owner&&<View style={[styles.credits,{backgroundColor:colors.dark?'#403428':'#FFF2CF'}]}>
   <Icon name="wallet-outline" size={17} color={colors.dark?'#FFE3A2':C.goldDeep}/>
   <Text style={{color:colors.dark?'#FFE3A2':C.goldDeep,fontWeight:'800',flex:1}}>Credits</Text>
   <Text style={{color:colors.dark?'#FFE3A2':C.goldDeep}}>Private</Text>
  </View>}
  {owner&&uid&&<Pressable accessibilityRole="button" accessibilityState={{expanded:tab==='Liked'}} onPress={()=>select('Liked')}
   style={[styles.credits,{paddingHorizontal:0}]}>
   <Icon name="heart-outline" size={17} color={colors.accent}/>
   <Text style={{color:colors.ink,fontWeight:'800',flex:1}}>Liked posts</Text>
   <Icon name={tab==='Liked'?'chevron-up':'chevron-down'} size={16} color={colors.muted}/>
  </Pressable>}
  {tab&&<View style={{gap:8}}>
   <View style={[styles.row,{alignItems:'center',justifyContent:'space-between'}]}>
    <Text accessibilityRole="header" style={{color:colors.ink,fontSize:17,fontWeight:'800'}}>{tab==='Liked'?'Liked posts':tab}</Text>
    <ProfileIcon label={`Hide ${tab.toLowerCase()}`} name="chevron-up" colors={colors} onPress={()=>setTab(null)}/>
   </View>
   {!uid?<Text style={[styles.feedback,{color:colors.muted}]}>Sign in to see your community activity.</Text>
   :error?<ProfileAction label="Couldn’t load activity · Retry" onPress={()=>setRetry(v=>v+1)} colors={colors}/>
   :!rows?<View accessibilityLabel="Loading profile activity" style={{gap:8,paddingVertical:12}}>
     {[68,92,45].map(width=><View key={width} style={{width:`${width}%`,height:10,borderRadius:5,backgroundColor:colors.soft}}/>)}
    </View>
   :!rows.length?<Text style={[styles.feedback,{color:colors.muted}]}>{tab==='Liked'?'No liked posts yet.':tab==='Likes received'?'No likes received yet.':`No published ${tab.toLowerCase()} yet.`}</Text>
   :<>{rows.slice(0,visible).map(row=><View key={(row.dictionary?'word:':'post:')+row.id} style={[styles.entry,styles.divider,{borderColor:colors.line}]}>
     <Text style={{color:colors.ink,fontSize:16,fontWeight:'800'}}>{row.term}</Text>
     <Text style={{color:colors.muted,lineHeight:21}}>{row.meaning}</Text>
     {!!row.example&&<Text style={{color:colors.muted,fontStyle:'italic'}}>{row.example}</Text>}
     {!!row.category&&<Text style={{color:colors.muted,fontSize:12}}>{row.category}</Text>}
     {row.dictionary?<Text style={{color:colors.muted,fontSize:12}}>Published in the codebook</Text>:<View style={[styles.row,{alignItems:'center',flexWrap:'wrap',gap:10}]}>
      <Text style={{color:colors.muted}}>{row.likeCount??0} likes</Text>
      <Pressable accessibilityRole="button" onPress={()=>setThread({row,report:false})} style={{paddingVertical:12}}>
       <Text style={{color:colors.accent}}>{row.commentCount??0} comments</Text>
      </Pressable>
      {!!viewer?.emailVerified&&viewer.uid!==row.uid&&<ProfileIcon label="Report post" name="flag-outline" colors={colors} onPress={()=>setThread({row,report:true})}/>}
     </View>}
    </View>)}{rows.length>visible&&<ProfileAction label="Show more" onPress={()=>setVisible(v=>v+12)} colors={colors}/>}</>}
  </View>}
  </>}
  {thread&&<Modal visible onRequestClose={()=>setThread(null)}>
   <SafeAreaView style={{flex:1,backgroundColor:C.bg}}><KeyboardDock>
    <View style={{flex:1}}>
     <View style={[styles.row,{alignItems:'center',gap:8}]}>
      <ProfileIcon label="Close discussion" name="arrow-back" colors={{...colors,ink:C.ink}} onPress={()=>setThread(null)}/>
      <Text style={{color:C.ink,fontWeight:'800'}}>{thread.report?'Report post':'Comments'}</Text>
     </View>
     <PostThread key={thread.row.id} row={thread.row} report={thread.report} uid={viewer?.emailVerified?viewer.uid:undefined} onDone={()=>setThread(null)}/>
    </View>
   </KeyboardDock></SafeAreaView>
  </Modal>}
 </>;
}

const styles=StyleSheet.create({
 row:{flexDirection:'row'},divider:{borderBottomWidth:StyleSheet.hairlineWidth},
 stat:{flex:1,minWidth:0,minHeight:48,alignItems:'center',justifyContent:'center',paddingVertical:8,paddingHorizontal:2},
 number:{fontSize:21,fontWeight:'900'},entry:{gap:5,paddingVertical:13},feedback:{paddingVertical:14},
 icon:{width:44,height:44,alignItems:'center',justifyContent:'center'},
 action:{flexGrow:1,minHeight:44,justifyContent:'center',paddingHorizontal:10,paddingVertical:8,borderRadius:12,borderWidth:1},
 credits:{flexDirection:'row',minHeight:42,gap:8,alignItems:'center',paddingHorizontal:12,borderRadius:10},
});
