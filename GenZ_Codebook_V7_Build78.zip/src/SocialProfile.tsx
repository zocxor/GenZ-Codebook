import AsyncStorage from '@react-native-async-storage/async-storage';
import {createProfileTheme} from './profileTheme';
import React,{useEffect,useState,useSyncExternalStore} from 'react';
import {Alert,Modal,Pressable,StyleSheet,Text,View} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {Button as MaterialButton, IconButton as MaterialIconButton, MD3LightTheme} from 'react-native-paper';
import {collection,getDocs,onSnapshot,query,where} from 'firebase/firestore';
import {cloudDbLive} from './firebase/app';
import {ms,savedPosts,type FeatureRow} from './communityFeatures';
import type {PublicAbout} from './publicProfile';
import {SafeAreaView} from 'react-native-safe-area-context';
import {KeyboardDock} from './KeyboardDock';
import {PostThread} from './CommunityPostsPanel';
import {useBlocked} from './safety';
import {useAccountUser} from './services';
import {C,Icon} from './ui';

type Tab='Overview'|'Posts'|'Slangs'|'Codes'|'Likes received'|'Liked';
type ProfileEntry=FeatureRow&{dictionary?:boolean};
type Count={label:string;value?:number;action?:()=>void;expanded?:boolean};

const profileThemes=new Map<string,ReturnType<typeof createProfileTheme>>();
export function useProfileColors(){
 const user=useAccountUser();
 const key=user?'genz.profile.theme.user.'+user.uid:'genz.profile.theme.guest';
 let theme=profileThemes.get(key);
 if(!theme){theme=createProfileTheme(AsyncStorage,key);profileThemes.set(key,theme);}
 const activeTheme=theme;
 const dark=useSyncExternalStore(activeTheme.subscribe,activeTheme.snapshot,activeTheme.snapshot);
 const ready=useSyncExternalStore(activeTheme.subscribe,activeTheme.ready,activeTheme.ready);
 useEffect(()=>{void activeTheme.load();},[activeTheme]);
 return {dark,ready,toggle:()=>{void activeTheme.toggle().catch(()=>Alert.alert('Profile appearance','Could not save the selection on this device.'));},bg:dark?C.navy:'#EEE6FF',ink:dark?C.bg:'#0D1736',muted:dark?'#BCCAE5':'#33416B',
  line:dark?'#354769':'#D2D6EF',accent:dark?'#A9BFFF':'#4F46E5',soft:dark?'#1C2E55':'rgba(255,255,255,.76)'};
}
export type ProfileColors=ReturnType<typeof useProfileColors>;

export function ProfileCardSurface({dark,children}:{dark:boolean;children:React.ReactNode}){
 const content={gap:10,padding:14};
 if(dark)return <View style={[content,{borderRadius:16,backgroundColor:C.navy}]}>{children}</View>;
 return <LinearGradient colors={['#DCE7FF','#EEE6FF','#DDF5FF']} start={{x:0,y:0}} end={{x:1,y:1}}
   style={[content,{borderRadius:26,overflow:'hidden',borderWidth:1.5,borderColor:'rgba(255,255,255,.95)'}]}>
   <View pointerEvents="none" accessible={false} style={StyleSheet.absoluteFill}>
    <View style={{position:'absolute',width:170,height:170,borderRadius:85,top:-60,right:-40,backgroundColor:'rgba(99,102,241,.22)'}}/>
    <View style={{position:'absolute',width:130,height:130,borderRadius:65,bottom:-50,left:-30,backgroundColor:'rgba(34,211,238,.24)'}}/>
    <View style={{position:'absolute',width:80,height:80,borderRadius:40,top:30,left:'55%',backgroundColor:'rgba(236,72,153,.14)'}}/>
   </View>
   {children}
 </LinearGradient>;
}

const lightProfileTheme={
 ...MD3LightTheme, roundness:4,
 colors:{...MD3LightTheme.colors,primary:'#4F46E5',onPrimary:'#FFFFFF',onSurface:'#0D1736'},
};

export function ProfileIcon({label,name,onPress,colors}:{label:string;name:React.ComponentProps<typeof Icon>['name'];onPress:()=>void;colors:ProfileColors}){
 if(!colors.dark)return <MaterialIconButton theme={lightProfileTheme} size={20} style={{margin:0,width:44,height:44}}
  icon={({size,color})=><Icon name={name} size={size} color={color}/>} iconColor={colors.ink} containerColor={colors.soft}
  accessibilityLabel={label} onPress={onPress}/>;
 return <Pressable style={styles.icon} accessibilityRole="button" accessibilityLabel={label} onPress={onPress}><Icon name={name} size={20} color={colors.ink}/></Pressable>;
}

export function ProfileAction({label,onPress,colors,primary,disabled}:{label:string;onPress:()=>void;colors:ProfileColors;primary?:boolean;disabled?:boolean}){
 if(!colors.dark)return <MaterialButton theme={lightProfileTheme} mode={primary?'contained':'outlined'} onPress={onPress} disabled={disabled}
  buttonColor={primary?colors.accent:colors.soft} textColor={primary?'#FFFFFF':colors.ink}
  contentStyle={{minHeight:44}} style={{flexGrow:1,borderColor:colors.line}}>{label}</MaterialButton>;
 return <Pressable accessibilityRole="button" disabled={disabled} onPress={onPress}
  style={({pressed})=>[styles.action,{backgroundColor:primary?C.blue:colors.soft,borderColor:primary?C.blue:colors.line,opacity:disabled?.65:pressed?.8:1}]}>
  <Text style={{color:primary?'#fff':colors.ink,fontWeight:'800',textAlign:'center'}}>{label}</Text>
 </Pressable>;
}

export function SocialProfile({uid,owner=false,colors,followers,following,likes,onConnections,credits,onWallet,about}:{uid?:string;owner?:boolean;colors:ProfileColors;followers?:number;following?:number;likes?:number;onConnections?:(list:'followers'|'following')=>void;credits?:number|null;onWallet?:()=>void;about?:PublicAbout}){
 const viewer=useAccountUser();
 const blocked=useBlocked();
 const [thread,setThread]=useState<{row:FeatureRow;report:boolean}|null>(null);
 const [expanded,setExpanded]=useState(false);
 const [tab,setTab]=useState<Tab>('Overview');
 const [posts,setPosts]=useState<FeatureRow[]|null>(null);
 const [dictionary,setDictionary]=useState<ProfileEntry[]|null>(null);
 const [dictionaryError,setDictionaryError]=useState(false);
 const [liked,setLiked]=useState<FeatureRow[]|null>(null);
 const [postError,setPostError]=useState(false),[likedError,setLikedError]=useState(false);
 const [retry,setRetry]=useState(0),[visible,setVisible]=useState(12);
 useEffect(()=>{
  if(!uid)return;
  return onSnapshot(query(collection(cloudDbLive(),'communityPosts'),where('uid','==',uid),where('status','==','approved'),where('hidden','==',false)),
   snapshot=>{setPostError(false);setPosts(snapshot.docs.map(d=>({...d.data(),id:d.id}) as FeatureRow).sort((a,b)=>ms(b.createdAt)-ms(a.createdAt)));},
   ()=>setPostError(true));
 },[uid,retry]);
 useEffect(()=>{
  if(!uid)return;
  return onSnapshot(query(collection(cloudDbLive(),'communityWords'),where('uid','==',uid),where('status','==','live')),
   snapshot=>{
    setDictionaryError(false);
    setDictionary(snapshot.docs.map(d=>({...d.data(),id:d.id,dictionary:true}) as ProfileEntry));
   },()=>setDictionaryError(true));
 },[uid,retry]);
 useEffect(()=>{
  if(!owner||!uid||tab!=='Liked')return;
  let active=true;
  setLiked(null);setLikedError(false);
  void getDocs(query(collection(cloudDbLive(),'communityPostLikes'),where('uid','==',uid)))
   .then(snapshot=>savedPosts(snapshot.docs.map(d=>String(d.get('postId')))))
   .then(rows=>{if(active)setLiked(rows.sort((a,b)=>ms(b.createdAt)-ms(a.createdAt)));},()=>{if(active)setLikedError(true);});
  return ()=>{active=false;};
 },[owner,uid,tab,retry]);
 const slangs=posts?.filter(row=>row.category==='Slang');
 const codes=posts&&dictionary?[...posts.filter(row=>row.category==='Code Word'),...dictionary].sort((a,b)=>ms(b.createdAt)-ms(a.createdAt)):null;
 const received=tab==='Likes received'?posts?.filter(row=>(row.likeCount??0)>0)
  .sort((a,b)=>(b.likeCount??0)-(a.likeCount??0)):undefined;
 const overview=posts&&dictionary?[...posts,...dictionary].sort((a,b)=>ms(b.createdAt)-ms(a.createdAt)):null;
 const rows:ProfileEntry[]|undefined=(tab==='Overview'?overview:tab==='Likes received'?received:tab==='Liked'?liked:tab==='Slangs'?slangs:tab==='Codes'?codes:posts)?.filter(row=>!blocked.has(row.uid));
 const error=tab==='Liked'?likedError:postError||((tab==='Codes'||tab==='Overview')&&dictionaryError);
 const [hidden,setHidden]=useState<Partial<Record<Tab,boolean>>>({});
 const toggleable=['Overview','Slangs','Codes','Posts'].includes(tab);
 const select=(next:Tab)=>{setVisible(12);setTab(next);};
 const counts=(items:Count[])=><View style={[styles.row,styles.divider,{borderColor:colors.line}]}>{items.map(({label,value,action,expanded})=>{
  const body=<><Text style={[styles.number,{color:colors.ink}]}>{value?.toLocaleString()??'—'}</Text><Text style={{color:colors.muted,textAlign:'center'}}>{label}</Text></>;
  return action?<Pressable key={label} accessibilityRole="button" accessibilityState={{expanded}} onPress={action} style={[styles.stat,expanded&&{backgroundColor:colors.soft}]}>{body}</Pressable>:<View key={label} style={styles.stat}>{body}</View>;
 })}</View>;
 return <>
  {uid&&blocked.has(uid)&&!owner?<Text style={{color:colors.muted}}>This member’s activity is hidden.</Text>:<>
  {counts([{label:'Followers',value:followers,action:onConnections&&(()=>onConnections('followers'))},
    {label:'Following',value:following,action:onConnections&&(()=>onConnections('following'))},
    {label:'Likes',value:posts?.reduce((sum,post)=>sum+(post.likeCount??0),0)??likes,action:()=>select('Likes received'),expanded:tab==='Likes received'}])}
  <View style={styles.activityCards} accessibilityLabel="Published Slangs, Codes and Posts">
   {/* Light profile keeps the approved deep tiles. Dark profile (Build 64): brighter versions of the same three
       colours so they stand out on navy; white text stays ≥ 5:1 at the card centre. */}
   {([ {label:'Slangs',value:slangs?.length,icon:'chatbubble-ellipses' as const,from:'#46118D',to:'#26084E',tint:'#DB8BFF',darkFrom:'#6E45C9',darkTo:'#3B1F7A'},
       {label:'Codes',value:codes?.length,icon:'code-slash' as const,from:'#06558D',to:'#062553',tint:'#8AB9FF',darkFrom:'#2F67C2',darkTo:'#16386F'},
       {label:'Posts',value:posts?.length,icon:'document-text' as const,from:'#8F1D2C',to:'#420B17',tint:'#FFB5B9',darkFrom:'#B23A48',darkTo:'#6B1A26'}] as const).map(item=><Pressable key={item.label} accessibilityRole="button"
     accessibilityLabel={`${item.value?.toLocaleString()??'Loading'} ${item.label}; view ${item.label.toLowerCase()}`}
     accessibilityState={{selected:tab===item.label}} onPress={()=>select(item.label)}
     style={({pressed})=>[styles.activityCardWrap,{opacity:pressed?.82:1}]}>
      <LinearGradient colors={colors.dark?[item.darkFrom,item.darkTo]:[item.from,item.to]} start={{x:0,y:0}} end={{x:1,y:1}}
       style={[styles.activityCard,colors.dark&&styles.activityCardDark]}>
       {colors.dark&&<LinearGradient pointerEvents="none" colors={['rgba(255,255,255,0.12)','rgba(255,255,255,0)']} locations={[0,0.6]} style={styles.activityShine}/>}
       {colors.dark?<View style={styles.activityIconChip}><Icon name={item.icon} size={18} color="#FFFFFF"/></View>:<Icon name={item.icon} size={22} color={item.tint}/>}
       <Text style={styles.activityCardNumber}>{item.value?.toLocaleString()??'—'}</Text>
       <Text style={styles.activityCardLabel}>{item.label}</Text>
      </LinearGradient>
    </Pressable>)}
  </View>
  {about&&(about.bio||about.interests||about.favoriteCategories)&&<View>
   <Pressable accessibilityRole="button" accessibilityState={{expanded}} onPress={()=>setExpanded(v=>!v)}
    style={[styles.credits,{paddingHorizontal:0}]}>
    <Text style={{color:colors.ink,fontWeight:'800',flex:1}}>About</Text>
    {!!about.interests&&<Text numberOfLines={1} style={{color:colors.muted,flexShrink:1}}>{about.interests}</Text>}
    <Icon name={expanded?'chevron-up':'chevron-down'} size={16} color={colors.muted}/>
   </Pressable>
   {expanded&&<View style={{gap:6,paddingBottom:10}}>
    {!!about.bio&&<Text style={{color:colors.ink}}>{about.bio}</Text>}
    {!!about.interests&&<Text style={{color:colors.muted}}>Interests · {about.interests}</Text>}
    {!!about.favoriteCategories&&<Text style={{color:colors.muted}}>Favorite categories · {about.favoriteCategories}</Text>}
   </View>}
  </View>}
  {owner&&onWallet&&<Pressable accessibilityRole="button" onPress={onWallet} style={[styles.credits,{backgroundColor:colors.dark?'#403428':'#FFF2CF'}]}>
   <Icon name="wallet-outline" size={17} color={colors.dark?'#FFE3A2':C.goldDeep}/>
   <Text style={{color:colors.dark?'#FFE3A2':C.goldDeep,fontWeight:'800',flex:1}}>Credits</Text>
   <Text style={{color:colors.dark?'#FFE3A2':C.goldDeep,fontWeight:'800'}}>{credits?.toLocaleString()??'—'}</Text>
  </Pressable>}
  {!owner&&<View style={[styles.credits,{backgroundColor:colors.dark?'#403428':'#FFF2CF'}]}>
   <Icon name="wallet-outline" size={17} color={colors.dark?'#FFE3A2':C.goldDeep}/>
   <Text style={{color:colors.dark?'#FFE3A2':C.goldDeep,fontWeight:'800',flex:1}}>Credits</Text>
   <Text style={{color:colors.dark?'#FFE3A2':C.goldDeep}}>Private</Text>
  </View>}
  {owner&&uid&&<Pressable accessibilityRole="button" accessibilityState={{expanded:tab==='Liked'}} onPress={()=>select(tab==='Liked'?'Overview':'Liked')}
   style={[styles.credits,{paddingHorizontal:0}]}>
   <Icon name="heart-outline" size={17} color={colors.accent}/>
   <Text style={{color:colors.ink,fontWeight:'800',flex:1}}>Liked posts</Text>
   <Icon name={tab==='Liked'?'chevron-up':'chevron-down'} size={16} color={colors.muted}/>
  </Pressable>}
  <View accessibilityRole="tablist" style={[styles.tabs,{borderColor:colors.line,backgroundColor:colors.soft}]}>
   {(['Overview','Slangs','Codes','Posts'] as const).map(item=><Pressable key={item} accessibilityRole="tab" accessibilityState={{selected:tab===item}} onPress={()=>select(item)}
    style={[styles.tab,{backgroundColor:tab===item?C.blue:'transparent',borderColor:tab===item?C.blue:'transparent'}]}>
    <Text numberOfLines={1} style={{fontFamily:'Calibri',color:tab===item?'#FFFFFF':colors.muted,fontWeight:'400',fontSize:13,textAlign:'center'}}>{item}</Text>
   </Pressable>)}
  </View>
  {tab&&<View style={{gap:8}}>
   <View style={[styles.row,{alignItems:'center',justifyContent:'space-between'}]}>
    <Text accessibilityRole="header" style={{fontFamily:'Calibri',color:colors.ink,fontSize:15,fontWeight:'400'}}>{tab==='Liked'?'Liked posts':tab==='Overview'?'Recent activity':tab}</Text>
    {toggleable&&<Pressable accessibilityRole="button" accessibilityState={{expanded:!hidden[tab]}} accessibilityLabel={(hidden[tab]?'View ':'Hide ')+(tab==='Overview'?'recent activity':tab)} onPress={()=>setHidden(previous=>({...previous,[tab]:!previous[tab]}))} style={{padding:10}}><Text style={{fontFamily:'Calibri',color:colors.accent,fontWeight:'400'}}>{hidden[tab]?'View':'Hide'}</Text></Pressable>}
    {(tab==='Liked'||tab==='Likes received')&&<ProfileIcon label="Back to overview" name="chevron-up" colors={colors} onPress={()=>setTab('Overview')}/>}
   </View>
   {toggleable&&hidden[tab]?null:!uid?<Text style={[styles.feedback,{color:colors.muted}]}>Sign in to see your community activity.</Text>
   :error?<ProfileAction label="Couldn’t load activity · Retry" onPress={()=>setRetry(v=>v+1)} colors={colors}/>
   :!rows?<View accessibilityLabel="Loading profile activity" style={{gap:8,paddingVertical:12}}>
     {[68,92,45].map(width=><View key={width} style={{width:`${width}%`,height:10,borderRadius:5,backgroundColor:colors.soft}}/>)}
    </View>
   :!rows.length?<Text style={[styles.feedback,{color:colors.muted}]}>{tab==='Liked'?'No liked posts yet.':tab==='Likes received'?'No likes received yet.':tab==='Overview'?'No published community activity yet.':`No published ${tab.toLowerCase()} yet.`}</Text>
   :<>{rows.slice(0,visible).map(row=><View key={(row.dictionary?'word:':'post:')+row.id} style={[styles.entry,styles.divider,{borderColor:colors.line}]}>
     <Text style={{fontFamily:'Calibri',color:colors.ink,fontSize:15,fontWeight:'400'}}>{row.term}</Text>
     <Text style={{fontFamily:'Calibri',color:colors.muted,lineHeight:21}}>{row.meaning}</Text>
     {!!row.example&&<Text style={{fontFamily:'Calibri',color:colors.muted,fontStyle:'italic'}}>{row.example}</Text>}
     {!!row.category&&<Text style={{fontFamily:'Calibri',color:colors.muted,fontSize:12}}>{row.category}</Text>}
     {row.dictionary?<Text style={{fontFamily:'Calibri',color:colors.muted,fontSize:12}}>Published in the codebook</Text>:<View style={[styles.row,{alignItems:'center',flexWrap:'wrap',gap:10}]}>
      <Text style={{fontFamily:'Calibri',color:colors.muted}}>{row.likeCount??0} likes</Text>
      <Pressable accessibilityRole="button" onPress={()=>setThread({row,report:false})} style={{paddingVertical:12}}>
       <Text style={{fontFamily:'Calibri',color:colors.accent}}>{row.commentCount??0} comments</Text>
      </Pressable>
      {!!viewer?.emailVerified&&viewer.uid!==row.uid&&<ProfileIcon label="Report post" name="flag-outline" colors={colors} onPress={()=>setThread({row,report:true})}/>}
     </View>}
    </View>)}{rows.length>visible&&<ProfileAction label="Show more" onPress={()=>setVisible(v=>v+12)} colors={colors}/>}</>}
  </View>}
  </>}
  {thread&&<Modal visible onRequestClose={()=>setThread(null)}>
   <SafeAreaView style={{flex:1,backgroundColor:C.bg}}><KeyboardDock>
    <View style={{flex:1}}>
     <View style={[styles.row,{alignItems:'center',gap:8}]}>
      <ProfileIcon label="Close discussion" name="arrow-back" colors={{...colors,ink:C.ink}} onPress={()=>setThread(null)}/>
      <Text style={{color:C.ink,fontWeight:'800'}}>{thread.report?'Report post':'Comments'}</Text>
     </View>
     <PostThread key={thread.row.id} row={thread.row} report={thread.report} uid={viewer?.emailVerified?viewer.uid:undefined} onDone={()=>setThread(null)}/>
    </View>
   </KeyboardDock></SafeAreaView>
  </Modal>}
 </>;
}

const styles=StyleSheet.create({
 row:{flexDirection:'row'},tabs:{flexDirection:'row',alignItems:'center',gap:3,padding:4,borderWidth:1,borderRadius:14},tab:{flex:1,minWidth:0,minHeight:38,alignItems:'center',justifyContent:'center',paddingHorizontal:3,paddingVertical:7,borderWidth:1,borderRadius:10},divider:{borderBottomWidth:StyleSheet.hairlineWidth},
 stat:{flex:1,minWidth:0,minHeight:48,alignItems:'center',justifyContent:'center',paddingVertical:8,paddingHorizontal:2},
 activityCards:{flexDirection:'row',gap:10,marginTop:10,marginBottom:12},
 activityCardWrap:{flex:1,minWidth:0},
 activityCard:{height:94,borderRadius:12,borderWidth:1,borderColor:'rgba(255,255,255,0.10)',alignItems:'center',justifyContent:'center',gap:2,paddingHorizontal:4},
 activityCardDark:{borderColor:'rgba(255,255,255,0.18)',overflow:'hidden',shadowColor:'#000',shadowOffset:{width:0,height:4},shadowOpacity:.28,shadowRadius:8,elevation:4},
 activityShine:{position:'absolute',top:0,left:0,right:0,bottom:0},
 activityIconChip:{width:30,height:30,borderRadius:15,alignItems:'center',justifyContent:'center',backgroundColor:'rgba(255,255,255,0.13)',borderWidth:1,borderColor:'rgba(255,255,255,0.20)'},
 activityCardNumber:{color:'#FFFFFF',fontSize:22,fontWeight:'900',fontVariant:['tabular-nums']},
 activityCardLabel:{color:'#FFFFFF',fontSize:13,fontWeight:'700'},
 number:{fontSize:21,fontWeight:'900'},entry:{gap:5,paddingVertical:13},feedback:{paddingVertical:14},
 icon:{width:44,height:44,alignItems:'center',justifyContent:'center'},
 action:{flexGrow:1,minHeight:44,justifyContent:'center',paddingHorizontal:10,paddingVertical:8,borderRadius:12,borderWidth:1},
 credits:{flexDirection:'row',minHeight:42,gap:8,alignItems:'center',paddingHorizontal:12,borderRadius:10},
});
