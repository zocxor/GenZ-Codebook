import React, {useMemo, useState} from 'react';
import {collection, getDocs, limit, orderBy, query, where} from 'firebase/firestore/lite';
import {db, errorMessage} from '../firebase';
import {useSession} from '../App';
import {can} from '../rbac';
import {Card, ConfirmButton, Field, Notice, Pill, Skeleton, Stat, Stats, useLoad, when} from '../ui';
import {runFeature} from './CommunityWorkflow';

type Report = {id: string; reporter: string; reportedUid: string; cid: string; mid: string | null; type: 'message' | 'user'; convType: 'personal' | 'group'; reason: string; note: string; snapshot: {text: string; context?: {uid: string; text: string}[]} | null; createdAt: {toMillis(): number}};
type Totals = {personal: number; groups: number; groupsClosed: number; activeGroups: number; messages: number; restricted: number};
const short = (u: string) => (u.length > 10 ? u.slice(0, 8) + '…' : u);

/** Messaging management. Moderators see only what was reported (the message and up to two lines of
 *  context). Private conversations are not readable here, and every action is permission-checked on
 *  the server and written to the audit log. */
export default function Messaging() {
  const s = useSession();
  const allowed = can(s.role, 'messaging.moderate');
  const [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null);
  const [busy, setBusy] = useState(false);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const totals = useLoad<Totals>(async () => (await runFeature({action: 'inbox-admin-stats'})) as unknown as Totals, [allowed]);
  const reports = useLoad<Report[]>(async () => {
    if (!allowed) return [];
    const snap = await getDocs(query(collection(db, 'messageReports'), where('status', '==', 'open'), orderBy('createdAt', 'desc'), limit(50)));
    return snap.docs.map(d => ({...d.data(), id: d.id}) as Report);
  }, [allowed]);
  const reported = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of reports.data ?? []) m.set(r.reportedUid, (m.get(r.reportedUid) ?? 0) + 1);
    return [...m].sort((a, b) => b[1] - a[1]);
  }, [reports.data]);
  const [restrictUid, setRestrictUid] = useState(''), [days, setDays] = useState('7'), [reason, setReason] = useState('');
  const [groupId, setGroupId] = useState('');

  const act = async (label: string, input: Record<string, unknown>, after?: () => void) => {
    setBusy(true); setMsg(null);
    try {await runFeature(input); setMsg({kind: 'ok', text: label}); after?.(); reports.reload?.(); totals.reload?.();}
    catch (e) {setMsg({kind: 'error', text: errorMessage(e)});}
    finally {setBusy(false);}
  };
  if (!allowed) return <Notice kind="error">Your role can’t manage messaging.</Notice>;

  return <div className="stack">
    {msg && <Notice kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Notice>}
    <Stats>
      <Stat label="Personal conversations" num={totals.data?.personal ?? null} icon={<span>✉</span>} tint="blue" />
      <Stat label="Active groups" num={totals.data?.activeGroups ?? null} hint={totals.data ? `${totals.data.groupsClosed} closed or deleted` : undefined} icon={<span>👥</span>} tint="purple" />
      <Stat label="Total messages" num={totals.data?.messages ?? null} icon={<span>💬</span>} tint="green" />
      <Stat label="Reported messages" num={reports.data ? reports.data.filter(r => r.type === 'message').length : null} hint="open" icon={<span>⚑</span>} tint="amber" />
      <Stat label="Pending user reports" num={reports.data ? reports.data.filter(r => r.type === 'user').length : null} hint="open" icon={<span>⚑</span>} tint="pink" />
      <Stat label="Messaging restrictions" num={totals.data?.restricted ?? null} hint="active records" icon={<span>⛔</span>} tint="red" />
    </Stats>
    {totals.error != null && <Notice kind="error">Couldn’t load totals: {errorMessage(totals.error)}</Notice>}

    <Card title="Reported messages and people" subtitle="Open reports, newest first. You only see the reported message and up to two lines before it.">
      {reports.loading ? <Skeleton rows={2} /> : reports.error != null ? <Notice kind="error">{errorMessage(reports.error)}</Notice>
        : !(reports.data ?? []).length ? <p className="muted">No open reports. Nice and quiet.</p>
        : <div className="table-wrap"><table><thead><tr><th>When</th><th>Report</th><th>Reported</th><th>Reporter</th><th>Resolution</th></tr></thead><tbody>
          {(reports.data ?? []).map(r => <tr key={r.id}>
            <td>{when(r.createdAt)}</td>
            <td><Pill tone={r.type === 'message' ? 'warn' : 'info'}>{r.type === 'message' ? 'Message' : 'Person'}</Pill> <Pill>{r.convType === 'group' ? 'Group' : 'Personal'}</Pill><br /><strong>{r.reason}</strong>{r.note && <><br /><small className="muted">“{r.note}”</small></>}
              {r.snapshot && <div className="note" style={{marginTop: 6}}>{(r.snapshot.context ?? []).map((c, i) => <div key={i} className="muted">{short(c.uid)}: {c.text}</div>)}<div><strong>{short(r.reportedUid)}:</strong> {r.snapshot.text || '(removed)'}</div></div>}</td>
            <td><code>{short(r.reportedUid)}</code></td><td><code>{short(r.reporter)}</code></td>
            <td style={{minWidth: 220}}>
              <input aria-label="Resolution note" placeholder="Note (optional)" value={notes[r.id] ?? ''} onChange={e => setNotes(n => ({...n, [r.id]: e.target.value}))} maxLength={300} />
              <div className="row wrap" style={{marginTop: 6}}>
                {r.mid && <button className="btn danger" disabled={busy} onClick={() => void act('Message removed and report resolved.', {action: 'inbox-admin-resolve', id: r.id, status: 'resolved', removeMessage: true, note: notes[r.id] ?? ''})}>Remove message</button>}
                <button className="btn" disabled={busy} onClick={() => void act('Report resolved.', {action: 'inbox-admin-resolve', id: r.id, status: 'resolved', note: notes[r.id] ?? ''})}>Resolve</button>
                <button className="btn ghost" disabled={busy} onClick={() => void act('Report dismissed.', {action: 'inbox-admin-resolve', id: r.id, status: 'dismissed', note: notes[r.id] ?? ''})}>Dismiss</button>
                <button className="btn" disabled={busy} onClick={() => {setRestrictUid(r.reportedUid); setReason(r.reason);}}>Restrict person…</button>
                {r.convType === 'group' && <button className="btn" disabled={busy} onClick={() => setGroupId(r.cid)}>Group…</button>}
              </div>
            </td>
          </tr>)}
        </tbody></table></div>}
    </Card>

    {reported.length > 0 && <Card title="Reported people" subtitle="People with open reports against them.">
      <div className="row wrap">{reported.map(([u, n]) => <button key={u} className="btn" onClick={() => setRestrictUid(u)}><code>{short(u)}</code> · {n} report{n > 1 ? 's' : ''}</button>)}</div>
    </Card>}

    <Card title="Messaging restriction" subtitle="Stops a person from sending messages or creating groups. Enter 0 days to lift it. Recorded in the audit log.">
      <div className="form-grid">
        <Field label="User ID"><input value={restrictUid} onChange={e => setRestrictUid(e.target.value.trim())} placeholder="User ID" maxLength={128} /></Field>
        <Field label="Days" hint="0 lifts the restriction. Up to 365."><input inputMode="numeric" value={days} onChange={e => setDays(e.target.value.replace(/\D/g, '').slice(0, 3))} /></Field>
        <Field label="Reason"><input value={reason} onChange={e => setReason(e.target.value)} maxLength={200} placeholder="Why (kept in the audit log)" /></Field>
      </div>
      <div className="row"><button className="btn primary" disabled={busy || !restrictUid || days === ''} onClick={() => void act(Number(days) === 0 ? 'Restriction lifted.' : 'Messaging restricted.', {action: 'inbox-admin-restrict', uid: restrictUid, days: Number(days), reason})}>{Number(days) === 0 ? 'Lift restriction' : 'Restrict messaging'}</button></div>
    </Card>

    <Card title="Group moderation" subtitle="Closing a group makes it read-only for its members. Recorded in the audit log.">
      <div className="form-grid"><Field label="Group ID"><input value={groupId} onChange={e => setGroupId(e.target.value.trim())} placeholder="g_…" maxLength={300} /></Field></div>
      <div className="row"><ConfirmButton label="Close group" word="CLOSE" disabled={busy || !/^g_/.test(groupId)} onConfirm={() => void act('Group closed.', {action: 'inbox-admin-close-group', cid: groupId, reason: reason || 'Closed by moderation'}, () => setGroupId(''))} /></div>
    </Card>
    <p className="muted">Private conversations are never shown here. You only ever see content that a member reported. To switch messaging off for everyone, set <code>messagingEnabled</code> to <code>false</code> in the <code>config/app</code> document.</p>
  </div>;
}
