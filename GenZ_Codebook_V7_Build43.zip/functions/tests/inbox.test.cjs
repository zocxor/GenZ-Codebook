// Inbox backend tests (personal chats, requests, groups, reports, admin) on the in-memory Firestore.
// Run: npm run build && npm run test:memory
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {getFirestore,Timestamp}=require('firebase-admin/firestore');
const {inboxAction,purgeInbox,INBOX_LIMITS}=require('../lib/inbox');
assert.ok(process.env.FIRESTORE_EMULATOR_HOST,'These tests use the in-memory Firestore preload.');
const db=getFirestore();
let clock=Date.UTC(2026,10,16,12);
const as=uid=>({uid,token:{email_verified:true}});
const run=(uid,action,data={})=>inboxAction(db,{action,...data},as(uid),clock);
const fails=(p,code)=>assert.rejects(p,e=>code?e.code===code:true);
const advance=ms=>{clock+=ms;};
async function user(uid,name,opts={}){
  await db.doc('users/'+uid).set({status:'active'});
  await db.doc('publicProfiles/'+uid).set({name,avatar:1});
  await db.doc('referrals/GZ'+uid.slice(-6).toUpperCase().padStart(6,'X')).set({uid});
  if(opts.who)await run(uid,'inbox-prefs',{whoCanMessage:opts.who});
}
const conv=async cid=>(await db.doc('conversations/'+cid).get()).data();
const msgs=async cid=>(await db.collection(`conversations/${cid}/messages`).get()).docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>a.seq-b.seq);
const unread=(c,uid)=>Math.max(0,(c.seq??0)-(c.reads?.[uid]?.seq??0));
const pid=(a,b)=>'p_'+[a,b].sort().join('_');

test('A finds B by name and by user code; blockers and self stay hidden',async()=>{
  await user('alice1','Alice');await user('bobby22','Bobby');await user('carol33','Carol');
  const byName=await run('alice1','inbox-find',{q:'Bob'});
  assert.deepEqual(byName.users.map(u=>u.name),['Bobby']);
  assert.equal(byName.users[0].canMessage,'request');                 // default: message request first
  const byCode=await run('alice1','inbox-find',{q:'GZOBBY22'});
  assert.equal(byCode.users[0].uid,'bobby22');
  assert.equal((await run('alice1','inbox-find',{q:'Alic'})).users.length,0,'never finds yourself');
  await run('carol33','inbox-block',{uid:'alice1'});
  assert.equal((await run('alice1','inbox-find',{q:'Carol'})).users.length,0,'a person who blocked you is not shown');
  await fails(run('alice1','inbox-find',{q:'a'}),'invalid-argument');
});

test('message request: one intro message, accept, chat both ways, unread and read receipts',async()=>{
  const cid=pid('alice1','bobby22');
  const first=await run('alice1','inbox-send',{to:'bobby22',text:'hey, nice codes!'});
  assert.equal(first.state,'request');assert.equal(first.cid,cid);
  await fails(run('alice1','inbox-send',{cid,text:'are you there?'}),'permission-denied');   // cannot bypass the request
  let c=await conv(cid);
  assert.equal(c.state,'request');assert.equal(c.requester,'alice1');assert.equal(unread(c,'bobby22'),1);assert.equal(unread(c,'alice1'),0);
  await fails(run('carol33','inbox-respond',{cid,accept:true}),'failed-precondition');       // only the receiver answers
  await fails(run('alice1','inbox-respond',{cid,accept:true}),'failed-precondition');
  await run('bobby22','inbox-respond',{cid,accept:true});
  await run('alice1','inbox-send',{cid,text:'are you there?'});
  await run('bobby22','inbox-send',{cid,text:'yes! what does HOD mean?'});
  c=await conv(cid);
  assert.equal(c.state,'active');assert.equal(c.seq,3);
  assert.equal(unread(c,'alice1'),1,'Alice has Bobby’s reply unread');
  assert.equal(unread(c,'bobby22'),0,'Bobby’s own reply counts as read for him');
  await run('alice1','inbox-read',{cid});
  c=await conv(cid);
  assert.equal(unread(c,'alice1'),0);
  assert.ok(c.reads.alice1.seq>=c.reads.bobby22.seq,'read receipt visible to the other person');
  assert.deepEqual((await msgs(cid)).map(m=>m.seq),[1,2,3],'messages stay ordered');
  await fails(run('carol33','inbox-send',{cid,text:'let me in'}),'permission-denied');
});

test('reject: sender cannot retry for 7 days; the rejecter may still write first',async()=>{
  await user('dan4444','Dan');await user('eve5555','Eve');
  const cid=pid('dan4444','eve5555');
  await run('dan4444','inbox-send',{to:'eve5555',text:'hello there'});
  await run('eve5555','inbox-respond',{cid,accept:false});
  await fails(run('dan4444','inbox-send',{cid,text:'please reply'}),'permission-denied');
  advance(INBOX_LIMITS.retryAfterReject+1000);
  assert.equal((await run('dan4444','inbox-send',{cid,text:'one more try'})).state,'request');
  await run('eve5555','inbox-respond',{cid,accept:false});
  assert.equal((await run('eve5555','inbox-send',{cid,text:'ok fine, hi'})).state,'active','a rejecter who writes first opens the chat');
});

test('privacy: "nobody" refuses, "everyone" skips the request',async()=>{
  await user('fay6666','Fay',{who:'nobody'});await user('gus7777','Gus',{who:'everyone'});await user('hal8888','Hal');
  await fails(run('hal8888','inbox-send',{to:'fay6666',text:'hi'}),'permission-denied');
  assert.equal((await run('hal8888','inbox-send',{to:'gus7777',text:'hi gus'})).state,'active');
  assert.equal((await run('hal8888','inbox-find',{q:'Fay'})).users[0].canMessage,'nobody');
});

test('blocking works in both directions and unblocking restores messaging',async()=>{
  await user('ida9999','Ida',{who:'everyone'});await user('jon1010','Jon',{who:'everyone'});
  await run('ida9999','inbox-send',{to:'jon1010',text:'hi jon'});
  await run('jon1010','inbox-block',{uid:'ida9999'});
  await fails(run('ida9999','inbox-send',{to:'jon1010',text:'still there?'}),'permission-denied');
  await fails(run('jon1010','inbox-send',{to:'ida9999',text:'oops'}),'permission-denied');
  await run('jon1010','inbox-unblock',{uid:'ida9999'});
  await run('ida9999','inbox-send',{to:'jon1010',text:'welcome back'});
  await fails(run('ida9999','inbox-block',{uid:'ida9999'}),'invalid-argument');
});

test('content screening and spam limits',async()=>{
  await user('kim1111','Kim',{who:'everyone'});await user('lee2222','Lee',{who:'everyone'});
  await fails(run('kim1111','inbox-send',{to:'lee2222',text:'visit https://example.com now'}),'invalid-argument');
  await fails(run('kim1111','inbox-send',{to:'lee2222',text:'call 0300 1234567 please'}),'invalid-argument');
  await fails(run('kim1111','inbox-send',{to:'lee2222',text:'   '}),'invalid-argument');
  await run('kim1111','inbox-send',{to:'lee2222',text:'same text'});await run('kim1111','inbox-send',{to:'lee2222',text:'same text'});await run('kim1111','inbox-send',{to:'lee2222',text:'same text'});
  await fails(run('kim1111','inbox-send',{to:'lee2222',text:'same text'}),'resource-exhausted');
  advance(61_000);
  for(let i=0;i<INBOX_LIMITS.perMinute;i++)await run('kim1111','inbox-send',{to:'lee2222',text:'line '+i});
  await fails(run('kim1111','inbox-send',{to:'lee2222',text:'one too many'}),'resource-exhausted');
  advance(61_000);
  await run('kim1111','inbox-send',{to:'lee2222',text:'fine again'});
});

test('new-chat limit: at most 10 new people per day',async()=>{
  await user('mia3333','Mia');
  for(let i=0;i<INBOX_LIMITS.newChatsPerDay+1;i++)await user('tgt'+String(i).padStart(4,'0'),'Target'+i,{who:'everyone'});
  for(let i=0;i<INBOX_LIMITS.newChatsPerDay;i++)await run('mia3333','inbox-send',{to:'tgt'+String(i).padStart(4,'0'),text:'hello '+i});
  await fails(run('mia3333','inbox-send',{to:'tgt'+String(INBOX_LIMITS.newChatsPerDay).padStart(4,'0'),text:'hello eleven'}),'resource-exhausted');
});

test('delete for me, delete conversation, pin, mute and archive are private to the person',async()=>{
  await user('ned4444','Ned',{who:'everyone'});await user('oli5555','Oli',{who:'everyone'});
  const cid=pid('ned4444','oli5555');
  await run('ned4444','inbox-send',{to:'oli5555',text:'first'});
  const [m]=await msgs(cid);
  await run('oli5555','inbox-delete-message',{cid,mid:m.id});
  assert.deepEqual((await db.doc(`users/oli5555/inbox/${cid}`).get()).get('hiddenMsgs'),[m.id]);
  assert.equal((await msgs(cid)).length,1,'the other person still has the message');
  await fails(run('oli5555','inbox-delete-message',{cid,mid:m.id,scope:'all'}),'permission-denied');   // personal chats: for me only
  await run('oli5555','inbox-settings',{cid,pinned:true,muted:true});
  assert.equal((await db.doc(`users/oli5555/inbox/${cid}`).get()).get('muted'),true);
  assert.equal((await db.doc(`users/ned4444/inbox/${cid}`).get()).exists,false);
  await run('oli5555','inbox-delete-conversation',{cid});
  assert.equal((await db.doc(`users/oli5555/inbox/${cid}`).get()).get('hidden'),true);
  await fails(run('carol33','inbox-settings',{cid,pinned:true}),'permission-denied');
});

test('groups: create, invitations, join, roles, removal, transfer, leave',async()=>{
  for(const [u,n] of [['own1111','Owner'],['adm2222','Admin'],['mod3333','Modie'],['mem4444','Member'],['out5555','Outsider'],['new6666','Newbie']])await user(u,n,{who:'everyone'});
  const created=await run('own1111','inbox-group-create',{name:'Slang Squad',description:'Share codes',privacy:'private',members:['adm2222','mod3333','mem4444']});
  const cid=created.cid;
  let c=await conv(cid);
  assert.deepEqual(c.participants,['own1111']);assert.equal(c.owner,'own1111');
  assert.equal((await db.doc(`groupInvites/${cid}_adm2222`).get()).exists,true);
  await fails(run('out5555','inbox-send',{cid,text:'let me in'}),'permission-denied');                // not a member yet
  for(const u of ['adm2222','mod3333','mem4444'])await run(u,'inbox-group-respond',{cid,accept:true});
  await run('new6666','inbox-group-invite',{cid,uids:['out5555']}).catch(e=>assert.equal(e.code,'permission-denied'));
  c=await conv(cid);assert.equal(c.participants.length,4);
  await run('mem4444','inbox-send',{cid,text:'hi all'});
  assert.ok((await msgs(cid)).some(m=>m.type==='system'&&/joined/.test(m.text)),'join events are recorded');
  // roles
  await fails(run('adm2222','inbox-group-role',{cid,uid:'mod3333',role:'moderator'}),'permission-denied');   // not an admin yet
  await run('own1111','inbox-group-role',{cid,uid:'adm2222',role:'admin'});
  await run('adm2222','inbox-group-role',{cid,uid:'mod3333',role:'moderator'});
  await fails(run('adm2222','inbox-group-role',{cid,uid:'adm2222',role:'member'}),'permission-denied');       // not your own role
  await fails(run('adm2222','inbox-group-role',{cid,uid:'own1111',role:'member'}),'permission-denied');       // owner is protected
  await fails(run('mem4444','inbox-group-update',{cid,name:'Hijacked'}),'permission-denied');
  await run('adm2222','inbox-group-update',{cid,name:'Slang Squad 2',description:'New rules'});
  assert.equal((await conv(cid)).name,'Slang Squad 2');
  // private group: members cannot invite, admins can
  await fails(run('mem4444','inbox-group-invite',{cid,uids:['out5555']}),'permission-denied');
  assert.equal((await run('adm2222','inbox-group-invite',{cid,uids:['out5555']})).sent,1);
  await run('out5555','inbox-group-respond',{cid,accept:false});
  // moderation of members
  await fails(run('mod3333','inbox-group-remove',{cid,uid:'adm2222'}),'permission-denied');
  await fails(run('adm2222','inbox-group-remove',{cid,uid:'own1111'}),'permission-denied');
  await fails(run('mem4444','inbox-group-remove',{cid,uid:'mod3333'}),'permission-denied');
  await run('mod3333','inbox-group-remove',{cid,uid:'mem4444'});
  assert.ok(!(await conv(cid)).participants.includes('mem4444'));
  await fails(run('mem4444','inbox-send',{cid,text:'am I still here?'}),'permission-denied');
  // delete a message and reactions
  await run('mod3333','inbox-send',{cid,text:'a bad message'});
  const bad=(await msgs(cid)).find(m=>m.text==='a bad message');
  await run('adm2222','inbox-delete-message',{cid,mid:bad.id,scope:'all'});
  assert.equal((await msgs(cid)).find(m=>m.id===bad.id).status,'removed');
  await run('adm2222','inbox-send',{cid,text:'react to me'});
  const target=(await msgs(cid)).find(m=>m.text==='react to me');
  await run('mod3333','inbox-react',{cid,mid:target.id,emoji:'👍'});
  assert.deepEqual((await msgs(cid)).find(m=>m.id===target.id).reactions,{'👍':['mod3333']});
  await run('mod3333','inbox-react',{cid,mid:target.id,emoji:'❤️'});
  assert.deepEqual((await msgs(cid)).find(m=>m.id===target.id).reactions,{'❤️':['mod3333']},'one reaction each');
  await run('mod3333','inbox-react',{cid,mid:target.id,emoji:'❤️'});
  assert.deepEqual((await msgs(cid)).find(m=>m.id===target.id).reactions,{},'tap again removes it');
  await fails(run('mod3333','inbox-react',{cid,mid:target.id,emoji:'💩'}),'invalid-argument');
  // owner rules
  await fails(run('own1111','inbox-group-leave',{cid}),'failed-precondition');
  await fails(run('adm2222','inbox-group-transfer',{cid,uid:'mod3333'}),'permission-denied');
  await run('own1111','inbox-group-transfer',{cid,uid:'adm2222'});
  assert.equal((await conv(cid)).owner,'adm2222');
  await run('own1111','inbox-group-leave',{cid});
  assert.ok(!(await conv(cid)).participants.includes('own1111'));
  await fails(run('mod3333','inbox-group-close',{cid}),'permission-denied');
  await run('adm2222','inbox-group-close',{cid});
  await fails(run('mod3333','inbox-send',{cid,text:'anyone?'}),'failed-precondition');
  assert.equal((await conv(cid)).status,'closed');
});

test('invite-only group: any member may invite; invitations can be declined; size limit holds',async()=>{
  await user('gow7777','GroupOwner',{who:'everyone'});await user('gm18888','GM1',{who:'everyone'});await user('gm29999','GM2',{who:'everyone'});
  const {cid}=await run('gow7777','inbox-group-create',{name:'Open Door',privacy:'invite',members:['gm18888']});
  await run('gm18888','inbox-group-respond',{cid,accept:true});
  assert.equal((await run('gm18888','inbox-group-invite',{cid,uids:['gm29999']})).sent,1);
  assert.equal((await run('gm18888','inbox-group-invite',{cid,uids:['gm29999']})).sent,0,'no duplicate invitation');
  await run('gm29999','inbox-group-respond',{cid,accept:false});
  assert.equal((await db.doc(`groupInvites/${cid}_gm29999`).get()).exists,false);
  await fails(run('gm29999','inbox-group-respond',{cid,accept:true}),'failed-precondition');
  await fails(run('gow7777','inbox-group-create',{name:'x',members:[]}),'invalid-argument');
  const many=Array.from({length:INBOX_LIMITS.groupMax},(_,i)=>'big'+String(i).padStart(5,'0'));
  await fails(run('gow7777','inbox-group-create',{name:'Too Big',members:many}),'invalid-argument');
});

test('reports: message snapshot with context, only participants, moderators resolve (audited)',async()=>{
  await user('rep1111','Reporter',{who:'everyone'});await user('bad2222','BadActor',{who:'everyone'});
  const cid=pid('rep1111','bad2222');
  await run('rep1111','inbox-send',{to:'bad2222',text:'hello'});
  await run('bad2222','inbox-send',{cid,text:'you are annoying'});
  const m=(await msgs(cid)).find(x=>x.uid==='bad2222');
  await fails(run('carol33','inbox-report',{cid,mid:m.id,reason:'Spam'}),'permission-denied');
  await fails(run('rep1111','inbox-report',{cid,mid:m.id,reason:'Because'}),'invalid-argument');
  const {id}=await run('rep1111','inbox-report',{cid,mid:m.id,reason:'Harassment or bullying',note:'keeps insulting me'});
  const r=(await db.doc('messageReports/'+id).get()).data();
  assert.equal(r.reportedUid,'bad2222');assert.equal(r.snapshot.text,'you are annoying');assert.equal(r.snapshot.context.length,1);assert.equal(r.status,'open');
  await db.doc('users/mod1').set({status:'active'});await db.doc('admins/mod1').set({active:true,role:'moderator'});
  await db.doc('users/ana1').set({status:'active'});await db.doc('admins/ana1').set({active:true,role:'analyst'});
  await fails(run('rep1111','inbox-admin-resolve',{id,status:'resolved'}),'permission-denied');
  await fails(run('ana1','inbox-admin-resolve',{id,status:'resolved'}),'permission-denied');
  await run('mod1','inbox-admin-resolve',{id,status:'resolved',removeMessage:true,note:'warned'});
  assert.equal((await db.doc('messageReports/'+id).get()).get('status'),'resolved');
  assert.equal((await msgs(cid)).find(x=>x.id===m.id).status,'removed');
  const logs=(await db.collection('auditLogs').get()).docs.map(d=>d.data());
  assert.ok(logs.some(l=>l.actor==='mod1'&&l.action==='inbox.report.remove-message'),'moderator action is audited');
  await fails(run('mod1','inbox-admin-resolve',{id,status:'resolved'}),'failed-precondition');
  const {id:uid2}=await run('rep1111','inbox-report',{cid,uid:'bad2222',reason:'Spam'});
  assert.equal((await db.doc('messageReports/'+uid2).get()).get('type'),'user');
});

test('restrictions: a restricted person cannot message until it expires or is lifted (audited)',async()=>{
  await user('res1111','Restricted',{who:'everyone'});await user('res2222','Peer',{who:'everyone'});
  await run('mod1','inbox-admin-restrict',{uid:'res1111',days:2,reason:'spam'});
  await fails(run('res1111','inbox-send',{to:'res2222',text:'hello'}),'permission-denied');
  advance(3*86_400_000);
  await run('res1111','inbox-send',{to:'res2222',text:'back again'});
  await run('mod1','inbox-admin-restrict',{uid:'res1111',days:30,reason:'again'});
  await fails(run('res1111','inbox-send',{to:'res2222',text:'blocked?'}),'permission-denied');
  await run('mod1','inbox-admin-restrict',{uid:'res1111',days:0,reason:'appeal accepted'});
  await run('res1111','inbox-send',{to:'res2222',text:'free'});
  await fails(run('res1111','inbox-admin-restrict',{uid:'res2222',days:5}),'permission-denied');
  const actions=(await db.collection('auditLogs').get()).docs.map(d=>d.get('action'));
  assert.ok(actions.includes('inbox.restrict')&&actions.includes('inbox.restrict.lift'));
});

test('admin portal numbers; admin close group; messaging switch',async()=>{
  const s=await run('mod1','inbox-admin-stats');
  assert.ok(s.personal>=5&&s.messages>10&&s.groups>=2,JSON.stringify(s));
  assert.equal(s.activeGroups,s.groups-s.groupsClosed);
  await fails(run('rep1111','inbox-admin-stats'),'permission-denied');
  const {cid}=await run('own1111','inbox-group-create',{name:'Bad Group'});
  await run('mod1','inbox-admin-close-group',{cid,reason:'abuse'});
  assert.equal((await conv(cid)).status,'closed');
  await fails(run('own1111','inbox-send',{cid,text:'hello?'}),'failed-precondition');
  await db.doc('config/app').set({messagingEnabled:false});
  await fails(run('rep1111','inbox-send',{to:'bad2222',text:'hi'}),'failed-precondition');
  await db.doc('config/app').set({messagingEnabled:true});
});

test('unauthenticated and unverified callers are refused; account deletion removes the person',async()=>{
  await assert.rejects(inboxAction(db,{action:'inbox-find',q:'Bob'},undefined,clock),e=>e.code==='unauthenticated');
  await assert.rejects(inboxAction(db,{action:'inbox-find',q:'Bob'},{uid:'alice1',token:{email_verified:false}},clock),e=>e.code==='permission-denied');
  await fails(run('alice1','inbox-nonsense'),'invalid-argument');
  await purgeInbox(db,'alice1');
  assert.equal((await db.doc('conversations/'+pid('alice1','bobby22')).get()).exists,false,'personal chat removed with the account');
  assert.equal((await db.doc('messagingPrefs/alice1').get()).exists,false);
});

test('a retried send with the same key never creates a duplicate message',async()=>{
  await user('dup1111','Dup',{who:'everyone'});await user('dup2222','Dup2',{who:'everyone'});
  const cid=pid('dup1111','dup2222');
  await run('dup1111','inbox-send',{to:'dup2222',text:'only once',key:'key-abcdef12'});
  const again=await run('dup1111','inbox-send',{cid,text:'only once',key:'key-abcdef12'});
  assert.equal(again.duplicate,true);
  assert.equal((await msgs(cid)).length,1);assert.equal((await conv(cid)).seq,1);
  await run('dup1111','inbox-send',{cid,text:'second one',key:'key-abcdef13'});
  assert.equal((await msgs(cid)).length,2);
  await fails(run('dup1111','inbox-send',{cid,text:'bad key',key:'x'}),'invalid-argument');
});
