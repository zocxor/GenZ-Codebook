/**
 * Inbox: one-to-one chats (with message requests) and private group chats.
 *
 * Runs behind the existing `communityFeature` callable (actions starting with "inbox-"), so there is
 * no new function to deploy. Everything that matters is enforced here, on the server: blocks, message
 * requests, rate limits, group roles and sizes, restrictions. The security rules only let a person
 * READ their own conversations; every write to conversations, messages, invitations, reports and
 * settings goes through this file.
 *
 * Data (all new collections; nothing existing is renamed):
 *   conversations/{cid}                 personal (p_<uidA>_<uidB>, sorted) or group (g_<random>)
 *   conversations/{cid}/messages/{mid}  text messages and short system lines
 *   conversations/{cid}/typing/{uid}    typing stamps (written by the client, see rules)
 *   users/{uid}/inbox/{cid}             my settings: pinned, muted, archived, cleared, hidden messages
 *   users/{uid}/inboxBlocks/{other}     people I blocked in the inbox
 *   messagingPrefs/{uid}                who can message me, show online / last seen
 *   groupInvites/{cid}_{uid}            pending group invitation
 *   messageReports/{id}                 reports (message snapshot only, never the whole chat)
 *   messagingRestrictions/{uid}         moderator restriction
 *   inboxLimits/{uid}                   spam counters (server only)
 *   inboxStats/s0..s9                   sharded counters for the admin portal
 * Unread = conversation.seq - conversation.reads[me].seq, so a message costs one conversation write.
 */
import {HttpsError} from 'firebase-functions/v2/https';
import {FieldValue, Timestamp, type Firestore, type Transaction} from 'firebase-admin/firestore';
import {createHash} from 'node:crypto';
import {screenMessage, CHAT_MAX_LENGTH} from './validation/chat';
import {cleanText} from './validation/contentSchema';

type Input = Record<string, unknown>;
type Auth = {uid: string; token: {email_verified?: boolean; firebase?: unknown; [k: string]: unknown}};
type Doc = FirebaseFirestore.DocumentData;
const stamp = FieldValue.serverTimestamp;
const DAY = 86_400_000;

export const INBOX_LIMITS = {
  text: CHAT_MAX_LENGTH,        // characters per message (same content screening as the community chat)
  perMinute: 20,                // messages per minute per person
  repeat: 3,                    // identical messages in a row before it is treated as spam
  newChatsPerDay: 10,           // new people a person may start a chat with per day
  retryAfterReject: 7 * DAY,    // a rejected sender must wait before asking again
  groupMax: 30,                 // members per group
  groupsPerDay: 3, ownedGroups: 5, invitesPerDay: 20, findsPerMinute: 30, reportsPerDay: 20,
  name: 40, description: 200, preview: 80, hiddenMessages: 200,
};
export const REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🙏'];
const MODERATION = ['super_admin', 'moderator'];
const REPORT_REASONS = ['Spam', 'Harassment or bullying', 'Offensive or harmful', 'Inappropriate content', 'Impersonation', 'Other'];
const WHO = ['everyone', 'requests', 'nobody'];

// ---------- small helpers ----------
const deny = (m = 'You can’t message this person.') => new HttpsError('permission-denied', m);
const bad = (m: string) => new HttpsError('invalid-argument', m);
function uidOf(v: unknown): string {
  if (typeof v !== 'string' || !/^[A-Za-z0-9_-]{6,128}$/.test(v)) throw bad('Choose a person.');
  return v;
}
function cidOf(v: unknown): string {
  if (typeof v !== 'string' || !/^[pg]_[A-Za-z0-9_-]{6,300}$/.test(v)) throw bad('Choose a conversation.');
  return v;
}
function idOf(v: unknown): string {
  if (typeof v !== 'string' || !/^[A-Za-z0-9_-]{6,64}$/.test(v)) throw bad('Choose a message.');
  return v;
}
const personalId = (a: string, b: string) => 'p_' + [a, b].sort().join('_');
const clip = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1) + '…' : s);
const digest = (s: string) => createHash('sha256').update(s).digest('hex').slice(0, 24);
const shard = (cid: string) => 's' + (parseInt(digest(cid).slice(0, 4), 16) % 10);
const ms = (v: unknown) => (v && typeof (v as Timestamp).toMillis === 'function' ? (v as Timestamp).toMillis() : typeof v === 'number' ? v : 0);

function requireAccount(auth: Auth | undefined): Auth {
  if (!auth) throw new HttpsError('unauthenticated', 'Sign in to use the Inbox.');
  if (auth.token.email_verified !== true) throw new HttpsError('permission-denied', 'Verify your e-mail to use the Inbox.');
  return auth;
}
async function activeAccounts(db: Firestore, tx: Transaction, uids: string[]) {
  const snaps = await Promise.all(uids.map(u => tx.get(db.doc(`users/${u}`))));
  snaps.forEach((s, i) => {if (s.get('status') !== 'active') throw i === 0 ? new HttpsError('permission-denied', 'An active account is required.') : deny();});
}
async function gate(db: Firestore, tx: Transaction, uid: string, now: number, restricted = true) {
  const [cfg, res] = await Promise.all([tx.get(db.doc('config/app')), tx.get(db.doc(`messagingRestrictions/${uid}`))]);
  if (cfg.get('messagingEnabled') === false) throw new HttpsError('failed-precondition', 'Messaging is switched off for now.');
  if (restricted && res.exists) {
    const until = ms(res.get('until'));
    if (!until || until > now) throw new HttpsError('permission-denied', 'Messaging is restricted on your account. Contact support if you think this is a mistake.');
  }
}
async function adminRole(db: Firestore, tx: Transaction, auth: Auth) {
  const [staff, config] = await Promise.all([tx.get(db.doc(`admins/${auth.uid}`)), tx.get(db.doc('config/security'))]);
  const role = staff.get('role');
  const second = (auth.token.firebase as {sign_in_second_factor?: string} | undefined)?.sign_in_second_factor;
  if (staff.get('active') !== true || !MODERATION.includes(role)) throw new HttpsError('permission-denied', `This action requires one of these administrator roles: ${MODERATION.join(', ')}.`);
  if (config.get('adminMfaRequired') === true && !second) throw new HttpsError('permission-denied', 'Two-step sign-in is required for administrators.');
  return role as string;
}
function audit(db: Firestore, tx: Transaction, actor: string, role: string, action: string, target: string, summary = '') {
  tx.create(db.collection('auditLogs').doc(), {actor, role, action, target, summary: clip(summary, 300), at: stamp(), expireAt: Timestamp.fromMillis(Date.now() + 365 * DAY)});
}
async function nameOf(db: Firestore, tx: Transaction, uid: string) {
  const s = await tx.get(db.doc(`publicProfiles/${uid}`));
  return clip(String(s.get('name') ?? 'Someone'), 24);
}
function cleanMessage(raw: unknown): string {
  if (typeof raw !== 'string') throw bad('Type a message first.');
  const verdict = screenMessage(raw);
  if (!verdict.ok) throw bad(verdict.message.replace('community chat', 'chat'));
  return cleanText(raw, INBOX_LIMITS.text);
}
const isBlockedPair = async (db: Firestore, tx: Transaction, a: string, b: string) => {
  const [x, y] = await Promise.all([tx.get(db.doc(`users/${a}/inboxBlocks/${b}`)), tx.get(db.doc(`users/${b}/inboxBlocks/${a}`))]);
  return x.exists || y.exists;
};

/** Per-person spam counters. Returns the updated limits document; throws when a limit is hit. */
function applyLimits(prev: Doc | undefined, now: number, kind: 'message' | 'chat' | 'group' | 'invites' | 'find' | 'report', extra: {text?: string; invites?: number} = {}): Doc {
  const d: Doc = {...(prev ?? {})};
  const day = new Date(now).toISOString().slice(0, 10);
  const dayBox = d.day && d.day.d === day ? {...d.day} : {d: day, chats: 0, groups: 0, invites: 0, reports: 0};
  const minute = d.minute && now - d.minute.start < 60_000 ? {...d.minute} : {start: now, messages: 0, finds: 0};
  if (kind === 'message') {
    if (minute.messages >= INBOX_LIMITS.perMinute) throw new HttpsError('resource-exhausted', 'You’re sending messages too fast. Wait a moment.');
    minute.messages++;
    const h = digest(String(extra.text ?? '').toLowerCase());
    const last = d.last && d.last.h === h && now - d.last.at < 5 * 60_000 ? d.last.count + 1 : 1;
    if (last > INBOX_LIMITS.repeat) throw new HttpsError('resource-exhausted', 'That looks like spam. Please don’t repeat the same message.');
    d.last = {h, at: now, count: last};
  } else if (kind === 'find') {
    if (minute.finds >= INBOX_LIMITS.findsPerMinute) throw new HttpsError('resource-exhausted', 'Too many searches. Wait a moment.');
    minute.finds++;
  } else if (kind === 'chat') {
    if (dayBox.chats >= INBOX_LIMITS.newChatsPerDay) throw new HttpsError('resource-exhausted', 'You’ve reached today’s limit for starting new chats. Try again tomorrow.');
    dayBox.chats++;
  } else if (kind === 'group') {
    if (dayBox.groups >= INBOX_LIMITS.groupsPerDay) throw new HttpsError('resource-exhausted', 'You’ve reached today’s limit for creating groups.');
    dayBox.groups++;
  } else if (kind === 'invites') {
    const n = extra.invites ?? 1;
    if (dayBox.invites + n > INBOX_LIMITS.invitesPerDay) throw new HttpsError('resource-exhausted', 'You’ve reached today’s limit for invitations.');
    dayBox.invites += n;
  } else {
    if (dayBox.reports >= INBOX_LIMITS.reportsPerDay) throw new HttpsError('resource-exhausted', 'You’ve sent many reports today. Please try again tomorrow.');
    dayBox.reports++;
  }
  d.day = dayBox; d.minute = minute;
  return d;
}
const prefsOf = (snap: FirebaseFirestore.DocumentSnapshot) => ({
  whoCanMessage: WHO.includes(snap.get('whoCanMessage')) ? snap.get('whoCanMessage') as string : 'requests',
  showOnline: snap.get('showOnline') !== false,
  showLastSeen: snap.get('showLastSeen') !== false,
});
const roleIn = (c: Doc, uid: string): 'owner' | 'admin' | 'moderator' | 'member' =>
  c.owner === uid ? 'owner' : (c.admins ?? []).includes(uid) ? 'admin' : (c.mods ?? []).includes(uid) ? 'moderator' : 'member';
const canModerate = (c: Doc, uid: string) => roleIn(c, uid) !== 'member';

/** Appends one message to a conversation inside a transaction (document already read as `conv`). */
function appendMessage(db: Firestore, tx: Transaction, cid: string, conv: Doc, stats: Doc, msg: {uid: string; text: string; type?: 'text' | 'system'; replyTo?: Doc | null; id?: string}, now: number, extraConv: Doc = {}) {
  const seq = (conv.seq ?? 0) + 1;
  const col = db.collection(`conversations/${cid}/messages`);
  const ref = msg.id ? col.doc(msg.id) : col.doc();
  const preview = clip(msg.text.replace(/\s+/g, ' '), INBOX_LIMITS.preview);
  tx.create(ref, {uid: msg.uid, text: msg.text, type: msg.type ?? 'text', replyTo: msg.replyTo ?? null, seq, createdAt: stamp(), status: 'live', reactions: {}});
  const reads = {...(extraConv.reads ?? conv.reads ?? {})};
  if (msg.type !== 'system') reads[msg.uid] = {seq, at: Timestamp.fromMillis(now)};
  const next: Doc = {...conv, ...extraConv, seq, reads, lastAt: stamp(), lastMessage: {id: ref.id, uid: msg.uid, text: preview, type: msg.type ?? 'text'}};
  for (const k of Object.keys(next)) if (next[k] === undefined) delete next[k];     // Firestore rejects undefined values
  tx.set(db.doc(`conversations/${cid}`), next);
  tx.set(db.doc(`inboxStats/${shard(cid)}`), {...stats, messages: (stats.messages ?? 0) + 1});
  return ref.id;
}
const statRef = (db: Firestore, cid: string) => db.doc(`inboxStats/${shard(cid)}`);

// ---------- the action router ----------
export async function inboxAction(db: Firestore, input: Input, identity: Auth | undefined, now = Date.now()): Promise<Record<string, unknown>> {
  const auth = requireAccount(identity), me = auth.uid;
  switch (input.action) {
    case 'inbox-find': return find(db, me, input, now);
    case 'inbox-send': return send(db, me, input, now);
    case 'inbox-respond': return respond(db, me, input, now);
    case 'inbox-read': return markRead(db, me, input, now);
    case 'inbox-settings': return setSettings(db, me, input);
    case 'inbox-delete-conversation': return deleteConversation(db, me, input, now);
    case 'inbox-delete-message': return deleteMessage(db, me, input, now);
    case 'inbox-react': return react(db, me, input);
    case 'inbox-block': return block(db, me, input, true);
    case 'inbox-unblock': return block(db, me, input, false);
    case 'inbox-prefs': return setPrefs(db, me, input);
    case 'inbox-report': return report(db, me, input, now);
    case 'inbox-group-create': return groupCreate(db, me, input, now);
    case 'inbox-group-invite': return groupInvite(db, me, input, now);
    case 'inbox-group-respond': return groupRespond(db, me, input, now);
    case 'inbox-group-leave': return groupLeave(db, me, input, now);
    case 'inbox-group-update': return groupUpdate(db, me, input);
    case 'inbox-group-role': return groupRole(db, me, input);
    case 'inbox-group-remove': return groupRemove(db, me, input, now);
    case 'inbox-group-transfer': return groupTransfer(db, me, input, now);
    case 'inbox-group-close': return groupClose(db, me, input, now);
    case 'inbox-admin-stats': return adminStats(db, auth);
    case 'inbox-admin-resolve': return adminResolve(db, auth, input, now);
    case 'inbox-admin-restrict': return adminRestrict(db, auth, input, now);
    case 'inbox-admin-close-group': return adminCloseGroup(db, auth, input, now);
    default: throw bad('Unknown inbox action.');
  }
}

// ---------- find people ----------
async function find(db: Firestore, me: string, input: Input, now: number) {
  const raw = typeof input.q === 'string' ? input.q.trim().slice(0, 30) : '';
  if (raw.length < 2) throw bad('Type at least 2 characters or a user code.');
  await db.runTransaction(async tx => {
    const ref = db.doc(`inboxLimits/${me}`);
    const snap = await tx.get(ref);
    tx.set(ref, applyLimits(snap.data(), now, 'find'));
  });
  const found = new Map<string, {name: string; avatar: number}>();
  if (/^GZ[A-Za-z0-9]{6}$/.test(raw)) {
    const ref = await db.doc(`referrals/${raw.toUpperCase()}`).get();
    const uid = ref.get('uid');
    if (typeof uid === 'string') {
      const p = await db.doc(`publicProfiles/${uid}`).get();
      found.set(uid, {name: String(p.get('name') ?? 'Code Explorer'), avatar: Number(p.get('avatar')) || 0});
    }
  } else {
    const variants = [...new Set([raw, raw.toLowerCase(), raw[0]!.toUpperCase() + raw.slice(1).toLowerCase()])];
    for (const v of variants) {
      const q = await db.collection('publicProfiles').where('name', '>=', v).where('name', '<=', v + '\uf8ff').limit(10).get();
      for (const d of q.docs) found.set(d.id, {name: String(d.get('name') ?? ''), avatar: Number(d.get('avatar')) || 0});
    }
  }
  found.delete(me);
  const results: Record<string, unknown>[] = [];
  for (const [uid, p] of [...found].slice(0, 15)) {
    const [user, prefs, blockedMe, verified] = await Promise.all([db.doc(`users/${uid}`).get(), db.doc(`messagingPrefs/${uid}`).get(), db.doc(`users/${uid}/inboxBlocks/${me}`).get(), db.doc(`verifiedContributors/${uid}`).get()]);
    if (user.get('status') !== 'active' || blockedMe.exists) continue;     // never reveal who blocked you
    const who = prefsOf(prefs).whoCanMessage;
    results.push({uid, name: p.name, avatar: p.avatar, verified: verified.exists, canMessage: who === 'nobody' ? 'nobody' : who === 'everyone' ? 'ok' : 'request'});
  }
  return {users: results};
}

// ---------- personal and group messages ----------
async function send(db: Firestore, me: string, input: Input, now: number) {
  const text = cleanMessage(input.text);
  const replyId = input.replyTo == null ? null : idOf(input.replyTo);
  // A retry of the same send (same key) after a lost connection never creates a second message.
  const key = input.key == null ? null : (typeof input.key === 'string' && /^[A-Za-z0-9_-]{8,64}$/.test(input.key) ? input.key : (() => {throw bad('Invalid message key.');})());
  const mid = key ? 'k' + digest(me + key).slice(0, 24) : undefined;
  const cid = input.cid != null ? cidOf(input.cid) : personalId(me, uidOf(input.to));
  if (cid.startsWith('p_') && !cid.slice(2).split('_').includes(me)) throw deny('You can’t message here.');
  return db.runTransaction(async tx => {
    const convRef = db.doc(`conversations/${cid}`), limitRef = db.doc(`inboxLimits/${me}`);
    const [convSnap, limits, stats, dup] = await Promise.all([tx.get(convRef), tx.get(limitRef), tx.get(statRef(db, cid)), mid ? tx.get(db.doc(`conversations/${cid}/messages/${mid}`)) : Promise.resolve(null)]);
    const conv = convSnap.data() as Doc | undefined;
    if (dup?.exists) return {ok: true, cid, state: (conv?.state as string) ?? 'active', duplicate: true};
    let replyTo: Doc | null = null;
    if (replyId && conv) {
      const m = await tx.get(db.doc(`conversations/${cid}/messages/${replyId}`));
      if (m.exists && m.get('status') === 'live') replyTo = {id: replyId, uid: m.get('uid'), text: clip(String(m.get('text')), 80)};
    }
    if (cid.startsWith('g_')) {
      if (!conv || conv.type !== 'group' || !(conv.participants ?? []).includes(me)) throw deny('You’re not in this group.');
      await Promise.all([gate(db, tx, me, now), activeAccounts(db, tx, [me])]);
      if (conv.status !== 'open') throw new HttpsError('failed-precondition', 'This group is closed.');
      tx.set(limitRef, applyLimits(limits.data(), now, 'message', {text}));
      appendMessage(db, tx, cid, conv, stats.data() ?? {}, {uid: me, text, replyTo, id: mid}, now);
      return {ok: true, cid, state: 'active'};
    }
    const peer = cid.slice(2).split('_').find(u => u !== me);
    if (!peer || peer === me) throw bad('Choose another person.');
    const prefs = await tx.get(db.doc(`messagingPrefs/${peer}`));
    await Promise.all([gate(db, tx, me, now), activeAccounts(db, tx, [me, peer])]);
    if (await isBlockedPair(db, tx, me, peer)) throw deny();
    let next = limits.data();
    const base: Doc = conv ?? {type: 'personal', participants: [me, peer].sort(), state: 'active', requester: null, requestMessages: 0, seq: 0, reads: {}, createdAt: stamp()};
    let state = base.state as string, requestMessages = base.requestMessages ?? 0, requester = base.requester ?? null;
    if (!conv) {
      const who = prefsOf(prefs).whoCanMessage;
      if (who === 'nobody') throw deny('This person isn’t accepting messages.');
      next = applyLimits(next, now, 'chat');
      state = who === 'everyone' ? 'active' : 'request';
      requester = state === 'request' ? me : null;
    } else if (state === 'request') {
      if (requester === me) {
        if (requestMessages >= 1) throw deny('Wait for them to accept your message request.');
      } else state = 'active';            // replying to a request accepts it
    } else if (state === 'rejected') {
      if (requester === me) {
        if (now - ms(base.rejectedAt) < INBOX_LIMITS.retryAfterReject) throw deny('This person didn’t accept your request.');
        next = applyLimits(next, now, 'chat'); state = 'request'; requestMessages = 0;
      } else state = 'active';            // the person who rejected may write first
    }
    next = applyLimits(next, now, 'message', {text});
    tx.set(limitRef, next);
    if (state === 'request') requestMessages++;
    const withStats = stats.data() ?? {};
    if (!conv) withStats.personal = (withStats.personal ?? 0) + 1;
    appendMessage(db, tx, cid, base, withStats, {uid: me, text, replyTo, id: mid}, now, {state, requester, requestMessages, rejectedAt: undefined});
    return {ok: true, cid, state};
  });
}

async function respond(db: Firestore, me: string, input: Input, now: number) {
  const cid = cidOf(input.cid), accept = input.accept === true;
  if (!cid.startsWith('p_')) throw bad('Choose a message request.');
  await db.runTransaction(async tx => {
    const ref = db.doc(`conversations/${cid}`);
    const snap = await tx.get(ref), c = snap.data() as Doc | undefined;
    if (!c || !(c.participants ?? []).includes(me) || c.state !== 'request' || c.requester === me) throw new HttpsError('failed-precondition', 'There is no request to answer.');
    tx.update(ref, accept ? {state: 'active'} : {state: 'rejected', rejectedAt: Timestamp.fromMillis(now)});
  });
  return {ok: true};
}

async function markRead(db: Firestore, me: string, input: Input, now: number) {
  const cid = cidOf(input.cid);
  await db.runTransaction(async tx => {
    const ref = db.doc(`conversations/${cid}`), snap = await tx.get(ref), c = snap.data() as Doc | undefined;
    if (!c || !(c.participants ?? []).includes(me)) return;
    if ((c.reads?.[me]?.seq ?? 0) >= (c.seq ?? 0)) return;           // nothing new: no write
    tx.update(ref, {reads: {...(c.reads ?? {}), [me]: {seq: c.seq ?? 0, at: Timestamp.fromMillis(now)}}});
  });
  return {ok: true};
}

async function member(db: Firestore, tx: Transaction, cid: string, me: string) {
  const snap = await tx.get(db.doc(`conversations/${cid}`)), c = snap.data() as Doc | undefined;
  if (!c || !(c.participants ?? []).includes(me)) throw deny('You’re not in this conversation.');
  return c;
}
async function setSettings(db: Firestore, me: string, input: Input) {
  const cid = cidOf(input.cid), patch: Doc = {};
  for (const k of ['pinned', 'muted', 'archived']) if (typeof input[k] === 'boolean') patch[k] = input[k];
  if (!Object.keys(patch).length) throw bad('Nothing to change.');
  await db.runTransaction(async tx => {
    await member(db, tx, cid, me);
    const ref = db.doc(`users/${me}/inbox/${cid}`);
    tx.set(ref, {...patch, updatedAt: stamp()}, {merge: true});
  });
  return {ok: true};
}
async function deleteConversation(db: Firestore, me: string, input: Input, now: number) {
  const cid = cidOf(input.cid);
  if (!cid.startsWith('p_')) throw bad('Use Leave group for groups.');
  await db.runTransaction(async tx => {
    await member(db, tx, cid, me);
    tx.set(db.doc(`users/${me}/inbox/${cid}`), {hidden: true, clearedAt: Timestamp.fromMillis(now), pinned: false, archived: false, updatedAt: stamp()}, {merge: true});
  });
  return {ok: true};
}
async function deleteMessage(db: Firestore, me: string, input: Input, now: number) {
  const cid = cidOf(input.cid), mid = idOf(input.mid), forAll = input.scope === 'all';
  await db.runTransaction(async tx => {
    const c = await member(db, tx, cid, me);
    const mref = db.doc(`conversations/${cid}/messages/${mid}`), msg = await tx.get(mref);
    const sRef = db.doc(`users/${me}/inbox/${cid}`), settings = await tx.get(sRef);
    if (!msg.exists) throw bad('That message no longer exists.');
    if (!forAll) {                                                 // delete for me only
      const hidden = [...(settings.get('hiddenMsgs') ?? []), mid].slice(-INBOX_LIMITS.hiddenMessages);
      tx.set(sRef, {hiddenMsgs: hidden, updatedAt: stamp()}, {merge: true});
      return;
    }
    const own = msg.get('uid') === me;
    if (c.type !== 'group' || !(own || canModerate(c, me))) throw deny('Only the sender or a group admin can delete this for everyone.');
    if (c.status !== 'open' && !canModerate(c, me)) throw deny();
    tx.update(mref, {status: 'removed', text: '', removedBy: me, removedAt: Timestamp.fromMillis(now)});
    if (c.lastMessage?.id === mid) tx.update(db.doc(`conversations/${cid}`), {lastMessage: {...c.lastMessage, text: 'Message removed'}});
  });
  return {ok: true};
}
async function react(db: Firestore, me: string, input: Input) {
  const cid = cidOf(input.cid), mid = idOf(input.mid), emoji = String(input.emoji ?? '');
  if (!REACTIONS.includes(emoji)) throw bad('Choose one of the reactions.');
  await db.runTransaction(async tx => {
    const c = await member(db, tx, cid, me);
    if (c.status === 'closed' || c.status === 'deleted') throw deny();
    const mref = db.doc(`conversations/${cid}/messages/${mid}`), msg = await tx.get(mref);
    if (!msg.exists || msg.get('status') !== 'live') throw bad('That message no longer exists.');
    const reactions: Record<string, string[]> = {...(msg.get('reactions') ?? {})};
    for (const k of Object.keys(reactions)) {                       // one reaction per person; tap again to remove
      const had = reactions[k]!.includes(me);
      reactions[k] = reactions[k]!.filter(u => u !== me);
      if (had && k === emoji) {if (!reactions[k]!.length) delete reactions[k]; tx.update(mref, {reactions}); return;}
      if (!reactions[k]!.length) delete reactions[k];
    }
    reactions[emoji] = [...(reactions[emoji] ?? []), me];
    tx.update(mref, {reactions});
  });
  return {ok: true};
}

// ---------- blocking, privacy, reporting ----------
async function block(db: Firestore, me: string, input: Input, on: boolean) {
  const other = uidOf(input.uid);
  if (other === me) throw bad('You can’t block yourself.');
  const ref = db.doc(`users/${me}/inboxBlocks/${other}`);
  if (on) await ref.set({at: stamp()}); else await ref.delete();
  return {ok: true};
}
async function setPrefs(db: Firestore, me: string, input: Input) {
  const patch: Doc = {};
  if (input.whoCanMessage !== undefined) {
    if (!WHO.includes(String(input.whoCanMessage))) throw bad('Choose who can message you.');
    patch.whoCanMessage = input.whoCanMessage;
  }
  for (const k of ['showOnline', 'showLastSeen']) if (typeof input[k] === 'boolean') patch[k] = input[k];
  if (!Object.keys(patch).length) throw bad('Nothing to change.');
  await db.runTransaction(async tx => {
    const ref = db.doc(`messagingPrefs/${me}`), snap = await tx.get(ref);
    const merged = {...prefsOf(snap), ...patch};
    tx.set(ref, {...merged, updatedAt: stamp()});
    if (!merged.showOnline || !merged.showLastSeen) tx.set(db.doc(`presence/${me}`), {online: merged.showOnline, seen: merged.showLastSeen, ...(!merged.showOnline && !merged.showLastSeen ? {at: FieldValue.delete()} : {})}, {merge: true});
    else tx.set(db.doc(`presence/${me}`), {online: true, seen: true}, {merge: true});
  });
  return {ok: true};
}
async function report(db: Firestore, me: string, input: Input, now: number) {
  const reason = String(input.reason ?? '');
  if (!REPORT_REASONS.includes(reason)) throw bad('Choose a reason.');
  const note = typeof input.note === 'string' ? cleanText(input.note, 300) : '';
  const cid = cidOf(input.cid), mid = input.mid != null ? idOf(input.mid) : null;
  const id = await db.runTransaction(async tx => {
    const c = await member(db, tx, cid, me);
    const limitRef = db.doc(`inboxLimits/${me}`), limits = await tx.get(limitRef);
    let reported: string, snapshot: Doc | null = null;
    if (mid) {
      const m = await tx.get(db.doc(`conversations/${cid}/messages/${mid}`));
      if (!m.exists) throw bad('That message no longer exists.');
      reported = String(m.get('uid'));
      snapshot = {text: clip(String(m.get('text')), 500), at: m.get('createdAt') ?? null};
      const before = await tx.get(db.collection(`conversations/${cid}/messages`).where('seq', '<', m.get('seq')).orderBy('seq', 'desc').limit(2));
      snapshot.context = before.docs.reverse().map(d => ({uid: d.get('uid'), text: clip(String(d.get('text')), 200)}));
    } else reported = uidOf(input.uid);
    if (reported === me) throw bad('You can’t report yourself.');
    if (!(c.participants ?? []).includes(reported)) throw bad('That person isn’t in this conversation.');
    tx.set(limitRef, applyLimits(limits.data(), now, 'report'));
    const ref = db.collection('messageReports').doc();
    tx.create(ref, {reporter: me, reportedUid: reported, cid, mid, type: mid ? 'message' : 'user', convType: c.type, reason, note, snapshot, status: 'open', createdAt: stamp()});
    return ref.id;
  });
  return {ok: true, id};
}

// ---------- groups ----------
async function groupCreate(db: Firestore, me: string, input: Input, now: number) {
  const name = cleanText(String(input.name ?? ''), INBOX_LIMITS.name), description = cleanText(String(input.description ?? ''), INBOX_LIMITS.description);
  if (name.length < 2) throw bad('Give the group a name (at least 2 characters).');
  for (const t of [name, description]) if (t && !screenMessage(t).ok) throw bad('Please keep the group name and description friendly.');
  const privacy = input.privacy === 'invite' ? 'invite' : 'private';
  const invitees = [...new Set(Array.isArray(input.members) ? (input.members as unknown[]).map(uidOf) : [])].filter(u => u !== me);
  if (invitees.length + 1 > INBOX_LIMITS.groupMax) throw bad(`A group can have up to ${INBOX_LIMITS.groupMax} members.`);
  const cid = 'g_' + digest(me + now + Math.random()).slice(0, 20);
  await db.runTransaction(async tx => {
    const limitRef = db.doc(`inboxLimits/${me}`);
    const [limits, stats, owned] = await Promise.all([tx.get(limitRef), tx.get(statRef(db, cid)), tx.get(db.collection('conversations').where('owner', '==', me).where('status', '==', 'open').limit(INBOX_LIMITS.ownedGroups + 1))]);
    await Promise.all([gate(db, tx, me, now), activeAccounts(db, tx, [me])]);
    if (owned.size >= INBOX_LIMITS.ownedGroups) throw new HttpsError('resource-exhausted', `You can own up to ${INBOX_LIMITS.ownedGroups} groups.`);
    let next = applyLimits(limits.data(), now, 'group');
    const who = await Promise.all(invitees.map(async u => {
      const [user, blocked] = await Promise.all([tx.get(db.doc(`users/${u}`)), isBlockedPair(db, tx, me, u)]);
      return user.get('status') === 'active' && !blocked;
    }));
    const ok = invitees.filter((_, i) => who[i]);
    if (ok.length) next = applyLimits(next, now, 'invites', {invites: ok.length});
    tx.set(limitRef, next);
    const myName = await nameOf(db, tx, me);
    const conv = {type: 'group', participants: [me], owner: me, admins: [me], mods: [], status: 'open', name, description, privacy, seq: 0, reads: {}, createdAt: stamp(), lastAt: stamp()};
    appendMessage(db, tx, cid, conv, {...(stats.data() ?? {}), groups: ((stats.data() ?? {}).groups ?? 0) + 1}, {uid: me, text: `${myName} created the group`, type: 'system'}, now);
    for (const u of ok) tx.set(db.doc(`groupInvites/${cid}_${u}`), {cid, uid: u, by: me, name, createdAt: stamp()});
  });
  return {ok: true, cid};
}
async function groupInvite(db: Firestore, me: string, input: Input, now: number) {
  const cid = cidOf(input.cid), invitees = [...new Set(Array.isArray(input.uids) ? (input.uids as unknown[]).map(uidOf) : [])].filter(u => u !== me);
  if (!cid.startsWith('g_') || !invitees.length || invitees.length > 10) throw bad('Choose 1 to 10 people to invite.');
  let sent = 0;
  await db.runTransaction(async tx => {
    const limitRef = db.doc(`inboxLimits/${me}`);
    const [convSnap, limits] = await Promise.all([tx.get(db.doc(`conversations/${cid}`)), tx.get(limitRef)]);
    const c = convSnap.data() as Doc | undefined;
    if (!c || c.type !== 'group' || !(c.participants ?? []).includes(me)) throw deny('You’re not in this group.');
    await Promise.all([gate(db, tx, me, now), activeAccounts(db, tx, [me])]);
    if (c.status !== 'open') throw new HttpsError('failed-precondition', 'This group is closed.');
    if (c.privacy === 'private' && !canModerate(c, me)) throw deny('Only the group admins can invite people to this private group.');
    const checks = await Promise.all(invitees.map(async u => {
      const [user, blocked, invite] = await Promise.all([tx.get(db.doc(`users/${u}`)), isBlockedPair(db, tx, me, u), tx.get(db.doc(`groupInvites/${cid}_${u}`))]);
      return user.get('status') === 'active' && !blocked && !(c.participants ?? []).includes(u) && !invite.exists;
    }));
    const ok = invitees.filter((_, i) => checks[i]);
    if ((c.participants ?? []).length + ok.length > INBOX_LIMITS.groupMax) throw bad(`A group can have up to ${INBOX_LIMITS.groupMax} members.`);
    if (!ok.length) return;
    tx.set(limitRef, applyLimits(limits.data(), now, 'invites', {invites: ok.length}));
    for (const u of ok) tx.set(db.doc(`groupInvites/${cid}_${u}`), {cid, uid: u, by: me, name: c.name, createdAt: stamp()});
    sent = ok.length;
  });
  return {ok: true, sent};
}
async function groupRespond(db: Firestore, me: string, input: Input, now: number) {
  const cid = cidOf(input.cid), accept = input.accept === true;
  await db.runTransaction(async tx => {
    const inviteRef = db.doc(`groupInvites/${cid}_${me}`);
    const [invite, convSnap, stats] = await Promise.all([tx.get(inviteRef), tx.get(db.doc(`conversations/${cid}`)), tx.get(statRef(db, cid))]);
    if (!invite.exists) throw new HttpsError('failed-precondition', 'That invitation is no longer available.');
    const c = convSnap.data() as Doc | undefined;
    if (!accept) {tx.delete(inviteRef); return;}
    if (!c || c.status !== 'open') {tx.delete(inviteRef); throw new HttpsError('failed-precondition', 'This group is no longer open.');}
    await Promise.all([gate(db, tx, me, now), activeAccounts(db, tx, [me])]);
    if ((c.participants ?? []).length >= INBOX_LIMITS.groupMax) throw new HttpsError('resource-exhausted', 'This group is full.');
    if (await isBlockedPair(db, tx, me, String(invite.get('by')))) {tx.delete(inviteRef); throw deny('You can’t join this group.');}
    const myName = await nameOf(db, tx, me);
    tx.delete(inviteRef);
    appendMessage(db, tx, cid, c, stats.data() ?? {}, {uid: me, text: `${myName} joined`, type: 'system'}, now, {participants: [...(c.participants ?? []), me], reads: {...(c.reads ?? {}), [me]: {seq: (c.seq ?? 0) + 1, at: Timestamp.fromMillis(now)}}});
  });
  return {ok: true, cid};
}
async function removeMember(db: Firestore, tx: Transaction, cid: string, c: Doc, stats: Doc, target: string, text: string, now: number) {
  const participants = (c.participants ?? []).filter((u: string) => u !== target);
  const reads = {...(c.reads ?? {})}; delete reads[target];
  appendMessage(db, tx, cid, c, stats, {uid: target, text, type: 'system'}, now, {participants, reads, admins: (c.admins ?? []).filter((u: string) => u !== target), mods: (c.mods ?? []).filter((u: string) => u !== target)});
  tx.delete(db.doc(`users/${target}/inbox/${cid}`));
}
async function groupLeave(db: Firestore, me: string, input: Input, now: number) {
  const cid = cidOf(input.cid);
  await db.runTransaction(async tx => {
    const [snap, stats] = await Promise.all([tx.get(db.doc(`conversations/${cid}`)), tx.get(statRef(db, cid))]);
    const c = snap.data() as Doc | undefined;
    if (!c || c.type !== 'group' || !(c.participants ?? []).includes(me)) throw deny('You’re not in this group.');
    const myName = await nameOf(db, tx, me);
    if (c.owner === me) {
      if ((c.participants ?? []).length > 1) throw new HttpsError('failed-precondition', 'Transfer ownership to another member before leaving.');
      tx.update(db.doc(`conversations/${cid}`), {status: 'deleted', participants: [], admins: [], mods: [], lastAt: stamp()});
      tx.set(statRef(db, cid), {...(stats.data() ?? {}), groupsClosed: ((stats.data() ?? {}).groupsClosed ?? 0) + 1});
      tx.delete(db.doc(`users/${me}/inbox/${cid}`));
      return;
    }
    await removeMember(db, tx, cid, c, stats.data() ?? {}, me, `${myName} left`, now);
  });
  return {ok: true};
}
async function adminOf(db: Firestore, tx: Transaction, cid: string, me: string, need: 'admin' | 'moderator' = 'admin') {
  const [snap, stats] = await Promise.all([tx.get(db.doc(`conversations/${cid}`)), tx.get(statRef(db, cid))]);
  const c = snap.data() as Doc | undefined;
  if (!c || c.type !== 'group' || !(c.participants ?? []).includes(me)) throw deny('You’re not in this group.');
  const r = roleIn(c, me);
  if (!(r === 'owner' || r === 'admin' || (need === 'moderator' && r === 'moderator'))) throw deny('Only group admins can do this.');
  if (c.status !== 'open') throw new HttpsError('failed-precondition', 'This group is closed.');
  return {c, stats: stats.data() ?? {}, role: r};
}
async function groupUpdate(db: Firestore, me: string, input: Input) {
  const cid = cidOf(input.cid), patch: Doc = {};
  if (input.name !== undefined) {const n = cleanText(String(input.name), INBOX_LIMITS.name); if (n.length < 2 || !screenMessage(n).ok) throw bad('Choose a friendly group name (2 to 40 characters).'); patch.name = n;}
  if (input.description !== undefined) {const d = cleanText(String(input.description), INBOX_LIMITS.description); if (d && !screenMessage(d).ok) throw bad('Please keep the description friendly.'); patch.description = d;}
  if (input.privacy !== undefined) patch.privacy = input.privacy === 'invite' ? 'invite' : 'private';
  if (!Object.keys(patch).length) throw bad('Nothing to change.');
  await db.runTransaction(async tx => {
    await adminOf(db, tx, cid, me);
    tx.update(db.doc(`conversations/${cid}`), patch);
  });
  return {ok: true};
}
async function groupRole(db: Firestore, me: string, input: Input) {
  const cid = cidOf(input.cid), target = uidOf(input.uid), role = String(input.role);
  if (!['admin', 'moderator', 'member'].includes(role)) throw bad('Choose a role.');
  await db.runTransaction(async tx => {
    const {c, role: mine} = await adminOf(db, tx, cid, me);
    if (target === me) throw deny('You can’t change your own role.');
    if (c.owner === target) throw deny('The owner’s role can’t be changed.');
    if (!(c.participants ?? []).includes(target)) throw bad('That person isn’t in this group.');
    const current = roleIn(c, target);
    if ((role === 'admin' || current === 'admin') && mine !== 'owner') throw deny('Only the group owner can add or remove admins.');
    const admins = (c.admins ?? []).filter((u: string) => u !== target), mods = (c.mods ?? []).filter((u: string) => u !== target);
    if (role === 'admin') admins.push(target); else if (role === 'moderator') mods.push(target);
    tx.update(db.doc(`conversations/${cid}`), {admins, mods});
  });
  return {ok: true};
}
async function groupRemove(db: Firestore, me: string, input: Input, now: number) {
  const cid = cidOf(input.cid), target = uidOf(input.uid);
  await db.runTransaction(async tx => {
    const {c, stats, role: mine} = await adminOf(db, tx, cid, me, 'moderator');
    if (target === me) throw bad('Use Leave group.');
    if (!(c.participants ?? []).includes(target)) throw bad('That person isn’t in this group.');
    const theirs = roleIn(c, target);
    if (theirs === 'owner' || (theirs === 'admin' && mine !== 'owner') || (theirs === 'moderator' && mine === 'moderator')) throw deny('You can’t remove this member.');
    const [theirName, myName] = await Promise.all([nameOf(db, tx, target), nameOf(db, tx, me)]);
    await removeMember(db, tx, cid, c, stats, target, `${theirName} was removed by ${myName}`, now);
  });
  return {ok: true};
}
async function groupTransfer(db: Firestore, me: string, input: Input, now: number) {
  const cid = cidOf(input.cid), target = uidOf(input.uid);
  await db.runTransaction(async tx => {
    const {c, stats, role} = await adminOf(db, tx, cid, me);
    if (role !== 'owner') throw deny('Only the owner can transfer ownership.');
    if (target === me || !(c.participants ?? []).includes(target)) throw bad('Choose another member.');
    const name = await nameOf(db, tx, target);
    const admins = [...new Set([...(c.admins ?? []), target])];
    appendMessage(db, tx, cid, c, stats, {uid: me, text: `${name} is now the group owner`, type: 'system'}, now, {owner: target, admins, mods: (c.mods ?? []).filter((u: string) => u !== target)});
  });
  return {ok: true};
}
async function groupClose(db: Firestore, me: string, input: Input, now: number) {
  const cid = cidOf(input.cid), forEveryone = input.mode === 'delete';
  await db.runTransaction(async tx => {
    const {stats, role} = await adminOf(db, tx, cid, me);
    if (role !== 'owner') throw deny('Only the group owner can close or delete the group.');
    if (forEveryone) tx.update(db.doc(`conversations/${cid}`), {status: 'deleted', closedAt: Timestamp.fromMillis(now), participants: [], admins: [], mods: [], lastAt: stamp()});
    else tx.update(db.doc(`conversations/${cid}`), {status: 'closed', closedAt: Timestamp.fromMillis(now), lastAt: stamp()});
    tx.set(statRef(db, cid), {...stats, groupsClosed: (stats.groupsClosed ?? 0) + 1});
  });
  return {ok: true};
}

// ---------- administration (moderators only; audited) ----------
async function adminStats(db: Firestore, auth: Auth) {
  await db.runTransaction(async tx => {await adminRole(db, tx, auth);});
  const shards = await db.collection('inboxStats').get();
  const sum = (k: string) => shards.docs.reduce((n, d) => n + (Number(d.get(k)) || 0), 0);
  const restricted = await db.collection('messagingRestrictions').limit(500).get();
  return {personal: sum('personal'), groups: sum('groups'), groupsClosed: sum('groupsClosed'), messages: sum('messages'),
    activeGroups: Math.max(0, sum('groups') - sum('groupsClosed')), restricted: restricted.size};
}
async function adminResolve(db: Firestore, auth: Auth, input: Input, now: number) {
  const id = idOf(input.id), status = input.status === 'dismissed' ? 'dismissed' : 'resolved', note = clip(cleanText(String(input.note ?? ''), 300), 300);
  const removeMessage = input.removeMessage === true;
  await db.runTransaction(async tx => {
    const role = await adminRole(db, tx, auth);
    const ref = db.doc(`messageReports/${id}`), snap = await tx.get(ref);
    if (!snap.exists || snap.get('status') !== 'open') throw new HttpsError('failed-precondition', 'This report was already handled.');
    let mref: FirebaseFirestore.DocumentReference | null = null, msg: FirebaseFirestore.DocumentSnapshot | null = null;
    if (removeMessage && snap.get('mid')) {mref = db.doc(`conversations/${snap.get('cid')}/messages/${snap.get('mid')}`); msg = await tx.get(mref);}
    tx.update(ref, {status, resolution: note, resolvedBy: auth.uid, resolvedAt: Timestamp.fromMillis(now)});
    if (mref && msg?.exists) tx.update(mref, {status: 'removed', text: '', removedBy: auth.uid, removedAt: Timestamp.fromMillis(now)});
    audit(db, tx, auth.uid, role, status === 'dismissed' ? 'inbox.report.dismiss' : removeMessage ? 'inbox.report.remove-message' : 'inbox.report.resolve', ref.path, note);
  });
  return {ok: true};
}
async function adminRestrict(db: Firestore, auth: Auth, input: Input, now: number) {
  const target = uidOf(input.uid), days = Number(input.days), reason = clip(cleanText(String(input.reason ?? ''), 200), 200);
  if (!Number.isInteger(days) || days < 0 || days > 365) throw bad('Choose 0 (lift the restriction) to 365 days.');
  await db.runTransaction(async tx => {
    const role = await adminRole(db, tx, auth);
    const ref = db.doc(`messagingRestrictions/${target}`);
    if (days === 0) {tx.delete(ref); audit(db, tx, auth.uid, role, 'inbox.restrict.lift', ref.path, reason); return;}
    tx.set(ref, {until: Timestamp.fromMillis(now + days * DAY), reason, by: auth.uid, at: stamp()});
    audit(db, tx, auth.uid, role, 'inbox.restrict', ref.path, `${days} days · ${reason}`);
  });
  return {ok: true};
}
async function adminCloseGroup(db: Firestore, auth: Auth, input: Input, now: number) {
  const cid = cidOf(input.cid), reason = clip(cleanText(String(input.reason ?? ''), 200), 200);
  if (!cid.startsWith('g_')) throw bad('Choose a group.');
  await db.runTransaction(async tx => {
    const role = await adminRole(db, tx, auth);
    const [snap, stats] = await Promise.all([tx.get(db.doc(`conversations/${cid}`)), tx.get(statRef(db, cid))]);
    if (!snap.exists || snap.get('status') !== 'open') throw new HttpsError('failed-precondition', 'This group is already closed.');
    tx.update(db.doc(`conversations/${cid}`), {status: 'closed', closedAt: Timestamp.fromMillis(now), closedBy: 'moderation', lastAt: stamp()});
    tx.set(statRef(db, cid), {...(stats.data() ?? {}), groupsClosed: ((stats.data() ?? {}).groupsClosed ?? 0) + 1});
    audit(db, tx, auth.uid, role, 'inbox.group.close', `conversations/${cid}`, reason);
  });
  return {ok: true};
}

// ---------- account deletion ----------
/** Removes a deleted account from the Inbox: personal chats are deleted, groups lose the member. */
export async function purgeInbox(db: Firestore, uid: string) {
  const convs = await db.collection('conversations').where('participants', 'array-contains', uid).get();
  for (const d of convs.docs) {
    const c = d.data();
    if (c.type === 'personal') {await db.recursiveDelete(d.ref); continue;}
    await db.runTransaction(async tx => {
      const snap = await tx.get(d.ref), cur = snap.data() as Doc | undefined;
      if (!cur) return;
      const rest = (cur.participants ?? []).filter((u: string) => u !== uid);
      if (!rest.length) {tx.update(d.ref, {status: 'deleted', participants: [], admins: [], mods: []}); return;}
      const owner = cur.owner === uid ? ((cur.admins ?? []).find((u: string) => u !== uid) ?? rest[0]) : cur.owner;
      const reads = {...(cur.reads ?? {})}; delete reads[uid];
      tx.update(d.ref, {participants: rest, owner, admins: [...new Set([...(cur.admins ?? []).filter((u: string) => u !== uid), owner])], mods: (cur.mods ?? []).filter((u: string) => u !== uid), reads});
    });
  }
  for (const col of ['inbox', 'inboxBlocks']) {
    const snaps = await db.collection(`users/${uid}/${col}`).get();
    for (const s of snaps.docs) await s.ref.delete();
  }
  for (const path of [`messagingPrefs/${uid}`, `presence/${uid}`, `inboxLimits/${uid}`]) await db.doc(path).delete();
  const invites = await db.collection('groupInvites').where('uid', '==', uid).get();
  for (const s of invites.docs) await s.ref.delete();
}
