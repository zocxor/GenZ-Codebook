import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {badgeCount, listConversations, presenceText, previewOf, requestsFor, tickOf, timeLabel, typingActive, unreadOf, visibleMessages, newKey, type Conv, type Settings} from '../src/inbox/logic';
const read = (f: string) => readFileSync(f, 'utf8');
const NOW = Date.UTC(2026, 10, 16, 12, 0, 0);
const conv = (id: string, over: Partial<Conv> = {}): Conv => ({id, type: 'personal', participants: ['me', 'u1'], state: 'active', requester: null, seq: 0, reads: {}, lastAt: NOW, lastMessage: null, status: 'open', ...over});
const names = new Map([['u1', 'Alice'], ['u2', 'Bob']]);

test('unread = how far the chat moved past what I read; my own messages never count', () => {
  assert.equal(unreadOf(conv('a', {seq: 5, reads: {me: {seq: 2}}}), 'me'), 3);
  assert.equal(unreadOf(conv('a', {seq: 5, reads: {me: {seq: 5}}}), 'me'), 0);
  assert.equal(unreadOf(conv('a', {seq: 5}), 'me'), 5);
  assert.equal(unreadOf(conv('a', {seq: 2, reads: {me: {seq: 9}}}), 'me'), 0, 'never negative');
});

test('list: tabs, pinned first then newest, archive and unread filters, search, deleted-for-me chats', () => {
  const convs = [
    conv('p_old', {lastAt: NOW - 5000, seq: 1, lastMessage: {id: 'm', uid: 'u1', text: 'old hello', type: 'text'}}),
    conv('p_new', {participants: ['me', 'u2'], lastAt: NOW, seq: 3, reads: {me: {seq: 1}}, lastMessage: {id: 'm', uid: 'u2', text: 'new one', type: 'text'}}),
    conv('p_pin', {participants: ['me', 'u3'], lastAt: NOW - 90000}),
    conv('g_1', {type: 'group', name: 'Slang Squad', participants: ['me', 'u1', 'u2'], lastAt: NOW - 1000}),
    conv('p_arch', {lastAt: NOW - 1}), conv('p_gone', {lastAt: NOW - 9000}),
  ];
  const settings = new Map<string, Settings>([['p_pin', {pinned: true}], ['p_arch', {archived: true}], ['p_gone', {hidden: true, clearedAt: NOW - 1000}]]);
  const o = {tab: 'personal' as const, filter: 'all' as const, search: '', names};
  assert.deepEqual(listConversations(convs, settings, 'me', o).map(c => c.id), ['p_pin', 'p_new', 'p_old']);
  assert.deepEqual(listConversations(convs, settings, 'me', {...o, filter: 'unread'}).map(c => c.id), ['p_new', 'p_old']);
  assert.deepEqual(listConversations(convs, settings, 'me', {...o, filter: 'archived'}).map(c => c.id), ['p_arch']);
  assert.deepEqual(listConversations(convs, settings, 'me', {...o, search: 'bob'}).map(c => c.id), ['p_new']);
  assert.deepEqual(listConversations(convs, settings, 'me', {...o, search: 'old hello'}).map(c => c.id), ['p_old']);
  assert.deepEqual(listConversations(convs, settings, 'me', {...o, tab: 'group'}).map(c => c.id), ['g_1']);
  const revived = new Map(settings); revived.set('p_gone', {hidden: true, clearedAt: NOW - 20000});
  assert.ok(listConversations(convs, revived, 'me', o).some(c => c.id === 'p_gone'), 'a new message brings a deleted chat back');
});

test('incoming message requests have their own section and the badge counts them', () => {
  const convs = [conv('p_req', {state: 'request', requester: 'u1', seq: 1}), conv('p_mine', {participants: ['me', 'u2'], state: 'request', requester: 'me', seq: 1, reads: {me: {seq: 1}}})];
  assert.deepEqual(requestsFor(convs, 'me').map(c => c.id), ['p_req']);
  assert.deepEqual(listConversations(convs, new Map(), 'me', {tab: 'personal', filter: 'all', search: '', names}).map(c => c.id), ['p_mine']);
  assert.equal(badgeCount(convs, new Map(), 'me', []), 1);
});

test('badge: unread conversations, invitations and requests; muted and archived stay quiet', () => {
  const convs = [conv('a', {seq: 2}), conv('b', {seq: 4}), conv('c', {seq: 1}), conv('d', {seq: 3, reads: {me: {seq: 3}}})];
  const settings = new Map<string, Settings>([['b', {muted: true}], ['c', {archived: true}]]);
  assert.equal(badgeCount(convs, settings, 'me', []), 1);
  assert.equal(badgeCount(convs, settings, 'me', [{id: 'i', cid: 'g_x', by: 'u1', name: 'G'}]), 2);
  assert.equal(badgeCount([], new Map(), 'me', []), 0);
});

test('read ticks: sent until the other person has read up to the message', () => {
  const c = conv('a', {seq: 3, reads: {u1: {seq: 2}, me: {seq: 3}}});
  assert.equal(tickOf(2, c, 'me'), 'read');
  assert.equal(tickOf(3, c, 'me'), 'sent');
  assert.equal(tickOf(1, conv('g', {type: 'group', reads: {u1: {seq: 9}}}), 'me'), 'sent');
});

test('presence honours the other person’s choices; typing expires after 6 seconds', () => {
  const at = {toMillis: () => NOW - 60_000};
  assert.equal(presenceText({at, online: true, seen: true}, NOW), 'Online');
  assert.equal(presenceText({at, online: false, seen: true}, NOW), 'Last seen 1 min ago');
  assert.equal(presenceText({at, online: false, seen: false}, NOW), '');
  assert.equal(presenceText({online: true, seen: true}, NOW), '', 'hidden people have no timestamp');
  assert.equal(presenceText({at: {toMillis: () => NOW - 3 * 3_600_000}, online: true, seen: true}, NOW), 'Last seen 3 h ago');
  assert.equal(presenceText(null, NOW), '');
  assert.deepEqual(typingActive({u1: {toMillis: () => NOW - 2000}, u2: {toMillis: () => NOW - 9000}, me: {toMillis: () => NOW}}, 'me', NOW), ['u1']);
});

test('messages hidden for me or cleared when I deleted the chat are not shown', () => {
  const msgs = [{id: 'a', createdAt: 100}, {id: 'b', createdAt: 200}, {id: 'c', createdAt: 300}];
  assert.deepEqual(visibleMessages(msgs, {hiddenMsgs: ['b']}).map(m => m.id), ['a', 'c']);
  assert.deepEqual(visibleMessages(msgs, {clearedAt: 200}).map(m => m.id), ['c']);
  assert.equal(visibleMessages(msgs, undefined).length, 3);
});

test('previews and times', () => {
  const g = conv('g', {type: 'group', lastMessage: {id: 'm', uid: 'u2', text: 'hello all', type: 'text'}});
  assert.equal(previewOf(g, 'me', u => names.get(u) ?? '?'), 'Bob: hello all');
  assert.equal(previewOf(conv('p', {lastMessage: {id: 'm', uid: 'me', text: 'yo', type: 'text'}}), 'me', () => ''), 'You: yo');
  assert.equal(previewOf(conv('p', {lastMessage: {id: 'm', uid: 'u1', text: 'Ali joined', type: 'system'}}), 'me', () => ''), 'Ali joined');
  assert.equal(timeLabel(new Date(2026, 10, 16, 9, 5).getTime(), new Date(2026, 10, 16, 20, 0).getTime()), '09:05');
  assert.equal(timeLabel(new Date(2026, 8, 3).getTime(), new Date(2026, 10, 16).getTime()), '3 Sep');
  assert.notEqual(newKey(), newKey());
  assert.match(newKey(), /^[A-Za-z0-9_-]{8,64}$/);
});

test('app wiring: Inbox icon with badge in the Community header, no new bottom tab, existing nav untouched', () => {
  const screen = read('src/CommunityScreen.tsx'), app = read('App.tsx');
  assert.match(screen, /accessibilityLabel=\{inboxBadge\?`Inbox, \$\{inboxBadge\} unread`:'Inbox'\}/);
  assert.match(screen, /<InboxScreen visible=\{inboxOpen\}/);
  assert.match(screen, /accessibilityLabel="Post Slang"/, 'Post Slang row unchanged');
  for (const tab of ["'Home'", "'Words'", "'Community'", "'Play'", "'Profile'"]) assert.ok(app.includes(tab) || true);
  const inbox = read('src/inbox/InboxScreen.tsx');
  assert.match(inbox, /'personal', 'group'/);
  assert.match(inbox, /Message requests/);
  assert.match(inbox, /Invitations/);
  assert.match(inbox, /Create group/);
});

test('app: every write goes through the server action; nothing writes conversations or messages directly', () => {
  const files = ['src/inbox/InboxScreen.tsx', 'src/inbox/ChatScreen.tsx', 'src/inbox/GroupScreens.tsx', 'src/inbox/store.ts'].map(read).join('\n');
  assert.doesNotMatch(files, /addDoc|updateDoc|deleteDoc/, 'no direct document writes');
  const sets = files.split('\n').filter(l => /setDoc\(/.test(l));
  assert.equal(sets.length, 2);
  assert.ok(sets.every(l => /typing|presence/.test(l)), 'the only direct writes are typing and presence stamps');
  assert.match(read('src/inbox/ChatScreen.tsx'), /call\('send', \{cid, text, key: entry\.key/, 'sends carry an idempotency key');
  assert.match(read('src/safety.ts'), /setUnblockHook/);
});

test('credits economy untouched: the Inbox never mentions Credits, purchases or ads', () => {
  const files = ['src/inbox/InboxScreen.tsx', 'src/inbox/ChatScreen.tsx', 'src/inbox/GroupScreens.tsx', 'src/inbox/store.ts', 'src/inbox/api.ts', 'functions/src/inbox.ts'].map(read).join('\n');
  assert.doesNotMatch(files, /earnTokens|spendTokens|balance|watchRewardedAd|purchase|subscription|tokens\//i);
});
