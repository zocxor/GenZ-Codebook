import React from 'react';
import {Modal, Pressable, StyleSheet, Text, View} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {BrandAvatar, C, Glass, Button, Icon, type IconName} from '../ui';
import type {PublicProfile} from '../publicProfile';

export function PeerAvatar({uid, profiles, size = 44}: {uid: string; profiles: Map<string, PublicProfile>; size?: number}) {
  const p = profiles.get(uid);
  return <BrandAvatar index={p?.avatar ?? 0} size={size} photo={p?.photo ?? null} />;
}
export function GroupAvatar({size = 44}: {size?: number}) {
  return <LinearGradient colors={['#3156CF', '#5736BB']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={{width: size, height: size, borderRadius: size / 2, alignItems: 'center', justifyContent: 'center'}}><Icon name="people" size={size * 0.5} color="#fff" /></LinearGradient>;
}
export function CountBadge({n, small = false}: {n: number; small?: boolean}) {
  if (n <= 0) return null;
  return <View accessibilityLabel={`${n} unread`} style={[s.badge, small && {minWidth: 18, height: 18, borderRadius: 9}]}><Text style={[s.badgeText, small && {fontSize: 10.5}]}>{n > 99 ? '99+' : n}</Text></View>;
}
export type SheetAction = {label: string; icon: IconName; danger?: boolean; onPress: () => void};
/** Bottom sheet of actions (Android alerts allow only three buttons, so this is used instead). */
export function ActionSheet({visible, title, actions, onClose, top}: {visible: boolean; title?: string; actions: SheetAction[]; onClose: () => void; top?: React.ReactNode}) {
  return <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
    <Pressable accessibilityLabel="Close menu" style={s.backdrop} onPress={onClose}>
      <Pressable accessible={false} style={s.sheet} onPress={() => undefined}>
        {!!title && <Text style={s.sheetTitle} numberOfLines={1}>{title}</Text>}
        {top}
        {actions.map(a => <Pressable key={a.label} accessibilityRole="button" onPress={() => {onClose(); a.onPress();}} style={({pressed}) => [s.action, pressed && {backgroundColor: C.soft}]}>
          <Icon name={a.icon} size={21} color={a.danger ? C.danger : C.ink} /><Text style={[s.actionText, a.danger && {color: C.danger}]}>{a.label}</Text>
        </Pressable>)}
        <Pressable accessibilityRole="button" onPress={onClose} style={[s.action, {justifyContent: 'center'}]}><Text style={[s.actionText, {color: C.muted}]}>Cancel</Text></Pressable>
      </Pressable>
    </Pressable>
  </Modal>;
}
export function Empty({icon, title, body, action}: {icon: IconName; title: string; body: string; action?: {label: string; onPress: () => void}}) {
  return <Glass style={{alignItems: 'center', gap: 8, paddingVertical: 26}}>
    <Icon name={icon} size={34} color={C.accent} />
    <Text style={s.emptyTitle}>{title}</Text><Text style={s.emptyBody}>{body}</Text>
    {action && <Button title={action.label} onPress={action.onPress} />}
  </Glass>;
}
export function Banner({text, tone = 'info', children}: {text: string; tone?: 'info' | 'warn'; children?: React.ReactNode}) {
  return <View accessibilityRole="alert" style={[s.banner, tone === 'warn' && {backgroundColor: '#FFF4E5', borderColor: '#F5D9A8'}]}><Text style={s.bannerText}>{text}</Text>{children}</View>;
}
const s = StyleSheet.create({
  badge: {minWidth: 22, height: 22, paddingHorizontal: 6, borderRadius: 11, backgroundColor: '#D92D20', alignItems: 'center', justifyContent: 'center'},
  badgeText: {color: '#fff', fontSize: 12, fontWeight: '900'},
  backdrop: {flex: 1, backgroundColor: 'rgba(13,23,54,.45)', justifyContent: 'flex-end'},
  sheet: {backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingTop: 10, paddingBottom: 14, paddingHorizontal: 10, gap: 2},
  sheetTitle: {fontSize: 13, fontWeight: '800', color: C.muted, textAlign: 'center', paddingVertical: 8},
  action: {flexDirection: 'row', alignItems: 'center', gap: 14, minHeight: 52, paddingHorizontal: 14, borderRadius: 14},
  actionText: {fontSize: 16, fontWeight: '800', color: C.ink},
  emptyTitle: {fontSize: 18, fontWeight: '900', color: C.ink, textAlign: 'center'}, emptyBody: {fontSize: 14, color: C.muted, textAlign: 'center', lineHeight: 20},
  banner: {borderRadius: 16, borderWidth: 1, borderColor: '#D1DBEE', backgroundColor: '#EBF1FF', padding: 12, gap: 10},
  bannerText: {fontSize: 14, color: C.ink, fontWeight: '700', lineHeight: 20},
});
