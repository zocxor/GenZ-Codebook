import React, {useEffect, useMemo, useState} from 'react';
import {Modal, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {SafeAreaView} from 'react-native-safe-area-context';
import {C, Button, Chip, Glass, Icon, RoundIcon, Skeleton, confirmAction} from '../ui';
import {useAccountUser} from '../services';
import {usePublicProfiles} from '../publicProfile';
import {VerifiedBadge, useBadges} from '../VerifiedBadge';
import {setUnblockHook, unblockUser} from '../safety';
import {call, inboxError, type FoundUser} from './api';
import {badgeCount, isIncomingRequest, listConversations, peerOf, previewOf, requestsFor, timeLabel, unreadOf, type Conv, type Filter} from './logic';
import {restartInbox, useInboxData, usePresenceBeacon} from './store';
import {ActionSheet, CountBadge, Empty, GroupAvatar, PeerAvatar, type SheetAction} from './parts';
import ChatScreen from './ChatScreen';
import {GroupInfoScreen, NewGroupScreen} from './GroupScreens';

setUnblockHook(uid => {void call('unblock', {uid}).catch(() => undefined);});
export const personalId = (a: string, b: string) => 'p_' + [a, b].sort().join('_');
type Route = {name: 'list'} | {name: 'chat'; cid: string} | {name: 'find'} | {name: 'group-new'} | {name: 'group-info'; cid: string} | {name: 'privacy'};

/** The unread badge for the Community header (shares the Inbox listeners, so it adds no extra reads). */
export function useInboxBadge(): number {
  const user = useAccountUser();
  const uid = user && user.emailVerified ? user.uid : null;
  const d = useInboxData(uid);
  return useMemo(() => uid ? badgeCount(d.convs, d.settings, uid, d.invites) : 0, [d.convs, d.settings, d.invites, uid]);
}

export default function InboxScreen({visible, onClose, onSignIn}: {visible: boolean; onClose: () => void; onSignIn: () => void}) {
  const user = useAccountUser();
  const me = user && user.emailVerified ? user.uid : null;
  const data = useInboxData(me);
  const [route, setRoute] = useState<Route>({name: 'list'});
  useEffect(() => {if (!visible) setRoute({name: 'list'});}, [visible]);
  usePresenceBeacon(me, visible, data.prefs);
  const back = () => {
    if (route.name === 'group-info') {setRoute({name: 'chat', cid: route.cid}); return;}
    if (route.name === 'list') onClose(); else setRoute({name: 'list'});
  };
  const open = (cid: string) => setRoute({name: 'chat', cid});

  return <Modal visible={visible} animationType="slide" onRequestClose={back}>
    <LinearGradient colors={['#FAFBFF', C.bg, '#EAF0FE']} style={{flex: 1}}>
      <SafeAreaView style={{flex: 1}}>
        {!user ? <Gate title="Sign in to message" body="Messages and groups need a GenZ Codebook account." action="Sign in" onAction={() => {onClose(); onSignIn();}} onClose={onClose} />
          : !me ? <Gate title="Verify your e-mail" body="Verify your e-mail address to use the Inbox, then reopen it." action="Close" onAction={onClose} onClose={onClose} />
          : route.name === 'list' ? <InboxList me={me} data={data} onClose={onClose} onOpen={open} onFind={() => setRoute({name: 'find'})} onNewGroup={() => setRoute({name: 'group-new'})} onPrivacy={() => setRoute({name: 'privacy'})} />
          : route.name === 'chat' ? <ChatScreen key={route.cid} me={me} cid={route.cid} data={data} onBack={back} onInfo={() => setRoute({name: 'group-info', cid: route.cid})} />
          : route.name === 'find' ? <FindScreen me={me} onBack={back} mode="message" onMessage={u => open(personalId(me, u.uid))} />
          : route.name === 'group-new' ? <NewGroupScreen me={me} onBack={back} onCreated={open} />
          : route.name === 'group-info' ? <GroupInfoScreen me={me} cid={route.cid} data={data} onBack={back} onLeft={() => setRoute({name: 'list'})} onOpenChat={open} />
          : <PrivacyScreen me={me} data={data} onBack={back} />}
      </SafeAreaView>
    </LinearGradient>
  </Modal>;
}

function Gate({title, body, action, onAction, onClose}: {title: string; body: string; action: string; onAction: () => void; onClose: () => void}) {
  return <View style={{padding: 18, gap: 14}}><Header title="Inbox" onBack={onClose} /><Glass style={{gap: 10}}><Text style={s.h2}>{title}</Text><Text style={s.body}>{body}</Text><Button title={action} onPress={onAction} /></Glass></View>;
}
export function Header({title, onBack, right, sub}: {title: string; onBack: () => void; right?: React.ReactNode; sub?: string}) {
  return <View style={s.header}><RoundIcon name="arrow-back" label="Go back" onPress={onBack} /><View style={{flex: 1}}><Text accessibilityRole="header" style={s.title} numberOfLines={1}>{title}</Text>{!!sub && <Text style={s.sub} numberOfLines={1}>{sub}</Text>}</View>{right}</View>;
}

type InboxData = ReturnType<typeof useInboxData>;
function InboxList({me, data, onClose, onOpen, onFind, onNewGroup, onPrivacy}: {me: string; data: InboxData; onClose: () => void; onOpen: (cid: string) => void; onFind: () => void; onNewGroup: () => void; onPrivacy: () => void}) {
  const [tab, setTab] = useState<'personal' | 'group'>('personal');
  const [filter, setFilter] = useState<Filter>('all');
  const [search, setSearch] = useState('');
  const [menu, setMenu] = useState<Conv | null>(null);
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const uids = useMemo(() => [...new Set(data.convs.flatMap(c => c.type === 'personal' ? [peerOf(c, me)] : c.lastMessage ? [c.lastMessage.uid] : []).concat(data.invites.map(i => i.by)))], [data.convs, data.invites, me]);
  const profiles = usePublicProfiles(uids);
  const badges = useBadges(uids);
  const names = useMemo(() => new Map([...profiles].map(([u, p]) => [u, p.name])), [profiles]);
  const nameOf = (u: string) => names.get(u) ?? 'Someone';
  const rows = useMemo(() => listConversations(data.convs, data.settings, me, {tab, filter, search, names}), [data.convs, data.settings, me, tab, filter, search, names]);
  const requests = useMemo(() => requestsFor(data.convs, me), [data.convs, me]);
  const personalUnread = data.convs.filter(c => c.type === 'personal' && (isIncomingRequest(c, me) || (!data.settings.get(c.id)?.muted && unreadOf(c, me) > 0))).length;
  const groupUnread = data.convs.filter(c => c.type === 'group' && !data.settings.get(c.id)?.muted && unreadOf(c, me) > 0).length + data.invites.length;

  const run = async (label: string, fn: () => Promise<unknown>) => {
    setBusy(label); setError('');
    try {await fn();} catch (e) {setError(inboxError(e));} finally {setBusy('');}
  };
  const setting = (c: Conv, patch: Record<string, boolean>) => run('settings', () => call('settings', {cid: c.id, ...patch}));
  const actionsFor = (c: Conv): SheetAction[] => {
    const st = data.settings.get(c.id) ?? {};
    const list: SheetAction[] = [
      {label: st.pinned ? 'Unpin' : 'Pin to top', icon: st.pinned ? 'pin-outline' : 'pin', onPress: () => void setting(c, {pinned: !st.pinned})},
      {label: st.muted ? 'Unmute' : 'Mute', icon: st.muted ? 'notifications-outline' : 'notifications-off-outline', onPress: () => void setting(c, {muted: !st.muted})},
      {label: st.archived ? 'Unarchive' : 'Archive', icon: 'archive-outline', onPress: () => void setting(c, {archived: !st.archived})},
    ];
    if (c.type === 'personal') list.push({label: 'Delete chat', icon: 'trash-outline', danger: true, onPress: () => confirmAction('Delete this chat?', 'It disappears from your Inbox. The other person keeps their copy. New messages will bring it back.', () => void run('delete', () => call('delete-conversation', {cid: c.id})), 'Delete')});
    else if (c.status === 'open') list.push({label: 'Leave group', icon: 'exit-outline', danger: true, onPress: () => confirmAction('Leave this group?', 'You will stop receiving its messages. You need a new invitation to come back.', () => void run('leave', () => call('group-leave', {cid: c.id})), 'Leave')});
    return list;
  };
  const answer = (c: Conv, accept: boolean) => run('respond', () => call('respond', {cid: c.id, accept}));
  const answerInvite = (cid: string, accept: boolean) => run('invite', () => call('group-respond', {cid, accept}));

  return <View style={{flex: 1}}>
    <Header title="Inbox" onBack={onClose} right={<View style={{flexDirection: 'row', gap: 8}}><RoundIcon name="create-outline" label="New message" onPress={onFind} /><RoundIcon name="shield-checkmark-outline" label="Message privacy and blocked people" onPress={onPrivacy} /></View>} />
    <View style={s.tabs} accessibilityRole="tablist">
      {(['personal', 'group'] as const).map(t => <Pressable key={t} accessibilityRole="tab" accessibilityState={{selected: tab === t}} onPress={() => setTab(t)} style={s.tabPress}>
        {tab === t && <LinearGradient colors={['#3156CF', '#5736BB']} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={StyleSheet.absoluteFill} />}
        <Icon name={t === 'personal' ? 'person-outline' : 'people-outline'} size={18} color={tab === t ? '#fff' : C.muted} />
        <Text style={[s.tabText, tab === t && {color: '#fff'}]}>{t === 'personal' ? 'Personal' : 'Groups'}</Text>
        <CountBadge n={t === 'personal' ? personalUnread : groupUnread} small />
      </Pressable>)}
    </View>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{padding: 16, gap: 12, paddingBottom: 30}}>
      <View style={s.searchRow}><Icon name="search" size={18} color={C.muted} /><TextInput accessibilityLabel="Search conversations" value={search} onChangeText={setSearch} placeholder="Search conversations" placeholderTextColor="#7A88A6" style={s.search} />{!!search && <Pressable accessibilityLabel="Clear search" onPress={() => setSearch('')} hitSlop={8}><Icon name="close-circle" size={18} color={C.muted} /></Pressable>}</View>
      <View style={{flexDirection: 'row', gap: 8, flexWrap: 'wrap'}}>{(['all', 'unread', 'archived'] as const).map(f => <Chip key={f} label={f === 'all' ? 'All' : f === 'unread' ? 'Unread' : 'Archived'} selected={filter === f} onPress={() => setFilter(f)} />)}</View>
      {!!error && <Text accessibilityRole="alert" style={s.error}>{error}</Text>}
      {!!data.error && <Glass style={{gap: 8}}><Text style={s.error}>{data.error}</Text><Button light title="Try again" icon="refresh" onPress={restartInbox} /></Glass>}
      {tab === 'group' && <Button title="Create group" icon="add-circle-outline" onPress={onNewGroup} />}
      {tab === 'personal' && requests.length > 0 && filter === 'all' && <View style={{gap: 8}}>
        <Text style={s.section}>Message requests</Text>
        {requests.map(c => {
          const u = peerOf(c, me);
          return <Glass key={c.id} style={{gap: 10}}>
            <Pressable accessibilityRole="button" accessibilityLabel={`Open request from ${nameOf(u)}`} onPress={() => onOpen(c.id)} style={s.rowTop}><PeerAvatar uid={u} profiles={profiles} /><View style={{flex: 1}}><View style={s.nameLine}><Text style={s.name} numberOfLines={1}>{nameOf(u)}</Text><VerifiedBadge verified={badges.has(u)} tier={badges.tier(u)} size={16} /></View><Text style={s.preview} numberOfLines={2}>{c.lastMessage?.text ?? 'Wants to message you'}</Text></View></Pressable>
            <View style={{flexDirection: 'row', gap: 10}}><View style={{flex: 1}}><Button title="Accept" icon="checkmark" disabled={!!busy} onPress={() => void answer(c, true)} /></View><View style={{flex: 1}}><Button light title="Decline" icon="close" disabled={!!busy} onPress={() => void answer(c, false)} /></View></View>
          </Glass>;
        })}
      </View>}
      {tab === 'group' && data.invites.length > 0 && filter === 'all' && <View style={{gap: 8}}>
        <Text style={s.section}>Invitations</Text>
        {data.invites.map(i => <Glass key={i.id} style={{gap: 10}}>
          <View style={s.rowTop}><GroupAvatar /><View style={{flex: 1}}><Text style={s.name} numberOfLines={1}>{i.name}</Text><Text style={s.preview}>Invited by {nameOf(i.by)}</Text></View></View>
          <View style={{flexDirection: 'row', gap: 10}}><View style={{flex: 1}}><Button title="Join" icon="checkmark" disabled={!!busy} onPress={() => void answerInvite(i.cid, true)} /></View><View style={{flex: 1}}><Button light title="Decline" icon="close" disabled={!!busy} onPress={() => void answerInvite(i.cid, false)} /></View></View>
        </Glass>)}
      </View>}
      {!data.ready ? <View style={{gap: 10}}>{[0, 1, 2, 3].map(i => <Skeleton key={i} height={72} radius={18} />)}</View>
        : rows.length === 0 ? (search || filter !== 'all'
            ? <Empty icon="search" title={filter === 'unread' ? 'No unread conversations' : filter === 'archived' ? 'Nothing archived' : 'No matches'} body={search ? 'Try a different name.' : 'You’re all caught up.'} />
            : tab === 'personal' && requests.length === 0 ? <Empty icon="chatbubbles-outline" title="No conversations yet" body="Find a friend by name or user code and say hi. They’ll get a message request first." action={{label: 'Find someone', onPress: onFind}} />
            : tab === 'group' && data.invites.length === 0 ? <Empty icon="people-outline" title="No groups yet" body="Create a private group to share codes and slang with friends." />
            : null)
          : rows.map(c => {
            const st = data.settings.get(c.id) ?? {}, u = peerOf(c, me), unread = unreadOf(c, me);
            const title = c.type === 'group' ? c.name ?? 'Group' : nameOf(u);
            return <Pressable key={c.id} accessibilityRole="button" accessibilityLabel={`${title}${unread ? `, ${unread} unread` : ''}`} onPress={() => onOpen(c.id)} onLongPress={() => setMenu(c)} style={({pressed}) => [s.row, pressed && {opacity: 0.85}]}>
              {c.type === 'group' ? <GroupAvatar /> : <PeerAvatar uid={u} profiles={profiles} />}
              <View style={{flex: 1, gap: 2}}>
                <View style={s.nameLine}>
                  <Text style={[s.name, unread > 0 && {fontWeight: '900'}]} numberOfLines={1}>{title}</Text>
                  {c.type === 'personal' && <VerifiedBadge verified={badges.has(u)} tier={badges.tier(u)} size={16} />}
                  {st.pinned && <Icon name="pin" size={13} color={C.muted} />}{st.muted && <Icon name="notifications-off" size={13} color={C.muted} />}
                  <Text style={s.time}>{timeLabel(c.lastAt)}</Text>
                </View>
                <View style={s.nameLine}>
                  <Text style={[s.preview, {flex: 1}, unread > 0 && {color: C.ink, fontWeight: '800'}]} numberOfLines={1}>{c.status === 'closed' ? 'This group is closed' : c.state === 'request' ? 'Waiting for them to accept' : c.state === 'rejected' ? 'Request declined' : previewOf(c, me, nameOf)}</Text>
                  {c.type === 'group' && <Text style={s.time}>{c.participants.length} members</Text>}
                  <CountBadge n={unread} />
                </View>
              </View>
              <Pressable accessibilityRole="button" accessibilityLabel={`More options for ${title}`} hitSlop={10} onPress={() => setMenu(c)}><Icon name="ellipsis-vertical" size={18} color={C.muted} /></Pressable>
            </Pressable>;
          })}
    </ScrollView>
    <ActionSheet visible={!!menu} title={menu ? (menu.type === 'group' ? menu.name : nameOf(peerOf(menu, me))) : ''} actions={menu ? actionsFor(menu) : []} onClose={() => setMenu(null)} />
  </View>;
}

/** Find people by name or user code. mode "message" opens a chat; mode "pick" collects people for a group. */
export function FindScreen({me, onBack, mode, onMessage, picked, onToggle, title}: {me: string; onBack: () => void; mode: 'message' | 'pick'; onMessage?: (u: FoundUser) => void; picked?: Map<string, FoundUser>; onToggle?: (u: FoundUser) => void; title?: string}) {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<FoundUser[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const badges = useBadges((results ?? []).map(r => r.uid));
  const profiles = usePublicProfiles((results ?? []).map(r => r.uid));
  const search = async () => {
    if (q.trim().length < 2 || busy) return;
    setBusy(true); setError('');
    try {setResults((await call<{users: FoundUser[]}>('find', {q})).users);} catch (e) {setError(inboxError(e)); setResults(null);} finally {setBusy(false);}
  };
  return <View style={{flex: 1}}>
    <Header title={title ?? 'New message'} onBack={onBack} />
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{padding: 16, gap: 12}}>
      <View style={s.searchRow}><Icon name="search" size={18} color={C.muted} /><TextInput accessibilityLabel="Search by name or user code" autoFocus value={q} onChangeText={setQ} onSubmitEditing={() => void search()} returnKeyType="search" autoCapitalize="none" maxLength={30} placeholder="Name or user code (GZ…)" placeholderTextColor="#7A88A6" style={s.search} /></View>
      <Button title={busy ? 'Searching…' : 'Search'} icon="search" disabled={busy || q.trim().length < 2} onPress={() => void search()} />
      {!!error && <Text accessibilityRole="alert" style={s.error}>{error}</Text>}
      {results && results.length === 0 && <Empty icon="person-outline" title="No one found" body="Check the spelling, or ask your friend for their user code (it’s on their You page)." />}
      {(results ?? []).map(u => {
        const on = !!picked?.has(u.uid), p = profiles.get(u.uid);
        return <Glass key={u.uid} style={{flexDirection: 'row', alignItems: 'center', gap: 12}}>
          <PeerAvatar uid={u.uid} profiles={profiles} />
          <View style={{flex: 1}}><View style={s.nameLine}><Text style={s.name} numberOfLines={1}>{p?.name ?? u.name}</Text><VerifiedBadge verified={u.verified || badges.has(u.uid)} tier={badges.tier(u.uid)} size={16} /></View>
            <Text style={s.preview}>{u.canMessage === 'nobody' ? 'Not accepting messages' : u.canMessage === 'request' ? 'Message request needed' : 'Open to messages'}</Text></View>
          {mode === 'message'
            ? <Button light title="Message" disabled={u.canMessage === 'nobody'} onPress={() => onMessage?.(u)} />
            : <Button light title={on ? 'Added ✓' : 'Add'} onPress={() => onToggle?.(u)} />}
        </Glass>;
      })}
      <Text style={s.fine}>You can’t see who has blocked you, and people who have turned messages off can’t be messaged.</Text>
    </ScrollView>
  </View>;
}

function PrivacyScreen({me, data, onBack}: {me: string; data: InboxData; onBack: () => void}) {
  const [error, setError] = useState('');
  const profiles = usePublicProfiles(data.blocked);
  const save = async (patch: Record<string, unknown>) => {setError(''); try {await call('prefs', patch);} catch (e) {setError(inboxError(e));}};
  const WHO: {id: 'everyone' | 'requests' | 'nobody'; label: string; hint: string}[] = [
    {id: 'requests', label: 'People I accept', hint: 'New people send a message request first (recommended).'},
    {id: 'everyone', label: 'Everyone', hint: 'Anyone can message you directly.'},
    {id: 'nobody', label: 'Nobody', hint: 'No one can start a new chat with you.'},
  ];
  void me;
  return <View style={{flex: 1}}>
    <Header title="Message privacy" onBack={onBack} />
    <ScrollView contentContainerStyle={{padding: 16, gap: 12}}>
      {!!error && <Text accessibilityRole="alert" style={s.error}>{error}</Text>}
      <Glass style={{gap: 6}}>
        <Text style={s.h2}>Who can message me</Text>
        {WHO.map(o => <Pressable key={o.id} accessibilityRole="radio" accessibilityState={{checked: data.prefs.whoCanMessage === o.id}} onPress={() => void save({whoCanMessage: o.id})} style={s.optRow}>
          <Icon name={data.prefs.whoCanMessage === o.id ? 'radio-button-on' : 'radio-button-off'} size={22} color={C.accent} /><View style={{flex: 1}}><Text style={s.name}>{o.label}</Text><Text style={s.preview}>{o.hint}</Text></View></Pressable>)}
      </Glass>
      <Glass style={{gap: 6}}>
        <Text style={s.h2}>Status</Text>
        <View style={s.optRow}><View style={{flex: 1}}><Text style={s.name}>Show when I’m online</Text></View><Switch accessibilityLabel="Show when I’m online" value={data.prefs.showOnline} onValueChange={v => void save({showOnline: v})} /></View>
        <View style={s.optRow}><View style={{flex: 1}}><Text style={s.name}>Show my last seen</Text></View><Switch accessibilityLabel="Show my last seen" value={data.prefs.showLastSeen} onValueChange={v => void save({showLastSeen: v})} /></View>
      </Glass>
      <Glass style={{gap: 8}}>
        <Text style={s.h2}>Blocked people</Text>
        {data.blocked.length === 0 && <Text style={s.body}>You haven’t blocked anyone in messages.</Text>}
        {data.blocked.map(u => <View key={u} style={s.optRow}><PeerAvatar uid={u} profiles={profiles} size={36} /><Text style={[s.name, {flex: 1}]} numberOfLines={1}>{profiles.get(u)?.name ?? 'Member'}</Text><Button light title="Unblock" onPress={() => {unblockUser(u); void call('unblock', {uid: u}).catch(e => setError(inboxError(e)));}} /></View>)}
      </Glass>
    </ScrollView>
  </View>;
}

const s = StyleSheet.create({
  header: {flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 16, paddingTop: 6, paddingBottom: 6},
  title: {fontSize: 24, fontWeight: '900', color: C.navy, letterSpacing: -0.5}, sub: {fontSize: 12.5, color: C.muted, fontWeight: '700'},
  h2: {fontSize: 17, fontWeight: '900', color: C.ink}, body: {fontSize: 14, color: C.muted, lineHeight: 20},
  tabs: {flexDirection: 'row', marginHorizontal: 16, marginTop: 4, padding: 4, borderRadius: 18, backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#DCE8F5'},
  tabPress: {flex: 1, minHeight: 44, borderRadius: 14, overflow: 'hidden', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7},
  tabText: {fontSize: 15, fontWeight: '800', color: C.muted},
  searchRow: {flexDirection: 'row', alignItems: 'center', gap: 8, minHeight: 46, paddingHorizontal: 14, borderRadius: 16, backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#DCE8F5'},
  search: {flex: 1, fontSize: 15, color: C.ink, paddingVertical: 8},
  section: {fontSize: 13, fontWeight: '900', color: C.muted, textTransform: 'uppercase', letterSpacing: 0.6, paddingHorizontal: 4},
  row: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 20, backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#DCE8F5'},
  rowTop: {flexDirection: 'row', alignItems: 'center', gap: 12},
  nameLine: {flexDirection: 'row', alignItems: 'center', gap: 5},
  name: {fontSize: 16, fontWeight: '800', color: C.ink, flexShrink: 1}, preview: {fontSize: 13.5, color: C.muted},
  time: {marginLeft: 'auto', fontSize: 12, color: C.muted, fontWeight: '700'},
  error: {fontSize: 13.5, color: C.danger, fontWeight: '700'}, fine: {fontSize: 12.5, color: C.muted, textAlign: 'center', lineHeight: 18},
  optRow: {flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 48, paddingVertical: 4},
});
