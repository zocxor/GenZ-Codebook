/** Realtime Inbox data. One shared set of listeners (conversations, my settings, invitations, privacy) that
 *  starts when the first screen needs it and stops when nobody does, so the badge and the Inbox share reads. */
import {useEffect, useRef, useState, useSyncExternalStore} from 'react';
import {collection, doc, getDocs, limit, onSnapshot, orderBy, query, serverTimestamp, setDoc, startAfter, where, type Unsubscribe} from 'firebase/firestore';
import {cloudDbLive} from '../firebase/app';
import {ms, type Conv, type Invite, type Settings} from './logic';
import type {MessageRow} from './api';

export type Prefs = {whoCanMessage: 'everyone' | 'requests' | 'nobody'; showOnline: boolean; showLastSeen: boolean};
type State = {uid: string; convs: Conv[]; settings: Map<string, Settings>; invites: Invite[]; blocked: string[]; prefs: Prefs; ready: boolean; error: string};
const DEFAULT_PREFS: Prefs = {whoCanMessage: 'requests', showOnline: true, showLastSeen: true};
const empty = (uid = ''): State => ({uid, convs: [], settings: new Map(), invites: [], blocked: [], prefs: DEFAULT_PREFS, ready: false, error: ''});
let state = empty();
let stops: Unsubscribe[] = [];
let users = 0;
const listeners = new Set<() => void>();
const publish = (patch: Partial<State>) => {state = {...state, ...patch}; listeners.forEach(f => f());};

function start(uid: string) {
  stop();
  state = empty(uid);
  const db = cloudDbLive();
  const fail = (e: unknown) => publish({error: (e as {code?: string})?.code === 'permission-denied' ? 'The Inbox isn’t switched on on the server yet.' : 'Couldn’t load your Inbox. Check your connection.', ready: true});
  stops = [
    onSnapshot(query(collection(db, 'conversations'), where('participants', 'array-contains', uid), orderBy('lastAt', 'desc'), limit(60)), snap => publish({
      ready: true, error: '',
      convs: snap.docs.map(d => {const x = d.data(); return {...x, id: d.id, seq: x.seq ?? 0, reads: x.reads ?? {}, lastAt: ms(x.lastAt)} as Conv;}),
    }), fail),
    onSnapshot(query(collection(db, `users/${uid}/inbox`), limit(300)), snap => publish({
      settings: new Map(snap.docs.map(d => {const x = d.data(); return [d.id, {...x, clearedAt: ms(x.clearedAt)} as Settings];})),
    }), () => undefined),
    onSnapshot(query(collection(db, 'groupInvites'), where('uid', '==', uid)), snap => publish({invites: snap.docs.map(d => ({id: d.id, cid: d.get('cid'), by: d.get('by'), name: d.get('name')}))}), () => undefined),
    onSnapshot(query(collection(db, `users/${uid}/inboxBlocks`), limit(200)), snap => publish({blocked: snap.docs.map(d => d.id)}), () => undefined),
    onSnapshot(doc(db, `messagingPrefs/${uid}`), snap => publish({prefs: snap.exists() ? {...DEFAULT_PREFS, ...(snap.data() as Partial<Prefs>)} : DEFAULT_PREFS}), () => undefined),
  ];
}
/** Retry after an error: start the listeners again. */
export const restartInbox = () => {if (state.uid && users > 0) start(state.uid);};
function stop() {stops.forEach(f => {try {f();} catch {/* ignore */}}); stops = [];}

/** Inbox data for a signed-in person. Pass null when signed out (nothing is listened to). */
export function useInboxData(uid: string | null): State {
  useEffect(() => {
    if (!uid) return;
    users++;
    if (state.uid !== uid || !stops.length) start(uid);
    return () => {users--; if (users <= 0) {users = 0; stop(); state = empty();}};
  }, [uid]);
  const snap = useSyncExternalStore(cb => {listeners.add(cb); return () => {listeners.delete(cb);};}, () => state);
  return uid && snap.uid === uid ? snap : empty(uid ?? '');
}

const toMessage = (d: {id: string; data: () => Record<string, unknown>}): MessageRow => {const x = d.data(); return {...x, id: d.id, createdAt: ms(x.createdAt) || Date.now(), reactions: (x.reactions ?? {}) as Record<string, string[]>} as MessageRow;};
export const PAGE = 30;
/** Newest messages live; older ones are loaded in pages (not re-read on every new message). */
export function useMessages(cid: string | null) {
  const [live, setLive] = useState<MessageRow[]>([]);
  const [older, setOlder] = useState<MessageRow[]>([]);
  const [state2, setState2] = useState<{loading: boolean; error: string; more: boolean; loadingMore: boolean}>({loading: true, error: '', more: true, loadingMore: false});
  const oldestSeq = useRef(Infinity);
  useEffect(() => {
    setLive([]); setOlder([]); oldestSeq.current = Infinity; setState2({loading: true, error: '', more: true, loadingMore: false});
    if (!cid) {setState2(s => ({...s, loading: false, more: false})); return;}
    return onSnapshot(query(collection(cloudDbLive(), `conversations/${cid}/messages`), orderBy('seq', 'desc'), limit(PAGE)), snap => {
      const rows = snap.docs.map(toMessage);
      setLive(rows);
      if (oldestSeq.current === Infinity) oldestSeq.current = rows.length ? rows[rows.length - 1]!.seq : 0;
      setState2(s => ({...s, loading: false, error: '', more: s.more && snap.size >= PAGE}));
    }, e => setState2(s => ({...s, loading: false, error: (e as {code?: string})?.code === 'permission-denied' ? 'You don’t have access to this conversation.' : 'Couldn’t load messages. Check your connection.'})));
  }, [cid]);
  const loadOlder = async () => {
    if (!cid || state2.loadingMore || !state2.more || oldestSeq.current === Infinity || oldestSeq.current <= 1) return;
    setState2(s => ({...s, loadingMore: true}));
    try {
      const snap = await getDocs(query(collection(cloudDbLive(), `conversations/${cid}/messages`), orderBy('seq', 'desc'), startAfter(oldestSeq.current), limit(PAGE)));
      const rows = snap.docs.map(toMessage);
      if (rows.length) oldestSeq.current = rows[rows.length - 1]!.seq;
      setOlder(prev => [...prev, ...rows]);
      setState2(s => ({...s, loadingMore: false, more: rows.length >= PAGE}));
    } catch {setState2(s => ({...s, loadingMore: false, error: 'Couldn’t load older messages.'}));}
  };
  const seen = new Set<string>();
  const messages = [...live, ...older].filter(m => !seen.has(m.id) && !!seen.add(m.id)).sort((a, b) => b.seq - a.seq);   // newest first (inverted list)
  return {messages, ...state2, loadOlder};
}

/** Who is typing in this conversation (stamps expire after 6 seconds) and a throttled way to say "I am typing". */
export function useTyping(cid: string | null, me: string) {
  const [stamps, setStamps] = useState<Record<string, unknown>>({});
  const [, tick] = useState(0);
  const last = useRef(0);
  useEffect(() => {
    setStamps({});
    if (!cid) return;
    const stopSnap = onSnapshot(collection(cloudDbLive(), `conversations/${cid}/typing`), snap => setStamps(Object.fromEntries(snap.docs.map(d => [d.id, d.get('at')]))), () => undefined);
    const timer = setInterval(() => tick(n => n + 1), 2000);
    return () => {stopSnap(); clearInterval(timer);};
  }, [cid]);
  const sendTyping = () => {
    if (!cid || Date.now() - last.current < 3000) return;
    last.current = Date.now();
    void setDoc(doc(cloudDbLive(), `conversations/${cid}/typing/${me}`), {at: serverTimestamp()}).catch(() => undefined);
  };
  return {stamps, sendTyping};
}

export function usePresence(uid: string | null) {
  const [p, setP] = useState<{at?: unknown; online?: boolean; seen?: boolean} | null>(null);
  const [, tick] = useState(0);
  useEffect(() => {
    setP(null);
    if (!uid) return;
    const stopSnap = onSnapshot(doc(cloudDbLive(), `presence/${uid}`), s => setP(s.exists() ? s.data() as {at?: unknown; online?: boolean; seen?: boolean} : null), () => undefined);
    const timer = setInterval(() => tick(n => n + 1), 30_000);
    return () => {stopSnap(); clearInterval(timer);};
  }, [uid]);
  return p;
}
/** While the Inbox is open, tell others I am around (every 2 minutes), unless I hid both online and last seen. */
export function usePresenceBeacon(uid: string | null, on: boolean, prefs: Prefs) {
  useEffect(() => {
    if (!uid || !on || (!prefs.showOnline && !prefs.showLastSeen)) return;
    const ping = () => void setDoc(doc(cloudDbLive(), `presence/${uid}`), {at: serverTimestamp()}, {merge: true}).catch(() => undefined);
    ping();
    const t = setInterval(ping, 120_000);
    return () => clearInterval(t);
  }, [uid, on, prefs.showOnline, prefs.showLastSeen]);
}
