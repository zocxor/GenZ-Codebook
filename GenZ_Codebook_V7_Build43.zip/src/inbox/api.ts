import {feature, errorOf} from '../communityFeatures';

/** Calls the server for an Inbox action (the server enforces every rule; the app only asks). */
export const call = <T = Record<string, unknown>>(action: string, data: Record<string, unknown> = {}) => feature('inbox-' + action, data) as unknown as Promise<T>;
export const inboxError = (e: unknown): string => {
  const m = errorOf(e);
  return /Credit service/.test(m) ? 'Messaging is unavailable right now. Check your connection and try again.' : m;
};
export const REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🙏'];
export const QUICK_EMOJI = ['😀', '😂', '🤣', '😍', '😎', '🥹', '😭', '😅', '🤔', '🙌', '👏', '🔥', '💯', '✨', '💀', '🫶', '👀', '🎉', '💙', '🙏'];
export const REPORT_REASONS = ['Spam', 'Harassment or bullying', 'Offensive or harmful', 'Inappropriate content', 'Impersonation', 'Other'];
export type FoundUser = {uid: string; name: string; avatar: number; verified: boolean; canMessage: 'ok' | 'request' | 'nobody'};
export type MessageRow = {id: string; uid: string; text: string; type: 'text' | 'system'; seq: number; createdAt: number; status: 'live' | 'removed'; reactions: Record<string, string[]>; replyTo?: {id: string; uid: string; text: string} | null};
