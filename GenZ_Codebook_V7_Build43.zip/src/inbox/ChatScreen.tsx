import React, {useEffect, useMemo, useRef, useState} from 'react';
import {ActivityIndicator, AppState, FlatList, Pressable, StyleSheet, Text, TextInput, View} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Button, Icon, confirmAction} from '../ui';
import {KeyboardDock} from '../KeyboardDock';
import {usePublicProfiles} from '../publicProfile';
import {VerifiedBadge, useBadges} from '../VerifiedBadge';
import {blockUser, unblockUser} from '../safety';
import {call, inboxError, QUICK_EMOJI, REACTIONS, REPORT_REASONS, type MessageRow} from './api';
import {canModerate, newKey, peerOf, presenceText, tickOf, timeLabel, typingActive, unreadOf, visibleMessages} from './logic';
import {PAGE, restartInbox, usePresence, useMessages, useTyping, type useInboxData} from './store';
import {ActionSheet, Banner, GroupAvatar, PeerAvatar, type SheetAction} from './parts';
import {Header} from './InboxScreen';

type Pending = {pending: true; key: string; text: string; replyTo: string | null; status: 'sending' | 'failed'; error?: string};
type Item = MessageRow | Pending;
const isPending = (i: Item): i is Pending => (i as Pending).pending === true;
const MAX = 500;

export default function ChatScreen({me, cid, data, onBack, onInfo}: {me: string; cid: string; data: ReturnType<typeof useInboxData>; onBack: () => void; onInfo: () => void}) {
  const isGroup = cid.startsWith('g_');
  const conv = data.convs.find(c => c.id === cid);
  const peer = isGroup ? '' : cid.slice(2).split('_').find(u => u !== me) ?? '';
  const settings = data.settings.get(cid);
  const {messages, loading, error: loadError, more, loadingMore, loadOlder} = useMessages(conv ? cid : null);
  const members = useMemo(() => isGroup ? (conv?.participants ?? []) : [peer], [isGroup, conv?.participants, peer]);
  const profiles = usePublicProfiles(members);
  const badges = useBadges(isGroup ? [] : [peer]);
  const nameOf = (u: string) => u === me ? 'You' : profiles.get(u)?.name ?? 'Member';
  const presence = usePresence(isGroup ? null : peer);
  const {stamps, sendTyping} = useTyping(conv ? cid : null, me);
  const typers = typingActive(stamps, me);

  const [draft, setDraft] = useState('');
  const [reply, setReply] = useState<MessageRow | null>(null);
  const [outbox, setOutbox] = useState<Pending[]>([]);
  const [emoji, setEmoji] = useState(false);
  const [menu, setMenu] = useState<MessageRow | null>(null);
  const [head, setHead] = useState(false);
  const [reporting, setReporting] = useState<{mid?: string; uid?: string} | null>(null);
  const [notice, setNotice] = useState('');
  const [actionError, setActionError] = useState('');
  const sending = useRef(false);

  // Read receipts: tell the server once I have seen the latest message (only while the app is in front).
  const unread = conv ? unreadOf(conv, me) : 0;
  useEffect(() => {
    if (!conv || unread === 0 || AppState.currentState !== 'active') return;
    const t = setTimeout(() => void call('read', {cid}).catch(() => undefined), 900);
    return () => clearTimeout(t);
  }, [cid, conv?.seq, unread]);   // eslint-disable-line react-hooks/exhaustive-deps

  const items: Item[] = useMemo(() => {
    const shown = visibleMessages(messages, settings) as MessageRow[];
    return [...outbox, ...shown];
  }, [messages, settings, outbox]);

  const send = async (again?: Pending) => {
    const text = (again?.text ?? draft).trim();
    if (!text || sending.current) return;
    const entry: Pending = again ? {...again, status: 'sending', error: undefined} : {pending: true, key: newKey(), text, replyTo: reply?.id ?? null, status: 'sending'};
    sending.current = true;
    if (!again) {setDraft(''); setReply(null); setEmoji(false);}
    setOutbox(list => [entry, ...list.filter(x => x.key !== entry.key)]);
    try {
      await call('send', {cid, text, key: entry.key, ...(entry.replyTo ? {replyTo: entry.replyTo} : {})});
      setOutbox(list => list.filter(x => x.key !== entry.key));
    } catch (e) {
      setOutbox(list => list.map(x => x.key === entry.key ? {...x, status: 'failed', error: inboxError(e)} : x));
    } finally {sending.current = false;}
  };

  const guard = (fn: () => Promise<unknown>) => async () => {setActionError(''); try {await fn();} catch (e) {setActionError(inboxError(e));}};
  const blockedByMe = !isGroup && data.blocked.includes(peer);
  const incoming = !isGroup && conv?.state === 'request' && conv.requester !== me;
  const waiting = !isGroup && conv?.state === 'request' && conv.requester === me && !!conv.lastMessage;
  const declined = !isGroup && conv?.state === 'rejected' && conv.requester === me;
  const closed = isGroup && (conv?.status === 'closed' || conv?.status === 'deleted');
  const gone = isGroup && data.ready && !conv;
  const canWrite = !blockedByMe && !incoming && !waiting && !declined && !closed && !gone;
  const title = isGroup ? conv?.name ?? 'Group' : nameOf(peer);
  const sub = typers.length ? (isGroup ? `${typers.map(nameOf).slice(0, 2).join(', ')} typing…` : 'typing…') : isGroup ? `${conv?.participants.length ?? 0} members` : presenceText(presence);

  const headActions: SheetAction[] = [];
  const st = settings ?? {};
  if (isGroup) headActions.push({label: 'Group info and members', icon: 'information-circle-outline', onPress: onInfo});
  headActions.push({label: st.muted ? 'Unmute' : 'Mute notifications', icon: st.muted ? 'notifications-outline' : 'notifications-off-outline', onPress: guard(() => call('settings', {cid, muted: !st.muted}))});
  headActions.push({label: st.archived ? 'Unarchive' : 'Archive', icon: 'archive-outline', onPress: guard(() => call('settings', {cid, archived: !st.archived}))});
  if (!isGroup) {
    headActions.push(blockedByMe
      ? {label: 'Unblock', icon: 'lock-open-outline', onPress: () => unblockUser(peer)}
      : {label: 'Block', icon: 'ban-outline', danger: true, onPress: () => blockUser(peer, nameOf(peer), ok => {if (ok) void guard(() => call('block', {uid: peer}))();})});
    headActions.push({label: 'Report this person', icon: 'flag-outline', danger: true, onPress: () => setReporting({uid: peer})});
    headActions.push({label: 'Delete chat', icon: 'trash-outline', danger: true, onPress: () => confirmAction('Delete this chat?', 'It disappears from your Inbox. The other person keeps their copy.', () => {void guard(() => call('delete-conversation', {cid}))().then(onBack);}, 'Delete')});
  } else if (conv?.status === 'open') {
    headActions.push({label: 'Leave group', icon: 'exit-outline', danger: true, onPress: () => confirmAction('Leave this group?', 'You need a new invitation to come back.', () => {void guard(() => call('group-leave', {cid}))().then(onBack);}, 'Leave')});
  }

  const messageActions = (m: MessageRow): SheetAction[] => {
    const mine = m.uid === me, list: SheetAction[] = [];
    if (m.status === 'live') {
      if (canWrite) list.push({label: 'Reply', icon: 'arrow-undo-outline', onPress: () => setReply(m)});
      list.push({label: 'Copy', icon: 'copy-outline', onPress: () => void Clipboard.setStringAsync(m.text)});
    }
    list.push({label: 'Delete for me', icon: 'eye-off-outline', onPress: () => confirmAction('Delete for you?', 'It is removed from your screen only.', () => void guard(() => call('delete-message', {cid, mid: m.id}))(), 'Delete')});
    if (isGroup && m.status === 'live' && conv && (mine || canModerate(conv, me))) list.push({label: 'Delete for everyone', icon: 'trash-outline', danger: true, onPress: () => confirmAction('Delete for everyone?', 'Everyone in the group will see “Message removed”.', () => void guard(() => call('delete-message', {cid, mid: m.id, scope: 'all'}))(), 'Delete')});
    if (!mine && m.status === 'live' && m.type !== 'system') list.push({label: 'Report message', icon: 'flag-outline', danger: true, onPress: () => setReporting({mid: m.id})});
    return list;
  };
  const reportActions: SheetAction[] = REPORT_REASONS.map(reason => ({label: reason, icon: 'flag-outline' as const, onPress: guard(async () => {
    await call('report', {cid, reason, ...(reporting?.mid ? {mid: reporting.mid} : {uid: reporting?.uid})});
    setNotice('Thanks. Our moderators will review your report. They only see the reported message, not your whole chat.');
  })}));

  const renderItem = ({item}: {item: Item}) => {
    if (isPending(item)) return <View style={[s.row, {justifyContent: 'flex-end'}]}><View style={{maxWidth: '82%', alignItems: 'flex-end', gap: 4}}>
      <View style={[s.bubble, s.mine, {opacity: item.status === 'sending' ? 0.7 : 1}]}><Text style={s.mineText}>{item.text}</Text></View>
      {item.status === 'sending' ? <Text style={s.meta}>Sending…</Text> : <View style={{alignItems: 'flex-end', gap: 4}}><Text accessibilityRole="alert" style={[s.meta, {color: C.danger}]}>{item.error ?? 'Not sent.'}</Text>
        <View style={{flexDirection: 'row', gap: 12}}><Pressable accessibilityRole="button" onPress={() => void send(item)}><Text style={s.link}>Retry</Text></Pressable><Pressable accessibilityRole="button" onPress={() => setOutbox(l => l.filter(x => x.key !== item.key))}><Text style={[s.link, {color: C.muted}]}>Delete</Text></Pressable></View></View>}
    </View></View>;
    if (item.type === 'system') return <View style={{alignItems: 'center', paddingVertical: 6}}><Text style={s.system}>{item.text}</Text></View>;
    const mine = item.uid === me, removed = item.status === 'removed', repliedTo = item.replyTo;
    const reactions = Object.entries(item.reactions ?? {}).filter(([, u]) => u.length);
    return <View style={[s.row, mine && {justifyContent: 'flex-end'}]}>
      {!mine && isGroup && <PeerAvatar uid={item.uid} profiles={profiles} size={30} />}
      <View style={{maxWidth: '82%', gap: 3, alignItems: mine ? 'flex-end' : 'flex-start'}}>
        {!mine && isGroup && <Text style={s.sender}>{nameOf(item.uid)}</Text>}
        <Pressable accessibilityRole="button" accessibilityLabel={`${nameOf(item.uid)}: ${removed ? 'message removed' : item.text}. Long press for options.`} onLongPress={() => setMenu(item)} delayLongPress={280} style={[s.bubble, mine ? s.mine : s.theirs]}>
          {!!repliedTo && !removed && <View style={[s.quote, mine && {backgroundColor: 'rgba(255,255,255,.18)', borderLeftColor: '#fff'}]}><Text style={[s.quoteName, mine && {color: '#fff'}]} numberOfLines={1}>{nameOf(repliedTo.uid)}</Text><Text style={[s.quoteText, mine && {color: '#E6ECFF'}]} numberOfLines={2}>{repliedTo.text}</Text></View>}
          <Text style={[mine ? s.mineText : s.theirText, removed && {fontStyle: 'italic', opacity: 0.7}]} selectable={!removed}>{removed ? 'Message removed' : item.text}</Text>
        </Pressable>
        {reactions.length > 0 && <View style={{flexDirection: 'row', gap: 5, flexWrap: 'wrap'}}>{reactions.map(([e, u]) => <Pressable key={e} accessibilityRole="button" accessibilityLabel={`${e} ${u.length}. Tap to ${u.includes(me) ? 'remove' : 'add'} your reaction`} onPress={() => void guard(() => call('react', {cid, mid: item.id, emoji: e}))()} style={[s.react, u.includes(me) && {backgroundColor: '#DCE6FF', borderColor: C.accent}]}><Text style={s.reactText}>{e} {u.length}</Text></Pressable>)}</View>}
        <View style={{flexDirection: 'row', alignItems: 'center', gap: 4}}>
          <Text style={s.meta}>{timeLabel(item.createdAt)}</Text>
          {mine && !removed && conv && !isGroup && <Icon name={tickOf(item.seq, conv, me) === 'read' ? 'checkmark-done' : 'checkmark'} size={15} color={tickOf(item.seq, conv, me) === 'read' ? C.accent : C.muted} />}
        </View>
      </View>
    </View>;
  };

  return <View style={{flex: 1}}>
    <Header title={title} sub={sub} onBack={onBack}
      right={<View style={{flexDirection: 'row', alignItems: 'center', gap: 8}}>
        <Pressable accessibilityRole="button" accessibilityLabel={isGroup ? 'Group info' : `${title}, options`} onPress={isGroup ? onInfo : () => setHead(true)}>{isGroup ? <GroupAvatar size={38} /> : <PeerAvatar uid={peer} profiles={profiles} size={38} />}</Pressable>
        <Pressable accessibilityRole="button" accessibilityLabel="Conversation options" hitSlop={8} onPress={() => setHead(true)}><Icon name="ellipsis-vertical" size={22} color={C.ink} /></Pressable>
      </View>} />
    {!isGroup && !!peer && badges.has(peer) && <View style={{flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 18}}><VerifiedBadge verified tier={badges.tier(peer)} size={15} /><Text style={s.meta}>Verified member</Text></View>}
    <KeyboardDock>
      <View style={{flex: 1}}>
        {!!notice && <View style={{paddingHorizontal: 14, paddingTop: 6}}><Banner text={notice}><Button light title="OK" onPress={() => setNotice('')} /></Banner></View>}
        {!!actionError && <Text accessibilityRole="alert" style={[s.error, {paddingHorizontal: 16, paddingTop: 6}]}>{actionError}</Text>}
        {(loadError || (isGroup && !conv && !data.ready)) ? <View style={{padding: 16, gap: 10}}><Text style={s.error}>{loadError || 'Loading…'}</Text>{!!loadError && <Button light title="Try again" icon="refresh" onPress={restartInbox} />}</View>
          : gone ? <View style={{padding: 16}}><Banner text="You’re no longer in this group." /></View>
          : loading && conv ? <View style={{padding: 30}}><ActivityIndicator color={C.accent} /></View>
          : <FlatList inverted data={items} keyExtractor={i => isPending(i) ? i.key : i.id} renderItem={renderItem} contentContainerStyle={{paddingHorizontal: 12, paddingVertical: 10, gap: 8}}
              keyboardShouldPersistTaps="handled" initialNumToRender={20} windowSize={9} removeClippedSubviews
              onEndReachedThreshold={0.4} onEndReached={() => {if (more) void loadOlder();}}
              ListFooterComponent={loadingMore ? <ActivityIndicator color={C.accent} style={{padding: 10}} /> : more && messages.length >= PAGE ? <Pressable accessibilityRole="button" onPress={() => void loadOlder()} style={{alignItems: 'center', padding: 10}}><Text style={s.link}>Load earlier messages</Text></Pressable> : <View style={{alignItems: 'center', padding: 12}}><Text style={s.meta}>{conv ? 'Start of the conversation' : 'Say hello 👋'}</Text></View>}
              ListEmptyComponent={conv || !isGroup ? <View style={{padding: 24, alignItems: 'center', transform: [{scaleY: -1}]}}><Text style={s.meta}>{!isGroup && !conv ? 'New people need to accept a message request first, so you can send one message to start.' : 'No messages yet.'}</Text></View> : null} />}
        {incoming && <View style={{padding: 12}}><Banner text={`${nameOf(peer)} wants to message you. They can’t see when you read it until you accept.`}>
          <View style={{flexDirection: 'row', gap: 10}}><View style={{flex: 1}}><Button title="Accept" icon="checkmark" onPress={() => void guard(() => call('respond', {cid, accept: true}))()} /></View><View style={{flex: 1}}><Button light title="Decline" icon="close" onPress={() => void guard(() => call('respond', {cid, accept: false}))().then(onBack)} /></View></View>
          <Button light title="Report or block" icon="flag-outline" onPress={() => setHead(true)} /></Banner></View>}
        {waiting && <View style={{padding: 12}}><Banner text={`Your request was sent. You can send more once ${nameOf(peer)} accepts.`} /></View>}
        {declined && <View style={{padding: 12}}><Banner tone="warn" text={`${nameOf(peer)} didn’t accept your request. You can try again in a few days.`} /></View>}
        {closed && <View style={{padding: 12}}><Banner tone="warn" text="This group is closed. You can read it, but no one can send messages." /></View>}
        {blockedByMe && <View style={{padding: 12}}><Banner tone="warn" text={`You blocked ${nameOf(peer)}.`}><Button light title="Unblock" onPress={() => unblockUser(peer)} /></Banner></View>}
        {canWrite && <View style={s.composerWrap}>
          {!!reply && <View style={s.replyBar}><View style={{flex: 1}}><Text style={s.quoteName} numberOfLines={1}>Replying to {nameOf(reply.uid)}</Text><Text style={s.quoteText} numberOfLines={1}>{reply.text}</Text></View><Pressable accessibilityRole="button" accessibilityLabel="Cancel reply" hitSlop={10} onPress={() => setReply(null)}><Icon name="close" size={20} color={C.muted} /></Pressable></View>}
          {emoji && <View style={s.emojiTray}>{QUICK_EMOJI.map(e => <Pressable key={e} accessibilityRole="button" accessibilityLabel={`Insert ${e}`} onPress={() => setDraft(d => (d + e).slice(0, MAX))} style={{padding: 6}}><Text style={{fontSize: 24}}>{e}</Text></Pressable>)}</View>}
          <View style={s.composer}>
            <Pressable accessibilityRole="button" accessibilityLabel={emoji ? 'Hide emoji' : 'Show emoji'} onPress={() => setEmoji(v => !v)} style={s.iconBtn}><Icon name={emoji ? 'keypad-outline' : 'happy-outline'} size={24} color={C.muted} /></Pressable>
            <TextInput accessibilityLabel="Message" value={draft} onChangeText={t => {setDraft(t.slice(0, MAX)); if (t) sendTyping();}} placeholder={!isGroup && !conv ? 'Write your first message…' : 'Message'} placeholderTextColor="#7A88A6" multiline maxLength={MAX} style={s.input} onFocus={() => setEmoji(false)} />
            <Pressable accessibilityRole="button" accessibilityLabel="Send message" disabled={!draft.trim()} onPress={() => void send()} style={{opacity: draft.trim() ? 1 : 0.45}}>
              <LinearGradient colors={['#3156CF', '#5736BB']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.sendBtn}><Icon name="send" size={20} color="#fff" /></LinearGradient>
            </Pressable>
          </View>
          {draft.length > MAX - 80 && <Text style={[s.meta, {textAlign: 'right', paddingRight: 14}]}>{draft.length}/{MAX}</Text>}
        </View>}
      </View>
    </KeyboardDock>
    <ActionSheet visible={head} title={title} actions={headActions} onClose={() => setHead(false)} />
    <ActionSheet visible={!!menu} title={menu?.status === 'removed' ? 'Removed message' : menu ? menu.text.slice(0, 60) : ''} actions={menu ? messageActions(menu) : []} onClose={() => setMenu(null)}
      top={menu && menu.status === 'live' && menu.type !== 'system' && canWrite ? <View style={s.reactRow}>{REACTIONS.map(e => <Pressable key={e} accessibilityRole="button" accessibilityLabel={`React ${e}`} onPress={() => {const m = menu; setMenu(null); void guard(() => call('react', {cid, mid: m.id, emoji: e}))();}} style={{padding: 8}}><Text style={{fontSize: 28}}>{e}</Text></Pressable>)}</View> : null} />
    <ActionSheet visible={!!reporting} title="Why are you reporting this?" actions={reportActions} onClose={() => setReporting(null)} />
  </View>;
}

const s = StyleSheet.create({
  row: {flexDirection: 'row', alignItems: 'flex-end', gap: 7},
  bubble: {borderRadius: 20, paddingHorizontal: 13, paddingVertical: 9, maxWidth: '100%'},
  mine: {backgroundColor: C.accent, borderBottomRightRadius: 6}, theirs: {backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#DCE8F5', borderBottomLeftRadius: 6},
  mineText: {color: '#fff', fontSize: 15.5, lineHeight: 21, fontWeight: '600'}, theirText: {color: C.ink, fontSize: 15.5, lineHeight: 21, fontWeight: '600'},
  sender: {fontSize: 12, fontWeight: '800', color: C.purple, marginLeft: 6}, meta: {fontSize: 11.5, color: C.muted, fontWeight: '700'},
  system: {fontSize: 12.5, color: C.muted, fontWeight: '700', backgroundColor: '#E4EAF8', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4, overflow: 'hidden', textAlign: 'center'},
  quote: {borderLeftWidth: 3, borderLeftColor: C.accent, backgroundColor: '#EEF2FD', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4, marginBottom: 5}, quoteName: {fontSize: 12, fontWeight: '800', color: C.accent}, quoteText: {fontSize: 12.5, color: C.muted},
  react: {flexDirection: 'row', borderRadius: 12, borderWidth: 1.5, borderColor: '#DCE8F5', backgroundColor: '#fff', paddingHorizontal: 8, paddingVertical: 3}, reactText: {fontSize: 13, fontWeight: '800', color: C.ink},
  link: {fontSize: 13.5, fontWeight: '800', color: C.accent}, error: {fontSize: 13.5, color: C.danger, fontWeight: '700'},
  composerWrap: {borderTopWidth: 1, borderTopColor: '#DCE8F5', backgroundColor: 'rgba(255,255,255,.96)', paddingBottom: 6},
  composer: {flexDirection: 'row', alignItems: 'flex-end', gap: 6, paddingHorizontal: 8, paddingTop: 8},
  input: {flex: 1, minHeight: 44, maxHeight: 120, borderRadius: 22, borderWidth: 1.5, borderColor: '#DCE8F5', backgroundColor: '#fff', paddingHorizontal: 14, paddingTop: 10, paddingBottom: 10, fontSize: 15.5, color: C.ink},
  iconBtn: {width: 44, height: 44, alignItems: 'center', justifyContent: 'center'}, sendBtn: {width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center'},
  replyBar: {flexDirection: 'row', alignItems: 'center', gap: 10, marginHorizontal: 10, marginTop: 8, padding: 8, borderRadius: 12, backgroundColor: '#EEF2FD', borderLeftWidth: 3, borderLeftColor: C.accent},
  emojiTray: {flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 8, paddingTop: 6}, reactRow: {flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 4},
});
