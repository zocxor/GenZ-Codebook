import React, {useMemo, useState} from 'react';
import {Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View} from 'react-native';
import {C, Button, Glass, Icon, confirmAction} from '../ui';
import {usePublicProfiles} from '../publicProfile';
import {VerifiedBadge, useBadges} from '../VerifiedBadge';
import {call, inboxError, type FoundUser} from './api';
import {canModerate, roleOf, type Role} from './logic';
import {ActionSheet, GroupAvatar, PeerAvatar, type SheetAction} from './parts';
import {FindScreen, Header} from './InboxScreen';
import type {useInboxData} from './store';

const MAX_MEMBERS = 30;
const ROLE_LABEL: Record<Role, string> = {owner: 'Owner', admin: 'Admin', moderator: 'Moderator', member: 'Member'};

export function NewGroupScreen({me, onBack, onCreated}: {me: string; onBack: () => void; onCreated: (cid: string) => void}) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [privacy, setPrivacy] = useState<'private' | 'invite'>('private');
  const [picked, setPicked] = useState<Map<string, FoundUser>>(new Map());
  const [adding, setAdding] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const profiles = usePublicProfiles([...picked.keys()]);
  if (adding) return <FindScreen me={me} mode="pick" title="Add people" picked={picked} onBack={() => setAdding(false)}
    onToggle={u => setPicked(m => {const n = new Map(m); if (n.has(u.uid)) n.delete(u.uid); else if (n.size < MAX_MEMBERS - 1 && u.canMessage !== 'nobody') n.set(u.uid, u); return n;})} />;
  const create = async () => {
    if (busy || name.trim().length < 2) return;
    setBusy(true); setError('');
    try {onCreated((await call<{cid: string}>('group-create', {name, description, privacy, members: [...picked.keys()]})).cid);}
    catch (e) {setError(inboxError(e));} finally {setBusy(false);}
  };
  return <View style={{flex: 1}}>
    <Header title="Create group" onBack={onBack} />
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{padding: 16, gap: 12, paddingBottom: 30}}>
      <Glass style={{gap: 10}}>
        <Text style={s.label}>Group name</Text>
        <TextInput accessibilityLabel="Group name" value={name} onChangeText={setName} maxLength={40} placeholder="e.g. Slang Squad" placeholderTextColor="#7A88A6" style={s.input} />
        <Text style={s.label}>Description (optional)</Text>
        <TextInput accessibilityLabel="Group description" value={description} onChangeText={setDescription} maxLength={200} multiline placeholder="What is this group for?" placeholderTextColor="#7A88A6" style={[s.input, {minHeight: 70, textAlignVertical: 'top'}]} />
      </Glass>
      <Glass style={{gap: 6}}>
        <Text style={s.label}>Privacy</Text>
        {([['private', 'Private', 'Only admins can invite people.'], ['invite', 'Invite-only', 'Any member can invite. Invited people choose whether to join.']] as const).map(([id, label, hint]) =>
          <Pressable key={id} accessibilityRole="radio" accessibilityState={{checked: privacy === id}} onPress={() => setPrivacy(id)} style={s.opt}>
            <Icon name={privacy === id ? 'radio-button-on' : 'radio-button-off'} size={22} color={C.accent} /><View style={{flex: 1}}><Text style={s.name}>{label}</Text><Text style={s.hint}>{hint}</Text></View></Pressable>)}
      </Glass>
      <Glass style={{gap: 10}}>
        <Text style={s.label}>Invite people ({picked.size}/{MAX_MEMBERS - 1})</Text>
        {[...picked.values()].map(u => <View key={u.uid} style={s.opt}><PeerAvatar uid={u.uid} profiles={profiles} size={36} /><Text style={[s.name, {flex: 1}]} numberOfLines={1}>{profiles.get(u.uid)?.name ?? u.name}</Text><Pressable accessibilityRole="button" accessibilityLabel={`Remove ${u.name}`} hitSlop={10} onPress={() => setPicked(m => {const n = new Map(m); n.delete(u.uid); return n;})}><Icon name="close-circle" size={22} color={C.muted} /></Pressable></View>)}
        <Button light title="Add people" icon="person-add-outline" onPress={() => setAdding(true)} />
        <Text style={s.hint}>People you add get an invitation and join only if they accept. You become the group admin and owner.</Text>
      </Glass>
      {!!error && <Text accessibilityRole="alert" style={s.error}>{error}</Text>}
      <Button title={busy ? 'Creating…' : 'Create group'} icon="checkmark-circle-outline" disabled={busy || name.trim().length < 2} onPress={() => void create()} />
    </ScrollView>
  </View>;
}

export function GroupInfoScreen({me, cid, data, onBack, onLeft, onOpenChat}: {me: string; cid: string; data: ReturnType<typeof useInboxData>; onBack: () => void; onLeft: () => void; onOpenChat: (cid: string) => void}) {
  const conv = data.convs.find(c => c.id === cid);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(conv?.name ?? '');
  const [description, setDescription] = useState(conv?.description ?? '');
  const [inviting, setInviting] = useState(false);
  const [picked, setPicked] = useState<Map<string, FoundUser>>(new Map());
  const [target, setTarget] = useState<string | null>(null);
  const members = conv?.participants ?? [];
  const profiles = usePublicProfiles(members);
  const badges = useBadges(members);
  const mine = conv ? roleOf(conv, me) : 'member';
  const open = conv?.status === 'open';
  const ordered = useMemo(() => conv ? [...members].sort((a, b) => ['owner', 'admin', 'moderator', 'member'].indexOf(roleOf(conv, a)) - ['owner', 'admin', 'moderator', 'member'].indexOf(roleOf(conv, b))) : [], [conv, members]);
  const settings = data.settings.get(cid) ?? {};
  const run = async (fn: () => Promise<unknown>, ok?: string) => {setError(''); setNotice(''); try {await fn(); if (ok) setNotice(ok);} catch (e) {setError(inboxError(e));}};
  if (!conv) return <View style={{flex: 1}}><Header title="Group" onBack={onBack} /><View style={{padding: 16}}><Text style={s.hint}>This group isn’t available.</Text></View></View>;
  if (inviting) return <FindScreen me={me} mode="pick" title="Invite people" picked={picked} onBack={() => {setInviting(false); setPicked(new Map());}}
    onToggle={u => setPicked(m => {const n = new Map(m); if (n.has(u.uid)) n.delete(u.uid); else if (n.size < 10 && !members.includes(u.uid) && u.canMessage !== 'nobody') n.set(u.uid, u); return n;})} />;

  const memberActions = (uid: string): SheetAction[] => {
    const theirs = roleOf(conv, uid), list: SheetAction[] = [];
    if (uid !== me) list.push({label: 'Message', icon: 'chatbubble-outline', onPress: () => onOpenChat('p_' + [me, uid].sort().join('_'))});
    if (!open || uid === me) return list;
    if (mine === 'owner' || mine === 'admin') {
      if (theirs === 'member') list.push({label: 'Make moderator', icon: 'shield-outline', onPress: () => void run(() => call('group-role', {cid, uid, role: 'moderator'}))});
      if (theirs === 'moderator') list.push({label: 'Remove moderator', icon: 'shield-outline', onPress: () => void run(() => call('group-role', {cid, uid, role: 'member'}))});
    }
    if (mine === 'owner' && theirs !== 'owner') {
      if (theirs !== 'admin') list.push({label: 'Make admin', icon: 'star-outline', onPress: () => void run(() => call('group-role', {cid, uid, role: 'admin'}))});
      else list.push({label: 'Remove admin', icon: 'star-outline', onPress: () => void run(() => call('group-role', {cid, uid, role: 'member'}))});
      list.push({label: 'Transfer ownership', icon: 'ribbon-outline', onPress: () => confirmAction('Transfer ownership?', `${profiles.get(uid)?.name ?? 'This member'} becomes the group owner. You stay an admin.`, () => void run(() => call('group-transfer', {cid, uid})), 'Transfer')});
    }
    const removable = theirs !== 'owner' && (mine === 'owner' || (mine === 'admin' && theirs !== 'admin') || (mine === 'moderator' && theirs === 'member'));
    if (removable) list.push({label: 'Remove from group', icon: 'person-remove-outline', danger: true, onPress: () => confirmAction('Remove this member?', 'They lose access to the group.', () => void run(() => call('group-remove', {cid, uid})), 'Remove')});
    return list;
  };

  return <View style={{flex: 1}}>
    <Header title="Group info" onBack={onBack} />
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{padding: 16, gap: 12, paddingBottom: 30}}>
      {!!error && <Text accessibilityRole="alert" style={s.error}>{error}</Text>}
      {!!notice && <Text accessibilityRole="alert" style={s.ok}>{notice}</Text>}
      <Glass style={{gap: 10, alignItems: 'center'}}>
        <GroupAvatar size={72} />
        {editing ? <>
          <TextInput accessibilityLabel="Group name" value={name} onChangeText={setName} maxLength={40} style={[s.input, {alignSelf: 'stretch'}]} />
          <TextInput accessibilityLabel="Group description" value={description} onChangeText={setDescription} maxLength={200} multiline style={[s.input, {alignSelf: 'stretch', minHeight: 64, textAlignVertical: 'top'}]} />
          <View style={{flexDirection: 'row', gap: 10}}><Button title="Save" icon="checkmark" disabled={name.trim().length < 2} onPress={() => void run(async () => {await call('group-update', {cid, name, description}); setEditing(false);}, 'Group updated.')} /><Button light title="Cancel" onPress={() => {setEditing(false); setName(conv.name ?? ''); setDescription(conv.description ?? '');}} /></View>
        </> : <>
          <Text style={s.groupName}>{conv.name}</Text>
          {!!conv.description && <Text style={[s.hint, {textAlign: 'center'}]}>{conv.description}</Text>}
          <Text style={s.hint}>{members.length} members · {conv.privacy === 'invite' ? 'Invite-only' : 'Private'}{conv.status === 'closed' ? ' · Closed' : ''}</Text>
          {open && (mine === 'owner' || mine === 'admin') && <Button light title="Edit name and description" icon="create-outline" onPress={() => setEditing(true)} />}
        </>}
      </Glass>
      <Glass style={{gap: 4}}>
        <View style={s.opt}><View style={{flex: 1}}><Text style={s.name}>Mute notifications</Text></View><Switch accessibilityLabel="Mute this group" value={!!settings.muted} onValueChange={v => void run(() => call('settings', {cid, muted: v}))} /></View>
        {open && (mine === 'owner' || mine === 'admin') && <View style={s.opt}><View style={{flex: 1}}><Text style={s.name}>Any member can invite</Text><Text style={s.hint}>Off: only admins and moderators invite.</Text></View><Switch accessibilityLabel="Any member can invite" value={conv.privacy === 'invite'} onValueChange={v => void run(() => call('group-update', {cid, privacy: v ? 'invite' : 'private'}))} /></View>}
      </Glass>
      {open && (conv.privacy === 'invite' || canModerate(conv, me)) && <Button title="Invite people" icon="person-add-outline" disabled={members.length >= MAX_MEMBERS} onPress={() => setInviting(true)} />}
      {picked.size > 0 && <Button light title={`Send ${picked.size} invitation${picked.size > 1 ? 's' : ''}`} onPress={() => void run(async () => {const r = await call<{sent: number}>('group-invite', {cid, uids: [...picked.keys()]}); setPicked(new Map()); setNotice(`${r.sent} invitation${r.sent === 1 ? '' : 's'} sent.`);})} />}
      <Text style={s.section}>Members ({members.length}/{MAX_MEMBERS})</Text>
      {ordered.map(uid => {
        const role = roleOf(conv, uid);
        return <Pressable key={uid} accessibilityRole="button" accessibilityLabel={`${profiles.get(uid)?.name ?? 'Member'}, ${ROLE_LABEL[role]}. Options`} onPress={() => setTarget(uid)} style={s.memberRow}>
          <PeerAvatar uid={uid} profiles={profiles} size={42} />
          <View style={{flex: 1}}><View style={{flexDirection: 'row', alignItems: 'center', gap: 5}}><Text style={s.name} numberOfLines={1}>{uid === me ? 'You' : profiles.get(uid)?.name ?? 'Member'}</Text><VerifiedBadge verified={badges.has(uid)} tier={badges.tier(uid)} size={16} /></View><Text style={s.hint}>{ROLE_LABEL[role]}</Text></View>
          <Icon name="ellipsis-vertical" size={18} color={C.muted} />
        </Pressable>;
      })}
      <View style={{gap: 10, marginTop: 6}}>
        {conv.status !== 'deleted' && mine !== 'owner' && <Button light title="Leave group" icon="exit-outline" onPress={() => confirmAction('Leave this group?', 'You need a new invitation to come back.', () => void run(async () => {await call('group-leave', {cid}); onLeft();}), 'Leave')} />}
        {mine === 'owner' && open && <>
          <Button light title="Close group (read-only)" icon="lock-closed-outline" onPress={() => confirmAction('Close this group?', 'Everyone can still read it, but no one can send messages.', () => void run(() => call('group-close', {cid})), 'Close')} />
          <Button light title="Delete group for everyone" icon="trash-outline" onPress={() => confirmAction('Delete this group?', 'It disappears for every member and can’t be undone.', () => void run(async () => {await call('group-close', {cid, mode: 'delete'}); onLeft();}), 'Delete')} />
          {members.length > 1 && <Text style={s.hint}>To leave the group, transfer ownership first (tap a member).</Text>}
          {members.length === 1 && <Button light title="Leave and delete group" icon="exit-outline" onPress={() => confirmAction('Leave and delete?', 'You are the only member, so the group is deleted.', () => void run(async () => {await call('group-leave', {cid}); onLeft();}), 'Delete')} />}
        </>}
      </View>
    </ScrollView>
    <ActionSheet visible={!!target} title={target ? profiles.get(target)?.name ?? 'Member' : ''} actions={target ? memberActions(target) : []} onClose={() => setTarget(null)} />
  </View>;
}

const s = StyleSheet.create({
  label: {fontSize: 13, fontWeight: '900', color: C.muted, textTransform: 'uppercase', letterSpacing: 0.5},
  input: {minHeight: 46, borderRadius: 14, borderWidth: 1.5, borderColor: '#DCE8F5', backgroundColor: '#fff', paddingHorizontal: 14, paddingVertical: 10, fontSize: 16, color: C.ink},
  opt: {flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 48, paddingVertical: 4},
  name: {fontSize: 16, fontWeight: '800', color: C.ink, flexShrink: 1}, hint: {fontSize: 13, color: C.muted, lineHeight: 18},
  groupName: {fontSize: 22, fontWeight: '900', color: C.navy, textAlign: 'center'}, section: {fontSize: 13, fontWeight: '900', color: C.muted, textTransform: 'uppercase', letterSpacing: 0.6, paddingHorizontal: 4},
  memberRow: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10, borderRadius: 18, backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#DCE8F5'},
  error: {fontSize: 13.5, color: C.danger, fontWeight: '700'}, ok: {fontSize: 13.5, color: C.success, fontWeight: '700'},
});
