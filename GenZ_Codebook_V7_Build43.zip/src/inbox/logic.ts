/** Pure Inbox rules (no React, no Firebase) so they can be unit-tested. */
export type Role = 'owner' | 'admin' | 'moderator' | 'member';
export type Reads = Record<string, {seq?: number; at?: unknown}>;
export type Conv = {
  id: string; type: 'personal' | 'group'; participants: string[]; state?: 'active' | 'request' | 'rejected'; requester?: string | null;
  name?: string; description?: string; privacy?: 'private' | 'invite'; owner?: string; admins?: string[]; mods?: string[]; status?: 'open' | 'closed' | 'deleted';
  seq: number; reads: Reads; lastAt: number; lastMessage?: {id: string; uid: string; text: string; type: string} | null;
};
export type Settings = {pinned?: boolean; muted?: boolean; archived?: boolean; hidden?: boolean; clearedAt?: number; hiddenMsgs?: string[]};
export type Invite = {id: string; cid: string; by: string; name: string};
export type Filter = 'all' | 'unread' | 'archived';

export const ms = (v: unknown): number => typeof v === 'number' ? v : typeof (v as {toMillis?: unknown} | null)?.toMillis === 'function' ? (v as {toMillis: () => number}).toMillis() : 0;
export const peerOf = (c: Conv, me: string) => c.participants.find(u => u !== me) ?? '';
export const roleOf = (c: Conv, uid: string): Role => c.owner === uid ? 'owner' : (c.admins ?? []).includes(uid) ? 'admin' : (c.mods ?? []).includes(uid) ? 'moderator' : 'member';
export const canModerate = (c: Conv, uid: string) => roleOf(c, uid) !== 'member';
export const isIncomingRequest = (c: Conv, me: string) => c.type === 'personal' && c.state === 'request' && c.requester !== me;

/** Unread messages = how far the conversation moved past what I have read. */
export const unreadOf = (c: Conv, me: string): number => Math.max(0, (c.seq ?? 0) - (c.reads?.[me]?.seq ?? 0));
const hiddenBy = (c: Conv, s?: Settings) => !!s?.hidden && c.lastAt <= (s.clearedAt ?? 0);

/** What shows in the list: visible conversations for the chosen tab, filter and search, pinned first, newest first. */
export function listConversations(convs: Conv[], settings: Map<string, Settings>, me: string, opts: {tab: 'personal' | 'group'; filter: Filter; search: string; names: Map<string, string>}): Conv[] {
  const q = opts.search.trim().toLowerCase();
  return convs.filter(c => {
    const s = settings.get(c.id);
    if (c.type !== opts.tab || c.status === 'deleted' || hiddenBy(c, s)) return false;
    if (isIncomingRequest(c, me)) return false;                           // requests have their own section
    if (opts.filter === 'archived') {if (!s?.archived) return false;} else if (s?.archived) return false;
    if (opts.filter === 'unread' && unreadOf(c, me) === 0) return false;
    if (!q) return true;
    const title = c.type === 'group' ? (c.name ?? '') : (opts.names.get(peerOf(c, me)) ?? '');
    return title.toLowerCase().includes(q) || (c.lastMessage?.text ?? '').toLowerCase().includes(q);
  }).sort((a, b) => Number(!!settings.get(b.id)?.pinned) - Number(!!settings.get(a.id)?.pinned) || b.lastAt - a.lastAt);
}
export const requestsFor = (convs: Conv[], me: string) => convs.filter(c => isIncomingRequest(c, me) && c.status !== 'deleted').sort((a, b) => b.lastAt - a.lastAt);

/** Badge on the Inbox icon: conversations with something new (muted and archived ones stay quiet), requests and invitations. */
export function badgeCount(convs: Conv[], settings: Map<string, Settings>, me: string, invites: Invite[]): number {
  let n = invites.length;
  for (const c of convs) {
    const s = settings.get(c.id);
    if (c.status === 'deleted' || hiddenBy(c, s)) continue;
    if (isIncomingRequest(c, me)) {n++; continue;}
    if (!s?.muted && !s?.archived && unreadOf(c, me) > 0) n++;
  }
  return n;
}
/** Message ticks for my own messages in a personal chat: sent, then read once the other person has read up to it. */
export const tickOf = (msgSeq: number, c: Conv, me: string): 'sent' | 'read' => {
  const other = peerOf(c, me);
  return c.type === 'personal' && (c.reads?.[other]?.seq ?? 0) >= msgSeq ? 'read' : 'sent';
};
const ONLINE_MS = 3 * 60_000;
/** Online / last seen text, honouring the other person's choices (flags are set by the server). */
export function presenceText(p: {at?: unknown; online?: boolean; seen?: boolean} | null, now = Date.now()): string {
  if (!p) return '';
  const at = ms(p.at);
  if (!at) return '';
  if (p.online !== false && now - at < ONLINE_MS) return 'Online';
  if (p.seen === false) return '';
  const mins = Math.floor((now - at) / 60_000);
  if (mins < 60) return `Last seen ${Math.max(1, mins)} min ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `Last seen ${hours} h ago`;
  return `Last seen ${new Date(at).toISOString().slice(0, 10)}`;
}
export const typingActive = (stamps: Record<string, unknown>, me: string, now = Date.now()): string[] => Object.entries(stamps).filter(([u, t]) => u !== me && now - ms(t) < 6000 && ms(t) > 0).map(([u]) => u);
export function timeLabel(t: number, now = Date.now()): string {
  if (!t) return '';
  const d = new Date(t), n = new Date(now), same = d.toDateString() === n.toDateString();
  if (same) return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  if (now - t < 6 * 86_400_000) return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getDay()]!;
  return `${d.getDate()} ${['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()]}`;
}
/** Messages I removed "for me" or that were cleared when I deleted the chat are not shown. */
export const visibleMessages = <M extends {id: string; createdAt: number}>(msgs: M[], s?: Settings): M[] => {
  const hidden = new Set(s?.hiddenMsgs ?? []);
  const cleared = s?.clearedAt ?? 0;
  return msgs.filter(m => !hidden.has(m.id) && (!cleared || m.createdAt > cleared));
};
export const previewOf = (c: Conv, me: string, name: (uid: string) => string): string => {
  const m = c.lastMessage;
  if (!m) return c.type === 'group' ? 'No messages yet' : '';
  if (m.type === 'system') return m.text;
  const who = m.uid === me ? 'You: ' : c.type === 'group' ? name(m.uid) + ': ' : '';
  return who + m.text;
};
export const newKey = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}-${Math.random().toString(36).slice(2, 10)}`;
