const {test,after}=require('node:test'),assert=require('node:assert/strict');
const {initializeApp,deleteApp}=require('firebase-admin/app'),{getFirestore}=require('firebase-admin/firestore');
const {messagingAction}=require('../lib/messaging');
assert.ok(process.env.FIRESTORE_EMULATOR_HOST,'Use emulator or in-memory preload.');
const app=initializeApp({projectId:'demo-genz-feature-core'}),db=getFirestore(app);after(()=>deleteApp(app));
const run=(uid,command,data={},now=Date.now())=>messagingAction(db,{command,...data},{uid,token:{email_verified:true}},now);
const denied=code=>e=>e.code===code;
async function user(uid,name=uid){await db.doc('users/'+uid).set({status:'active'});await db.doc('publicProfiles/'+uid).set({name,avatar:0});return uid;}
async function pair(prefix,accept=true){const a=await user(prefix+'-a'),b=await user(prefix+'-b'),{id}=await run(a,'request',{uid:b});if(accept)await run(b,'respond-request',{conversationId:id,accept:true});return {a,b,id};}
const box=(u,c)=>db.doc(`users/${u}/inbox/${c}`);
test('messaging: authentication, request acceptance, idempotency, sender integrity and free delivery',async()=>{
 const {a,b,id}=await pair('request',false);
 await assert.rejects(messagingAction(db,{command:'search'},undefined),denied('unauthenticated'));
 await assert.rejects(messagingAction(db,{command:'search'},{uid:a,token:{email_verified:false}}),denied('permission-denied'));
 await assert.rejects(run(a,'send',{conversationId:id,text:'Hi',requestId:'early'}),denied('failed-precondition'));
 await assert.rejects(run(a,'respond-request',{conversationId:id,accept:true}),denied('permission-denied'));
 await run(b,'respond-request',{conversationId:id,accept:true});
 const result=await Promise.all([run(a,'send',{conversationId:id,text:'Hello 😊',requestId:'same'}),run(a,'send',{conversationId:id,text:'Hello 😊',requestId:'same'})]);assert.equal(result.filter(r=>r.duplicate).length,1);
 assert.equal((await box(b,id).get()).get('unread'),1);await run(b,'read',{conversationId:id});assert.equal((await box(b,id).get()).get('unread'),0);
 await run(b,'send',{conversationId:id,text:'Welcome',requestId:'reply',replyTo:'same',senderId:a});const m=(await db.doc(`conversations/${id}/messages/reply`).get()).data();assert.equal(m.senderId,b);assert.equal(m.replyTo,'same');assert.equal(m.replyText,undefined);
 assert.equal((await db.collection(`users/${a}/tokenLedger`).get()).size,0);
 await user('outsider');await assert.rejects(run('outsider','roster',{conversationId:id}),denied('permission-denied'));
});
test('messaging: rejection, preferences, mutual block, suspension and restriction are enforced',async()=>{
 const p=await pair('privacy',false);await run(p.b,'respond-request',{conversationId:p.id,accept:false});await assert.rejects(run(p.a,'request',{uid:p.b}),denied('permission-denied'));
 const c=await user('private-c');await run(c,'preferences',{requests:'nobody',showPresence:false});await assert.rejects(run(p.a,'request',{uid:c}),denied('permission-denied'));
 const {a,b,id}=await pair('blocks');await run(b,'block',{uid:a});for(const u of [a,b])await assert.rejects(run(u,'send',{conversationId:id,text:'Blocked',requestId:'no'}),denied('permission-denied'));
 await run(b,'block',{uid:a,blocked:false});await run(a,'send',{conversationId:id,text:'Allowed',requestId:'yes'});
 await db.doc('users/'+b).set({status:'suspended'},{merge:true});await assert.rejects(run(a,'send',{conversationId:id,text:'No',requestId:'suspended'}),denied('permission-denied'));
 await db.doc('users/'+b).set({status:'active',messagingRestricted:true},{merge:true});await assert.rejects(run(b,'search',{query:'hello'}),denied('permission-denied'));
});
test('messaging: group invitations, privilege escalation prevention, roles, removals, ownership and closure',async()=>{
 const a=await user('group-owner'),b=await user('group-member'),c=await user('group-third'),{id}=await run(a,'create-group',{name:'Code Crew',description:'Learn together',privacy:'invite-only',requestId:'group-1'});
 assert.equal((await run(a,'create-group',{name:'Code Crew',description:'',privacy:'private',requestId:'group-1'})).duplicate,true);
 await run(a,'invite',{conversationId:id,uid:b});await assert.rejects(run(b,'send',{conversationId:id,text:'Not yet',requestId:'early'}),denied('permission-denied'));await run(b,'respond-invite',{conversationId:id,accept:true});
 await assert.rejects(run(b,'group-member',{conversationId:id,uid:b,role:'admin'}),denied('permission-denied'));await assert.rejects(run(b,'group-member',{conversationId:id,uid:a,role:'remove'}),denied('permission-denied'));
 await run(a,'group-member',{conversationId:id,uid:b,role:'moderator'});await run(b,'invite',{conversationId:id,uid:c});await run(c,'respond-invite',{conversationId:id,accept:true});
 await run(c,'send',{conversationId:id,text:'Hello',requestId:'group-msg'});await run(b,'remove-message',{conversationId:id,messageId:'group-msg'});assert.equal((await db.doc(`conversations/${id}/messages/group-msg`).get()).get('removed'),true);
 await run(b,'group-member',{conversationId:id,uid:c,role:'remove'});await assert.rejects(run(c,'roster',{conversationId:id}),denied('permission-denied'));
 await assert.rejects(run(a,'group-member',{conversationId:id,uid:a,role:'remove'}),denied('permission-denied'));await run(a,'group-member',{conversationId:id,uid:b,role:'owner'});await run(a,'group-member',{conversationId:id,uid:a,role:'remove'});
 await run(b,'group-update',{conversationId:id,name:'New name',description:'Updated'});assert.equal((await box(b,id).get()).get('name'),'New name');await run(b,'close-group',{conversationId:id});await assert.rejects(run(b,'send',{conversationId:id,text:'Closed',requestId:'closed'}),denied('failed-precondition'));
});
test('messaging: mute and active view suppress notifications; presence is private by default; reactions and hide work',async()=>{
 const {a,b,id}=await pair('options');await run(b,'inbox-settings',{conversationId:id,muted:true,pinned:true,archived:true});const before=(await db.collection(`users/${b}/messageNotifications`).get()).size;
 await run(a,'send',{conversationId:id,text:'Quiet message',requestId:'quiet'});assert.equal((await db.collection(`users/${b}/messageNotifications`).get()).size,before);assert.equal((await box(b,id).get()).get('archived'),false);
 await run(b,'react',{conversationId:id,messageId:'quiet',emoji:'👍'});assert.equal((await db.doc(`conversations/${id}/messages/quiet/reactions/${b}`).get()).get('emoji'),'👍');await run(b,'hide-message',{conversationId:id,messageId:'quiet'});assert.equal((await db.collection(`users/${b}/hiddenMessages`).get()).size,1);
 await run(b,'presence');let roster=await run(a,'roster',{conversationId:id});assert.equal(roster.members.find(m=>m.uid===b).lastSeen,undefined);await run(b,'preferences',{requests:'everyone',showPresence:true});roster=await run(a,'roster',{conversationId:id});assert.equal(roster.members.find(m=>m.uid===b).online,true);
 await run(b,'read',{conversationId:id});await run(b,'inbox-settings',{conversationId:id,muted:false});const count=(await db.collection(`users/${b}/messageNotifications`).get()).size;await run(a,'send',{conversationId:id,text:'Viewing',requestId:'viewed'});assert.equal((await db.collection(`users/${b}/messageNotifications`).get()).size,count);await run(b,'viewing',{conversationId:id});await run(a,'send',{conversationId:id,text:'Notify now',requestId:'notify'});assert.equal((await db.collection(`users/${b}/messageNotifications`).get()).size,count+1);assert.ok((await run(a,'roster',{conversationId:id})).members.find(m=>m.uid===b).readAt>0);await run(b,'inbox-settings',{conversationId:id,deleted:true});assert.equal((await box(b,id).get()).get('deleted'),true);
});
test('messaging: reports expose only reported content, moderation is permission checked and audit logged',async()=>{
 const {a,b,id}=await pair('reports');await run(a,'send',{conversationId:id,text:'Report this sample',requestId:'reported'});await run(b,'report',{conversationId:id,messageId:'reported',reason:'Spam'});assert.equal((await run(b,'report',{conversationId:id,messageId:'reported',reason:'Spam'})).duplicate,true);
 const staff=await user('messaging-mod');await db.doc('admins/'+staff).set({active:true,role:'moderator'});await assert.rejects(run(a,'admin-summary'),denied('permission-denied'));
 const summary=await run(staff,'admin-summary'),r=summary.reports.find(r=>r.conversationId===id);assert.ok(r);assert.equal(r.text,'Report this sample');assert.equal(summary.conversations,undefined);
 await run(staff,'admin-report',{target:r.id,remove:true});assert.equal((await db.doc(`conversations/${id}/messages/reported`).get()).get('removed'),true);assert.ok((await db.collection('auditLogs').where('actor','==',staff).get()).size>=1);
 await run(staff,'admin-restrict',{target:a,restricted:true});await assert.rejects(run(a,'search',{query:'hello'}),denied('permission-denied'));
});
test('messaging: bounded user-code search and server-side send rate limit',async()=>{
 const {a,b,id}=await pair('rates');await db.doc('referrals/GZTEST01').set({uid:b});const found=await run(a,'search',{query:'GZTEST01'});assert.equal(found.users[0].uid,b);assert.equal(found.users[0].email,undefined);const now=Date.now();
 for(let i=0;i<30;i++)await run(a,'send',{conversationId:id,text:'Test '+i,requestId:'rate-'+i},now);await assert.rejects(run(a,'send',{conversationId:id,text:'Over limit',requestId:'limit'},now),denied('resource-exhausted'));
});
test('messaging: account deletion revokes membership and closes owner groups without transferring ownership',async()=>{
 const {purgeMessagingUser}=require('../lib/messaging'),a=await user('deleted-owner'),b=await user('retained-member');
 const {id}=await run(a,'create-group',{name:'Deletion test',description:'',privacy:'private',requestId:'delete-group'});await run(a,'invite',{conversationId:id,uid:b});await run(b,'respond-invite',{conversationId:id,accept:true});await run(a,'send',{conversationId:id,text:'Retained history',requestId:'retained'});
 await db.doc('users/'+a).set({status:'deleted'},{merge:true});await purgeMessagingUser(db,a);
 const c=(await db.doc('conversations/'+id).get()).data();assert.equal(c.status,'closed');assert.equal(c.ownerId,a);assert.deepEqual(c.members,[b]);assert.equal((await box(b,id).get()).get('status'),'closed');assert.equal((await db.doc(`conversations/${id}/messages/retained`).get()).get('text'),'Retained history');
 await assert.rejects(run(a,'search',{query:'hello'}),denied('permission-denied'));
});
