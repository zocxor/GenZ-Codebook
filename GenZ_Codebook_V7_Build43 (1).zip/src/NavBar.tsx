/** Compact tab dock with a sliding selection indicator. */
import React, {useEffect, useRef, useState} from 'react';
import {Animated, LayoutChangeEvent, Pressable, StyleSheet, Text, View} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {useReducedMotion} from './motion';
import {C, Icon, IconName, ACTION_COLORS} from './ui';

export type NavItem<T extends string> = {name: T; label?:string; icon: IconName; activeIcon: IconName; badge?: number};

/** Width follows label length: Community (9) widest, You (3) narrowest. */
const tabFlex = (name: string) => 1 + (name.length - 5) * 0.12;
const SPRING = {stiffness: 340, damping: 30, mass: 0.9} as const;

export default function NavBar<T extends string>({items, active, onSelect}: {items: NavItem<T>[]; active: T; onSelect: (t: T) => void}) {
  const reduced = useReducedMotion();
  const [layouts, setLayouts] = useState<Record<string, {x: number; width: number}>>({});
  const ix = useRef(new Animated.Value(0)).current;
  const iw = useRef(new Animated.Value(0)).current;
  const io = useRef(new Animated.Value(0)).current;
  const placed = useRef(false);

  const onTabLayout = (name: string) => (e: LayoutChangeEvent) => {
    const {x, width} = e.nativeEvent.layout;
    setLayouts(prev => (prev[name]?.x === x && prev[name]?.width === width ? prev : {...prev, [name]: {x, width}}));
  };

  useEffect(() => {
    const l = layouts[active];
    if (!l) return;
    if (reduced) {
      ix.setValue(l.x); iw.setValue(l.width); io.setValue(1);
      placed.current = true;
      return;
    }
    if (!placed.current) {
      ix.setValue(l.x);
      iw.setValue(l.width);
      placed.current = true;
      Animated.timing(io, {toValue: 1, duration: 200, useNativeDriver: false}).start();
      return;
    }
    const animation = Animated.parallel([
      Animated.spring(ix, {toValue: l.x, useNativeDriver: false, ...SPRING}),
      Animated.spring(iw, {toValue: l.width, useNativeDriver: false, ...SPRING}),
    ]);
    animation.start();
    return () => animation.stop();
  }, [active, layouts, ix, iw, io, reduced]);

  return <View style={s.wrap} accessibilityRole="tablist">
    {/* Solid backdrop + fade so scrolled content ends cleanly above the dock instead of being cut under it. */}
    <LinearGradient pointerEvents="none" colors={['#F3F6FE00', C.bg]} style={s.fade} />
    <LinearGradient colors={['#BECDF2', '#D5D0F1']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.edge}>
      <LinearGradient colors={['#FFFFFF', '#F5F7FF']} start={{x: 0, y: 0}} end={{x: 0, y: 1}} style={s.dock}>
        <View pointerEvents="none" style={s.shine} />
        <Animated.View pointerEvents="none" style={[s.indicator, {opacity: io, left: ix, width: iw}]}>
          <LinearGradient colors={ACTION_COLORS} start={{x: 0, y: 0}} end={{x: 0, y: 1}} style={s.indicatorFill}>
            <View pointerEvents="none" style={s.pillShine} />
          </LinearGradient>
        </Animated.View>
        {items.map(n => {
          const on = n.name === active;
          const label = `${n.label??n.name}${n.badge ? `, ${n.badge} ${n.badge === 1 ? 'item' : 'items'} waiting` : ''}`;
          return <TabButton key={n.label??n.name} item={n} on={on} label={label} onSelect={onSelect} onLayout={onTabLayout(n.name)} />;
        })}
      </LinearGradient>
    </LinearGradient>
  </View>;
}

function TabButton<T extends string>({item, on, label, onSelect, onLayout}: {item: NavItem<T>; on: boolean; label: string; onSelect: (t: T) => void; onLayout: (e: LayoutChangeEvent) => void}) {
  return <Pressable accessibilityRole="tab" accessibilityLabel={label} accessibilityState={{selected: on}} onPress={() => onSelect(item.name)} onLayout={onLayout} style={({pressed}) => [s.tab, {flex: tabFlex(item.name)}, pressed && !on && {transform: [{scale: 0.96}]}]}>
    <View style={[s.tabInner, on && {transform: [{scale: 1.04}]}]}>
      <View style={s.iconBox}><Icon name={on ? item.activeIcon : item.icon} color={on ? '#fff' : C.muted} size={23} />{!!item.badge && <Badge value={item.badge} on={on} />}</View>
      <Text style={on ? s.activeLabel : s.label} numberOfLines={1}>{item.label??item.name}</Text>
    </View>
  </Pressable>;
}

/** Count badge pinned to the icon's top-right corner so it never covers the glyph. */
function Badge({value, on = false}: {value: number; on?: boolean}) {
  return <View pointerEvents="none" style={[s.badge, on && s.badgeOn]}><Text style={[s.badgeText, on && {color: C.blue}]}>{value > 99 ? '99+' : value}</Text></View>;
}

const s = StyleSheet.create({
  wrap: {paddingHorizontal: 14, paddingTop: 8, paddingBottom: 10, backgroundColor: C.bg},
  fade: {position: 'absolute', left: 0, right: 0, top: -22, height: 22},
  iconBox: {width: 30, height: 26, alignItems: 'center', justifyContent: 'center'},
  edge: {borderRadius: 29, padding: 1.5, shadowColor: '#7c3aed', shadowOffset: {width: 0, height: 10}, shadowOpacity: 0.18, shadowRadius: 20, elevation: 10},
  dock: {flexDirection: 'row', gap: 4, padding: 6, borderRadius: 28, overflow: 'visible'},
  shine: {position: 'absolute', top: 1, left: 24, right: 24, height: 1, backgroundColor: '#fff'},
  indicator: {position: 'absolute', top: 6, bottom: 6, left: 0, borderRadius: 22, shadowColor: '#245ee6', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.3, shadowRadius: 10, elevation: 4},
  indicatorFill: {flex: 1, borderRadius: 22, borderTopWidth: 1, borderTopColor: '#a4c6ff', borderBottomWidth: 2, borderBottomColor: '#1344b8', overflow: 'hidden'},
  pillShine: {position: 'absolute', top: 0, left: 0, right: 0, height: '45%', backgroundColor: 'rgba(255,255,255,.12)'},
  tab: {minHeight: 54, borderRadius: 22, alignItems: 'center', justifyContent: 'center', flexShrink: 1, minWidth: 0},
  tabInner: {alignItems: 'center', justifyContent: 'center', gap: 3},
  label: {fontSize: 10.5, fontWeight: '700', color: C.muted},
  activeLabel: {fontSize: 10.5, fontWeight: '900', color: '#fff'},
  badge: {position: 'absolute', top: -7, left: 21, minWidth: 18, height: 18, paddingHorizontal: 4, borderRadius: 9, backgroundColor: '#e2552f', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff'},
  badgeOn: {backgroundColor: '#fff', borderColor: '#cfe0ff'},
  badgeText: {fontSize: 10, fontWeight: '900', color: '#fff'},
});
