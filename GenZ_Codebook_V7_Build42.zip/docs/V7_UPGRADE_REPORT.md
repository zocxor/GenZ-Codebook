# GenZ Codebook V7 — Build 42 (version 1.0.1): admin Claymorphism redesign + Community layout

| Requested | Done |
|---|---|
| Admin portal = the supplied Claymorphism reference | `admin/src/theme.css` rewritten (replaces the Build 40-1 neon theme). Light = the reference: #F0EBFF page with soft purple and orange balls, floating rich-purple sidebar (#6740C9 to #895BE8) with 3D icon chips and a pink-lavender raised active pill, white clay cards (26-28 px radius, purple-tinted layered shadows), pastel KPI cards (blue, peach, lavender, mint) with coloured 3D icon bubbles, pill buttons, inset pill search, purple gradient charts with subtle gridlines. |
| Dark mode | Same shapes, spacing and components in deep violet (#151033 page, #43309F sidebar). |
| Light / Dark / System | Same switcher in the header, order Light, Dark, System. Remembered, instant, no reload, no flash (`public/theme-init.js`), System follows the OS. |
| Compact welcome bar | 112 px high on desktop, one row: name, email and role, Platform status, Registered users, logo. The small "WORKSPACE OVERVIEW" label is hidden. |
| All pages | Every page shares the same tokens, so tables, forms, calendar, referrals tree, notices and sign-in use the clay look. Nothing removed: all 12 menu items kept; Posts moderation, Daily Code and Verified Badges got their own icons. |
| App: Community > Posts | "Post Slang" and the three-dots button now sit on the same row as the "Community" heading (Posts tab only). The duplicate “Credits” line above the feed was removed (Credits already show in the top bar). |

Backend, Firestore rules, roles and logins untouched; no new dependencies. Checks: app typecheck and 170 tests, admin typecheck and 32 tests, admin production build, security scan; both themes rendered at 1360 px and 390 px. Fonts: the portal's CSP only allows bundled fonts and none is bundled, so headings use a rounded system font stack at heavy weight. **Deploy:** Firebase `admin-portal`, and upload the new AAB (build 42).

# GenZ Codebook V7 — Build 40 (version 1.0.1)

| Requested | Done |
|---|---|
| No automatic ads; relaxed, optional only | Removed every automatic full-screen ad except the post-delete one: after the 3rd activity, on finishing a round, after adding a word, after a post. |
| One small skippable ad after a level | After a **cleared level** the result page offers an optional “Watch a short ad” card (`src/SupportAdButton.tsx`). Shown only if a skippable ad is loaded, never with Premium, disappears after use. |
| Ad on post delete | Kept, now **skippable**: deleting your own post opens a full-screen ad with a close X while the delete runs. No ad loaded or Premium = no ad; the delete never waits. |
| “Watch an ad → get a benefit” everywhere | Same pattern as the quiz hint: a **locked level** now offers “Watch ad” to unlock it (`unlockLevelByAd`, costs no points). Existing: quiz hint, +5 conversions, +10 Credits buttons. |
| Version 1.0.1 | `app.json` version 1.0.1, `android/app/build.gradle` versionName 1.0.1, build label 40. |

Texts updated: Terms (About), Threat Shield “Ads”, privacy page (`admin/site/privacy.html`), profile help. Backend unchanged.
**Deploy:** Firebase `admin-portal` (privacy text only), then build and upload the new AAB.

# GenZ Codebook V7 — Build 39

| Requested | Done |
|---|---|
| Ad when a user deletes their post | Removing your own post in Community now shows a **full-screen (interstitial) ad** while the delete runs (`showInterstitialForAction`). Not a rewarded ad, not a banner (the app has no banners); never with Premium; at most once per 2-minute cooldown; the post is removed even if no ad loads. |
| Sign-in / sign-up page too white | V8 look in the app’s light colours: tinted page, holographic welcome banner with the logo, glowing orbs and feature chips, frosted form card with a soft gradient frame, light neon “portal” panel (Google’s official button + E-mail), icon fields, glowing gradient button (`src/AuthPortal.tsx`). No dark panel. |
| Game level icons | Each level has its own bright glossy icon (shine, coloured glow); passed levels get a ✓ badge, locked ones keep their colour softened with a 🔒 badge (`GlossyIcon` in `src/ui.tsx`). |
| Profile picture colours | The 11 icon avatars each have their own theme — light (sunshine, gold, blush), bright (sky, mint, violet, teal, coral, caramel) and dark (graphite, midnight) — instead of all fading to dark purple. Same 12 choices, so saved profiles keep their picture. |
| Sync should be automatic | **Sign out** is one tap: it syncs automatically, then signs out (no keep-or-remove choice; your learning stays on the phone and in your account). Signing in with another account switches the phone automatically when nothing is waiting to upload (only asks if unsynced changes would be lost). Pending changes also upload when the app goes to the background. To wipe a phone: Threat Shield → Delete all data on this device. |
| Threat Shield listed 8 protections by name | Now a shield status with four general areas — **Account, This device, Backup, Privacy** — each only “Protected / Action needed / Off”, with one simple fix when needed. The individual protections and technical details are no longer shown. “What we store” and “Recent account activity” are folded, and the storage notes were corrected (no banner ads; Credits on the account; Google Play purchases). |
| Daily reward could be collected again on another screen | One daily reward everywhere (Home card, daily pop-up, You page, Wallet): one tap gives **+10 Credits** (server, once per UTC day) **and +10 learning points**; every button shows “Collected today” at once and checks the server receipt on start (`src/dailyReward.ts`). |
| Admin portal: edit / replace / delete today’s Daily Code | Daily Codes → Published: today’s row has **✎ Edit**, **⇄ Replace with <picked word>** and **🗑 Remove** (same server commands as the app, audit-logged). Past days show “Archived”; a removed day shows “Removed by an administrator”. |

Tests: app 166/166 (new: Threat Shield areas, sync account switching, Build 39 checks), backend 43/43, admin 26/26 + build, security scan clean, Android bundle export OK; sign-in page (360 px and 390 px), Threat Shield, Play levels and avatars checked in a phone-size preview. Version code **39**. No backend function changes since Build 38: deploy Firebase **admin-portal** (portal Daily Code actions) — **everything** also works — then build and upload the AAB.

# GenZ Codebook V7 — Build 38

| Requested | Done |
|---|---|
| Edit / replace / delete the running Daily Code, admins only | Super Admins and Content Managers see ✏️ Edit, ⇄ Replace and 🗑 Remove on today’s Daily Code card (Home and Codes). Edit changes the code, meaning and category for everyone at once (live). Replace searches the dictionary (safe entries only), or takes a typed code, and publishes it as today’s code straight away (audit: `daily-code.replace-live`). Remove takes it off Home and Codes for the rest of the UTC day; the app shows its standard word of the day and the scheduler does not republish it. Server: new `daily-admin` commands `edit-live` / `remove-live` (today only, role checked, audit-logged). A removed paid request is not refunded automatically (the admin can grant Credits). |
| Expired verification link | The You page and the account page say “Link expired or not working? Send a new link” (button **Send new link** / **Send new verification link**). The new e-mail carries a fresh link. |
| Sign out on the You page and the profile page | Sign-out icon in the You page header, a **Sign out** button at the bottom of the You page, and a **Your account → Sign out** card on the profile page (top-right picture). All open the existing safe sign-out choice (sync first, keep or remove learning data, Cancel). |
| Futuristic login / sign-up buttons | New neon “portal” panel: dark gradient with a neon frame and a slow light sweep (off with reduce motion), Google’s **official** button in a neon ring (Google branding rules), a matching neon E-mail tile, a glowing gradient **Sign in with e-mail / Create account** button and a neon pill to switch between sign-in and sign-up (`src/AuthPortal.tsx`). |
| Deploy run red although deployed | `deploy-firebase.yml` now treats only Firebase’s optional container-image cleanup-policy message as a warning; any other error still fails. `rtdnHandler` needed the deploy account to create Pub/Sub topics (owner added **Pub/Sub Editor**). |

Tests: app 156/156, backend 43/43 (new: edit/remove today’s Daily Code), admin 25/25 + build, security scan clean, Android bundle export OK; login panel and Daily Code admin tools checked in a phone-size preview. Version code **38**. Deploy **everything** (Daily Code commands + `rtdnHandler`), then upload the AAB.

# GenZ Codebook V7 — Build 37

**Google Play purchases switched on.** Credit packs (`tokens_1000` … `tokens_100000`) and Premium (`premium_monthly` / `premium_yearly`) now appear in Get Credits. Every purchase is checked with Google Play on our server (`verifyPurchase`, `verifySubscription`) before any Credits are added, using the `PLAY_SERVICE_ACCOUNT_JSON` secret.

| Change | Why |
|---|---|
| `shared/backend.json` → `tokenPurchasesEnabled: true` | Shows Credit packs and Premium. |
| Premium checkout uses the same switch (`src/subscription.ts`), no longer blocked by `SPARK_MODE` | `SPARK_MODE` only controls free community contributions; it had hidden Premium permanently. |
| **Fix:** a Premium subscription is linked to the first account that verifies it | Before, every account signed in on the same phone (same Google Play purchase) would also get Premium and the 10,000/200,000 Credits. Other accounts now get "already linked to another GenZ Codebook account". |
| **Fix:** after a plan change (monthly → yearly), the old plan's expiry no longer switches off the new plan | The old token's late "expired" notice overwrote the active entitlement. |
| **Fix:** a pending or inactive subscription is no longer reported as "Premium is active" | The server now answers "Payment is pending…" / "not active". New vs already-active is decided by whether Credits were granted for this period. |
| Credit packs are recorded under Google Play's own order ID, and the pack Google reports must match | The app's value is only a fallback; IDs with slashes are refused. |
| Wording: Premium = "No pop-up ads" (rewarded videos stay optional); Terms say Premium renews until cancelled in Google Play | Accurate benefits (Play subscription policy). |

Tests: app 155/155, backend 42/42 (7 new purchase tests run the real handlers against the in-memory database with Google Play simulated — 5 of them fail on the Build 36 backend, which confirms they catch the bugs), admin 25/25 + build, security scan clean, Android bundle export OK. **Not yet tested on a phone:** a real license-tester purchase on the internal testing track (owner step).

Version code **37**. Deploy order: create the Pub/Sub topic `genz-codebook-rtdn` → Deploy Firebase **everything** (adds `verifyPurchase`, `verifySubscription`, `rtdnHandler`) → set Real-time developer notifications in Play Console → upload the AAB to **Internal testing** and test with license testers → promote. Known limit: a refunded Credit pack is not taken back automatically (the admin portal can deduct Credits).

# GenZ Codebook V7 — Build 36

**Google Play readiness (User Generated Content policy):** users can now **block** other users (chat message ⚑, post ⋮, comment ⊘; Settings → Blocked users to unblock; blocked people's messages, posts and comments are hidden) and must **agree to the community rules** once before their first chat message, post, comment or new word; the sign-up form states the Terms and Privacy Policy. The in-app Terms and the public privacy policy were corrected (Credits are account-based; no banner ads; blocking; referrals; leaderboard). Credit packs and Premium are hidden until Google Play checkout is switched on, so no button in the app is non-functional.

| Reported | Fix |
|---|---|
| Wallet showed 44 and 54 Credits | 44 is the server-verified (spendable) balance; 54 was an older wallet record that earlier app versions mixed with device learning points. The wallet now shows only the verified Credits, with **Purchased** and **Learning points** labelled separately. The admin portal shows the spendable Credits from the server (new `user-balance` action). No history was changed or deleted. |
| 1 free word a day, then 100 Credits | Server: the first dictionary word each UTC day is free, each extra one costs 100 (admin price). The form shows "Today's word is free" / the price. |
| Daily Code: "Daily Code Display", 100 Credits, 1 free a month | Server: the first request each UTC month is free, extra requests 100. Cancelling or rejecting a free request gives the free use back (no Credit refund); paid requests are refunded as before. Renamed everywhere. |
| Daily reward 5 vs 10 | The daily account reward is 10 Credits (server and every label). Highlighted gold "Daily reward · +10 Credits" button with a collected state. |
| Google button blue | Uses Google's official sign-in button (white, Google "G"). Login shows **Sign in/up with: [Google] [E-mail]** side by side, the e-mail form below. |
| Daily Code cards | Home card is blue again; the Codes page card is gold. |
| Social icons looked fake | Brand look: Instagram rounded-square gradient, Facebook blue circle with "f", WhatsApp green, red e-mail. |
| Slow screens | Faster entrance animations (≈0.16 s, no long stagger), sheets fade instead of slide, the most-used sheets are preloaded after start, Credits show instantly from the last confirmed value, and the Wallet shows history before the Google Play checks finish. |
| Leaderboard | Real 🥇🥈🥉 medals for the top 3. Tabs **Levels** (ranked by game XP, shows level, rank title, XP and Credits), **Word creators** (most community words) and **Top posters** (most approved posts, likes break ties). Top 3 on gold/silver/bronze cards with medals; your row is outlined. |
| Leaderboard / Back to chat / wallet not visible | Header buttons on their own row: green **Get Credits**, gold **Join leaderboard / Leaderboard**, solid blue **Back to chat**. "Community" title no longer wraps. |
| Chat messages | Each person's messages have their own light background colour. |
| Home icon | Bottom bar Home uses a house icon. |
| E-mail verification | The verification e-mail is sent at sign-up in the phone's language; a pop-up says where it went (check Spam); the You page shows "Verify your e-mail" with Resend / I've verified and re-checks when you return to the app. Unverified accounts can't chat, post, use Credits or open the portal (enforced by rules and server). |

Version code **36**. Firebase: deploy **community** (rules: leaderboard XP/level/rank; functions: free word/day, free Daily Code/month, 100 prices, daily reward 10, admin balance; hosting: privacy page and admin portal). If you saved prices in admin Settings earlier (150/250), set **Extra dictionary word** and **Extra Daily Code Display** to 100 there. Checks: app 154/154, admin 25/25 + build, backend 35/35 (the emulator test files now also run without Java via `npm run test:memory`; 4 new Credit tests), security scan clean, Android bundle export; chat, leaderboard, Daily Code cards, social icons and reward button checked in a phone-size browser preview. The rules test additions run in the GitHub deploy workflow.

# GenZ Codebook V7 — Build 35

| Reported | Fix |
|---|---|
| Verified Badge page text cut off at the edge, not premium | Redesigned: gold hero with a large seal, "Get the Verified badge" and the price; Blue and Gold tiers as full-width cards (no side-by-side text that overflowed); "What you get" and "How it works"; the application card with cost, balance, what's missing, Get Credits and Confirm; your application status when one is open. |
| Purple profile card; restore gold and blue | The profile card is gold for a gold badge and blue for a blue badge again (navy for no badge). The badge now sits on a white ring, so it stays clearly visible on the gold or blue card. |
| Daily Code cards (Home and Codes) both blue | Both are now deep teal–emerald, distinct from the blue/gold profile cards, with matching label and category colours. |
| Chat shows the "30 Credits" page for a second although paid | The app waited for the server's chat-pass check before showing the chat. Today's pass is now remembered on the phone, so the chat opens straight away; on first check a short "Opening the chat room…" shows instead of the payment page. The server still verifies the pass on every message. |

Version code **35**. Includes Builds 32–34-1. App-only changes: no Firebase deploy needed for this build (deploy **community** if you haven't since Build 32, and **admin-portal** for the Referrals page). Checks: app 154/154, admin 25/25, typecheck, security scan clean, Android bundle export passed; the badge page, profile cards and Daily Code cards were checked in a phone-size browser preview.

# GenZ Codebook V7 — Build 34-1 (admin: Referrals page)

- New admin page **Referrals** (roles with Users access): referred sign-ups, lead users ranked by **whole chain** (everyone who joined through them at every level), direct invites, levels, last join, and whether each lead **started the chain** or joined via someone else.
- **Find a user's chain** by invite code (GZXXXXXX), user ID or e-mail (e-mail for Super/Support admins). The chain view shows who invited them up to the top lead user, direct invites, whole chain, levels (L1/L2/…), an expandable tree of every person, and **Download CSV** (level, user ID, name, e-mail for PII roles, invite code, invited by, code used, joined).
- Reads only `referralClaims`, which the rules already allow for admin roles; no rules or server change. Names/e-mails are shown only to roles allowed to see them; others see the public invite code.
- App unchanged (versionCode stays **34**): deploy **admin-portal** only. Checks: admin typecheck, 25/25 admin tests (5 new chain tests), production build, security scan clean; page checked in a browser with 124 sample sign-ups (100-person chain, 5 levels, CSV export).

# GenZ Codebook V7 — Build 34 (invite link on the profile)

- **Invite card on the main You page:** your invite code, a copy button, **Share invite link**, and how many friends joined (+100 Credits each). Guests see "Create account" to get a code.
- **The shared link is now a Google Play link** that carries the code (`…details?id=com.genzmode.app&referrer=utm_source=invite&utm_content=GZXXXXXX`), with the code also written in the message. The old `genzcode://` link could not be tapped in WhatsApp/Instagram and did nothing for people without the app. The Play link opens once the app is published.
- The friend types the code in the sign-up form (it is in the message). Optional later: auto-fill the code from the Play install referrer (needs one small native module; testable only on a Play-installed build).
- The referral history (who you invited, who invited you) stays under Wallet & rewards; an outdated "chat and posting are free" note was removed.
- Includes Builds 32–33. Version code **34**. Checks: app 154/154 (new invite-link test), typecheck, security scan clean, Android bundle export passed.

# GenZ Codebook V7 — Build 33 (Google sign-in)

- **Google sign-in switched on.** The fresh `android/app/google-services.json` (Android OAuth client for SHA-1 `5E:8F:…:F6:25`, the GitHub APK key) is in the project, and `GOOGLE_WEB_CLIENT_ID` is set to the Web client `1095502586634-09bohub3v58v9f25lmssqu37na02ugpd.apps.googleusercontent.com`. The login page now shows "Continue with Google".
- For Play builds, add the **upload key** and **Play App Signing key** SHA-1s in Firebase as well (Play Console → App integrity), or Google sign-in will show "developer error" on Play-installed copies.
- Restored "ID token" in five technical messages that the Tokens→Credits rename had changed (Google sign-in and the purchase-verification server).
- Includes everything in Build 32. Version code **33**. Checks: app 154/154, typecheck, backend build + 11/11, security scan clean, Android bundle export passed.

# GenZ Codebook V7 — Build 32 update (after device testing of Build 31)

| Reported | Fix |
|---|---|
| Tester: "Cloud sync refused … account may be restricted" | Not a restriction. The database rule accepted profile avatars 0–5, but the app offers 12 (0–11); anyone using avatar 6–11 had every sync refused. The rule now accepts 0–11 (new rules test included). **Deploy community** to apply it. |
| Tester: chat "permission-denied" although verified | That phone ran the old Build 29 app, which cannot pay for a Chat Pass while paid community is on. Testers need Build 32, or turn paid community off in admin Settings until they update. |
| Chat messages appear ~2 s after sending | Each send ran four network checks one after another (account, e-mail, chat switch, rate limit) and the message only appeared when the live feed echoed it. The checks now run in parallel once, are reused for 3 minutes (pre-run when the room opens), the 10-second limit is tracked on the phone, and your message shows instantly as "Sending…" and is removed or restored to the box if the server refuses it. The security rules still check everything on every message. |
| "Enter for today" greyed although Credits are enough | The required "Vibe check" chip was easy to miss. It is now a large "I agree to be respectful" checkbox, and the reason the button is disabled is shown under it (tick the box / you need N more Credits). |
| Trophy icon unclear | Header pill now says **Join leaderboard** (joins and opens it), **Leaderboard** when joined, **Back to chat** while open; the board has Join/Leave. |
| Daily Code shows another code first, then today's | The offline fallback word showed until the live listener answered (~3 s). Now: the last code seen today shows at once (memory/device), one quick read runs alongside the listener, and a "Loading today's code…" placeholder shows until the real one arrives. The offline word only appears with no connection (after 6 s) or when today has no published code. |
| Profile card blue hides the blue badge; too large | The profile card is now a dark plum gradient for everyone, so blue and gold badges stand out, with smaller padding, name and sync row. |
| Social links buried in Settings | "Follow us" Instagram / Facebook / WhatsApp / Email icons sit in one row at the bottom of the You page, with **Rate the app** and **Feedback** tiles above them. |
| Buy Credits: text cut off, badge price missing | One full-width list with no truncation: chat (day), post, new word, Daily Code, **Verified badge review 5,000**, Encode and Decode (after the daily free allowance), each with a one-line explanation. |
| "Create your own code" gone from home | It only showed in Decode mode before a result. It now shows on the home page in both Decode and Encode modes, with its Credit price when paid community is on (price read after first paint). |
| Premium and ad-free | Premium Monthly **10,000 Credits** and Yearly **200,000 Credits** each period (app and server tables), ad-free while active, rewarded ads optional. Recommended Play prices **$4.99/month** and **$39.99/year** (save 33%). Subscribe buttons appear once checkout is enabled; until then the plans say "Opens with Google Play checkout". |
| Google sign-in card "Not set up yet" | Hidden until the Web client ID is set (see the setup steps given with this build). |
| Posts: hearts and comments vanish for ~3 s after switching from Chat | Switching tabs rebuilt the feed from empty ("Loading posts…") and reset your likes until they reloaded. The last feed per filter, your likes/saves and verified badges are now kept in memory, so Posts shows instantly with the right hearts while live data refreshes in the background. |
| Leftover "tokens" wording | Remaining labels (wallet, leaderboard, referral, chat pass) now say Credits; the post button typo "Credens" is fixed. |

Version code **32**. Firebase changes: Firestore rules (avatar 0–11) — deploy **community**, then rebuild the APK. The Premium grant table lives in the purchase functions (`verifySubscription` and the Play notification handler), which are deployed with the **functions** target once the `PLAY_SERVICE_ACCOUNT_JSON` secret is set.

Checks for this update: app 154/154 tests, app and admin typecheck, backend build + 11/11 in-memory tests, security scan clean (146 files), Android Hermes bundle export passed. Rules tests (including the new avatar test) run in your GitHub deploy workflow.

# GenZ Codebook V7 — Build 31 update (after device testing of Build 30)

| Reported | Fix |
|---|---|
| Admin calendar showed no colours | Reserved/scheduled and published dates are green, pending requests amber, past dates grey, with a legend. |
| Portal not V7 / "liquid glass" | New glass theme: frosted cards and top bar, gradient sidebar and buttons, soft colour background, focus rings; reduced-motion respected. |
| Empty dark squares in the portal | The logos were served from `public/` and, when missing, came back as the portal page through the `/admin/**` rewrite. They are now bundled build assets. |
| Portal pages open after a long pause (follow-up) | Root causes: `firebase.json` sent `Cache-Control: no-store` for all of `/admin/**`, so the portal code was re-downloaded on every visit; the Dashboard downloaded the whole 4.9 MB dictionary (~0.44 MB compressed) just to show the entry count; every page switch remounted the page and re-ran all its queries; and card/number animations took up to ~1 s. Fixes: hashed code files are cached for a year (new deploys use new file names), entry pages and the dictionary revalidate via ETag; the Dashboard count comes from the bundled manifest; the dictionary downloads at most once per session; opened pages stay mounted; other pages' code is prefetched after sign-in; animations shortened to ~0.2–0.35 s. A repeat Dashboard visit now downloads only a revalidation check instead of ~640 KB. |
| Portal slow to open | Startup checks run in parallel (admin role + email reload; token + two-step setting), the login audit write no longer blocks, and each page loads on demand (Dashboard prefetched while the session is checked). |
| Encode: weak results, "you → j00", "headach" not converted | The encoder now converts every word or phrase with a sensible code, including community words (HOD), and never uses leetspeak or emoji except everyday codes. The result card highlights codes, with copy and share buttons; tap a code to switch it. |
| 10 free each for Encode and Decode, then Credits | Each has its own free daily allowance (admin: default 10), then a Credit price per conversion (admin: default 5; 0 = free). Charged by the server only after a successful conversion, once per request; an optional ad gives +5. |
| Change Credit prices | Admin Settings → Prices: chat day, post, new word, Daily Code, badge review, Encode, Decode. The server charges the same live price; refunds return what was actually paid. |
| Buy Credits page empty | Always shows what Credits buy, free ways to earn, all 7 packs with their planned prices ($1.99–$25.99) and the Premium (ad-free) monthly/yearly plans. Buttons say "Opens soon" until checkout is enabled. |
| Badge error with an email | The badge box accepts an email or a user ID. Badges are **blue** (verified users) or **gold** (owner/staff, Super Admin only). |
| Badge/profile colour | Seal-style badge beside the name; the profile card is gold for gold badges and blue for blue badges. "Verified badge" is the first row of the profile list. |
| Profile photo missing on posts | Posts and comments show the author's avatar icon and, if they opt in ("Show my photo on my posts"), a 96 px photo from `publicProfiles/{uid}` (owner-written, public read, deleted with the account). The privacy policy and About text were updated. **Also update the Play Data safety form: Photos — optional, shared publicly by user choice.** |

Version code **31**. Firebase changes in this update: `communityFeature` (prices, `convert-fee`, refunds use the paid amount, public card removed on account deletion), Firestore rules (`config/app.prices`, `decodeFreeDaily`, `publicProfiles`, badge `tier`). Deploy **community** again, then rebuild the APK.

Checks for this update: app 154/154 tests, admin 20/20 + production build, backend 11/11 (in-memory Firestore), security scan clean, Android Hermes bundle export passed. Firestore rules and the backend emulator suite run in your GitHub deploy workflow.

---

# GenZ Codebook V7 — Build 30 upgrade report

Source: Build 29 (`GenZ_Codebook_Build29_Deploy_Fix`). Android version code **30** (version name 1.0.0). Package, signing and release credentials are unchanged.

This build fixes the ten priorities in order and adds the parts of the V7 brief listed below. **It is not the whole V7 brief.** Section 8 lists exactly what is still open and what each item needs. Nothing was deployed from this workspace.

## 1. Modifications

| Area | Files |
|---|---|
| Startup speed | `metro.config.js` (new), `src/engine.ts`, `src/discovery.ts`, `src/reviewQueue.ts`, `App.tsx`, `scripts/measure-startup.mts` (new) |
| Sign-in persistence | `src/auth/chunkedStorage.ts` (new), `src/auth/persistence.native.ts`, `src/secure/session.ts`, `src/services.ts` |
| Community | `src/optimistic.ts` (new), `src/CommunityPostsPanel.tsx`, `src/CommunityScreen.tsx` |
| Daily Code (app) | `src/ContributionScreens.tsx` |
| Credits / paid mode | `src/appConfig.ts` (new), `src/publishing.ts`, `src/communityFeatures.ts`, `src/SubmitForms.tsx`, `functions/src/communityPolicy.json` |
| V7 header | `src/AppHeader.tsx` (new), `src/AdRewardButton.tsx`, `App.tsx` |
| Encode Message | `src/encode.ts`, `src/encodeQuota.ts`, `src/EncodePanel.tsx` (new), `App.tsx` |
| Social & support | `shared/brand.ts`, `src/FollowUs.tsx` (new), `src/SettingsScreen.tsx`, `src/AboutScreen.tsx` |
| Wording (Tokens → Credits) | 85 user-facing strings across `src/`, `admin/src/pages/`, `shared/`, `functions/src/` |
| Backend | `functions/src/communityFeatures.ts`, `functions/src/communityEndpoints.ts` |
| Security rules and indexes | `firebase/firestore.rules`, `firebase/firestore.indexes.json` |
| Admin portal | `admin/src/lib/metrics.ts`, `admin/src/pages/Dashboard.tsx`, `admin/src/firebase.ts`, `admin/src/pages/Users.tsx`, `CommunityWorkflow.tsx`, `DailyCodesList.tsx` (new), `Settings.tsx`, `Logs.tsx`, `admin/src/lib/dailyRows.ts` (new) |
| Browser favicon only | `admin/public/favicon.{ico,svg}`, `admin/site/public/favicon.{ico,svg}`, `assets/favicon.png` (Expo **web** favicon), cache-busting `?v=8` in the HTML pages. Android launcher, adaptive and splash icons are untouched. |
| Version | `app.json` versionCode 30, `android/app/build.gradle` default 30 |
| Tests | `functions/tests/community-features.test.cjs` (balances updated for the 50-Credit post), `tests/{optimistic,chunkedStorage,encode,social}.test.ts`, `admin/tests/dailyRows.test.ts`, `functions/tests/{fake-firestore.cjs,credits-daily.fake.test.cjs}` (new); wording/fee/header assertions updated in `tests/{posts,chat,notifications,referral}.test.ts` |

## 2. Fixed bugs and root causes

1. **30-second Home startup.** Before the first frame, the app built all 30 quiz levels (re-sorting ~5,000 words with `localeCompare` for each level) and the full search/decoder index (`normalize` + `toLocaleLowerCase` on every entry): **232,990 locale-sensitive string calls**. On Android, Hermes runs each through a JNI call into java.text, which is why phones took tens of seconds while desktop measurements looked small. All five tabs were also mounted, hidden, at launch, and Expo's default Metro setting (`inlineRequires: false`) evaluated every module (Firebase SDK, billing, ads, all screens) before the first frame.
   *Fix:* ASCII fast path and lazy index (built 1.2 s after Home appears), one ordinal sort, quiz levels generated when Play first opens, each tab mounted on first visit, inline requires on.
2. **Admin 500-Credit grant "did not work".** The admin page showed "Something went wrong" for every Cloud Function error, because its error mapper only knew Firestore error codes. The real reason was never visible. The grant logic itself works: a test grants 500, rejects the duplicate request and spends the Credits on a Daily Code. The portal already requires a verified email, so the remaining server refusals are wrong role, two-step sign-in required (`config/security.adminMfaRequired`) or an inactive target account. Each now shows its own message, and the server separates the role and two-step messages.
3. **Daily Code Confirm button greyed out.** In the app, Confirm stayed disabled until a word *chip* was tapped. Typing "HDOT" in the search box did not select it, and nothing said why the button was disabled. A taken date or a low balance were also silent. In the admin portal, scheduled words such as HDOT appeared only as a calendar cell, with no list or actions.
4. **Chatroom asking signed-in users to sign in.** Screens could not tell "still restoring the saved session" from "signed out", so during startup they showed "Sign in to chat". The session was also stored as one SecureStore value; SecureStore documents a ~2 KB limit per value and a Firebase session can exceed it, so some sessions were not restored after a restart.
6. **Admin Dashboard "This report needs a database index" / "Platform status: Unavailable".** The Users report's learning totals (sum/average of five `stats.*` fields) need a composite index, but the index was never declared in `firebase/firestore.indexes.json`; a code comment wrongly said none was needed. It was created by hand in the console, and the **community** deploy runs with `--force`, which removes indexes that are not in the file. *Fix:* the index is now declared, so every deploy creates and keeps it. The totals are also optional, so user counts and platform status load while the index builds.
5. **Likes and saves taking 2–3 s.** The UI waited for a Firestore transaction plus the next feed snapshot before changing the heart.

## 3. New features

- **Encode Message (Home → Encode).** Converts plain text into codes from the GenZ Codebook dictionary, on the device. "Hello, how are you?" becomes "Hello, hru?" and "to be honest I don't know" becomes "tbh idk". Matching is case-insensitive; punctuation and unmatched words are kept; phrases never join across punctuation. Ordinary single words change only to well-known codes. Tap a code to cycle through alternatives. Copy, Share, Edit and "Decode it" are included. A free daily limit is set by the admin (default 10), and an optional rewarded ad gives +5. A conversion is counted only when something was encoded.
- **V7 header** (per the reference image): GZ mark + wordmark, with the tagline on wider phones; gold Credit pill; blue "Ad +10" pill; bell; avatar with a gradient ring. It stays on one row on narrow phones, and the Credit balance shows on every tab.
- **V7 post card:** gradient avatar, verified badge, time, code chip, "# category" chip, "Meaning:", red heart with count, comment count, and Save/Copy/Share pills (icon-only under 400 px). Likes and saves update instantly and roll back if the server refuses.
- **Daily Code form:** numbered steps; an exact search match is selected automatically; the calendar shows green = reserved, amber = pending, grey = unavailable; the reason Confirm is disabled is shown in a list, with a **Get Credits** button when short.
- **Admin Daily Codes list** with Upcoming / Pending / Approved & scheduled / Published / Rejected / All tabs, and per-row ✓ Approve (with date), ✎ Edit, ⇄ Replace (refunds the requester) and 🗑 Delete (refunds the requester). The applications queue has one-step **Approve & schedule**. Every disabled button explains itself.
- **Admin Credits card:** grant and **deduct** (reason required, never below zero), both with confirmation and idempotent request IDs. If the backend is unreachable, the grant falls back to the audited ledger write.
- **Paid community switch** (admin Settings → Credits): chat day pass 30 · post 50 · new dictionary code 150. It is enforced by the Cloud Function, the app and the Firestore rules. It is **off by default**.
- **Stay connected** (Settings and About): Instagram, Facebook, WhatsApp Channel and Help & Support email. Only these fixed https links open; if a link can't open, it is copied instead. No rewards are offered for following.
- **Browser favicon** from the supplied GZ icon (transparent corners; 16/32/48/64 px .ico, SVG, 196 px PNG).

## 4. Firebase changes (deploy required)

- **`communityFeature` function:**
  - New `deduct-tokens` action (writes ledger type `admin_debit`; the wallet check accepts it only as a negative amount).
  - `daily-admin` gains `approve` with a date (approve and schedule in one step), `edit-schedule` and `replace-schedule` (refunds the requester in full).
  - The scheduler publishes an admin's edited text.
  - Clearer role and two-step messages.
  - Paid create-code / create-post / chat-pass run only when `config/app.paidCommunity` is true.
- **Policy:** `postFee` is now 50 (from 25). The others are unchanged: chat 30/day, dictionary code 150, Daily Code 250, referral +100.
- **Firestore rules:**
  - `config/app` accepts `paidCommunity`, `encodeFreeDaily` and `encodeCreditCost` (type- and range-checked).
  - When paid mode is on, chat messages need an unexpired `chatPasses/{uid}`, and direct free post/code writes are refused.
  - Collections and existing fields are not renamed or deleted. "Credits" is display wording only; the `tokenLedger`, `tokenWallet` and `tokens.*` names stay as they are for compatibility.
- **One new composite index:** `users` on `stats.levels`, `stats.quizzes`, `stats.reviewed`, `stats.saved`, `stats.streak` (admin Dashboard totals). It takes a few minutes to build after deploy.

## 5. Admin portal changes

- **Errors:** the real Cloud Function message is shown (not deployed, session expired, wrong role, two-step required, unreachable, or the server's own text).
- **Users → Credits:** grant/deduct with confirmation, plus a verification-email shortcut if an admin email is ever unverified.
- **Daily Codes:** the new list, Approve & schedule, inline reasons for disabled buttons.
- **Settings:** the Credits switch and Encode limits.
- **Logs:** filters for the new Daily Code and deduction audit actions.
- The V7 *visual* restyle of the portal and the expanded dashboard statistics are **not** in this build.

## 6. Performance (measured)

`node --import tsx scripts/measure-startup.mts` measures the work done before the first screen can paint:

| | Build 29 | Build 30 |
|---|---|---|
| Locale-sensitive string calls before first paint | **232,990** (170,370 `localeCompare`, 31,310 `normalize`, 31,310 `toLocaleLowerCase`) | **0** |
| JS time on desktop Node (relative only) | 318 ms | 127 ms |
| Deferred until after first paint | — | index + 30 levels: 92 ms, 8,588 `normalize` (non-ASCII entries only) |

Desktop Node is much faster than a phone at these calls, so the phone saving is far larger than the desktop numbers suggest. **A real-device cold start has not been measured.** Please time it on the same phone before and after.

## 7. Security and testing results

- App: TypeScript passes; **150/150 tests**. New tests cover instant likes (6), chunked session storage (6: >2 KB sessions, legacy migration, crash safety, Keystore failure, removal, surrogate pairs), Encode Message (8) and social links (3).
- Backend: compiles; **9/9** tests run the real compiled `communityFeatures` against an in-memory Firestore stand-in. They cover a 500 grant with duplicate protection, role checks, deduction limits, a 250-Credit Daily Code with Approve & schedule, an approved code published on its date, an unapproved request never published (automatic word plus refund), edit/replace/delete with refunds, the chat pass charged once per UTC day, and a 50-Credit post refused when short. The stand-in is not the Firestore emulator.
- Admin: TypeScript passes; **20/20 tests**; production build passes.
- Security scan (`scripts/security-scan.mjs`): no findings (a targeted static scan, not a penetration test).
- **Firestore rules: 61/61 passed on the official emulator** in your GitHub Actions deploy run (they could not run in this workspace because the emulator download is blocked).
- **Backend emulator tests** (`functions/tests/community-features.test.cjs`): the first CI run failed 5 of 20 tests. All five were hard-coded to the old 25-Credit post price (for example, expecting 325 instead of 300). They were updated to the 50-Credit price: 15 assertion lines, with no backend code changed. They must pass in your next CI run before deployment continues.
- No device, live Firebase, AdMob or Play test was possible.

## 8. Remaining issues and what each needs

| Item | Status / what is needed |
|---|---|
| Google sign-in | Add the SHA-1 and SHA-256 of the upload key **and** the Play App Signing key in Firebase → Project settings → Android app; download the new `google-services.json`; confirm the Web OAuth client ID used by `src/googleAuth.ts`. |
| Phone number + OTP | Not built. The Firebase JS SDK needs a reCAPTCHA verifier, which React Native lacks; a native auth module (for example `@react-native-firebase/auth`) and a native rebuild are needed. Owner decision. |
| Password visibility toggle, merged profiles across methods | Not done. |
| Credit purchases and ad-free | Still disabled (`tokenPurchasesEnabled: false`). Needs the Play service-account secret, final product IDs (Credit packs plus an explicit ad-free product), and an internal-track test purchase. |
| Rewarded interstitial | Needs a new AdMob ad unit ID. Banner, interstitial and rewarded already exist. UMP consent was not audited. |
| Encode Message charged in Credits | The admin setting is stored but **not charged** in Build 30 (free limit + rewarded ad only). Needs a small server action. |
| Ranked Posts, blue/gold badges, profile upgrade, feedback replies, user search by username, separated Credit-history categories, admin dashboard statistics | Not in this build. |
| V7 restyle of the remaining screens and the admin portal | Partial (header, post cards, Encode, Daily Code form). |
| Learning points vs Credits | Two balances remain: server Credits (spendable) and device-only learning points (games and level unlocks). Merging them is a product decision. |

## 9. APK / AAB status

`npx expo export --platform android --clear` **passed** with inline requires enabled: Hermes bytecode bundle 9.09 MB. No native APK or signed AAB was built here (no Android SDK or signing keys). Build with **Actions → Android APK**, then the existing signed AAB release process. Version code 30 updates Build 29.

## 10. Deployment and Play readiness

1. Your repository uses **ZIP mode**: keep exactly **one** project ZIP at the repository root (this full ZIP) and delete any other `.zip` there. The workflows extract it automatically.
2. Run **Actions → Firestore rules tests**. Do not deploy until it passes. (The deploy workflow also runs the rules and backend tests before it deploys anything.)
3. Run **Actions → Deploy Firebase → community** (rules, Hosting/admin portal, `communityFeature`, scheduler).
4. Run **Actions → Android APK**, install Build 30 over Build 29 and time the cold start.
5. In the admin portal, grant 500 Credits to a test account and confirm the header updates. If it fails, the message now says why.
6. Only then turn on **Settings → Credits → Charge Credits for community features**. Users on Build 29 cannot pay for chat or posts once it is on.
7. Play readiness is **not complete**: Billing, ad-free, Google/phone sign-in, consent and real-device QA remain (section 8).
