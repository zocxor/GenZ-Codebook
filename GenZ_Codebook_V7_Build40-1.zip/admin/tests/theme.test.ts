import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {parsePref, resolveTheme, THEME_PREFS} from '../src/theme';
const read = (f: string) => readFileSync(new URL(`../${f}`, import.meta.url), 'utf8');

test('theme preference: only dark / light / system are accepted, anything else means system', () => {
  assert.deepEqual([...THEME_PREFS], ['dark', 'light', 'system']);
  for (const v of ['dark', 'light', 'system']) assert.equal(parsePref(v), v);
  for (const v of [null, undefined, '', 'blue', 'DARK', 7, {}]) assert.equal(parsePref(v), 'system');
});

test('system follows the operating system; explicit choices ignore it', () => {
  assert.equal(resolveTheme('system', true), 'dark');
  assert.equal(resolveTheme('system', false), 'light');
  assert.equal(resolveTheme('dark', false), 'dark');
  assert.equal(resolveTheme('light', true), 'light');
});

test('no flash: the pre-paint script is an external file (CSP forbids inline) and uses the same key and values', () => {
  const html = read('index.html'), init = read('public/theme-init.js');
  assert.match(html, /<script src="\/admin\/theme-init\.js"><\/script>/);
  assert.doesNotMatch(html, /<script>[^<]/, 'no inline script');
  assert.ok(html.indexOf('theme-init.js') < html.indexOf('/src/main.tsx'), 'runs before the app');
  assert.match(init, /genz-admin-theme/);
  assert.match(init, /prefers-color-scheme: dark/);
  assert.match(read('src/theme.ts'), /THEME_KEY = 'genz-admin-theme'/);
});

test('both themes define the full token set with the brief’s palette', () => {
  const css = read('src/theme.css');
  const dark = css.slice(css.indexOf(':root[data-theme="dark"]{'), css.indexOf(':root[data-theme="light"]{'));
  const light = css.slice(css.indexOf(':root[data-theme="light"]{'), css.indexOf('/* ---------- 2.'));
  for (const hex of ['#050817', '#0A1025', '#080D20', '#00E5FF', '#168BFF', '#8B35FF', '#D946EF', '#F4F8FF', '#A8B5D1']) assert.ok(dark.includes(hex), `dark ${hex}`);
  for (const hex of ['#F3F7FF', '#E9F0FF', '#009FCB', '#3478F6', '#7950E8', '#9860E8', '#14213D', '#596985']) assert.ok(light.includes(hex), `light ${hex}`);
  const tokens = (block: string) => new Set([...block.matchAll(/(--[a-z0-9-]+):/g)].map(m => m[1]));
  const d = tokens(dark), l = tokens(light);
  assert.deepEqual([...d].filter(t => !l.has(t)), [], 'every dark token exists in light');
  assert.deepEqual([...l].filter(t => !d.has(t)), [], 'every light token exists in dark');
});

test('switcher: three radios in the top header; charts use theme variables; reduced motion respected', () => {
  const sw = read('src/ThemeSwitcher.tsx'), app = read('src/App.tsx'), ui = read('src/ui.tsx');
  for (const id of ["'dark'", "'light'", "'system'"]) assert.ok(sw.includes(id));
  assert.match(sw, /role="radiogroup"/);
  assert.match(app, /<ThemeSwitcher \/>/);
  assert.doesNotMatch(ui, /#1769F5|#7654F6|#64748B|#E3E9F5/, 'no hard-coded chart colours left');
  assert.match(read('src/main.tsx'), /import '\.\/theme\.css'/);
  assert.match(read('src/theme.css'), /prefers-reduced-motion:reduce/);
});
