import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read = (f: string) => readFileSync(f, 'utf8');

test('version 1.0.1, build 40 in every place', () => {
  const app = JSON.parse(read('app.json')).expo;
  assert.equal(app.version, '1.0.1');
  assert.equal(app.android.versionCode, 40);
  const gradle = read('android/app/build.gradle');
  assert.match(gradle, /versionName "1\.0\.1"/);
  assert.match(gradle, /\?: '40'/);
});

test('only post delete opens an ad by itself; everything else is a tap', () => {
  for (const f of ['App.tsx', 'src/SubmitForms.tsx', 'src/CommunityPostsPanel.tsx', 'src/CommunityScreen.tsx', 'src/ads.tsx']) {
    assert.doesNotMatch(read(f), /showInterstitialIfReady|showInterstitialForAction|INTERSTITIAL_COOLDOWN_MS|completedBreaks/, f);
  }
  assert.equal((read('App.tsx').match(/showSupportAd/g) ?? []).length, 0, 'no automatic ad in App');
  const button = read('src/SupportAdButton.tsx');
  assert.match(button, /onPress=\{\(\)=>void watch\(\)\}/);
  assert.match(button, /if\(!ready&&!busy\)return null/, 'hidden when no ad is loaded (Premium included)');
});

test('locked level: watch-an-ad unlock is optional and costs no points', () => {
  const app = read('App.tsx');
  assert.match(app, /Alert\.alert\('This level is locked'/);
  assert.match(app, /watchRewardedAd\(\(\)=>true,'unlock'\)/);
  const learning = read('src/learning.ts');
  assert.match(learning, /export const unlockLevelByAd/);
  const body = learning.slice(learning.indexOf('export const unlockLevelByAd'), learning.indexOf('Pay the accepted-word bonus'));
  assert.doesNotMatch(body, /balance:/, 'no balance change');
});
