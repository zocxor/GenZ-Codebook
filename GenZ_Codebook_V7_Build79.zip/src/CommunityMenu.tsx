import React from 'react';
import {Modal, Pressable, ScrollView, StyleSheet, View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {C} from './ui';

export function CommunityMenu({children,onDismiss}:{children:React.ReactNode;onDismiss:()=>void}){
 return <Modal transparent animationType="none" onRequestClose={onDismiss}>
  <SafeAreaView style={styles.overlay}>
   <Pressable accessibilityRole="button" accessibilityLabel="Dismiss menu" style={StyleSheet.absoluteFill} onPress={onDismiss}/>
   <View accessibilityViewIsModal style={styles.panel}>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.items}>{children}</ScrollView>
   </View>
  </SafeAreaView>
 </Modal>;
}
const styles=StyleSheet.create({
 overlay:{flex:1,alignItems:'flex-end',paddingHorizontal:12},
 panel:{marginTop:60,maxWidth:'100%',maxHeight:'75%',minWidth:175,backgroundColor:'#fff',borderRadius:14,borderColor:C.line,borderWidth:1,elevation:8},
 items:{padding:8,gap:6},
});
