import React,{useEffect,useRef,useState} from 'react';
import {ActivityIndicator,AppState,Image,Keyboard,Modal,Pressable,ScrollView,StyleSheet,Text,TextInput,View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {collection,doc,onSnapshot,orderBy,query,limit} from 'firebase/firestore';
import * as Clipboard from 'expo-clipboard';
import {C,BrandAvatar,Button,Chip,Glass,Icon,RoundIcon,confirmAction,type IconName} from './ui';
import {KeyboardDock} from './KeyboardDock';
import {search} from './engine';
import {pickChatPhoto,pickChatFile,openChatFile,type ChatFile} from './chatAttachments';
import {ProfileAction,ProfileIcon,SocialProfile,useProfileColors} from './SocialProfile';
import {CHAT_ATTACHMENT_DAYS} from '../shared/chatAttachments';
import {referralCodeForUid,referralInstallLink} from '../shared/referral';
import {usePublicAbout,usePublicProfiles} from './publicProfile';
import {VerifiedBadge,useBadges} from './VerifiedBadge';
import {cloudDbLive} from './firebase/app';
import {useAccountUser} from './services';
import {errorOf,ms,requestKey} from './communityFeatures';
import {ensureCommunityRules} from './safety';
import {REPORT_REASONS} from './ugc';
import {messaging,useInbox,usePrivateMessages,useMessagingPresence,type InboxRow,type Invite,type Person,type ProfileDetails,type PrivateMessage,type ConnectionList} from './messaging';
const time=(v:unknown)=>ms(v)?new Date(ms(v)).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):'';
const no=()=>{};
type InboxTab='personal'|'group'|'requests';
function Avatar({person,size=44}:{person:{avatar?:number;photo?:string;type?:string};size?:number}){return person.type==='group'?<View style={[s.groupAvatar,{width:size,height:size,borderRadius:size/3}]}><Icon name="people" color={C.purple}/></View>:person.photo?<Image source={{uri:person.photo}} style={{width:size,height:size,borderRadius:size/3}}/>:<BrandAvatar size={size} index={person.avatar||0}/>;}
function Header({title,subtitle,onBack,action}:{title:string;subtitle?:string;onBack:()=>void;action?:React.ReactNode}){return <View style={s.header}><RoundIcon name="arrow-back" label="Back" onPress={onBack}/><View style={{flex:1}}><Text accessibilityRole="header" style={s.title}>{title}</Text>{subtitle&&<Text style={s.small}>{subtitle}</Text>}</View>{action}</View>;}
function PresenceDot({uid}:{uid?:string}){const [until,setUntil]=useState(0),[now,setNow]=useState(Date.now());useEffect(()=>{setUntil(0);if(!uid)return;const stop=onSnapshot(doc(cloudDbLive(),'messagingPresence',uid),snap=>setUntil(snap.get('onlineUntil')||0),()=>setUntil(0));const timer=setInterval(()=>setNow(Date.now()),10000);return()=>{stop();clearInterval(timer);};},[uid]);return until>now?<View accessibilityLabel="Online" style={{width:8,height:8,borderRadius:4,backgroundColor:'#0D9A60'}}/>:null;}
export function InboxList({rows,uid,tab,onOpen,onAction}:{rows:InboxRow[];uid:string;tab:InboxTab;onOpen:(r:InboxRow)=>void;onAction:(r:InboxRow,patch:Record<string,unknown>)=>void}){
 const [search,setSearch]=useState(''),[filter,setFilter]=useState('all'),[menu,setMenu]=useState('');
 const shown=rows.filter(r=>!r.deleted&&(tab==='requests'?r.type==='personal'&&['pending','rejected'].includes(r.status):r.type===tab&&['active','closed'].includes(r.status))&&(filter==='archived'?r.archived:!r.archived)&&(filter!=='unread'||r.unread>0)&&r.name.toLowerCase().includes(search.toLowerCase())).sort((a,b)=>Number(!!b.pinned)-Number(!!a.pinned)||ms(b.updatedAt)-ms(a.updatedAt));
 const badges=useBadges(shown.flatMap(r=>r.peerId?[r.peerId]:[]));
 return <><TextInput accessibilityLabel="Search conversations" placeholder="Search conversations…" placeholderTextColor={C.muted} value={search} onChangeText={setSearch} style={s.input}/><View style={s.wrap}>{(tab==='requests'?['all','archived']:['all','unread','archived']).map(f=><Chip key={f} label={f==='all'?'All':f==='unread'?'Unread':'Archived'} selected={filter===f} onPress={()=>setFilter(f)}/>)}</View>
 {!shown.length&&<Glass><Icon name={tab==='group'?'people-outline':'chatbubbles-outline'} size={32} color={C.purple}/><Text style={s.heading}>{search?'No conversations found':tab==='group'?'Your groups live here':tab==='requests'?'No message requests':'Your personal inbox'}</Text><Text style={s.body}>{tab==='group'?'Create a group or accept an invitation to get started.':tab==='requests'?'Incoming and sent requests appear here.':'Find a user by name or code to start a conversation.'}</Text></Glass>}
 {shown.map(row=><View key={row.id} style={s.inboxCard}><Pressable accessibilityRole="button" accessibilityLabel={tab==='requests'?`Review request with ${row.name}`:`Open ${row.name}, ${row.unread||0} unread`} onPress={()=>onOpen(row)} style={s.inboxRow}><Avatar person={row}/><View style={{flex:1,gap:4}}><View style={s.inline}><Text style={[s.heading,{flexShrink:1}]} numberOfLines={1}>{row.name}</Text><PresenceDot uid={row.peerId}/><VerifiedBadge verified={badges.has(row.peerId||'')} tier={badges.tier(row.peerId)}/>{row.pinned&&<Icon name="pin" size={13}/>}<View style={{flex:1}}/><Text style={s.small}>{time(row.updatedAt)}</Text></View><Text style={s.body} numberOfLines={1}>{row.status==='pending'?(row.requestedBy===uid?'Request sent · waiting for acceptance':'Message request · review'):row.status==='rejected'?'Request declined':row.lastMessage&&!(row.lastMessage==='Request accepted'&&!row.lastMessageId)?row.lastMessage:'Start the conversation'}</Text>{row.type==='group'&&<Text style={s.small}>{row.memberCount||0} members{row.muted?' · muted':''}</Text>}</View>{row.unread>0&&<View style={s.badge}><Text style={s.badgeText}>{row.unread>99?'99+':row.unread}</Text></View>}</Pressable><Pressable accessibilityRole="button" accessibilityLabel={`Options for ${row.name}`} onPress={()=>setMenu(menu===row.id?'':row.id)} style={s.options}><Icon name="ellipsis-horizontal" size={19}/></Pressable>{menu===row.id&&<View style={[s.wrap,{padding:10}]}>{(['pinned','muted','archived']as const).map(k=><Chip key={k} label={k==='pinned'?(row.pinned?'Unpin':'Pin'):k==='muted'?(row.muted?'Unmute':'Mute'):(row.archived?'Unarchive':'Archive')} onPress={()=>{setMenu('');onAction(row,{[k]:!row[k]});}}/>)}<Chip label="Delete from my inbox" onPress={()=>confirmAction('Delete from your inbox?','Your copy and earlier messages will be hidden. Other members keep their copies.',()=>{setMenu('');onAction(row,{deleted:true});},'Delete')}/></View>}</View>)}
 </>;
}
export default function MessagingScreen({onClose,onSignIn,initialFind=false,initialConnections}:{onClose:()=>void;onSignIn:()=>void;initialFind?:boolean;initialConnections?:ConnectionList}){
 const user=useAccountUser(),uid=user?.uid,eligible=!!user?.emailVerified;
 const feed=useInbox(uid,eligible),[tab,setTab]=useState<InboxTab>('personal'),[row,setRow]=useState<InboxRow|null>(null),[mode,setMode]=useState<'inbox'|'find'|'create'|'privacy'>(initialFind?'find':'inbox'),[person,setPerson]=useState<Person|null>(null),[note,setNote]=useState(''),[busy,setBusy]=useState(false),[invites,setInvites]=useState<Invite[]>([]);
 const [connections,setConnections]=useState<{uid:string;list:ConnectionList}|null>(()=>uid&&initialConnections?{uid,list:initialConnections}:null);
 const closeConnections=()=>{setConnections(null);if(initialConnections&&!person)onClose();};
 const chooseConnection=(item:Person)=>{
  setConnections(null);
  if(item.uid===uid){onClose();return;}
  setPerson(item);
 };
 useMessagingPresence(uid,eligible);
 useEffect(()=>{if(!row)return;const fresh=feed.rows.find(r=>r.id===row.id);if(fresh)setRow(fresh);},[feed.rows]);
 useEffect(()=>{setInvites([]);if(!uid||!eligible)return;return onSnapshot(query(collection(cloudDbLive(),`users/${uid}/messageInvites`),orderBy('createdAt','desc'),limit(50)),s=>setInvites(s.docs.filter(d=>d.get('status')==='pending').map(d=>({...d.data(),id:d.id})as Invite)),()=>{});},[uid,eligible]);
 const act=async(command:string,data:Record<string,unknown>={})=>{setBusy(true);setNote('');try{return await messaging(command,data);}catch(e){setNote(errorOf(e));}finally{setBusy(false);}};
 const open=(r:InboxRow)=>{setNote('');setRow(r);};
 const start=async(profile:ProfileDetails)=>{
  const existing=feed.rows.find(r=>r.id===profile.conversationId);
  if(!profile.chatStatus&&!(await ensureCommunityRules()))return;
  const result=await act('request',{uid:profile.uid});
  if(!result)return;
  const status=result.status??profile.chatStatus??'pending';
  const requestTab=status==='pending'||status==='rejected';
  setConnections(null);setPerson(null);setMode('inbox');setTab(requestTab?'requests':'personal');
  if(!profile.chatStatus&&status==='pending'){setRow(null);setNote('Request sent. The conversation opens when they accept.');}
  else setRow(existing?{...existing,status,archived:false,deleted:false}:{
   id:result.id,conversationId:result.id,type:'personal',name:profile.name,peerId:profile.uid,avatar:profile.avatar,
   photo:profile.photo,status,unread:0,requestedBy:profile.requestedByMe?uid:profile.uid,
  });
 };

 return <SafeAreaView style={s.screen}><KeyboardDock><View style={s.fill}>
 {!uid||!eligible?<><Header title="Inbox" onBack={onClose}/><View style={s.content}><Glass><Icon name="mail-unread-outline" color={C.purple} size={36}/><Text style={s.heading}>Your conversations, in one place</Text><Text style={s.body}>{!uid?'Sign in to send private messages and join groups.':'Verify your email before using private messaging.'}</Text><Button title={!uid?'Sign in':'Open account'} onPress={()=>{onClose();onSignIn();}}/></Glass></View></>:row?<Conversation key={row.id} row={row} uid={uid} onBack={()=>{if(tab==='requests'&&row.status==='active')setTab('personal');setRow(null);}} onNote={setNote} onOpenProfileChat={start}/>:connections?<ConnectionsScreen key={connections.uid+connections.list} target={connections.uid} list={connections.list} onBack={closeConnections} onChoose={chooseConnection}/>:mode==='privacy'?<Privacy uid={uid} onBack={()=>setMode('inbox')}/>:person?<><Header title="Public profile" onBack={()=>{setPerson(null);if(initialConnections&&uid)setConnections({uid,list:initialConnections});}}/><ScrollView contentContainerStyle={s.content}><PersonProfile key={person.uid} person={person} messageBusy={busy} onMessage={start} onConnections={list=>setConnections({uid:person.uid,list})}/></ScrollView></>:mode==='find'?<><Header title="Find a friend" subtitle="Search by name or user code" onBack={()=>setMode('inbox')}/><PeopleSearch onChoose={setPerson}/></>:mode==='create'?<CreateGroup onBack={()=>setMode('inbox')} onDone={()=>{setMode('inbox');setTab('group');setNote('Group created. Open it to invite friends.');}}/>:<><Header title="Inbox" subtitle="Personal messages & private groups" onBack={onClose} action={<RoundIcon name="settings-outline" label="Messaging privacy" onPress={()=>setMode('privacy')}/>}/><View style={s.tabs}><Chip label="Personal" icon="person-outline" selected={tab==='personal'} onPress={()=>setTab('personal')}/><Chip label="Groups" icon="people-outline" selected={tab==='group'} onPress={()=>setTab('group')}/><Chip label={feed.requests?`Requests (${feed.requests})`:'Requests'} selected={tab==='requests'} onPress={()=>setTab('requests')}/><View style={{flex:1}}/><RoundIcon name={tab==='group'?'add':'search-outline'} label={tab==='group'?'Create group':'Find people'} onPress={()=>setMode(tab==='group'?'create':'find')}/></View><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.content}>
 {!!feed.error&&<><Text style={s.error}>{feed.error}</Text><Button light title="Retry Inbox" onPress={feed.retry}/></>}{feed.loading&&<ActivityIndicator color={C.accent}/>}
 {tab==='group'&&invites.map(inv=><Glass key={inv.id}><Text style={s.heading}>Invitation: {inv.name}</Text><Text style={s.body}>Only accepted members can read this group.</Text><View style={s.wrap}><Chip label="Accept" onPress={()=>void act('respond-invite',{conversationId:inv.id,accept:true})}/><Chip label="Decline" onPress={()=>void act('respond-invite',{conversationId:inv.id,accept:false})}/></View></Glass>)}
 <InboxList key={tab} rows={feed.rows} uid={uid} tab={tab} onOpen={open} onAction={(r,p)=>void act('inbox-settings',{conversationId:r.id,...p})}/><Text style={s.small}>Personal and group text messages are free. New personal chats require acceptance.</Text></ScrollView></>}
 {!!note&&<View accessibilityLiveRegion="polite" style={s.notice}><Text style={s.body}>{note}</Text><Pressable accessibilityRole="button" accessibilityLabel="Dismiss notice" onPress={()=>setNote('')}><Icon name="close" size={18}/></Pressable></View>}
 </View></KeyboardDock></SafeAreaView>;
}
function PersonProfile({person,onMessage,messageBusy=false,onConnections}:{person:Person;onMessage:(p:ProfileDetails)=>Promise<void>;messageBusy?:boolean;onConnections?:(list:ConnectionList)=>void}){
 const badges=useBadges([person.uid]);
 const [profile,setProfile]=useState<ProfileDetails|null>(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[epoch,retry]=useState(0);
 const colors=useProfileColors();
 const [menu,setMenu]=useState(false),[shareNote,setShareNote]=useState('');
 useEffect(()=>{
  let active=true;setProfile(null);setError('');
  void messaging('profile',{uid:person.uid}).then(r=>{if(active)setProfile(r.person);},e=>{if(active)setError(errorOf(e));});
  return()=>{active=false;};
 },[person.uid,epoch]);
 const follow=async()=>{
  if(!profile||busy)return;
  setBusy(true);setError('');
  try{
   await messaging('follow',{uid:profile.uid,following:!profile.following});
   setProfile((await messaging('profile',{uid:profile.uid})).person);
  }catch(e){setError(errorOf(e));}
  finally{setBusy(false);}
 };
 const visible=profile??person;
 const about=usePublicAbout(profile?.uid);
 const messageLabel=profile?.chatStatus==='pending'?'Message request':profile?.chatStatus==='rejected'?'Request declined':'Message';
 return <View style={{padding:14,gap:10,borderRadius:16,backgroundColor:colors.bg}}>
  <View style={[s.inline,{justifyContent:'flex-end'}]}>
   <ProfileIcon colors={colors} label={colors.dark?'Switch to light profile':'Switch to dark profile'} name={colors.dark?'sunny-outline':'moon-outline'} onPress={colors.toggle}/>
   {profile&&<ProfileIcon colors={colors} label="Profile options" name="ellipsis-horizontal" onPress={()=>setMenu(v=>!v)}/>}
  </View>
  <View style={s.inline}>
   <BrandAvatar index={visible.avatar} photo={visible.photo} size={72}/>
   <View style={{flex:1,gap:4}}>
    <View style={s.inline}><Text accessibilityRole="header" style={[s.title,{flexShrink:1,color:colors.ink}]}>{visible.name}</Text>
     <VerifiedBadge verified={badges.has(person.uid)} tier={badges.tier(person.uid)} size={20}/></View>
    <View style={[s.inline,{alignItems:'center',flexWrap:'wrap'}]}>
     <Text selectable style={{color:colors.muted}}>{referralCodeForUid(person.uid)}</Text>
     <ProfileIcon colors={colors} label="Copy sharing code" name="copy-outline" onPress={()=>void Clipboard.setStringAsync(referralCodeForUid(person.uid)).then(()=>setShareNote('Sharing code copied'),e=>setShareNote(errorOf(e)))}/>
     <ProfileIcon colors={colors} label="Copy invite link" name="link-outline" onPress={()=>void Clipboard.setStringAsync(referralInstallLink(referralCodeForUid(person.uid))).then(()=>setShareNote('Invite link copied'),e=>setShareNote(errorOf(e)))}/>
    </View>
    {!!shareNote&&<Text accessibilityLiveRegion="polite" style={s.small}>{shareNote}</Text>}
   </View>
  </View>
  {!!profile&&!!about.bio&&<Text numberOfLines={2} style={{color:colors.ink}}>{about.bio}</Text>}
  {!!profile&&!!about.location&&<Text style={{color:colors.muted}}>{about.location}</Text>}
  {profile?<><View style={{flexDirection:'row',gap:8}}>
   <View style={{flex:1}}><ProfileAction colors={colors} label={busy?'Updating…':profile.following?'Following':'Follow'} primary={!profile.following} disabled={busy} onPress={()=>{
    if(profile.following)confirmAction(`Unfollow ${visible.name}?`,'You can follow this member again any time.',()=>void follow(),'Unfollow');
    else void follow();
   }}/></View>
   <View style={{flex:1}}><ProfileAction colors={colors} label={messageBusy?'Opening…':messageLabel} disabled={messageBusy||profile.chatStatus==='rejected'} onPress={()=>void onMessage(profile)}/></View>
  </View>
  {menu&&<View style={{gap:6}}>
   <ProfileAction colors={colors} label="Copy user code" onPress={()=>void Clipboard.setStringAsync(referralCodeForUid(person.uid)).then(()=>setMenu(false),e=>setError(errorOf(e)))}/>
   <ProfileAction colors={colors} label="Block private messages" onPress={()=>confirmAction(`Block ${visible.name}?`,'You can unblock this person in Messaging privacy.',()=>void messaging('block',{uid:person.uid,blocked:true}).then(()=>{
    setProfile(null);setMenu(false);setError('Private messages blocked.');
   },e=>setError(errorOf(e))),'Block')}/>
  </View>}
  <SocialProfile uid={profile.uid} colors={colors} about={about} followers={profile.followers} following={profile.followingCount} likes={profile.postLikes} onConnections={onConnections}/>
  </>:error?<ProfileAction colors={colors} label="Retry profile" onPress={()=>retry(v=>v+1)}/>:<ActivityIndicator color={colors.accent}/>}
  {!!error&&<Text accessibilityLiveRegion="polite" style={{color:colors.muted}}>{error}</Text>}
 </View>;
}
function ConnectionsScreen({target,list,onBack,onChoose}:{target:string;list:ConnectionList;onBack:()=>void;onChoose:(person:Person)=>void}){
 const [rows,setRows]=useState<Person[]>([]),[cursor,setCursor]=useState<string|null>(null),[busy,setBusy]=useState(true),[error,setError]=useState('');
 const load=async(after?:string)=>{
  setBusy(true);setError('');
  try{
   const result=await messaging('connections',{uid:target,list,...(after?{cursor:after}:{})});
   setRows(current=>after?[...current,...result.users]:result.users);
   setCursor(result.cursor);
  }catch(e){setError(errorOf(e));}
  finally{setBusy(false);}
 };
 useEffect(()=>{void load();},[target,list]);
 return <><Header title={list==='followers'?'Followers':'Following'} onBack={onBack}/><ScrollView contentContainerStyle={s.content}>
  {busy&&<ActivityIndicator color={C.accent}/>}
  {rows.map(person=><Pressable key={person.uid} accessibilityRole="button" accessibilityLabel={'View '+person.name} onPress={()=>onChoose(person)} style={s.inboxRow}><Avatar person={person}/><Text style={[s.heading,{flex:1}]}>{person.name}</Text><Icon name="chevron-forward" size={18}/></Pressable>)}
  {!!error&&<Text style={s.error}>{error}</Text>}
  {!busy&&(cursor||error)?<Button light title={error?'Try again':'Load more'} onPress={()=>void load(cursor??undefined)}/>:null}
  {!busy&&!error&&!cursor&&!rows.length&&<Text style={s.body}>{list==='followers'?'No followers yet.':'No accounts followed yet.'}</Text>}
 </ScrollView></>;
}
function PeopleSearch({onChoose}:{onChoose:(p:Person)=>void}){
 const [value,setValue]=useState(''),[rows,setRows]=useState<Person[]>([]),[error,setError]=useState(''),[busy,setBusy]=useState(false),seq=useRef(0);
 const badges=useBadges(rows.map(p=>p.uid));
 useEffect(()=>{const token=++seq.current;setRows([]);setError('');if(value.trim().length<2){setBusy(false);return;}setBusy(true);const timer=setTimeout(()=>{void messaging('search',{query:value.trim()}).then(result=>{if(token===seq.current){setRows(result.users||[]);setBusy(false);}},e=>{if(token===seq.current){setError(errorOf(e));setBusy(false);}});},450);return()=>{clearTimeout(timer);seq.current++;};},[value]);
 return <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.content}><TextInput accessibilityLabel="Search users by name or user code" autoCapitalize="none" placeholder="Name or user code…" placeholderTextColor={C.muted} value={value} onChangeText={setValue} maxLength={40} style={s.input}/>{busy&&<ActivityIndicator color={C.accent}/>}{!!error&&<Text style={s.error}>{error}</Text>}{!busy&&!error&&value.trim().length>=2&&!rows.length&&<Text style={s.body}>No available users found. Try their exact user code.</Text>}{rows.map(p=><Pressable key={p.uid} accessibilityRole="button" accessibilityLabel={'View '+p.name} onPress={()=>onChoose(p)} style={s.inboxRow}><Avatar person={p}/><View style={[s.inline,{flex:1}]}><Text numberOfLines={2} style={[s.heading,{flexShrink:1}]}>{p.name}</Text><VerifiedBadge verified={badges.has(p.uid)} tier={badges.tier(p.uid)}/></View><Icon name="chevron-forward" size={18}/></Pressable>)}</ScrollView>;
}
function CreateGroup({onBack,onDone}:{onBack:()=>void;onDone:()=>void}){const [name,setName]=useState(''),[description,setDescription]=useState(''),[privacy,setPrivacy]=useState('invite-only'),[busy,setBusy]=useState(false),[error,setError]=useState(''),key=useRef(requestKey());const create=async()=>{if(!(await ensureCommunityRules()))return;setBusy(true);setError('');try{await messaging('create-group',{name,description,privacy,requestId:key.current});onDone();}catch(e){setError(errorOf(e));}finally{setBusy(false);}};return <><Header title="Create a group" onBack={onBack}/><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.content}><Glass><Text style={s.heading}>A space for your people</Text><Text style={s.body}>Private text conversations · free · up to 50 members</Text><TextInput accessibilityLabel="Group name" placeholder="Group name" placeholderTextColor={C.muted} value={name} onChangeText={setName} maxLength={60} style={s.input}/><TextInput accessibilityLabel="Group description" placeholder="Description (optional)" placeholderTextColor={C.muted} value={description} onChangeText={setDescription} maxLength={240} multiline style={s.input}/><View style={s.wrap}>{['private','invite-only'].map(p=><Chip key={p} label={p==='private'?'Private':'Invite-only'} selected={privacy===p} onPress={()=>setPrivacy(p)}/>)}</View><Text style={s.body}>Text-only groups. Invite members after creating the group. Each person must accept.</Text>{!!error&&<Text style={s.error}>{error}</Text>}<Button title={busy?'Creating…':'Create group'} icon="people-outline" disabled={busy||!name.trim()} onPress={()=>void create()}/></Glass></ScrollView></>;}
function Privacy({uid,onBack}:{uid:string;onBack:()=>void}){const [requests,setRequests]=useState('everyone'),[presence,setPresence]=useState(false),[blocked,setBlocked]=useState<string[]>([]),[note,setNote]=useState(''),[busy,setBusy]=useState(false);const blockedProfiles=usePublicProfiles(blocked);useEffect(()=>{const a=onSnapshot(doc(cloudDbLive(),`users/${uid}/messaging/preferences`),s=>{setRequests(s.get('requests')||'everyone');setPresence(s.get('showPresence')===true);},()=>setNote('Privacy settings could not load.'));const b=onSnapshot(collection(cloudDbLive(),`users/${uid}/messagingBlocks`),s=>setBlocked(s.docs.map(d=>d.id)),()=>setNote('Blocked users could not load.'));return()=>{a();b();};},[uid]);return <><Header title="Messaging privacy" onBack={onBack}/><ScrollView contentContainerStyle={s.content}><Glass><Text style={s.heading}>Who can request a chat or invite you?</Text><View style={s.wrap}><Chip label="Everyone" selected={requests==='everyone'} onPress={()=>setRequests('everyone')}/><Chip label="Nobody" selected={requests==='nobody'} onPress={()=>setRequests('nobody')}/></View><Text style={s.body}>Every new personal conversation still requires your acceptance. Existing accepted conversations remain available.</Text><Chip label={presence?'Online / last seen: visible':'Online / last seen: hidden'} selected={presence} onPress={()=>setPresence(v=>!v)}/><Text style={s.body}>Presence is visible only to your conversation members when enabled.</Text><Button title={busy?'Saving…':'Save preferences'} disabled={busy} onPress={()=>{setBusy(true);void messaging('preferences',{requests,showPresence:presence}).then(()=>setNote('Privacy settings saved.'),e=>setNote(errorOf(e))).finally(()=>setBusy(false));}}/></Glass><Text style={s.heading}>Blocked for private messaging</Text>{!blocked.length&&<Text style={s.body}>Nobody blocked.</Text>}{blocked.map((id,index)=><Button light key={id} title={`Unblock ${blockedProfiles.get(id)?.name||'user '+(index+1)}`} onPress={()=>void messaging('block',{uid:id,blocked:false}).catch(e=>setNote(errorOf(e)))}/>)}{!!note&&<Text style={s.body}>{note}</Text>}</ScrollView></>;}
function ReceivedAttachment({conversationId,message}:{conversationId:string;message:PrivateMessage}){
 const [image,setImage]=useState(''),[loading,setLoading]=useState(false),[error,setError]=useState('');
 const [expired,setExpired]=useState(()=>Date.now()>=(message.attachmentExpiresAt??0));
 useEffect(()=>{
  if(expired)return;
  let timer:ReturnType<typeof setTimeout>;
  const check=()=>{
   const remaining=(message.attachmentExpiresAt??0)-Date.now();
   if(remaining<=0){setExpired(true);setImage('');return;}
   timer=setTimeout(check,Math.min(remaining,86400000));
  };
  check();
  return()=>clearTimeout(timer);
 },[message.attachmentExpiresAt,expired]);
 const open=async()=>{
  setLoading(true);setError('');
  try{
   const result=await messaging('attachment',{conversationId,messageId:message.id});
   if(Date.now()>=(message.attachmentExpiresAt??0)){setExpired(true);return;}
   if(result.fileName)await openChatFile({name:result.fileName,data:result.data});
   else setImage(result.data);
  }catch(e){setError(errorOf(e));}
  finally{setLoading(false);}
 };
 return <View style={s.photoCard}>
  {!!message.fileName&&<Text selectable numberOfLines={2} style={s.body}>{message.fileName}</Text>}
  <Button light icon={message.fileName?'document-outline':'image-outline'} title={expired?'Attachment expired':loading?'Loading…':message.fileName?'Open file':'Open photo'} disabled={expired||loading} onPress={()=>void open()}/>
  {!!error&&<Text accessibilityLiveRegion="polite" style={s.error}>{error}</Text>}
  <Modal visible={!!image&&!expired} onRequestClose={()=>setImage('')} animationType="fade">
   <SafeAreaView style={s.photoViewer}>
    <Header title="Photo" onBack={()=>setImage('')}/>
    {!!image&&<Image accessibilityLabel="Shared photo" style={s.viewerImage} resizeMode="contain" source={{uri:'data:image/jpeg;base64,'+image}}/>}
   </SafeAreaView>
  </Modal>
 </View>;
}
export function MessageBubble({message,mine,read,delivered=false,onPress,conversationId}:{message:PrivateMessage;mine:boolean;read:boolean;delivered?:boolean;onPress:()=>void;conversationId?:string}){const [quoted,setQuoted]=useState(message.replyText||'Reply');useEffect(()=>{if(!conversationId||!message.replyTo)return;return onSnapshot(doc(cloudDbLive(),`conversations/${conversationId}/messages/${message.replyTo}`),snap=>setQuoted(snap.exists()?(snap.get('removed')?'Message removed':String(snap.get('text')).slice(0,160)):'Message unavailable'),()=>setQuoted('Message unavailable'));},[conversationId,message.replyTo]);const [reactions,setReactions]=useState<string[]>([]);useEffect(()=>{if(!conversationId)return;return onSnapshot(collection(cloudDbLive(),`conversations/${conversationId}/messages/${message.id}/reactions`),s=>setReactions(s.docs.map(d=>d.get('emoji'))),()=>{});},[conversationId,message.id]);return <View style={[s.bubble,mine?s.mine:s.theirs]}><Pressable accessibilityRole="button" accessibilityLabel={`Message from ${message.name}. ${message.text}. Options`} onPress={onPress} style={{gap:5}}>{!mine&&<Text style={s.sender}>{message.name}</Text>}{message.replyTo&&<View style={s.reply}><Text style={s.sender}>{message.replyName}</Text><Text style={s.small} numberOfLines={2}>{quoted}</Text></View>}
 {(!message.attachmentExpiresAt||message.attachmentCaption||message.removed)&&<Text selectable style={s.messageText}>{message.text}</Text>}<View style={s.messageMeta}><Text style={s.small}>{time(message.createdAt)}</Text>{mine&&<Text style={[s.small,{color:read?C.accent:C.muted}]}>{read?'✓✓ Read':delivered?'✓✓ Delivered':'✓ Sent'}</Text>}</View>{reactions.length>0&&<Text style={s.body}>{[...new Set(reactions)].map(e=>e+' '+reactions.filter(v=>v===e).length).join('  ')}</Text>}</Pressable>{!!message.attachmentExpiresAt&&!message.removed&&conversationId&&<ReceivedAttachment conversationId={conversationId} message={message}/>}</View>;}
function Conversation({row,uid,onBack,onNote,onOpenProfileChat}:{row:InboxRow;uid:string;onBack:()=>void;onNote:(v:string)=>void;onOpenProfileChat:(p:ProfileDetails)=>Promise<void>}){
 const feed=usePrivateMessages(uid,row),[text,setText]=useState(''),[busy,setBusy]=useState(false),[reply,setReply]=useState<PrivateMessage|null>(null),[selected,setSelected]=useState<PrivateMessage|null>(null),[report,setReport]=useState(false),[detail,setDetail]=useState(false),[members,setMembers]=useState<Person[]>([]),[conversation,setConversation]=useState<Record<string,any>>({}),[typing,setTyping]=useState<string[]>([]),[now,setNow]=useState(Date.now()),[codeOpen,setCodeOpen]=useState(false),[codeQuery,setCodeQuery]=useState(''),key=useRef(requestKey()),lastTyping=useRef(0),scroll=useRef<ScrollView>(null),sending=useRef(false);
 const [image,setImage]=useState<string|null>(null),[file,setFile]=useState<ChatFile|null>(null),[picking,setPicking]=useState(false);
 const chooseAttachment=async(kind:'photo'|'file')=>{
  setPicking(true);
  try{
   if(kind==='photo'){
    const next=await pickChatPhoto();
    if(next){setImage(next);setFile(null);key.current=requestKey();}
   }else{
    const next=await pickChatFile();
    if(next){setFile(next);setImage(null);key.current=requestKey();}
   }
  }catch(err){onNote(err instanceof Error?err.message:'Could not open that attachment.');}
  finally{setPicking(false);}
 };
 const [receipts,setReceipts]=useState<Record<string,{readAt?:unknown;deliveredAt?:unknown}>>({});
 useEffect(()=>{setReceipts({});return onSnapshot(collection(cloudDbLive(),`conversations/${row.id}/receipts`),snap=>setReceipts(Object.fromEntries(snap.docs.map(d=>[d.id,d.data()]))),()=>{});},[row.id]);
 const reloadRoster=()=>void messaging('roster',{conversationId:row.id}).then(r=>{setMembers(r.members||[]);setConversation(r.conversation||{});},e=>onNote(errorOf(e)));
 useEffect(()=>{reloadRoster();let signature='';return onSnapshot(doc(cloudDbLive(),'conversations',row.id),snap=>{const c=snap.data();if(!c)return;const next=JSON.stringify([c.members,c.roles,c.ownerId,c.name,c.description,c.status]);if(signature&&signature!==next)reloadRoster();signature=next;setConversation({id:row.id,...c});},e=>onNote(errorOf(e)));},[row.id]);
 useEffect(()=>{if(!['active','closed'].includes(row.status))return;const read=()=>{if(AppState.currentState==='active')void messaging('read',{conversationId:row.id}).catch(e=>onNote(errorOf(e)));};read();const timer=setInterval(read,30000);const sub=AppState.addEventListener('change',state=>{if(state==='active')read();else void messaging('viewing',{conversationId:row.id}).catch(no);});return()=>{clearInterval(timer);sub.remove();void messaging('viewing',{conversationId:row.id}).catch(no);};},[row.id,row.status]);
 useEffect(()=>{if(row.status==='active'&&feed.rows.length&&AppState.currentState==='active')void messaging('read',{conversationId:row.id}).catch(no);},[row.id,row.status,feed.rows.at(-1)?.id]);
 useEffect(()=>{if(row.status!=='active')return;const stop=onSnapshot(collection(cloudDbLive(),`conversations/${row.id}/typing`),s=>setTyping(s.docs.filter(d=>d.id!==uid&&d.get('until')>Date.now()).map(d=>d.id)),()=>{});const timer=setInterval(()=>setNow(Date.now()),3000);return()=>{stop();clearInterval(timer);};},[row.id,row.status]);
 const call=async(command:string,data:Record<string,unknown>={})=>{try{const result=await messaging(command,{conversationId:row.id,...data});setSelected(null);setReport(false);return result;}catch(e){onNote(errorOf(e));}};
 const send=async()=>{if(sending.current||picking||(!text.trim()&&!image&&!file)||!(await ensureCommunityRules()))return;sending.current=true;setBusy(true);const draft=text;try{await messaging('send',{conversationId:row.id,text:draft,requestId:key.current,...(image?{image}:{}),...(file?{file}:{}),...(reply?{replyTo:reply.id}:{})});setText('');setImage(null);setFile(null);setReply(null);key.current=requestKey();void call('typing',{typing:false});}catch(e){onNote(errorOf(e)+' Your draft is kept; tap Send to retry.');}finally{sending.current=false;setBusy(false);}};
 const onText=(v:string)=>{setText(v);key.current=requestKey();if(Date.now()-lastTyping.current>4000&&row.status==='active'){lastTyping.current=Date.now();void messaging('typing',{conversationId:row.id,typing:!!v}).catch(no);}};
 const [peerPresence,setPeerPresence]=useState<{online?:boolean;onlineUntil?:number;lastSeen?:number}>({online:false});useEffect(()=>{setPeerPresence({online:false});if(!row.peerId)return;return onSnapshot(doc(cloudDbLive(),'messagingPresence',row.peerId),snap=>setPeerPresence({online:snap.get('onlineUntil')>Date.now(),onlineUntil:snap.get('onlineUntil'),lastSeen:ms(snap.get('lastSeen'))}),()=>setPeerPresence({online:false,lastSeen:undefined}));},[row.peerId]);
 const peerBase=members.find(m=>m.uid===row.peerId),peer=peerBase?{...peerBase,...peerPresence,online:peerPresence.online===true&&(peerPresence.onlineUntil||0)>now}:undefined,readAt=Math.min(...members.filter(m=>m.uid!==uid).map(m=>Math.max(m.readAt||0,ms(receipts[m.uid]?.readAt)))),myRole=conversation.roles?.[uid],canModerate=row.type==='group'&&['owner','admin','moderator'].includes(myRole);
 if(detail)return <GroupDetails row={row} uid={uid} members={members} conversation={conversation} onBack={()=>{setDetail(false);reloadRoster();}} onCall={call} onRefresh={reloadRoster} onLeave={onBack} onOpenProfileChat={onOpenProfileChat}/>;
 return <><Header title={row.name} subtitle={row.type==='group'?`${row.memberCount||members.length} members`:peer?.online?'Online':peer?.lastSeen?'Last seen '+new Date(peer.lastSeen).toLocaleString():row.status==='pending'?'Message request':'Private conversation'} onBack={onBack} action={<RoundIcon name="information-circle-outline" label="Conversation details" onPress={()=>setDetail(true)}/>}/>
 {row.status==='pending'?<View style={s.content}><Glass><Text style={s.heading}>{row.requestedBy===uid?'Waiting for acceptance':'A new message request'}</Text><Text style={s.body}>You can exchange messages after the recipient accepts.</Text>{row.requestedBy!==uid&&<View style={s.wrap}><Chip label="Accept" onPress={()=>void call('respond-request',{accept:true})}/><Chip label="Decline" onPress={()=>confirmAction('Decline this request?','This person cannot send another request to this conversation.',()=>void call('respond-request',{accept:false}),'Decline')}/></View>}</Glass></View>:!['active','closed'].includes(row.status)?<View style={s.content}><Text style={s.body}>This conversation is {row.status}. You cannot send messages.</Text></View>:<><ScrollView ref={scroll} keyboardShouldPersistTaps="handled" contentContainerStyle={s.messages} onContentSizeChange={()=>{if(!feed.more)scroll.current?.scrollToEnd({animated:true});}}>
 {feed.more&&<Button light title="Load older messages" disabled={feed.loading} onPress={()=>void feed.loadOlder()}/>} {!!feed.error&&<><Text style={s.error}>{feed.error}</Text><Button light title="Retry messages" onPress={feed.retry}/></>}{feed.loading&&<ActivityIndicator color={C.accent}/>}{!feed.loading&&!feed.rows.length&&<Text style={[s.body,{textAlign:'center',padding:20}]}>Say hello. Your conversation starts here.</Text>}
 {feed.rows.map(m=><MessageBubble key={m.id} message={m} mine={m.senderId===uid} read={readAt>=ms(m.createdAt)&&members.length>1} delivered={members.filter(p=>p.uid!==uid).every(p=>ms(receipts[p.uid]?.deliveredAt)>=ms(m.createdAt))&&members.length>1} onPress={()=>{Keyboard.dismiss();setSelected(m);setReport(false);}} conversationId={row.id}/>)}
 </ScrollView>{selected&&<View style={s.actionPanel}><Text style={s.heading}>{report?'Report message':'Message options'}</Text><View style={s.wrap}>{report?REPORT_REASONS.map(reason=><Chip key={reason} label={reason} onPress={()=>void call('report',{messageId:selected.id,reason})}/>):<><Chip label="Reply" onPress={()=>{setReply(selected);setSelected(null);}}/><Chip label="Copy" onPress={()=>{void Clipboard.setStringAsync(selected.text).then(()=>onNote('Message copied.'));setSelected(null);}}/><Chip label="Delete for me" onPress={()=>confirmAction('Hide this message?','It will disappear only for you.',()=>void call('hide-message',{messageId:selected.id}),'Hide')}/>{selected.senderId!==uid&&<Chip label="Report" onPress={()=>setReport(true)}/>} {canModerate&&<Chip label="Remove for everyone" onPress={()=>confirmAction('Remove this group message?','All group members will see a removal notice.',()=>void call('remove-message',{messageId:selected.id}),'Remove')}/>} {['❤️','👍','😂','😮','🙏'].map(emoji=><Chip key={emoji} label={emoji} onPress={()=>void call('react',{messageId:selected.id,emoji})}/>)}</>}<Chip label="Cancel" onPress={()=>setSelected(null)}/></View></View>}
 {typing.length>0&&now-lastTyping.current>=0&&<TypingLine ids={typing} rowId={row.id} members={members}/>}
 {row.status==='active'?<View style={s.composer}>
 {(image||file)&&<View style={s.inline}>
  {image?<Image style={s.draftPreview} source={{uri:'data:image/jpeg;base64,'+image}}/>:<Icon name="document-outline" color={C.accent}/>}
  <View style={{flex:1}}><Text numberOfLines={1} style={s.heading}>{file?.name??'Photo attached'}</Text><Text style={s.small}>Attachments expire after {CHAT_ATTACHMENT_DAYS} days.</Text></View>
  <RoundIcon name="close" label="Remove attachment" onPress={()=>{if(!busy){setImage(null);setFile(null);key.current=requestKey();}}}/>
 </View>}
 {row.type==='personal'&&<View style={s.wrap}>
  <Chip icon="image-outline" label="Attach photo" onPress={()=>{if(!busy&&!picking)void chooseAttachment('photo');}}/>
  <Chip icon="document-outline" label="Attach file" onPress={()=>{if(!busy&&!picking)void chooseAttachment('file');}}/>
  {picking&&<ActivityIndicator accessibilityLabel="Preparing attachment" color={C.accent}/>}
 </View>}
 {codeOpen&&<View style={{gap:6}}><TextInput accessibilityLabel="Find a dictionary code to share" placeholder="Find a Codebook word…" placeholderTextColor={C.muted} value={codeQuery} onChangeText={setCodeQuery} maxLength={120} style={s.input}/><ScrollView style={{maxHeight:180}} keyboardShouldPersistTaps="handled">{!!codeQuery.trim()&&search(codeQuery).slice(0,6).map(t=><Pressable key={t.id} accessibilityRole="button" accessibilityLabel={'Share '+t.expression} style={{padding:8}} onPress={()=>{const value=[text,`${t.expression}: ${t.meaning}`,t.example?'Example: '+t.example:''].filter(Boolean).join('\n');if(value.length>1500){onNote('This code will not fit in the current message. Shorten your draft first.');return;}onText(value);setCodeOpen(false);setCodeQuery('');}}><Text style={s.heading}>{t.expression}</Text><Text style={s.small} numberOfLines={2}>{t.meaning}</Text></Pressable>)}</ScrollView><Chip label="Close dictionary" onPress={()=>setCodeOpen(false)}/></View>}{reply&&<View style={s.inline}><View style={{flex:1}}><Text style={s.sender}>Replying to {reply.name}</Text><Text style={s.small} numberOfLines={1}>{reply.text}</Text></View><RoundIcon name="close" label="Cancel reply" onPress={()=>setReply(null)}/></View>}<View style={s.inline}><TextInput accessibilityLabel="Message" placeholder="Message…" placeholderTextColor={C.muted} value={text} onChangeText={onText} editable={!busy} maxLength={1500} multiline style={[s.input,{flex:1,maxHeight:110}]}/><RoundIcon name="book-outline" label="Share a Codebook word" onPress={()=>setCodeOpen(v=>!v)}/><RoundIcon name="happy-outline" label="Add smile emoji" onPress={()=>onText(text+' 😊')}/><Pressable accessibilityRole="button" accessibilityLabel="Send message" disabled={busy||picking||(!text.trim()&&!image&&!file)} onPress={()=>void send()} style={[s.send,(busy||picking||(!text.trim()&&!image&&!file))&&{opacity:.45}]}>{busy?<ActivityIndicator color="#fff"/>:<Icon name="send" color="#fff" size={19}/>}</Pressable></View><Text style={s.small}>Free messaging · {text.length}/1500</Text></View>:<Text style={[s.body,{padding:16}]}>This conversation is closed. Earlier messages remain available.</Text>}</>}
 </>;
}
function TypingLine({ids,rowId,members}:{ids:string[];rowId:string;members:Person[]}){const [visible,setVisible]=useState<string[]>([]);useEffect(()=>{let latest:{id:string;until:number}[]=[];const update=()=>setVisible(latest.filter(v=>v.until>Date.now()&&ids.includes(v.id)).map(v=>members.find(m=>m.uid===v.id)?.name||'Someone'));const stop=onSnapshot(collection(cloudDbLive(),`conversations/${rowId}/typing`),s=>{latest=s.docs.map(d=>({id:d.id,until:d.get('until')}));update();},no);const t=setInterval(update,1500);return()=>{stop();clearInterval(t);};},[rowId,ids.join('|'),members.map(m=>m.name).join('|')]);return visible.length?<Text style={[s.small,{paddingHorizontal:16}]}>{visible.join(', ')} typing…</Text>:null;}
function GroupDetails({row,uid,members,conversation,onBack,onCall,onRefresh,onLeave,onOpenProfileChat}:{row:InboxRow;uid:string;members:Person[];conversation:Record<string,any>;onBack:()=>void;onCall:(c:string,d?:Record<string,unknown>)=>Promise<Record<string,any>|undefined>;onRefresh:()=>void;onLeave:()=>void;onOpenProfileChat:(p:ProfileDetails)=>Promise<void>}){
 const [invite,setInvite]=useState(false),[person,setPerson]=useState<Person|null>(null),[edit,setEdit]=useState(false),[name,setName]=useState(conversation.name||row.name),[description,setDescription]=useState(conversation.description||'');
 const [connections,setConnections]=useState<ConnectionList|null>(null);
 const owner=conversation.ownerId===uid,role=conversation.roles?.[uid],admin=owner||role==='admin',moderator=admin||role==='moderator';
 if(invite)return <><Header title="Invite a member" onBack={()=>setInvite(false)}/><PeopleSearch onChoose={p=>confirmAction(`Invite ${p.name}?`,'They must accept before joining or reading new messages.',()=>void onCall('invite',{uid:p.uid}).then(r=>{if(r)setInvite(false);}), 'Invite')}/></>;
 if(person&&connections)return <ConnectionsScreen key={person.uid+connections} target={person.uid} list={connections} onBack={()=>setConnections(null)} onChoose={next=>{setConnections(null);if(next.uid!==uid)setPerson(next);}}/>;
 if(person)return <><Header title="Member profile" onBack={()=>setPerson(null)}/><ScrollView contentContainerStyle={s.content}><PersonProfile key={person.uid} person={person} onConnections={setConnections} onMessage={async p=>{await onOpenProfileChat(p);setPerson(null);}}/></ScrollView></>;
 return <><Header title="Conversation details" onBack={onBack}/><ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled"><Glass><Text style={s.title}>{row.name}</Text><Text style={s.body}>{conversation.description|| (row.type==='group'?'Private group · '+(conversation.privacy||'invite-only'):'Personal conversation · acceptance required')}</Text><View style={s.wrap}><Chip label={row.muted?'Unmute':'Mute'} onPress={()=>void onCall('inbox-settings',{muted:!row.muted})}/>{row.type==='group'&&moderator&&<Chip label="Invite member" onPress={()=>setInvite(true)}/>} {row.type==='group'&&admin&&<Chip label="Edit group" onPress={()=>setEdit(v=>!v)}/>}</View>{edit&&<><TextInput accessibilityLabel="Edit group name" value={name} maxLength={60} onChangeText={setName} style={s.input}/><TextInput accessibilityLabel="Edit group description" value={description} maxLength={240} onChangeText={setDescription} style={s.input}/><Button title="Save group" onPress={()=>void onCall('group-update',{name,description}).then(r=>{if(r){setEdit(false);onRefresh();}})}/></>}</Glass><Text style={s.heading}>{row.type==='group'?`Members · ${members.length}`:'Participants'}</Text>
 {members.map(m=><Glass key={m.uid}><Pressable accessibilityRole="button" accessibilityLabel={'View profile '+m.name} onPress={()=>m.uid!==uid&&setPerson(m)} style={s.inline}><Avatar person={m}/><View style={{flex:1}}><Text style={s.heading}>{m.name}{m.uid===uid?' (you)':''}</Text><Text style={s.small}>{row.type==='group'?m.role:'Community member'}</Text></View><Icon name="chevron-forward" size={16}/></Pressable>{m.uid!==uid&&<View style={s.wrap}><Chip label="Block private messages" onPress={()=>confirmAction(`Block ${m.name}?`,'Private conversations and invitations between you will be blocked. You can unblock in Messaging privacy.',()=>void messaging('block',{uid:m.uid,blocked:true}).then(onLeave,e=>confirmAction('Could not block',errorOf(e),no,'OK')),'Block')}/>{row.type==='group'&&moderator&&m.uid!==conversation.ownerId&&<Chip label="Remove member" onPress={()=>confirmAction(`Remove ${m.name}?`,'This member will no longer be able to read or send messages in the group.',()=>void onCall('group-member',{uid:m.uid,role:'remove'}).then(onRefresh),'Remove')}/>} {row.type==='group'&&owner&&(['admin','moderator','member','owner']as const).map(r=><Chip key={r} label={r==='owner'?'Transfer ownership':'Make '+r} onPress={()=>confirmAction(r==='owner'?'Transfer group ownership?':`Assign ${r}?`,r==='owner'?'This member will become the owner and you will become an administrator.':`Change the group role for ${m.name}.`,()=>void onCall('group-member',{uid:m.uid,role:r}).then(onRefresh),'Confirm')}/>)}</View>}</Glass>)}
 {row.type==='group'&&row.status==='active'&&<><Button light title={owner?'Transfer ownership above before leaving':'Leave group'} disabled={owner} onPress={()=>confirmAction('Leave this group?','You will lose access to its messages.',()=>void onCall('group-member',{uid,role:'remove'}).then(r=>{if(r)onLeave();}),'Leave')}/>{owner&&<Button light title="Close group" onPress={()=>confirmAction('Close this group?','Members can read earlier messages but nobody can send new ones.',()=>void onCall('close-group').then(r=>{if(r)onLeave();}),'Close group')}/>}</>}
 </ScrollView></>;
}
const s=StyleSheet.create({photoCard:{gap:6},photoViewer:{flex:1,backgroundColor:'#10101A'},viewerImage:{width:'100%',flex:1},draftPreview:{width:50,height:50,borderRadius:9},publicCard:{borderWidth:1,borderColor:C.line,borderRadius:24,overflow:'hidden',backgroundColor:'#fff'},publicStats:{paddingHorizontal:15,gap:16,flexDirection:'row',flexWrap:'wrap',backgroundColor:'#fff'},publicStat:{minHeight:40,justifyContent:'center'},publicActions:{padding:13,gap:8,backgroundColor:'#FAF9FD'},screen:{flex:1,backgroundColor:C.bg},fill:{flex:1},header:{padding:12,gap:10,flexDirection:'row',alignItems:'center',borderBottomWidth:1,borderBottomColor:C.line,backgroundColor:'#fff'},title:{fontSize:21,fontWeight:'900',color:C.ink},heading:{fontSize:15,fontWeight:'800',color:C.ink},body:{fontSize:13,lineHeight:19,color:C.muted},small:{fontSize:11,lineHeight:16,color:C.muted},sender:{fontSize:12,fontWeight:'800',color:C.purple},inline:{flexDirection:'row',alignItems:'center',gap:8},tabs:{padding:10,gap:5,flexDirection:'row',flexWrap:'wrap',alignItems:'center'},content:{padding:14,gap:12,paddingBottom:28,width:'100%',maxWidth:620,alignSelf:'center'},wrap:{flexDirection:'row',flexWrap:'wrap',gap:7},input:{borderRadius:14,borderWidth:1,borderColor:C.line,backgroundColor:'#fff',paddingHorizontal:13,paddingVertical:12,color:C.ink,fontSize:14,minHeight:45},inboxCard:{backgroundColor:'#fff',borderRadius:18,borderWidth:1,borderColor:C.line,overflow:'hidden'},inboxRow:{padding:13,gap:11,flexDirection:'row',alignItems:'center',minHeight:76,paddingRight:30},options:{position:'absolute',right:5,top:35,padding:5},groupAvatar:{alignItems:'center',justifyContent:'center',backgroundColor:'#EEE8FF'},badge:{minWidth:22,height:22,borderRadius:11,backgroundColor:C.accent,alignItems:'center',justifyContent:'center',paddingHorizontal:5},badgeText:{fontSize:11,fontWeight:'800',color:'#fff'},error:{color:C.danger,fontSize:13,lineHeight:19},notice:{padding:12,gap:8,flexDirection:'row',alignItems:'center',backgroundColor:'#FFF4D7'},messages:{padding:14,gap:11,paddingBottom:20},bubble:{maxWidth:'87%',padding:12,borderRadius:18,gap:5,borderWidth:1,borderColor:C.line,minWidth:96},mine:{alignSelf:'flex-end',backgroundColor:'#E5ECFF',borderBottomRightRadius:5},theirs:{alignSelf:'flex-start',backgroundColor:'#fff',borderBottomLeftRadius:5},messageText:{color:C.ink,fontSize:15,lineHeight:21},messageMeta:{flexDirection:'row',alignItems:'center',gap:8,justifyContent:'flex-end'},reply:{padding:8,borderLeftWidth:3,borderLeftColor:C.purple,borderRadius:6,backgroundColor:'#F0EBFF'},composer:{padding:10,gap:6,borderTopWidth:1,borderTopColor:C.line,backgroundColor:'#fff'},send:{width:44,height:44,borderRadius:15,backgroundColor:C.accent,alignItems:'center',justifyContent:'center'},actionPanel:{padding:12,gap:9,borderTopWidth:1,borderTopColor:C.line,backgroundColor:'#fff'},});
