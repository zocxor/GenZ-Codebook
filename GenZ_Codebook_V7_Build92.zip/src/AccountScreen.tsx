import {confirmPhoneSignIn,phoneSignInAvailable,phoneSignInError,startPhoneSignIn} from './phoneAuth';
import {AuthCard, AuthHero, AuthPortal, NeonButton, NeonSwitch} from './AuthPortal';
import {LinearGradient} from 'expo-linear-gradient';
import {PRIVACY_URL} from '../shared/brand';
import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, Pressable, StyleSheet, AppState, Platform, Linking, Switch, Alert} from 'react-native';
import {sendVerificationEmail} from './emailVerification';
import {signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail, sendEmailVerification, reload, signOut, deleteUser, EmailAuthProvider, linkWithCredential, reauthenticateWithCredential, updatePassword} from 'firebase/auth';
import {accountAuth} from './auth/client';
import {accountError, validateCredentials, validatePasswordChange, hasPasswordProvider, passwordResetSentMessage, isResetEnumerationError} from './auth/policy';
import {signInWithGoogle, isGoogleSignInConfigured} from './googleAuth';
import {C, Button, FadeIn, Icon, IconTile, SectionHeader, confirmAction} from './ui';
import {TOKENS} from '../shared/tokens';
import {claimReferral, takePendingReferralCode} from './referral';
import {startCloud, useAccountUser, useSyncStatus, useLearningState, loginGuard, securityLog, repository} from './services';
import {isDirty} from './profile';
import {ago} from './shield/status';
import {ACCOUNT_DELETION_URL} from './secure/config';

type Mode = 'signin' | 'create' | 'reset';
type Panel = null | 'delete' | 'change';
const CREDENTIAL_FAILURES = new Set(['auth/invalid-credential', 'auth/wrong-password', 'auth/user-not-found', 'auth/invalid-login-credentials', 'auth/too-many-requests']);
const codeOf = (e: unknown) => (e && typeof e === 'object' && 'code' in e ? String((e as {code: unknown}).code) : '');

export default function AccountScreen({onContinue, initialMode = 'signin', startSignOut = false, onTokensEarned}: {onContinue: () => void; initialMode?: Mode; /** Open straight at the sign-out choice (You page / profile page "Sign out"). */startSignOut?: boolean; onTokensEarned?: (amount: number) => void}) {
  const user = useAccountUser(), sync = useSyncStatus(), state = useLearningState();
  const [ready, setReady] = useState(false), [busy, setBusy] = useState(false), [mode, setMode] = useState<Mode>(initialMode), [panel, setPanel] = useState<Panel>(null);
  const [email, setEmail] = useState(''), [password, setPassword] = useState(''), [confirmation, setConfirmation] = useState(''), [notice, setNotice] = useState(''), [error, setError] = useState(''), [verified, setVerified] = useState(false);
  const [linkEmail,setLinkEmail]=useState(false);
  const [phoneMode,setPhoneMode]=useState(false),[phone,setPhone]=useState(''),[sms,setSms]=useState(''),[verificationId,setVerificationId]=useState('');
  const [referralCode, setReferralCode] = useState(''), [referralNote, setReferralNote] = useState('');
  // Build 92: UI-only state — password visibility toggles and the expandable
  // referral input. None of this touches auth, validation or the referral claim.
  const [showPassword, setShowPassword] = useState(false), [showConfirmation, setShowConfirmation] = useState(false), [referralOpen, setReferralOpen] = useState(false);
  const [currentPw, setCurrentPw] = useState(''), [newPw, setNewPw] = useState(''), [newPwConfirm, setNewPwConfirm] = useState(''), [pwErrors, setPwErrors] = useState<{current?: string; next?: string; confirm?: string}>({});
  const clearChangeForm = () => {setCurrentPw(''); setNewPw(''); setNewPwConfirm(''); setPwErrors({});};
  const [removeLocal, setRemoveLocal] = useState(false), [waitMs, setWaitMs] = useState(loginGuard.waitMs());
  useEffect(() => {startCloud().then(() => setReady(true)).catch(() => {setReady(true); setError('Couldn’t start account services. You can still learn offline.');});}, []);
  const wasSignedIn = useRef(!!user);
  const signOutAsked = useRef(false);
  const emailRef = useRef<TextInput>(null);
  const googleSignIn = () => void run(async () => {const r = await signInWithGoogle(); if (r.ok) {const uid = accountAuth.currentUser?.uid; if (uid) await claimReferralCode(uid); setNotice('You’re signed in with Google. Your learning syncs automatically.'); onContinue();} else setError(r.message);});
  useEffect(() => {
    setVerified(user?.emailVerified ?? false);
    if (!user && wasSignedIn.current) {setMode('signin'); setConfirmation(''); setPanel(null); clearChangeForm();} // after sign-out, returning users see Sign in
    wasSignedIn.current = !!user;
  }, [user]);
  useEffect(() => {const sub = AppState.addEventListener('change', s => {if (s !== 'active') {setPassword(''); setConfirmation(''); clearChangeForm();}}); return () => sub.remove();}, []);
  useEffect(() => {if (!waitMs) return; const t = setInterval(() => setWaitMs(loginGuard.waitMs()), 1000); return () => clearInterval(t);}, [waitMs > 0]);
  // Referral: when the create-account form opens, pre-fill the code from a
  // referral deep link (genzcode://referral?code=XXXXXX) if one was captured
  // and the field is still empty. The code stays optional — the user may
  // clear it, and sign-up never depends on it.
  useEffect(() => {
    if (mode !== 'create' || referralCode) return;
    const pending = takePendingReferralCode();
    if (pending) setReferralCode(pending);
  }, [mode]);
  // A pre-filled code (referral deep link) opens the referral input on its own.
  useEffect(() => { if (referralCode) setReferralOpen(true); }, [referralCode]);
  // Referral claim (best-effort, never blocks sign-up): claim the code in
  // the field (or a pending deep-link code) for a newly signed-up user, so
  // both the new user and the referrer get 100 tokens. On success, credit
  // the new user locally through onTokensEarned; the server wallet was
  // already updated by the claim batch, so the credit survives the login
  // wallet re-read. A gentle note explains a non-claim; a hard failure
  // stays silent — the account is ready either way.
  const claimReferralCode = async (uid: string): Promise<void> => {
    const codeToClaim = referralCode || takePendingReferralCode();
    if (!codeToClaim) return;
    const result = await claimReferral(codeToClaim, uid, state.tokens.balance);
    if (result.status === 'claimed') {
      onTokensEarned?.(TOKENS.REFERRAL_REWARD);
      setReferralNote(`Referral applied — you and your friend each got ${TOKENS.REFERRAL_REWARD} Credits.`);
    } else if (result.status === 'invalid') {
      setReferralNote('That referral code wasn’t recognised, so no referral bonus was applied. Your account is ready.');
    } else if (result.status === 'self') {
      setReferralNote('That’s your own referral code, so no bonus was applied. Your account is ready.');
    } else if (result.status === 'already-claimed') {
      setReferralNote('A referral was already claimed on this account, so no bonus was applied. Your account is ready.');
    }
  };
  const engine = () => startCloud().then(c => c.engine);
  const changeMode = (value: Mode) => {setMode(value); setPhoneMode(false); setVerificationId(''); setSms(''); setPassword(''); setConfirmation(''); setError(''); setNotice('');};
  const run = async (action: () => Promise<void>) => {if (busy) return; setBusy(true); setError(''); setNotice(''); setReferralNote(''); try {await action();} catch (e) {setError(accountError(e));} finally {setPassword(''); setConfirmation(''); setBusy(false);}};

  const submitPhone=()=>{
    void run(async()=>{
      try{
        if(verificationId){
          if(!/^\d{6}$/.test(sms))return setError('Enter the six-digit code from your SMS.');
          await confirmPhoneSignIn(verificationId,sms);
        }else{
          const number=phone.replace(/[\s()-]/g,'');
          if(!/^\+[1-9]\d{7,14}$/.test(number))return setError('Enter your mobile number with the country code, starting with +.');
          const id=await startPhoneSignIn(number);
          if(id){setVerificationId(id);return;}
        }
        const uid=accountAuth.currentUser?.uid;
        if(uid)await claimReferralCode(uid);
        onContinue();
      }catch(e){setError(phoneSignInError(e));}
    });
  };

  const submit = () => {
    const wait = loginGuard.waitMs();
    if (mode !== 'reset' && wait) {setWaitMs(wait); setError(`Too many attempts on this device. Try again in ${Math.ceil(wait / 1000)} s.`); return;}
    const invalid = validateCredentials(email, password, mode === 'create');
    if (mode !== 'reset' && invalid) {setError(invalid); return;}
    if (mode === 'reset' && validateCredentials(email, 'not-empty')) {setError('Enter a valid email address.'); return;}
    if (mode === 'create' && password !== confirmation) {setError('The passwords do not match.'); return;}
    void run(async () => {
      const address = email.trim();
      if (mode === 'reset') {
        // Anti-enumeration: an unregistered address gets the same generic
        // "sent" message as a registered one, so the response never reveals
        // whether the address has an account. Firebase only throws
        // auth/user-not-found when email enumeration protection is off in
        // the console; with it on, the call succeeds silently either way.
        try {await sendPasswordResetEmail(accountAuth, address);}
        catch (e) {if (!isResetEnumerationError(codeOf(e))) throw e;}
        setNotice(passwordResetSentMessage(address));
        return;
      }
      let verificationSent = false;
      try {
        if (mode === 'create') {
          const cred = await createUserWithEmailAndPassword(accountAuth, address, password);
          verificationSent = (await sendVerificationEmail(cred.user)).ok;
        } else await signInWithEmailAndPassword(accountAuth, address, password);
      } catch (e) {
        if (mode === 'create' && codeOf(e) === 'auth/email-already-in-use') {
          setMode('signin');
          throw Object.assign(new Error('exists'), {code: 'genz/email-exists'});
        }
        if (mode === 'signin' && CREDENTIAL_FAILURES.has(codeOf(e))) {
          void securityLog.record('login_failed', codeOf(e));
          const lock = await loginGuard.failed();
          if (lock) {void securityLog.record('login_throttled', `failures:${loginGuard.failures}`); setWaitMs(lock);}
        }
        throw e;
      }
      const prior = await loginGuard.succeeded().catch(() => 0);
      setWaitMs(0);
      if (prior >= 3) void securityLog.record('login_succeeded_after_failures', `count:${prior}`);
      // Referral (create only): claim an entered or deep-linked code so the
      // new user and the referrer each get 100 tokens. Best-effort — the
      // account is ready whether or not the claim succeeds.
      if (mode === 'create') {
        const uid = accountAuth.currentUser?.uid;
        if (uid) await claimReferralCode(uid);
      }
      if (mode === 'create') Alert.alert('Verify your e-mail', verificationSent ? `We sent a verification link to ${address}.\n\nOpen it to unlock chat, posts and Credits. If you can’t find it, check Spam or Promotions. You can resend it from the You page.` : 'Your account is ready. Send the verification e-mail from the You page to unlock chat, posts and Credits.', [{text: 'OK'}]);
      setNotice(mode === 'create' ? `Account created. ${verificationSent ? `We sent a verification link to ${address} — open it, then tap “Check verification status”.` : 'Send a verification email below.'} Your learning on this device is now backed up.` : 'You’re signed in. Your learning syncs automatically.');
      // Sign-in just succeeded in this sheet: enter the app now instead of
      // parking on the signed-in account view. onContinue persists
      // onboarding and opens Decode; the account view stays reachable from
      // the You tab, and "Continue learning" below remains as a manual
      // fallback for users who open this sheet while already signed in.
      onContinue();
    });
  };

  // Sign out is automatic: your learning syncs to your account first, then you're signed out.
  // It stays on this device too, and anything still waiting (offline) uploads when you sign in again.
  // To wipe this phone, use Threat Shield → Delete all data on this device.
  const signOutNow = () => void run(async () => {
    const clean = await (await engine()).flush();
    await signOut(accountAuth);
    setPanel(null); setEmail('');
    setNotice(clean ? 'Signed out. Your learning is backed up in your account and stays on this device.' : 'Signed out. You were offline, so your newest changes are kept on this device and upload automatically next time you sign in.');
  });
  const beginSignOut = () => confirmAction('Sign out?', 'Your learning syncs to your account automatically first, so nothing is lost.', signOutNow, 'Sign out');

  // "Sign out" from the You page or the profile page opens this sheet and asks once (then syncs and signs out automatically).
  useEffect(() => {if (ready && startSignOut && user && !signOutAsked.current) {signOutAsked.current = true; beginSignOut();}}, [ready, startSignOut, user]);

  const deleteAccount = () => void run(async () => {
    const current = accountAuth.currentUser;
    if(!current)return;
    if(hasPasswordProvider(current.providerData)&&current.email){
      try {await reauthenticateWithCredential(current, EmailAuthProvider.credential(current.email, password));}
      catch (e) {void securityLog.record('reauth_failed', codeOf(e)); throw e;}
    }else if(current.phoneNumber){
      const token=await current.getIdTokenResult();
      if(Date.now()-Date.parse(token.authTime)>5*60_000){
        setError('For your security, sign out, sign in with your mobile number, and try again.');
        return;
      }
    }else return;
    void securityLog.record('account_deletion_started');
    const sync = await engine();
    try {await sync.deleteCloudData();}
    catch {throw Object.assign(new Error('cloud'), {code: 'genz/cloud-deletion-failed'});}
    try {await deleteUser(current);}
    catch {throw Object.assign(new Error('auth'), {code: 'genz/auth-deletion-incomplete'});}
    void securityLog.record('account_deleted');
    if (removeLocal) await repository.clear();
    setPanel(null); setEmail('');
    setNotice(removeLocal ? 'Your account, its cloud data and this device’s learning data were deleted.' : 'Your account and its cloud data were deleted. Learning on this device was kept as a guest profile.');
  });

  const changePassword = () => {
    const errors = validatePasswordChange(currentPw, newPw, newPwConfirm);
    setPwErrors(errors);
    if (Object.keys(errors).length) return;
    void run(async () => {
      const current = accountAuth.currentUser;
      if (!current?.email) {setError('Sign in again, then change your password.'); return;}
      try {await reauthenticateWithCredential(current, EmailAuthProvider.credential(current.email, currentPw));}
      catch (e) {
        void securityLog.record('reauth_failed', codeOf(e));
        if (['auth/invalid-credential', 'auth/wrong-password', 'auth/invalid-login-credentials'].includes(codeOf(e))) {setPwErrors({current: 'Your current password is incorrect.'}); return;}
        throw e;
      }
      try {await updatePassword(current, newPw);}
      catch (e) {
        if (codeOf(e) === 'auth/requires-recent-login') {
          // Session too old to change the password: sign out so the sheet
          // returns to Sign in (the sign-out effect flips the view), and
          // tell the user to sign in again first.
          await signOut(accountAuth);
          setPanel(null);
          clearChangeForm();
          setNotice('Your session expired. Sign in again, then change your password.');
          return;
        }
        throw e;
      }
      clearChangeForm();
      setPanel(null);
      setNotice('Your password was changed.');
    });
  };

  const submitLinkedEmail=()=>void run(async()=>{
    const current=accountAuth.currentUser;
    if(!current?.phoneNumber||current.email)return;
    const invalid=validateCredentials(email,password,true);
    if(invalid){setError(invalid);return;}
    await linkWithCredential(current,EmailAuthProvider.credential(email.trim(),password));
    setLinkEmail(false);
    setNotice((await sendVerificationEmail(current)).message);
  });

  if (!ready) return <View style={s.card}><Text accessibilityLiveRegion="polite" style={s.body}>Checking your account…</Text></View>;
  const dirty = isDirty(state);
  return <View style={[s.page,!user&&{gap:7}]}>
    <FadeIn>
      {user ? <View style={s.center}><Text accessibilityRole="header" style={s.title}>Your corner of the internet.</Text></View> : <AuthHero mode={mode} />}
    </FadeIn>
    {!!error && <Text accessibilityRole="alert" style={s.error}>{error}</Text>}
    {!!notice && (user||mode!=='signin') && <Text accessibilityLiveRegion="polite" style={s.notice}>{notice}</Text>}
    {!!referralNote && <Text accessibilityLiveRegion="polite" style={s.notice}>{referralNote}</Text>}
    {user ? <>
      <FadeIn delay={60}>
        <View style={s.card}>
          <View style={s.identity}>
            <IconTile icon="person" from={C.accent} to={C.purple} size={36} iconSize={18} />
            <View style={{flex: 1, gap: 6}}>
              <Text selectable style={s.email}>{user.email||user.phoneNumber}</Text>
              <View style={[s.pill, verified ? s.pillOk : s.pillWarn]}><Icon name={verified ? 'checkmark-circle' : 'alert-circle-outline'} size={15} color={verified ? '#13805a' : '#a35a12'} /><Text style={[s.pillText, {color: verified ? '#13805a' : '#a35a12'}]}>{verified ? 'Email verified' : !user.email&&user.phoneNumber?'Mobile number verified':'Email not verified'}</Text></View>
            </View>
          </View>
          {!user.email&&user.phoneNumber&&<>
            <Text style={s.small}>Add and verify an email address to use chat, posts and Credits.</Text>
            {linkEmail?<><TextInput accessibilityLabel="Email to add" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" autoComplete="email" style={s.input} placeholder="you@example.com" editable={!busy}/>
            <TextInput accessibilityLabel="Password for your email sign-in" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" autoComplete="new-password" style={s.input} placeholder="Password · 12+ characters" editable={!busy}/>
            <Button title="Save email and send verification link" disabled={busy} onPress={submitLinkedEmail}/>
            <Button light title="Cancel" disabled={busy} onPress={()=>{setLinkEmail(false);setPassword('');}}/></>:<Button light title="Add an email address" disabled={busy} onPress={()=>setLinkEmail(true)}/>}
          </>}
          {!verified && user.email && <><Text style={s.small}>Link expired or not working? Send a new one and open the newest e-mail. Verifying unlocks chat, posts and Credits.</Text><Button title="Send new verification link" icon="mail-outline" disabled={busy} onPress={() => void run(async () => {setNotice((await sendVerificationEmail(user)).message);})} /><Button title="Check verification status" icon="checkmark-circle-outline" light disabled={busy} onPress={() => void run(async () => {await reload(user); setVerified(user.emailVerified); setNotice(user.emailVerified ? 'Your email is verified.' : 'Not verified yet. Open the verification link first.');})} /></>}
        </View>
      </FadeIn>
      <FadeIn delay={120}>
        <View style={s.card}>
          <SectionHeader eyebrow="CLOUD SYNC" title="Cloud sync" />
          <View style={s.syncRow}>
            <IconTile icon={sync.phase === 'idle' && !dirty ? 'cloud-done-outline' : sync.phase === 'offline' ? 'cloud-offline-outline' : 'cloud-upload-outline'} from={C.accent} to="#2E9BFF" size={36} iconSize={18} />
            <Text style={[s.body, {flex: 1}]}>{sync.phase === 'syncing' ? 'Syncing now…' : sync.phase === 'idle' ? (dirty ? 'Recent changes are saved on this device and will upload shortly.' : `Up to date${sync.lastSyncAt ? ` · last synced ${ago(Date.now() - sync.lastSyncAt)}` : ''}.`) : sync.lastError ?? 'Sync is paused.'}</Text>
          </View>
          {sync.phase === 'account-mismatch' ? <>
            <Text style={s.small}>This device still has changes from a different account that haven’t uploaded yet. Choose “Use this account here” to show {user.email}’s learning instead (those unsynced changes will be removed from this device).</Text>
            <Button title="Use this account here" icon="swap-horizontal-outline" disabled={busy} onPress={() => void run(async () => {await (await engine()).adoptSignedInAccount(); setNotice('This device now shows your account’s learning.');})} />
          </> : <Button light title="Sync now" icon="sync-outline" disabled={busy || sync.phase === 'syncing' || sync.phase === 'blocked'} onPress={() => void run(async () => {const st = await (await engine()).syncNow(); if (st.phase === 'idle') setNotice('Sync complete.');})} />}
        </View>
      </FadeIn>
      {panel === 'delete' ? <FadeIn><View style={s.card}>
        <SectionHeader eyebrow="DELETE ACCOUNT" title="Delete your account permanently" />
        <Text style={s.small}>This deletes your synced learning data, suggestions, reports and account. It can’t be undone.</Text>
        {(!user.phoneNumber||hasPasswordProvider(user.providerData))&&<><Text style={s.label}>Confirm your password</Text>
        <TextInput accessibilityLabel="Password to confirm deletion" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="current-password" maxLength={4096} editable={!busy} style={s.input} placeholder="Your password" placeholderTextColor={C.muted} /></>}
        <View style={s.toggle}><Text style={[s.small, {flex: 1}]}>Also delete learning data on this device</Text><Switch accessibilityLabel="Also delete learning data on this device" value={removeLocal} onValueChange={setRemoveLocal} /></View>
        <Button title={busy ? 'Deleting…' : 'Delete my account'} icon="trash-bin-outline" disabled={busy||(!password&&(!user.phoneNumber||hasPasswordProvider(user.providerData)))} onPress={deleteAccount} />
        <Button light title="Cancel" icon="close-outline" disabled={busy} onPress={() => {setPanel(null); setPassword('');}} />
      </View></FadeIn> : panel === 'change' ? <FadeIn><View style={s.card}>
        <SectionHeader eyebrow="CHANGE PASSWORD" title="Change your password" />
        {hasPasswordProvider(user.providerData) ? <>
          <Text style={s.label}>Current password</Text>
          <TextInput accessibilityLabel="Current password" value={currentPw} onChangeText={v => {setCurrentPw(v); setPwErrors(e => ({...e, current: undefined}));}} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="current-password" maxLength={4096} editable={!busy} style={s.input} placeholder="Your current password" placeholderTextColor={C.muted} />
          {!!pwErrors.current && <Text accessibilityRole="alert" style={s.fieldError}>{pwErrors.current}</Text>}
          <Text style={s.label}>New password · 8+ characters</Text>
          <TextInput accessibilityLabel="New password" value={newPw} onChangeText={v => {setNewPw(v); setPwErrors(e => ({...e, next: undefined}));}} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="new-password" maxLength={4096} editable={!busy} style={s.input} placeholder="Your new password" placeholderTextColor={C.muted} />
          {!!pwErrors.next && <Text accessibilityRole="alert" style={s.fieldError}>{pwErrors.next}</Text>}
          <Text style={s.label}>Confirm new password</Text>
          <TextInput accessibilityLabel="Confirm new password" value={newPwConfirm} onChangeText={v => {setNewPwConfirm(v); setPwErrors(e => ({...e, confirm: undefined}));}} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="new-password" maxLength={4096} editable={!busy} style={s.input} />
          {!!pwErrors.confirm && <Text accessibilityRole="alert" style={s.fieldError}>{pwErrors.confirm}</Text>}
          <Button title={busy ? 'Changing…' : 'Change password'} icon="key-outline" disabled={busy || !currentPw || !newPw || !newPwConfirm} onPress={changePassword} />
        </> : <Text style={s.body}>You signed in with Google — your password is managed by Google.</Text>}
        <Button light title="Cancel" icon="close-outline" disabled={busy} onPress={() => {clearChangeForm(); setPanel(null); setError('');}} />
      </View></FadeIn> : <FadeIn><View style={s.card}>
        <Button light title="Change password" icon="key-outline" disabled={busy} onPress={() => {clearChangeForm(); setPanel('change'); setError(''); setNotice('');}} />
        <Button light title="Sign out" icon="log-out-outline" disabled={busy} onPress={beginSignOut} />
        <Button light title="Delete account and cloud data" icon="trash-bin-outline" disabled={busy} onPress={() => {setPanel('delete'); setError(''); setNotice('');}} />
        <Pressable accessibilityRole="link" onPress={() => void Linking.openURL(ACCOUNT_DELETION_URL)} style={s.linkButton}><Text style={s.link}>Request deletion from the web instead</Text></Pressable>
      </View></FadeIn>}
    </> : <FadeIn delay={60}>
      <AuthCard>
        {phoneMode?<>
          <Text style={s.label}>Mobile number</Text>
          <View style={s.field}><Icon name="call-outline" size={19} color="#6366F1"/><TextInput accessibilityLabel="Mobile number" value={phone} onChangeText={setPhone} maxLength={24} keyboardType="phone-pad" autoComplete="tel" editable={!busy&&!verificationId} placeholder="+92 300 1234567" placeholderTextColor="#8A94B8" style={s.fieldInput}/></View>
          {verificationId&&<><Text style={s.label}>SMS verification code</Text><View style={s.field}><Icon name="key-outline" size={19} color="#6366F1"/><TextInput accessibilityLabel="SMS verification code" value={sms} onChangeText={v=>setSms(v.replace(/\D/g,''))} maxLength={6} keyboardType="number-pad" autoComplete="sms-otp" editable={!busy} style={s.fieldInput}/></View>
          <Pressable accessibilityRole="button" disabled={busy} style={s.linkButton} onPress={()=>{setVerificationId('');setSms('');setError('');}}><Text style={s.link}>Change number or resend SMS</Text></Pressable></>}
          <Text style={s.small}>By continuing you agree to the Terms of Use and <Text accessibilityRole="link" style={s.link} onPress={()=>void Linking.openURL(PRIVACY_URL)}>Privacy Policy</Text>. Firebase uses your number to verify your account. SMS rates may apply.</Text>
          <NeonButton title={busy?'Please wait…':verificationId?'Verify and continue':'Send SMS code'} icon="phone-portrait-outline" disabled={busy} onPress={submitPhone}/>
          <Button light title="Use e-mail instead" disabled={busy} onPress={()=>changeMode(mode)}/>
        </>:<>
        {mode === 'reset' && <SectionHeader eyebrow="RESET PASSWORD" title="Reset your password" />}

        {mode === 'create' && <Text style={s.formTitle}>Create your account</Text>}
        {mode === 'create' && isGoogleSignInConfigured() && <AuthPortal mode="create" busy={busy} onGoogle={googleSignIn} onEmail={() => emailRef.current?.focus()}/>}
        <Text style={s.label}>Email address</Text>
        <View style={s.field}><Icon name="mail-outline" size={19} color="#6366F1" /><TextInput ref={emailRef} accessibilityLabel="Account email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} autoComplete="email" textContentType="emailAddress" maxLength={254} editable={!busy} style={s.fieldInput} placeholder="you@example.com" placeholderTextColor="#8A94B8" /></View>
        {mode !== 'reset' && <><Text style={s.label}>Password{mode === 'create' ? ' · 12+ characters' : ''}</Text><View style={s.field}><Icon name="lock-closed-outline" size={19} color="#6366F1" /><TextInput accessibilityLabel="Account password" value={password} onChangeText={setPassword} secureTextEntry={!showPassword} autoCapitalize="none" autoCorrect={false} autoComplete={mode === 'create' ? 'new-password' : 'current-password'} textContentType={mode === 'create' ? 'newPassword' : 'password'} maxLength={4096} editable={!busy} style={s.fieldInput} placeholder="Your password" placeholderTextColor="#8A94B8" /><Pressable accessibilityRole="button" accessibilityLabel={showPassword ? 'Hide password' : 'Show password'} disabled={busy} onPress={() => setShowPassword(v => !v)} style={s.eye}><Icon name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={19} color="#6366F1" /></Pressable></View>{mode === 'signin' && <Pressable disabled={busy} accessibilityRole="button" onPress={() => changeMode('reset')} style={[s.linkButton, s.forgotLink]}><Text style={s.link}>Forgot password?</Text></Pressable>}</>}
        {mode === 'create' && <><Text style={s.label}>Confirm password</Text><View style={s.field}><Icon name="shield-checkmark-outline" size={19} color="#6366F1" /><TextInput accessibilityLabel="Confirm account password" value={confirmation} onChangeText={setConfirmation} secureTextEntry={!showConfirmation} autoCapitalize="none" autoCorrect={false} autoComplete="new-password" maxLength={4096} editable={!busy} style={s.fieldInput} placeholder="Repeat your password" placeholderTextColor="#8A94B8" /><Pressable accessibilityRole="button" accessibilityLabel={showConfirmation ? 'Hide confirmation password' : 'Show confirmation password'} disabled={busy} onPress={() => setShowConfirmation(v => !v)} style={s.eye}><Icon name={showConfirmation ? 'eye-off-outline' : 'eye-outline'} size={19} color="#6366F1" /></Pressable></View></>}
        {/* Build 92: the referral offer is a promo banner; the code input expands
            only when the user taps "+ Enter code" (or a deep-link code pre-filled it). */}
        {mode === 'create' && <LinearGradient colors={['#22D3EE', '#6366F1', '#A855F7', '#EC4899']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.codeRing}>
          <View style={s.codeBox}>
            <View style={s.codeHead}>
              <LinearGradient colors={['#F59E0B', '#EC4899']} style={s.codeIcon}><Icon name="gift" size={14} color="#fff" /></LinearGradient>
              <View style={{flex: 1, gap: 2}}>
                <Text style={s.codeTitle}>Use a Referral Code & Get</Text>
                <Text style={s.codeBonus}>+{TOKENS.REFERRAL_REWARD} Credits</Text>
              </View>
              <Pressable accessibilityRole="button" accessibilityLabel={referralOpen ? 'Hide referral code input' : 'Enter referral code'} disabled={busy} onPress={() => setReferralOpen(v => !v)} style={s.codeEnter}><Text style={s.codeEnterText}>{referralOpen ? 'Hide' : '+ Enter code'}</Text></Pressable>
            </View>
            {referralOpen && <>
              <View style={[s.field, s.codeField]}><Icon name="ticket-outline" size={18} color="#7C3AED" /><TextInput accessibilityLabel="Friend’s user code or referral code (optional)" value={referralCode} onChangeText={v => setReferralCode(v.toUpperCase())} autoCapitalize="characters" autoCorrect={false} maxLength={8} editable={!busy} style={[s.fieldInput, {letterSpacing: 1}]} placeholder="GZXXXXXX (optional)" placeholderTextColor="#8A94B8" /></View>
              <Text style={s.codeNote}>Optional — you both get {TOKENS.REFERRAL_REWARD} Credits. Leave it empty if you don’t have one.</Text>
            </>}
          </View>
        </LinearGradient>}
        {waitMs > 0 && mode !== 'reset' && <Text accessibilityLiveRegion="polite" style={s.small}>Sign-in paused on this device for {Math.ceil(waitMs / 1000)} s after repeated failed attempts.</Text>}
        {mode === 'create' && <Text style={s.small}>By creating an account you agree to the Terms of Use and community rules (You → Settings → About) and the <Text accessibilityRole="link" style={{color: C.accent, fontWeight: '800'}} onPress={() => void Linking.openURL(PRIVACY_URL).catch(() => {})}>Privacy Policy</Text>.</Text>}
        <NeonButton title={busy ? 'Please wait…' : mode === 'create' ? 'Create account' : mode === 'reset' ? 'Send password reset' : 'Sign in with e-mail'} icon={mode === 'reset' ? 'mail-outline' : mode === 'create' ? 'person-add-outline' : 'log-in-outline'} disabled={busy || (mode !== 'reset' && waitMs > 0)} onPress={submit} />
        {mode === 'signin' && isGoogleSignInConfigured() && <AuthPortal mode="signin" busy={busy} onGoogle={googleSignIn} onEmail={() => emailRef.current?.focus()}/>}
        {mode!=='reset'&&phoneSignInAvailable&&<Button light title={mode==='create'?'Create account with mobile number':'Continue with mobile number'} icon="phone-portrait-outline" disabled={busy} onPress={()=>{setError('');setPhoneMode(true);}}/>}
        {mode === 'signin' ? <NeonSwitch prompt="New here?" action="Create an account" disabled={busy} onPress={() => changeMode('create')} /> : <NeonSwitch prompt={mode === 'create' ? 'Already have an account?' : 'Remembered it?'} action="Sign in" disabled={busy} onPress={() => changeMode('signin')} />}
        </>}
      </AuthCard>
    </FadeIn>}
    {!!notice&&!user&&mode==='signin'&&<Text accessibilityLiveRegion="polite" style={[s.notice,{padding:8,fontSize:13,lineHeight:18}]}>{notice}</Text>}
    <Button light title="Continue learning" icon="book-outline" disabled={busy} onPress={onContinue} />
    <Text style={s.small}>{Platform.OS === 'web' ? 'Web sessions are memory-only and end on page reload.' : 'Account sessions use encrypted device storage when available.'} Passwords are never saved by GenZ Codebook. Without an account, uninstalling deletes your learning data.</Text>
  </View>;
}
const s = StyleSheet.create({
  options: {flexDirection: 'row', gap: 10, alignItems: 'center'},
  emailOption: {flex: 1, height: 46, borderRadius: 6, borderWidth: 1, borderColor: '#DADCE0', backgroundColor: '#fff', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, elevation: 1, shadowColor: '#000', shadowOpacity: .12, shadowRadius: 1.5, shadowOffset: {width: 0, height: 1}},
  emailOptionText: {fontSize: 14, fontWeight: '700', color: '#3C4043'},
  orRow: {flexDirection: 'row', alignItems: 'center', gap: 8, marginVertical: 2},
  orLine: {flex: 1, height: 1, backgroundColor: C.line},
  page: {gap: 10},
  center: {alignItems: 'center', gap: 10},
  title: {fontSize: 26, lineHeight: 32, fontWeight: '900', color: C.navy, textAlign: 'center', letterSpacing: -0.4},
  formTitle: {fontSize: 18, fontWeight: '900', color: C.navy, letterSpacing: -.2},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 14, gap: 10, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3},
  cardTitle: {fontSize: 17, fontWeight: '800', color: C.navy},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  label: {fontSize: 13, fontWeight: '800', letterSpacing: 0.4, color: C.navy},
  email: {fontSize: 16, fontWeight: '800', color: C.navy},
  field: {flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 62, paddingHorizontal: 14, borderWidth: 1.5, borderColor: '#D3DCFB', borderRadius: 16, backgroundColor: '#F5F7FF'},
  fieldInput: {flex: 1, minHeight: 50, fontSize: 16.5, color: C.navy},
  eye: {padding: 6, alignItems: 'center', justifyContent: 'center'},
  input: {minHeight: 48, paddingHorizontal: 16, paddingVertical: 14, borderWidth: 1.5, borderColor: '#c6d6e7', borderRadius: 16, backgroundColor: '#f5f9ff', fontSize: 17, color: C.navy},
  small: {fontSize: 12, lineHeight: 19, color: C.muted},
  links: {flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'space-between'},
  linkButton: {minHeight: 48, justifyContent: 'center'},
  link: {fontSize: 14, fontWeight: '700', color: C.accent},
  forgotLink: {alignSelf: 'flex-end'},
  fieldError: {fontSize: 12, lineHeight: 18, color: '#96383f'},
  error: {padding: 15, borderRadius: 16, borderWidth: 1, borderColor: '#f3c1bd', backgroundColor: '#fff0ee', color: '#96383f', fontSize: 14, lineHeight: 22},
  notice: {padding: 15, borderRadius: 16, borderWidth: 1, borderColor: '#bfe6cf', backgroundColor: '#e1f5e9', color: '#175e47', fontSize: 14, lineHeight: 22},
  google: {flexDirection: 'row', alignItems: 'center', gap: 12, flexWrap: 'wrap'},
  inline: {flexDirection: 'row', alignItems: 'center', gap: 8},
  identity: {flexDirection: 'row', alignItems: 'center', gap: 14},
  pill: {flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', gap: 5, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4},
  pillOk: {backgroundColor: '#e1f5e9'},
  pillWarn: {backgroundColor: '#fff1dc'},
  pillText: {fontSize: 12, fontWeight: '800'},
  syncRow: {flexDirection: 'row', alignItems: 'center', gap: 12},
  toggle: {flexDirection: 'row', alignItems: 'center', gap: 10},
  codeRing: {borderRadius: 18, padding: 1.5, shadowColor: '#A855F7', shadowOpacity: .28, shadowRadius: 10, shadowOffset: {width: 0, height: 4}, elevation: 4},
  codeBox: {borderRadius: 16.5, backgroundColor: '#F6F0FF', paddingHorizontal: 12, paddingVertical: 10, gap: 7},
  codeHead: {flexDirection: 'row', alignItems: 'center', gap: 8},
  codeIcon: {width: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center'},
  codeTitle: {fontSize: 13.5, fontWeight: '900', color: '#5B21B6'},
  codeBonus: {fontSize: 11, fontWeight: '800', color: '#9D174D', backgroundColor: '#FCE7F3', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10, overflow: 'hidden', alignSelf: 'flex-start'},
  codeField: {backgroundColor: '#FFFFFF', borderColor: '#C4B5FD'},
  codeEnter: {borderWidth: 1.5, borderColor: '#C4B5FD', backgroundColor: '#FFFFFF', borderRadius: 999, paddingHorizontal: 12, paddingVertical: 7},
  codeEnterText: {fontSize: 13, fontWeight: '800', color: '#5B21B6'},
  codeNote: {fontSize: 11.5, lineHeight: 16, color: '#6B5B95'},
});
