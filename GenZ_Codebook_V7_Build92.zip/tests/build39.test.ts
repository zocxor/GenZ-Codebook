import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read = (f: string) => readFileSync(f, 'utf8');

test('one daily reward: every button shares one collected state checked against the server', () => {
  const app = read('App.tsx'), reward = read('src/dailyReward.ts'), tokens = read('src/AccountTokens.tsx');
  assert.doesNotMatch(app, /collectDailyReward/, 'no separate learning-points button left in App');
  assert.equal((app.match(/<DailyRewardButton\/>/g) ?? []).length, 2, 'Home card and the daily pop-up use the shared button');
  assert.match(app, /<AccountTokens reward=\{false\}\/>/, 'the pop-up does not show a second reward button');
  assert.match(app, /if\(!dailyReward\.known\|\|dailyReward\.done\)return;/, 'the pop-up only opens while today’s reward is open');
  assert.match(reward, /doc\(cloudDb\(\), 'users', uid, 'tokenLedger', `daily-\$\{day\}`\)/, 'checks the server receipt');
  assert.match(reward, /mark\(key\);\n\s+if \(!localDone\) void repository\.mutate\(collectDailyReward\)/, 'one tap: Credits + learning points, shown at once');
  assert.match(reward, /e => \{busyKey = null; unmark\(key\); settled\?\.\(errorOf\(e\)\);\}/, 'a refused server credit undoes the instant mark');
  assert.match(tokens, /const reward=useDailyReward\(\);/);
});

test('removing your post opens a skippable full-screen ad while the delete runs (never blocks; Premium skips)', () => {
  const posts = read('src/CommunityPostsPanel.tsx'), ads = read('src/ads.tsx');
  assert.match(posts, /const removing=feature\('delete-post',\{id:menuRow\.id\}\);[\s\S]{0,140}await showSupportAd\(\);\s*await removing;/);
  assert.doesNotMatch(posts, /BannerAd|RewardedAd/);
  const fn = ads.slice(ads.indexOf('export function showSupportAd'), ads.indexOf('/**\n * Show one rewarded ad.'));
  assert.match(fn, /if \(!supportAdReady\(\)\) return Promise\.resolve\(false\)/, 'Premium, no-ad-loaded and rewarded-active skip it');
});

test('sign out is automatic: sync first, no keep-or-remove choice', () => {
  const account = read('src/AccountScreen.tsx');
  assert.doesNotMatch(account, /Keep your learning on this device\?/);
  assert.match(account, /const clean = await \(await engine\(\)\)\.flush\(\);\n\s+await signOut\(accountAuth\);/);
  assert.match(read('src/services.ts'), /else if \(s === 'background'\) void engine\.flush\(5_000\)/, 'pending changes upload when the app goes to the background');
});

test('V9 sign-up look: light holographic banner, frosted card, direct join buttons (no dark panel)', () => {
  const portal = read('src/AuthPortal.tsx'), account = read('src/AccountScreen.tsx');
  assert.match(account, /<AuthHero mode=\{mode\} \/>/);
  assert.match(account, /<AuthCard>/);
  assert.match(account, /<Text style=\{s\.formTitle\}>Create your account<\/Text>/, 'small card heading replaces the old join title');
  assert.match(portal, /or create an account using email/);
  assert.match(portal, /const NEON = \['#22D3EE', '#6366F1', '#A855F7', '#EC4899'\]/, 'buttons keep their neon rings');
  assert.match(portal, /colors=\{\['#FFFFFF', '#EEF2FF'\]\}/, 'e-mail tile stays light');
  assert.doesNotMatch(portal, /Choose how to join|JOIN WITH|SOFT|panel/, 'no outer panel, header row or join title left');
  assert.doesNotMatch(portal, /#070B1F|#111737/, 'no dark panel colours');
  assert.match(account, /\+ Enter code/, 'referral is a promo banner with an expandable input');
  assert.doesNotMatch(account, /<Text style=\{s\.codeTitle\}>Friend’s user code<\/Text>/, 'no always-visible referral box title');
  assert.match(read('App.tsx'), /sheet==='login'&&!user\?\['#E9F0FF','#F3EEFF','#E6F7FF'\]:undefined/, 'tinted page instead of white');
});

test('avatars: twelve colour themes, light and dark, and glossy level icons', () => {
  const ui = read('src/ui.tsx');
  const themes = ui.slice(ui.indexOf('const profileThemes'), ui.indexOf('];', ui.indexOf('const profileThemes')));
  assert.equal((themes.match(/\['#/g) ?? []).length, 12);
  assert.doesNotMatch(ui, /'#291649'/, 'no more single dark purple ending');
  assert.match(read('src/PlayHub.tsx'), /<GlossyIcon icon=\{stage\.icon\} color=\{LEVEL_COLORS\[index%LEVEL_COLORS\.length\]!\}/);
});
