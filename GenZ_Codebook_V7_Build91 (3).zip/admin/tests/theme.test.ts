import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {parsePref, resolveTheme, THEME_PREFS, THEME_COLORS} from '../src/theme';
const read = (f: string) => readFileSync(new URL(`../${f}`, import.meta.url), 'utf8');

test('theme preference: only light / dark / cafe are accepted, anything else means light', () => {
  assert.deepEqual([...THEME_PREFS], ['light', 'dark', 'cafe']);
  for (const v of ['light', 'dark', 'cafe']) assert.equal(parsePref(v), v);
  for (const v of [null, undefined, '', 'blue', 'system', 'DARK', 7, {}]) assert.equal(parsePref(v), 'light');
  assert.deepEqual(THEME_COLORS, {light: '#F8FAFC', dark: '#06363A', cafe: '#FFFBF3'});
});

test('resolveTheme returns the preference directly; there is no system-following', () => {
  assert.equal(resolveTheme('light'), 'light');
  assert.equal(resolveTheme('dark'), 'dark');
  assert.equal(resolveTheme('cafe'), 'cafe');
  assert.equal(resolveTheme('system' as never), 'light', 'an old stored system value falls back to light');
});

test('no flash: the pre-paint script is an external file (CSP forbids inline) and uses the same key and values', () => {
  const html = read('index.html'), init = read('public/theme-init.js');
  assert.match(html, /<script src="\/admin\/theme-init\.js"><\/script>/);
  assert.doesNotMatch(html, /<script>[^<]/, 'no inline script');
  assert.ok(html.indexOf('theme-init.js') < html.indexOf('/src/main.tsx'), 'runs before the app');
  assert.match(html, /<meta name="theme-color" content="#F8FAFC" \/>/);
  assert.match(init, /genz-admin-theme/);
  assert.match(init, /'cafe'/);
  assert.doesNotMatch(init, /prefers-color-scheme|system/, 'no system-following in the pre-paint script');
  assert.match(read('src/theme.ts'), /THEME_KEY = 'genz-admin-theme'/);
  assert.doesNotMatch(read('src/theme.ts'), /matchMedia|prefers-color-scheme/, 'no system-following in the store');
});

test('Build 86: exactly three schemes — Light, Dark (Cyber Teal), Cafe — with the same tokens; no old scheme colours', () => {
  const css = read('src/theme.css');
  for (const scheme of ['light', 'dark', 'cafe']) assert.ok(css.includes(`:root[data-theme="${scheme}"]{`), `${scheme} token block exists`);
  assert.doesNotMatch(css, /:root\[data-theme="system"\]/, 'no system scheme');
  const tokenBlock = (scheme: string) => {
    const start = css.indexOf(`:root[data-theme="${scheme}"]{`);
    const next = css.indexOf(':root[data-theme=', start + 1);
    return css.slice(start, next < 0 ? css.length : next);
  };
  const tokens = (block: string) => new Set([...block.matchAll(/(--[a-z0-9-]+):/g)].map(m => m[1]));
  const l = tokens(tokenBlock('light')), d = tokens(tokenBlock('dark')), c = tokens(tokenBlock('cafe'));
  assert.deepEqual([...d].filter(t => !l.has(t)), [], 'every dark token exists in light');
  assert.deepEqual([...l].filter(t => !d.has(t)), [], 'every light token exists in dark');
  assert.deepEqual([...c].filter(t => !l.has(t)), [], 'every cafe token exists in light');
  assert.deepEqual([...l].filter(t => !c.has(t)), [], 'every light token exists in cafe');
  for (const hex of ['#F8FAFC', '#0F172A', '#64748B', '#10B981', '#FFFFFF']) assert.ok(tokenBlock('light').toUpperCase().includes(hex), `light ${hex}`);
  for (const hex of ['#06363A', '#0B4A45', '#98FFE2', '#E6FFF6', '#8FD8C4']) assert.ok(tokenBlock('dark').toUpperCase().includes(hex), `dark ${hex}`);
  for (const hex of ['#FFFBF3', '#46291E', '#FF6115', '#46372F']) assert.ok(tokenBlock('cafe').toUpperCase().includes(hex), `cafe ${hex}`);
  for (const hex of ['#10B981', '#EF4444', '#3B82F6', '#F59E0B']) assert.ok(css.toUpperCase().includes(hex), `status colour ${hex}`);
  for (const hex of ['#C6FF3E', '#8B5CF6', '#FF2E88', '#155E70', '#FFAA1D', '#214DCC', '#FFDB43', '#FF7F52', '#EC634A', '#008082']) assert.ok(!css.toUpperCase().includes(hex), `old colour gone: ${hex}`);
  assert.doesNotMatch(css, /Midnight|neon/i, 'no Midnight Neon names left');
});

test('switcher: three radios in the top header (Light, Dark, Cafe); charts use theme variables; reduced motion respected', () => {
  const sw = read('src/ThemeSwitcher.tsx'), app = read('src/App.tsx'), ui = read('src/ui.tsx');
  assert.ok(sw.indexOf("id: 'light'") < sw.indexOf("id: 'dark'") && sw.indexOf("id: 'dark'") < sw.indexOf("id: 'cafe'"), 'order: Light, Dark, Cafe');
  assert.doesNotMatch(sw, /'system'/, 'no System option');
  assert.match(sw, /role="radiogroup"/);
  assert.match(app, /<ThemeSwitcher \/>/);
  assert.doesNotMatch(ui, /#1769F5|#7654F6|#64748B|#E3E9F5/, 'no hard-coded chart colours left');
  assert.match(read('src/main.tsx'), /import '\.\/theme\.css'/);
  assert.match(read('src/theme.css'), /prefers-reduced-motion:reduce/);
});

test('Build 86: no welcome banner; first row is two stats plus the user-overview donut; learning activity is compact and after referrals', () => {
  const dash = read('src/pages/Dashboard.tsx'), app = read('src/App.tsx'), css = read('src/theme.css');
  assert.doesNotMatch(dash, /className="banner"|Welcome back|banner-cta|logo128/, 'welcome banner is gone');
  assert.match(dash, /dash-first-row/);
  assert.match(dash, /Total registered users/);
  assert.match(dash, /Total active users/);
  assert.match(dash, /Weekly/);
  assert.match(dash, /Monthly/);
  assert.match(dash, /Yearly/);
  assert.match(dash, /activePeriod/);
  const firstRow = dash.slice(dash.indexOf('dash-first-row'), dash.indexOf('Referrals'));
  assert.ok(firstRow.includes('User overview') && firstRow.includes('Donut'), 'donut card is in the first row');
  for (const label of ['Daily active', 'Weekly active', 'Monthly active', 'New (7 days)', 'Suspended']) assert.ok(!dash.includes(`label="${label}"`), `removed card: ${label}`);
  assert.ok(dash.indexOf('Learning activity') > dash.indexOf('Referrals'), 'learning activity comes after referrals');
  assert.match(dash, /stats-compact/);
  assert.doesNotMatch(app, /nav-feature/, 'notifications item is no longer highlighted');
  assert.doesNotMatch(css, /\.nav-feature/, 'no nav-feature rule left');
});

test('Build 86: Daily Code calendar keeps status colours in all three schemes (green published, amber pending, grey past)', () => {
  const css = read('src/theme.css');
  // Day cells are <button class="btn feature-date is-…">, so the status rules must out-rank the glass-button rules.
  assert.match(css, /is-published\{background:#86EFAC;border-color:#16A34A/);
  assert.match(css, /is-past\{background:#EEF0F4;border-color:#DDE2EA/);
  assert.match(css, /:root\[data-theme="dark"\] \.feature-calendar \.btn\.feature-date\.is-published\{background:linear-gradient\(145deg,rgba\(34,197,94/);
  assert.match(css, /:root\[data-theme="cafe"\] \.feature-calendar \.btn\.feature-date\.is-published\{background:#86EFAC/);
  assert.match(read('src/pages/CommunityWorkflow.tsx'), /className=\{`btn feature-date is-\$\{status\}`\}/);
});

test('Build 86: Home and Codebook cards row — the select and the Save button align on the same baseline', () => {
  const css = read('src/theme.css'), cw = read('src/pages/CommunityWorkflow.tsx');
  assert.match(css, /\.daily-glass-preview \.row\{align-items:flex-end/);
  assert.match(css, /\.daily-glass-preview \.row \.btn\{flex:none;align-self:flex-end/);
  assert.match(cw, /Home and Codebook cards/);
  assert.match(cw, /Save card settings/);
});

test('Build 87: cafe-format hero + small stat cards — one accent per scheme; luxury buttons', () => {
  const css = read('src/theme.css'), dash = read('src/pages/Dashboard.tsx');
  const tokenBlock = (scheme: string) => {
    const start = css.indexOf(`:root[data-theme="${scheme}"]{`);
    const next = css.indexOf(':root[data-theme=', start + 1);
    return css.slice(start, next < 0 ? css.length : next);
  };
  // Hero gradient uses the scheme accent: green light, Aqua Foam dark, orange cafe.
  assert.match(tokenBlock('light'), /--hero-stat:linear-gradient\(135deg,#059669 0%,#10B981 55%,#34D399 100%\)/);
  assert.match(tokenBlock('dark'), /--hero-stat:linear-gradient\(135deg,#5EEAD4 0%,#98FFE2 55%,#C8FFF0 100%\)/);
  assert.match(tokenBlock('cafe'), /--hero-stat:linear-gradient\(135deg,#D65111 0%,#FF6115 55%,#FF8A3D 100%\)/);
  // Dark text on Aqua Foam (light accent); white text on green/orange.
  assert.match(tokenBlock('dark'), /--on-hero:#06363A/);
  assert.match(tokenBlock('light'), /--on-hero:#FFFFFF/);
  assert.match(tokenBlock('cafe'), /--on-hero:#FFFFFF/);
  // Hero rules: gradient fill, translucent chip top-right, readable period tabs.
  assert.match(css, /\.dash-first-row>\.stat\{background:var\(--hero-stat\)/);
  assert.match(css, /\.dash-first-row>\.stat \.stat-icon-row\{display:grid;grid-template-columns:minmax\(0,1fr\) auto/);
  assert.match(css, /\.dash-first-row>\.stat \.stat-icon-row>\.stat-ico\{grid-column:2;grid-row:1;background:var\(--hero-chip\)/);
  assert.match(css, /\.dash-first-row>\.stat \.seg-tabs\{background:var\(--hero-tab-bg\)/);
  assert.match(css, /\.dash-first-row>\.stat \.seg-tab\[aria-selected="true"\]\{background:var\(--hero-tab-on\);color:var\(--hero-tab-on-ink\)/);
  // Small cards: one accent chip + accent underline bar; Referrals uses stats-accent.
  assert.match(css, /\.stats-compact \.stat::after,\.stats-accent \.stat::after\{content:"";position:absolute;left:12px;right:12px;bottom:0;height:3px;border-radius:3px 3px 0 0;background:var\(--primary\)\}/);
  assert.match(css, /\.stats-compact \.stat \.stat-ico,\.stats-accent \.stat \.stat-ico\{background:var\(--grad\);color:var\(--on-primary\)\}/);
  assert.match(dash, /<Stats className="stats-accent">/);
  assert.match(dash, /<Stats className="stats-compact">/);
  // The donut card is not a hero stat: it keeps its own card background.
  assert.doesNotMatch(css, /\.dash-first-row>\.card\{background:var\(--hero-stat\)/);
  // Luxury Minimalism / Soft UI, portal-wide: large radii, diffused layered shadows, airy spacing.
  assert.match(css, /\.card\{padding:22px;border-radius:20px;box-shadow:0 2px 6px var\(--glass-shade\),0 18px 44px var\(--glass-shade\),inset 0 1px var\(--glass-highlight\)\}/);
  assert.match(css, /\.stat\{border-radius:18px;padding:16px 15px;box-shadow:0 2px 6px var\(--glass-shade\),0 14px 30px var\(--glass-shade\),inset 0 1px var\(--glass-highlight\)\}/);
  assert.match(css, /\.btn\{min-height:42px;box-shadow:0 2px 6px var\(--glass-shade\),0 8px 18px var\(--glass-shade\),inset 0 1px var\(--glass-highlight\)\}/);
  assert.match(css, /input,select,textarea\{border-radius:14px;padding:12px 16px\}/);
  assert.match(css, /\.stat-label\{font-weight:700;letter-spacing:\.02em\}/);
});

test('Build 88: glow cards mix light and dark scheme colours; nav items and fields stand out; hero cards are shorter with larger text', () => {
  const css = read('src/theme.css');
  for (const t of ['--glow', '--glow-soft', '--card-mix', '--card-edge', '--stat-mix', '--field-strong', '--field-line', '--side-mix', '--nav-item-bg', '--nav-item-line'])
    for (const scheme of ['light', 'dark', 'cafe']) {
      const start = css.indexOf(`:root[data-theme="${scheme}"]{`), end = css.indexOf('\n}', start);
      assert.ok(css.slice(start, end).includes(t + ':'), `${scheme} has ${t}`);
    }
  assert.match(css, /\.card\{border:1px solid transparent;background:var\(--card-mix\) padding-box,var\(--card-edge\) border-box;/);
  assert.match(css, /0 0 26px var\(--glow-soft\)/, 'soft accent glow around cards');
  assert.match(css, /\.side nav a\{background:var\(--nav-item-bg\);border:1px solid var\(--nav-item-line\)/);
  assert.match(css, /input,select,textarea,\.topbar-search input\{background-color:var\(--field-strong\);border:1\.5px solid var\(--field-line\)/);
  assert.match(css, /\.dash-first-row>\.stat \.stat-value\{font-size:42px/);
  assert.match(css, /\.dash-first-row>\.stat \.stat-label\{font-size:15px/);
  assert.match(css, /\.dash-first-row \.donut-wrap svg\{width:124px;height:124px\}/);
});
