import {runFeature} from './CommunityWorkflow';
import React, {useState} from 'react';
import {doc, getDoc, serverTimestamp} from 'firebase/firestore/lite';
import {multiFactor} from 'firebase/auth';
import {db, addAudit, newBatch, errorMessage} from '../firebase';
import {useSession} from '../App';
import {can, ROLE_LABELS} from '../rbac';
import {publishingMode,type PublishingMode} from '../../../shared/publishing';
import {BYLINE, RIGHTS, copyright} from '../../../shared/brand';
import {PORTAL_BUILD, PORTAL_VERSION} from '../version';
import {Card, Notice, Field, useLoad} from '../ui';

type AppConfig = {showDailyCreator:boolean;dictionaryPostingMode:'open'|'review'|'paused';postPostingMode:'open'|'review'|'paused';ugcEnabled: boolean; contentUpdatesEnabled: boolean; communityWordsEnabled: boolean; chatEnabled: boolean; minSupportedVersion: string; paidCommunity: boolean; /** Build 91 */ paidCodes: boolean; paidPosts: boolean; adPayEnabled: boolean; encodeFreeDaily: number; decodeFreeDaily: number; prices: Prices};
type Prices = {chatDay: number; post: number; code: number; dailyCode: number; verification: number; encode: number; decode: number};
const PRICE_FIELDS: {key: keyof Prices; label: string; min: number; def: number}[] = [
  {key: 'chatDay', label: 'Community chat · whole day', min: 1, def: 30}, {key: 'post', label: 'Publish one community post', min: 1, def: 50},
  {key: 'code', label: 'Extra dictionary word (1 free a day per user)', min: 1, def: 100}, {key: 'dailyCode', label: 'Extra Daily Code Display (1 free a month per user)', min: 1, def: 100},
  {key: 'verification', label: 'Verified badge review', min: 1, def: 5000}, {key: 'encode', label: 'Encode Message · each after the free ones (0 = free)', min: 0, def: 5},
  {key: 'decode', label: 'Decode Message · each after the free ones (0 = free)', min: 0, def: 5}];
const readPrices = (raw: unknown): Prices => Object.fromEntries(PRICE_FIELDS.map(f => {const v = (raw as Record<string, unknown> | undefined)?.[f.key]; return [f.key, Number.isInteger(v) && (v as number) >= f.min ? v : f.def];})) as Prices;

export default function Settings() {
  const s = useSession();
  const cfg = useLoad(async (): Promise<AppConfig> => {
    const d = await getDoc(doc(db, 'config', 'app'));
    const v = d.exists() ? d.data() : {};
    return {showDailyCreator:v.showDailyCreator===true,dictionaryPostingMode:publishingMode(v,'code'),postPostingMode:publishingMode(v,'post'),ugcEnabled: v.ugcEnabled !== false, contentUpdatesEnabled: v.contentUpdatesEnabled !== false, communityWordsEnabled: v.communityWordsEnabled !== false, chatEnabled: v.chatEnabled !== false, paidCommunity: v.paidCommunity === true, paidCodes: typeof v.paidCodes === 'boolean' ? v.paidCodes : v.paidCommunity === true, paidPosts: typeof v.paidPosts === 'boolean' ? v.paidPosts : v.paidCommunity === true, adPayEnabled: v.adPayEnabled === true, encodeFreeDaily: Number.isInteger(v.encodeFreeDaily) ? v.encodeFreeDaily : 10, decodeFreeDaily: Number.isInteger(v.decodeFreeDaily) ? v.decodeFreeDaily : 10, prices: readPrices(v.prices), minSupportedVersion: typeof v.minSupportedVersion === 'string' ? v.minSupportedVersion : '0.8.3'};
  }, []);
  const sharing = useLoad(async () => (await getDoc(doc(db,'config','ownerSharingCode-'+s.uid))).data(), [s.uid]);
  const [sharingDraft,setSharingDraft]=useState<string|null>(null);
  const [sharingStatus,setSharingStatus]=useState('');
  const [sharingBusy,setSharingBusy]=useState(false);
  const sharingCode=sharingDraft??(sharing.data?.uid===s.uid?String(sharing.data?.code??''):'');
  const saveSharingCode=async()=>{
    setSharingBusy(true);setSharingStatus('');
    try{
      await runFeature({action:'owner-sharing-code',code:sharingCode});
      sharing.reload();setSharingStatus('Sharing code saved.');
    }catch(e){setSharingStatus(errorMessage(e));}
    finally{setSharingBusy(false);}
  };
  const [draft, setDraft] = useState<AppConfig | null>(null);
  const [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null), [busy, setBusy] = useState(false);
  const value = draft ?? cfg.data;
  const dirty = !!draft && JSON.stringify(draft) !== JSON.stringify(cfg.data);
  const setPrice = (key: keyof Prices, n: number) => {
    if (!value) return;
    const f = PRICE_FIELDS.find(p => p.key === key)!, max = key === 'encode' || key === 'decode' ? 1000 : 100000;
    setMsg(null);
    setDraft({...value, prices: {...value.prices, [key]: Math.max(f.min, Math.min(max, Math.floor(n) || 0))}});
  };
  const save = async () => {
    if (!value) return;
    setBusy(true); setMsg(null);
    try {
      const b = newBatch();
      const lastAuditId = addAudit(b, s.uid, s.role, 'config.update', 'config/app', `ugc=${value.ugcEnabled} instant=${value.communityWordsEnabled} chat=${value.chatEnabled} chatPaid=${value.paidCommunity} codesPaid=${value.paidCodes} postsPaid=${value.paidPosts} adPay=${value.adPayEnabled} encode=${value.encodeFreeDaily} decode=${value.decodeFreeDaily} prices=${PRICE_FIELDS.map(f => f.key + ':' + value.prices[f.key]).join(',')} content=${value.contentUpdatesEnabled} min=${value.minSupportedVersion}`);
      b.set(doc(db, 'config', 'app'), {...value, updatedAt: serverTimestamp(), updatedBy: s.uid, lastAuditId});
      await b.commit(); setMsg({kind: 'ok', text: 'Settings saved and audited.'}); setDraft(null); cfg.reload();
    } catch (e) {setMsg({kind: 'error', text: errorMessage(e)});} finally {setBusy(false);}
  };
  const factors = multiFactor(s.user).enrolledFactors;
  return <div className="stack">

    {s.role==='super_admin'&&<Card title="Owner sharing code">
      <div className="row wrap"><label className="field">Sharing code<input placeholder="GZKBRSMK" maxLength={8} value={sharingCode} onChange={e=>setSharingDraft(e.target.value.toUpperCase())}/></label>
      <button className="btn primary" disabled={sharingBusy||!/^GZ[A-Z0-9]{6}$/.test(sharingCode)} onClick={()=>void saveSharingCode()}>Save sharing code</button></div>
      {!!sharingStatus&&<p role="status">{sharingStatus}</p>}
    </Card>}
    <Card title="Your session" index={0}>
      <dl className="grid-dl"><dt>Signed in as</dt><dd>{s.email}</dd><dt>Role</dt><dd>{ROLE_LABELS[s.role]}</dd><dt>Second factors</dt><dd>{factors.map(f => f.displayName ?? f.factorId).join(', ') || '—'}</dd><dt>Session</dt><dd>This tab only · ends after 30 minutes of inactivity</dd></dl>
    </Card>
    {can(s.role, 'config.manage') && (cfg.error ? <Card title="App controls" index={1}><Notice kind="error">{errorMessage(cfg.error)}</Notice></Card> : value && <>
      <Card title="Publishing" subtitle="How new codes, posts and chat reach the app. Read by the app and enforced by security rules." index={1}>
        <div className="ctl-list">
          <Toggle label="Accept suggestions and reports" desc="Kill switch for abuse. When off, users can’t send word suggestions or reports." checked={value.ugcEnabled} onChange={v => setDraft({...value, ugcEnabled: v})} />
          <Toggle label="Community chat is open" desc="Turn off to close the chat room for everyone." checked={value.chatEnabled} onChange={v => setDraft({...value, chatEnabled: v})} />
          <Toggle label="Show the creator on Daily Code cards" desc="Shows the creator’s display name under the Daily Code." checked={value.showDailyCreator} onChange={v => setDraft({...value, showDailyCreator: v})} />
        </div>
        <div className="ctl-grid">{(['dictionaryPostingMode','postPostingMode'] as const).map(key=><Field key={key} label={key==='dictionaryPostingMode'?'New code publishing':'Community post publishing'}>
          <select value={value[key]} onChange={e=>setDraft({...value,[key]:e.target.value as PublishingMode,...(key==='dictionaryPostingMode'?{communityWordsEnabled:e.target.value==='open'}:{})})}>
            <option value="open">Open — publish immediately</option><option value="review">Approval required</option><option value="paused">Paused — accept nothing new</option>
          </select>
        </Field>)}</div>
      </Card>

      <Card title="Charges and payments" subtitle="What users pay for. New prices apply at once and the server charges exactly these amounts." index={2}>
        <div className="summary-pills" aria-label="What users see now">
          <span className={`pill ${value.paidCodes ? 'pill-warn' : 'pill-good'}`}>New codes: {value.paidCodes ? `1 free a day, then ${value.prices.code} Credits${value.adPayEnabled ? ' or 1 ad' : ''}` : 'free'}</span>
          <span className={`pill ${value.paidPosts ? 'pill-warn' : 'pill-good'}`}>Posts: {value.paidPosts ? `${value.prices.post} Credits${value.adPayEnabled ? ' or 1 ad' : ''}` : 'free'}</span>
          <span className={`pill ${value.paidCommunity ? 'pill-warn' : 'pill-good'}`}>Chat: {value.paidCommunity ? `${value.prices.chatDay} Credits a day` : 'free'}</span>
        </div>

        <p className="section-label">Community charges</p>
        <div className="fee-table" role="table" aria-label="Community charges">
          <div className="fee-head" role="row"><span role="columnheader">Feature</span><span role="columnheader">Charge</span><span role="columnheader">Price (Credits)</span></div>
          <FeeRow name="New codes / words" rule="1 free per user each day (UTC), then this price for each extra code." on={value.paidCodes} onToggle={v => setDraft({...value, paidCodes: v})} price={value.prices.code} onPrice={n => setPrice('code', n)} />
          <FeeRow name="Community posts" rule="Charged for every post." on={value.paidPosts} onToggle={v => setDraft({...value, paidPosts: v})} price={value.prices.post} onPrice={n => setPrice('post', n)} />
          <FeeRow name="Community chat" rule="A day pass (UTC) with unlimited messages." on={value.paidCommunity} onToggle={v => setDraft({...value, paidCommunity: v})} price={value.prices.chatDay} onPrice={n => setPrice('chatDay', n)} />
        </div>

        <p className="section-label">Alternative payment</p>
        <div className="ctl-list">
          <Toggle label="Pay with 1 ad instead of Credits" checked={value.adPayEnabled} disabled={!value.paidCodes && !value.paidPosts} onChange={v => setDraft({...value, adPayEnabled: v})}
            desc={!value.paidCodes && !value.paidPosts ? 'Available when new codes or posts are charged.' : 'Users may watch one rewarded ad to the end instead of paying — up to 3 codes and 3 posts per user per day. Keep this off until your AdMob account is approved and serving ads.'}
            badge={value.adPayEnabled && (value.paidCodes || value.paidPosts) ? <span className="pill pill-info">On</span> : <span className="pill">Off</span>} />
        </div>

        <p className="section-label">Always charged</p>
        <div className="fee-table" role="table" aria-label="Always charged">
          <div className="fee-head" role="row"><span role="columnheader">Feature</span><span role="columnheader">Free allowance</span><span role="columnheader">Price (Credits)</span></div>
          <FeeRow name="Daily Code Display" rule="Your word on Home and Codes for a day." allowance="1 a month" price={value.prices.dailyCode} onPrice={n => setPrice('dailyCode', n)} />
          <FeeRow name="Verified badge review" rule="Manual review of a blue badge request." allowance="None" price={value.prices.verification} onPrice={n => setPrice('verification', n)} />
          <FeeRow name="Encode Message" rule="Each encode after the free ones. 0 = always free." allowanceInput={{value: value.encodeFreeDaily, label: 'Free encodes per user per day', onChange: n => setDraft({...value, encodeFreeDaily: n})}} price={value.prices.encode} min={0} max={1000} onPrice={n => setPrice('encode', n)} />
          <FeeRow name="Decode Message" rule="Each decode after the free ones. 0 = always free." allowanceInput={{value: value.decodeFreeDaily, label: 'Free decodes per user per day', onChange: n => setDraft({...value, decodeFreeDaily: n})}} price={value.prices.decode} min={0} max={1000} onPrice={n => setPrice('decode', n)} />
        </div>
      </Card>

      <Card title="App delivery" subtitle="Content updates and version information for the app." index={3}>
        <div className="ctl-list">
          <Toggle label="Deliver published content updates" desc="Apps download newly published dictionary content in the background." checked={value.contentUpdatesEnabled} onChange={v => setDraft({...value, contentUpdatesEnabled: v})} />
        </div>
        <div className="ctl-grid"><Field label="Minimum supported app version" hint="Informational only."><input value={value.minSupportedVersion} onChange={e => setDraft({...value, minSupportedVersion: e.target.value.slice(0, 20)})} /></Field></div>
      </Card>

      <div className="save-bar" role="region" aria-label="Save settings">
        <div className="save-state">
          {msg && (msg.kind === 'error' || !dirty) ? <span className={`pill ${msg.kind === 'ok' ? 'pill-good' : 'pill-bad'}`} role={msg.kind === 'ok' ? 'status' : 'alert'}>{msg.text}</span>
            : dirty ? <span className="pill pill-warn">Unsaved changes</span> : <span className="pill">All changes saved</span>}
          <small className="muted">Every save is recorded in the audit log.</small>
        </div>
        <div className="row">
          <button className="btn" disabled={busy || !dirty} onClick={() => {setDraft(null); setMsg(null);}}>Discard changes</button>
          <button className="btn primary" disabled={busy || !dirty} onClick={() => void save()}>{busy ? 'Saving…' : 'Save settings'}</button>
        </div>
      </div>
    </>)}
    <Card title="About this portal" index={4}>
      <dl className="grid-dl"><dt>Product</dt><dd>GenZ Codebook Admin Portal</dd><dt>Version</dt><dd>{PORTAL_VERSION} · Build {PORTAL_BUILD}</dd><dt>Released with</dt><dd>GenZ Codebook app {PORTAL_VERSION} (Android)</dd><dt>Publisher</dt><dd>{BYLINE}</dd></dl>
      <p className="muted small">{copyright()}. {RIGHTS}</p>
    </Card>
  </div>;
}

/** Build 91: one switch row (label + description on the left, switch on the right). */
function Toggle({label, desc, checked, onChange, disabled = false, badge}: {label: string; desc?: string; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean; badge?: React.ReactNode}) {
  return <label className={`ctl-row${disabled ? ' is-disabled' : ''}`}>
    <span className="ctl-text"><span className="ctl-title">{label}{badge && <> {badge}</>}</span>{desc && <span className="ctl-desc">{desc}</span>}</span>
    <Switch checked={checked && !disabled} disabled={disabled} onChange={onChange} label={label} />
  </label>;
}
function Switch({checked, onChange, disabled = false, label}: {checked: boolean; onChange: (v: boolean) => void; disabled?: boolean; label: string}) {
  return <span className="switch"><input type="checkbox" role="switch" aria-label={label} aria-checked={checked} checked={checked} disabled={disabled} onChange={e => onChange(e.target.checked)} /><span className="switch-track" aria-hidden="true" /></span>;
}
/** Build 91: one row of a charges table — feature and rule, a Charged/Free switch (or the free allowance), and the price. */
function FeeRow({name, rule, on, onToggle, allowance, allowanceInput, price, onPrice, min = 1, max = 100000}: {
  name: string; rule: string; on?: boolean; onToggle?: (v: boolean) => void; allowance?: string;
  allowanceInput?: {value: number; label: string; onChange: (n: number) => void}; price: number; onPrice: (n: number) => void; min?: number; max?: number;
}) {
  return <div className={`fee-row${onToggle && !on ? ' is-free' : ''}`} role="row">
    <div className="fee-name" role="cell"><strong>{name}</strong><small className="muted">{rule}</small></div>
    <div className="fee-state" role="cell">
      {onToggle ? <label className="fee-switch"><Switch checked={!!on} onChange={onToggle} label={`Charge for ${name.toLowerCase()}`} /><span>{on ? 'Charged' : 'Free'}</span></label>
        : allowanceInput ? <span className="fee-allowance-input"><input type="number" min={0} max={1000} aria-label={allowanceInput.label} value={allowanceInput.value} onChange={e => allowanceInput.onChange(Math.max(0, Math.min(1000, Math.floor(Number(e.target.value) || 0))))} /><span className="muted">/ day</span></span>
        : <span className="fee-allowance">{allowance}</span>}
    </div>
    <div className="fee-price" role="cell"><input type="number" min={min} max={max} aria-label={`${name} price in Credits`} value={price} onChange={e => onPrice(Number(e.target.value))} /></div>
  </div>;
}
