/**
 * Build 91: the portal's version comes from the app release it is built and deployed with
 * (app.json), so the sidebar and Settings → About never show an old number again.
 */
import app from '../../app.json';

export const PORTAL_VERSION: string = app.expo.version;
export const PORTAL_BUILD: number = app.expo.android.versionCode;
