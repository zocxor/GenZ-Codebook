import {useEffect,useMemo,useState} from 'react';
import {AppState} from 'react-native';
import {collection,doc,limit,onSnapshot,orderBy,query,Timestamp,where} from 'firebase/firestore';
import {getFunctions,connectFunctionsEmulator,httpsCallable} from 'firebase/functions';
import {firebaseApp,cloudDbLive,accountAuth} from './firebase/app';
import {EMULATOR_HOST} from './secure/config';
import {BACKEND_URL} from './backend';
import {ms} from './communityFeatures';
export type Person={uid:string;name:string;avatar:number;photo?:string;role?:string;online?:boolean;lastSeen?:number;readAt?:number};
export type ConnectionList='followers'|'following';
export type ProfileDetails=Person&{premiumUntil:number;followers:number;postLikes?:number;followingCount:number;following:boolean;chatStatus:string|null;conversationId:string|null;requestedByMe:boolean};
export type InboxRow={id:string;conversationId:string;type:'personal'|'group';name:string;peerId?:string;avatar?:number;photo?:string;groupIcon?:string;memberCount?:number;ownerId?:string;status:string;requestedBy?:string;unread:number;updatedAt?:unknown;lastMessage?:string;lastMessageId?:string;pinned?:boolean;pinnedMessageId?:string;muted?:boolean;archived?:boolean;deleted?:boolean;hiddenBefore?:unknown;visibleFrom?:unknown};
export type PrivateMessage={id:string;senderId:string;name:string;text:string;createdAt?:unknown;replyTo?:string;replyText?:string;replyName?:string;attachmentExpiresAt?:number;attachmentCaption?:boolean;fileName?:string;removed?:boolean;forwarded?:boolean;replySenderId?:string};
export type Invite={id:string;name:string;invitedBy:string;status:string};
export type MessageNotice={id:string;title:string;body:string;type:string;conversationId:string;createdAt?:unknown;read?:boolean};
const deliveredKeys=new Map<string,number>();
const functions=getFunctions(firebaseApp,BACKEND_URL||'us-central1');
if(EMULATOR_HOST)connectFunctionsEmulator(functions,EMULATOR_HOST,5001);
const invoke=httpsCallable<Record<string,unknown>,Record<string,any>>(functions,'communityFeature',{timeout:30000});
/**
 * Build 88: brief network drops and busy server moments ("Could not reach the Community service")
 * are retried automatically, twice, before an error is shown. Every command is safe to repeat:
 * sends carry a requestId and the server returns the same message ID for a repeat.
 */
const TRANSIENT=new Set(['functions/unavailable','functions/deadline-exceeded','functions/resource-exhausted','functions/aborted']);
export const transientCallError=(e:unknown)=>{const v=e as {code?:string;message?:string}|null;return TRANSIENT.has(v?.code??'')||(v?.code==='functions/internal'&&/^internal(?:\s*\[0\])?$/i.test(v?.message?.trim()??''));};
const pause=(ms:number)=>new Promise(resolve=>setTimeout(resolve,ms));
export async function messaging(command:string,data:Record<string,unknown>={}){
 const user=accountAuth.currentUser;
 if(user&&(await user.getIdTokenResult()).claims.email_verified!==true)await user.getIdToken(true);
 for(let attempt=0;;attempt++){
  try{return (await invoke({action:'messaging',command,...data})).data;}
  catch(e){if(attempt>=2||!transientCallError(e))throw e;await pause(attempt?1600:600);}
 }
}
export function useInbox(uid?:string,enabled=true){
 const [rows,setRows]=useState<InboxRow[]>([]),[error,setError]=useState(''),[loading,setLoading]=useState(!!uid),[epoch,reload]=useState(0);
 useEffect(()=>{setRows([]);setError('');if(!uid||!enabled){setLoading(false);return;}setLoading(true);return onSnapshot(query(collection(cloudDbLive(),`users/${uid}/inbox`),orderBy('updatedAt','desc'),limit(200)),snap=>{const next=snap.docs.map(d=>({...d.data(),id:d.id})as InboxRow);setRows(next);for(const r of next.filter(r=>r.unread>0&&r.status==='active').slice(0,10)){const key=uid+'|'+r.id,value=ms(r.updatedAt);if(deliveredKeys.get(key)!==value){deliveredKeys.set(key,value);void messaging('delivered',{conversationId:r.id}).catch(()=>deliveredKeys.delete(key));}}setLoading(false);setError('');},()=>{setLoading(false);setError('Inbox could not connect. Check your connection and retry.');});},[uid,enabled,epoch]);
 return {rows,error,loading,retry:()=>reload(x=>x+1),unread:rows.filter(r=>!r.deleted&&r.status==='active'&&r.unread>0).length,requests:rows.filter(r=>!r.deleted&&!r.archived&&r.status==='pending'&&r.requestedBy!==uid).length};
}
export function useMessageNotices(uid?:string){const [rows,setRows]=useState<MessageNotice[]>([]);useEffect(()=>{setRows([]);if(!uid)return;return onSnapshot(query(collection(cloudDbLive(),`users/${uid}/messageNotifications`),orderBy('createdAt','desc'),limit(50)),s=>setRows(s.docs.map(d=>({...d.data(),id:d.id})as MessageNotice)),()=>setRows([]));},[uid]);return rows;}
export function usePrivateMessages(uid:string|undefined,row:InboxRow|null){
 const [rows,setRows]=useState<PrivateMessage[]>([]),[error,setError]=useState(''),[loading,setLoading]=useState(false),[more,setMore]=useState(false),[epoch,reload]=useState(0),[hidden,setHidden]=useState<Set<string>>(new Set());
 const boundary=Math.max(ms(row?.visibleFrom),ms(row?.hiddenBefore)),cid=row?.id;
 const rawBound=ms(row?.visibleFrom)>=ms(row?.hiddenBefore)?row?.visibleFrom:row?.hiddenBefore;
 const scope=JSON.stringify([uid,cid,row?.status,boundary]);
 const [window,setWindow]=useState({scope,count:40});
 const count=window.scope===scope?window.count:40;
 const [loadedScope,setLoadedScope]=useState('');
 const visible=loadedScope===scope?rows:[];
 useEffect(()=>{
  setMore(false);setError('');
  if(!uid||!cid||!['active','closed'].includes(row?.status||'')){setLoading(false);return;}
  const bound=rawBound instanceof Timestamp?rawBound:Timestamp.fromMillis(boundary);
  setLoading(true);
  return onSnapshot(query(collection(cloudDbLive(),`conversations/${cid}/messages`),where('createdAt','>=',bound),orderBy('createdAt','desc'),limit(count+1)),{includeMetadataChanges:true},snapshot=>{
   if(snapshot.metadata.fromCache&&!snapshot.size)return;
   setRows(snapshot.docs.slice(0,count).map(d=>({...d.data(),id:d.id})as PrivateMessage));
   setLoadedScope(scope);setMore(snapshot.size>count);setLoading(false);setError('');
  },()=>{setLoading(false);setError('Messages could not load. Check membership or connection, then retry.');});
 },[scope,count,epoch]);
 useEffect(()=>{setHidden(new Set());if(!uid||!cid)return;return onSnapshot(query(collection(cloudDbLive(),`users/${uid}/hiddenMessages`),where('conversationId','==',cid)),s=>setHidden(new Set(s.docs.map(d=>d.get('messageId')))),()=>{});},[uid,cid]);
 const loadOlder=()=>{if(more&&!loading)setWindow({scope,count:count+40});};
 const ordered=useMemo(()=>visible.filter(m=>!hidden.has(m.id)&&ms(m.createdAt)>=boundary).sort((a,b)=>ms(a.createdAt)-ms(b.createdAt)||a.id.localeCompare(b.id)),[visible,hidden,boundary]);
 return {rows:ordered,error,loading,more,loadOlder,retry:()=>reload(x=>x+1)};
}
export function useMessagingPresence(uid?:string,active=true){useEffect(()=>{if(!uid||!active)return;const ping=()=>{if(AppState.currentState==='active')void messaging('presence').catch(()=>{});};ping();const timer=setInterval(ping,40000);const sub=AppState.addEventListener('change',state=>{void messaging('presence',{online:state==='active'}).catch(()=>{});});return()=>{clearInterval(timer);sub.remove();void messaging('presence',{online:false}).catch(()=>{});};},[uid,active]);}
