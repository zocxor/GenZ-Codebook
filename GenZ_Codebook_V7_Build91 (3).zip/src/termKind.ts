/**
 * What kind of expression an entry is — Code, Numeric Code, Slang, Emoji or Term — so every
 * entry can say plainly whether it is a code or a slang (Build 88). Pure, so it is unit-tested.
 *
 * The rule follows the "Learn the Codebook" guide:
 *  - Code: shorthand made of letters, numbers or symbols (BRB, l8r, goat = greatest of all time).
 *  - Numeric Code: only digits (143, 505).
 *  - Slang: an informal word or phrase (rizz, delulu, no cap).
 *  - Emoji: an emoji or symbol.
 *  - Term: a word from a field such as work or study.
 */
export type TermKind = 'Code' | 'Numeric Code' | 'Slang' | 'Emoji' | 'Term';
type KindInput = {expression: string; full?: string; category: string};

const CODE_CATEGORIES = new Set(['Chat', 'Numbers']);
const SLANG_CATEGORIES = new Set(['Social', 'Gaming', 'Regional']);
const letters = (s: string) => s.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');

/** "goat" + "greatest of all time", "fyp" + "for you page", "l8r", "gr8": a shorthand code. */
export function looksLikeCode(expression: string, full = ''): boolean {
  const e = expression.trim();
  if (!e || /\s/.test(e) || e.length > 10) return false;
  const core = letters(e);
  if (core.length < 2) return false;
  if (/\p{N}/u.test(core) && /\p{L}/u.test(core)) return true; // l8r, gr8, 2day
  const words = full.toLowerCase().split(/[\s\-/]+/).map(letters).filter(Boolean);
  if (words.length >= 2 && words.map(w => w[0]).join('') === core) return true; // acronym of its long form
  return /^[A-Z0-9&/.*^@#;:<>?!_+-]{2,}$/.test(e) && /[A-Z]/.test(e); // written in capitals: BRB, TBH, A/S/L
}

export function termKind(t: KindInput): TermKind {
  const e = t.expression.trim();
  if (t.category === 'Emoji' || !/[\p{L}\p{N}]/u.test(e)) return 'Emoji';
  if (/^\d+$/.test(e)) return 'Numeric Code';
  if (looksLikeCode(e, t.full)) return 'Code';
  if (CODE_CATEGORIES.has(t.category)) return 'Code';
  if (SLANG_CATEGORIES.has(t.category)) return 'Slang';
  return 'Term';
}

/** One line under the type badge, so people know why it is a code or a slang. */
export const termKindHelp: Record<TermKind, string> = {
  Code: 'A code: letters, numbers or symbols used as shorthand for words.',
  'Numeric Code': 'A numeric code: numbers that stand for a word or message.',
  Slang: 'Slang: an informal word or phrase used in casual talk.',
  Emoji: 'An emoji or symbol: its meaning depends on the chat.',
  Term: 'A term: a word or phrase from a field such as work, study or the internet.',
};

/** Badge colours (light background + strong text) per type. */
// One colour per family everywhere: every kind of code (Code, Numeric Code, Community "Code Word") is purple,
// slang is green, emoji amber and terms blue.
export const termKindColors: Record<TermKind, {bg: string; fg: string}> = {
  Code: {bg: '#EFE7FF', fg: '#6D28D9'},
  'Numeric Code': {bg: '#EFE7FF', fg: '#6D28D9'},
  Slang: {bg: '#DCFCE7', fg: '#15803D'},
  Emoji: {bg: '#FFF4D6', fg: '#A16207'},
  Term: {bg: '#E0F2FE', fg: '#0369A1'},
};

/** The Community post category that matches an entry's type. */
export type PostCategory = 'Code Word' | 'Slang' | 'General Term';
export function postCategoryFor(t: KindInput): PostCategory {
  const kind = termKind(t);
  return kind === 'Code' || kind === 'Numeric Code' ? 'Code Word' : kind === 'Slang' ? 'Slang' : 'General Term';
}

/**
 * Community post colours. Code Word keeps the original purple word chip with the red tag (unchanged);
 * Slang uses a green word chip with the red tag; General Term uses its own blue chip.
 */
export const postCategoryLook: Record<PostCategory, {chip: [string, string]; tagFg: string; tagBg: string}> = {
  'Code Word': {chip: ['#8B3FE0', '#4B3BDB'], tagFg: '#E11D61', tagBg: '#FFE4EE'},
  Slang: {chip: ['#16A34A', '#047857'], tagFg: '#E11D61', tagBg: '#FFE4EE'},
  'General Term': {chip: ['#2563EB', '#0891B2'], tagFg: '#C2410C', tagBg: '#FFEDD5'},
};
export function postLook(category?: string) {
  return postCategoryLook[(category as PostCategory)] ?? postCategoryLook['Code Word'];
}

/**
 * Build 88: light, category-wise card colours for the profile grid — a light fill, a slightly
 * deeper border, a dark title colour of the same hue (high contrast) and an accent for the label.
 */
export type CardTint = {bg: string; border: string; title: string; accent: string};
const CODE_TINT: CardTint = {bg: '#EFE7FF', border: '#D6C4FF', title: '#3B0F84', accent: '#6D28D9'};
const SLANG_TINT: CardTint = {bg: '#DDFBE7', border: '#AEEBC4', title: '#0F4A27', accent: '#15803D'};
const EMOJI_TINT: CardTint = {bg: '#FFF4D4', border: '#F7DE9A', title: '#5E3409', accent: '#A16207'};
const TERM_TINT: CardTint = {bg: '#E0F2FE', border: '#B4DFFA', title: '#0B3F5E', accent: '#0369A1'};
/** Same family, same colour: all codes share one tint, all slangs another, and so on. */
export const cardTints: Record<TermKind | PostCategory, CardTint> = {
  Code: CODE_TINT, 'Code Word': CODE_TINT, 'Numeric Code': CODE_TINT,
  Slang: SLANG_TINT,
  Emoji: EMOJI_TINT,
  Term: TERM_TINT, 'General Term': TERM_TINT,
};
export const cardTint = (category?: string): CardTint => cardTints[category as TermKind | PostCategory] ?? cardTints['Code Word'];
