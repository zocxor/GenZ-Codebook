import React,{useEffect,useState} from 'react';
import {AppState,Linking,NativeModules,PermissionsAndroid,Platform,Pressable,Text,View} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Button,C,Chip,Glass,Icon} from './ui';
import {messaging} from './messaging';
import {accountAuth} from './firebase/app';

const alerts=NativeModules.InboxAlerts as {
 account:(uid:string)=>void; read:(uid:string)=>Promise<string>; save:(uid:string,value:string)=>void;
 token:()=>Promise<string>; preview:(tone:string,vibration:string)=>void;
}|undefined;
const defaults={enabled:false,personal:'prism',group:'tidal',vibration:'short'};
type Options=typeof defaults;
const load=async(uid:string):Promise<Options>=>({...defaults,...JSON.parse(await alerts!.read(uid))});
async function register(uid:string,enabled:boolean){
 const token=await alerts!.token();
 if(accountAuth.currentUser?.uid!==uid)throw new Error('Account changed');
 await messaging('alert-device',{token,enabled});
}
export function useMessageAlertAccount(uid:string|undefined,restoring:boolean){
 useEffect(()=>{
  if(!alerts||restoring)return;
  alerts.account(uid||'');
  if(!uid)return;
  let live=true;
  const refresh=async()=>{if((await load(uid)).enabled&&live)await register(uid,true);};
  void refresh().catch(()=>{});
  const sub=AppState.addEventListener('change',state=>{if(state==='active')void refresh().catch(()=>{});});
  return ()=>{live=false;sub.remove();};
 },[uid,restoring]);
}
/** Turn alerts on: Android 13+ notification permission, FCM registration, then save. Shared by Settings and the Inbox prompt. */
async function enableAlerts(uid:string,options:Options):Promise<string>{
 if(Number(Platform.Version)>=33&&(await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS))!=='granted')
  return 'Allow notifications in Android settings to receive message alerts.';
 await register(uid,true);
 alerts!.save(uid,JSON.stringify({...options,enabled:true}));
 return '';
}
const promptKey=(uid:string)=>'genz.inboxAlerts.prompt.'+uid;
/**
 * Build 88: message alerts are opt-in (Android needs the user's permission), so many people never
 * found the switch in Inbox → Settings and got no notification. The Inbox now asks once, with one
 * tap to turn them on (notification in the status bar and at the top of the screen, with the
 * chosen tone). "Not now" hides the card on this phone; Settings keeps the full controls.
 */
export function MessageAlertPrompt({uid}:{uid:string}){
 const [state,setState]=useState<'hidden'|'ask'|'busy'>('hidden'),[error,setError]=useState('');
 useEffect(()=>{
  if(!alerts)return;
  let live=true;
  void Promise.all([load(uid),AsyncStorage.getItem(promptKey(uid))]).then(([options,dismissed])=>{if(live&&!options.enabled&&!dismissed)setState('ask');}).catch(()=>{});
  return ()=>{live=false;};
 },[uid]);
 if(!alerts||state==='hidden')return null;
 const dismiss=()=>{setState('hidden');void AsyncStorage.setItem(promptKey(uid),String(Date.now())).catch(()=>{});};
 const turnOn=async()=>{
  setState('busy');setError('');
  try{const problem=await enableAlerts(uid,await load(uid));if(problem){setError(problem);setState('ask');}else{setState('hidden');alerts.preview('prism','short');}}
  catch{setError('Could not turn on alerts. Check your connection and try again.');setState('ask');}
 };
 return <View style={{flexDirection:'row',gap:10,alignItems:'center',padding:12,borderRadius:16,backgroundColor:'#EEF2FF',borderWidth:1,borderColor:'#C7D2FE'}}>
  <View style={{width:36,height:36,borderRadius:12,backgroundColor:'#4F46E5',alignItems:'center',justifyContent:'center'}}><Icon name="notifications" size={19} color="#fff"/></View>
  <View style={{flex:1,gap:2}}>
   <Text style={{fontSize:14,fontWeight:'800',color:C.ink}}>Get message notifications</Text>
   <Text style={{fontSize:12,lineHeight:17,color:C.muted}}>{error||'See new messages in your phone’s notification bar, with a sound — even when the app is closed.'}</Text>
   <View style={{flexDirection:'row',gap:14,marginTop:4}}>
    <Pressable accessibilityRole="button" disabled={state==='busy'} onPress={()=>void turnOn()} hitSlop={6}><Text style={{fontSize:13.5,fontWeight:'900',color:'#4F46E5'}}>{state==='busy'?'Turning on…':'Turn on'}</Text></Pressable>
    <Pressable accessibilityRole="button" onPress={dismiss} hitSlop={6}><Text style={{fontSize:13.5,fontWeight:'700',color:C.muted}}>Not now</Text></Pressable>
   </View>
  </View>
 </View>;
}
export function MessageAlertSettings({uid}:{uid:string}){
 const [expanded,setExpanded]=useState(false);
 const [options,setOptions]=useState<Options|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 useEffect(()=>{let live=true;if(alerts)void load(uid).then(v=>{if(live)setOptions(v);},()=>{if(live)setError('Could not load alert preferences.');});return()=>{live=false;};},[uid]);
 if(!alerts)return null;
 const save=(value:Options)=>{alerts.save(uid,JSON.stringify(value));setOptions(value);};
 const toggle=async()=>{
  if(!options||busy)return;
  setBusy(true);setError('');
  try{
   const enabled=!options.enabled;
   if(enabled){const problem=await enableAlerts(uid,options);if(problem){setError(problem);return;}setOptions({...options,enabled});return;}
   save({...options,enabled});
   await register(uid,enabled);
  }catch{setError('Could not sync alert registration. Check your connection and try again.');}
  finally{setBusy(false);}
 };
 return <Glass><Text accessibilityRole="header" style={{fontSize:18,fontWeight:'700',color:C.ink}}>Message alerts</Text>
  {options&&<>
   <Button light title={busy?'Saving…':options.enabled?'Turn off message alerts':'Turn on message alerts'} disabled={busy} onPress={()=>void toggle()}/>
   <Chip label={expanded?'Hide sound and vibration':'Sound and vibration'} selected={expanded} onPress={()=>setExpanded(!expanded)}/>
   {expanded&&<>{(['personal','group'] as const).map(kind=><View key={kind} style={{gap:6}}>
    <Text style={{color:C.ink}}>{kind==='group'?'Group':'Personal'} message tone</Text>
    <View style={{flexDirection:'row',flexWrap:'wrap',gap:6}}>{['prism','tidal','pebble','silent'].map(tone=><Chip key={tone} label={tone[0]!.toUpperCase()+tone.slice(1)} selected={options[kind]===tone} onPress={()=>{if(busy)return;save({...options,[kind]:tone});alerts.preview(tone,'off');}}/>)}</View>
   </View>)}
   <Text style={{color:C.ink}}>Vibration</Text>
   <View style={{flexDirection:'row',flexWrap:'wrap',gap:6}}>{['off','short','double'].map(v=><Chip key={v} label={v==='double'?'Double pulse':v==='short'?'Short':'Off'} selected={options.vibration===v} onPress={()=>{if(busy)return;save({...options,vibration:v});alerts.preview('silent',v);}}/>)}</View>
   </>}
   <Button light title="Open Android app settings" onPress={()=>void Linking.openSettings().catch(()=>setError('Could not open Android settings.'))}/>
  </>}
  {!!error&&<Text accessibilityLiveRegion="polite" style={{color:C.ink}}>{error}</Text>}
 </Glass>;
}
