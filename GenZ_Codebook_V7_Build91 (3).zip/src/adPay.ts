/**
 * Build 91: helpers for paying for a code or post with one rewarded ad instead of Credits.
 * Google confirms the ad to our server a few seconds after it closes (admobReward), so the
 * create call may first answer "still confirming" — it is retried with the same request ID,
 * which the server treats as one request. No React Native imports: unit-tested in Node.
 */
export type PayWith = 'credits' | 'ad';

export const AD_PENDING_MESSAGE = 'Google hasn’t confirmed your ad yet. Tap the button again in a minute — you won’t need to watch another ad.';

/** The server's "Google is still confirming your ad" answer (HttpsError details.pending). */
export function isAdPending(error: unknown): boolean {
  const e = error as {details?: {pending?: unknown}; message?: unknown} | null;
  return e?.details?.pending === true || /still confirming your ad/i.test(String(e?.message ?? ''));
}
/** The watched ad can't be used again (already used, expired or for another item): the next try needs a new ad. */
export function adIntentSpent(error: unknown): boolean {
  return /already used|has expired|can.t pay for this item/i.test(String((error as {message?: unknown} | null)?.message ?? ''));
}

/** Run `call`, retrying only while Google's confirmation is pending (default 8 tries, 2.5 s apart). */
export async function retryWhileAdPending<T>(call: () => Promise<T>, tries = 8, waitMs = 2500, wait = (ms: number) => new Promise<void>(r => setTimeout(r, ms))): Promise<T> {
  for (let attempt = 1; ; attempt++) {
    try {return await call();}
    catch (e) {
      if (attempt >= tries || !isAdPending(e)) throw e;
      await wait(waitMs);
    }
  }
}
