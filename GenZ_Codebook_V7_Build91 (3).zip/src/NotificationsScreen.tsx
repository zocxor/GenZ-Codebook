/**
 * Notifications: a feed of real recent activity, newest first.
 *
 * Everything here is something the app genuinely records — token ledger
 * entries (purchases, subscription grants, admin grants, migration), accepted
 * word submissions (a moderator's reviewedAt stamp), the daily reward, best
 * quiz scores and day-streak milestones. Nothing is simulated: if there is
 * no recorded event, the feed is empty and says so. Ledger and submission
 * entries need a signed-in account; the local events (daily reward, best
 * scores, streaks) show even when signed out.
 *
 * Visuals only: navy type, one card per entry with a colour-coded icon tile
 * (gold for tokens, blue→purple for learning, purple→navy for community),
 * restyled filter chips. No unread badge — read state is not tracked.
 */
import {useMessageNotices} from './messaging';
import {fetchAnnouncements,type Announcement} from './announcements';
import React, {useEffect, useMemo, useState} from 'react';
import {View, Text, ScrollView, StyleSheet, ActivityIndicator, Pressable} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {C, Button, Chip, FadeIn, Icon, IconTile, SectionHeader, confirmAction} from './ui';
import {ms} from './communityFeatures';
import {useAccountUser} from './services';
import {fetchTokenTxns, currentUid, type TokenTxnRow} from './tokenLedger';
import {buildNotifications, fmtWhen, type AcceptedWord, type NotificationKind, type NotificationItem} from './notifications';
import type {LearningState} from './profile';
import {stages} from './games';

/**
 * Build 88: "Clear history" hides everything up to now on this phone, per account. Nothing is
 * deleted — Credit records, announcements and messages stay on the server — and anything newer
 * appears as usual.
 */
const CLEARED_KEY = (uid?: string) => 'genz.notifications.clearedAt.' + (uid || 'guest');
export const shownAfterClear = (at: number, clearedAt: number) => !clearedAt || at > clearedAt;

const stageName = (id: string) => stages.find(s => s.id === id)?.name ?? (id === 'review' ? 'Daily review' : id.startsWith('daily-') ? 'Daily five' : id.startsWith('shuffle-') ? 'Shuffle: ' + id.slice(8, 9).toUpperCase() + id.slice(9) : id);

const KIND_LABEL: Record<NotificationKind, string> = {tokens: 'Credits', learning: 'Learning', community: 'Community'};
const KIND_ICON: Record<NotificationKind, 'wallet-outline' | 'school-outline' | 'people-outline'> = {tokens: 'wallet-outline', learning: 'school-outline', community: 'people-outline'};
/** Gold is reserved for tokens/rewards; learning is blue→purple, community purple→navy. */
const KIND_TILE: Record<NotificationKind, {from: string; to: string}> = {
  tokens: {from: C.gold, to: C.goldDeep},
  learning: {from: C.accent, to: C.purple},
  community: {from: C.purple, to: C.navy},
};

/** The user's accepted word submissions, with the moderator's reviewedAt stamp. */
async function fetchAcceptedWords(uid: string): Promise<AcceptedWord[]> {
  try {
    const [{collection, query, where, getDocs, limit}, {cloudDb: dbFn}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
    // Single-field query (uid only) so no composite index is needed; the
    // accepted-only filter runs here, on the user's own small submission list.
    const snap = await getDocs(query(collection(dbFn(), 'submissions'), where('uid', '==', uid), limit(50)));
    const out: AcceptedWord[] = [];
    for (const d of snap.docs) {
      const data = d.data();
      if (data.status !== 'accepted' || typeof data.term !== 'string') continue;
      const at = typeof data.reviewedAt?.toMillis === 'function' ? data.reviewedAt.toMillis()
        : typeof data.createdAt?.toMillis === 'function' ? data.createdAt.toMillis() : 0;
      if (at > 0) out.push({id: d.id, term: data.term, reviewedAt: at});
    }
    return out;
  } catch {return [];}
}

/** newSince: the announcement "seen" time captured when the bell was tapped — newer items get a NEW tag. */
export default function NotificationsScreen({state, onClose, newSince}: {state: LearningState; onClose: () => void; newSince?: number}) {
  const user = useAccountUser();
  const messages=useMessageNotices(user?.emailVerified?user.uid:undefined);
  const [adminNotices, setAdminNotices] = useState<Announcement[]>([]);
  const [txns, setTxns] = useState<TokenTxnRow[]>([]);
  const [accepted, setAccepted] = useState<AcceptedWord[]>([]);
  const [loading, setLoading] = useState(!!user);
  const [filter, setFilter] = useState<'all' | NotificationKind>('all');
  const [clearedAt, setClearedAt] = useState(0);
  useEffect(() => {
    let live = true;
    void AsyncStorage.getItem(CLEARED_KEY(user?.uid)).then(v => {if (live) setClearedAt(Number(v) || 0);}).catch(() => {});
    return () => {live = false;};
  }, [user?.uid]);
  const clearHistory = () => confirmAction('Clear notification history?', 'Everything listed now is removed from this page on this phone. Your Credits, messages and announcements are not deleted, and new activity still appears here.', () => {
    const at = Date.now();
    setClearedAt(at);
    void AsyncStorage.setItem(CLEARED_KEY(user?.uid), String(at)).catch(() => {});
  }, 'Clear history');

  useEffect(() => {
    if (!user?.emailVerified) return;
    let active = true;
    void fetchAnnouncements(user.uid).then(rows => {if (active) setAdminNotices(rows);});
    return () => {active = false;};
  }, [user?.uid, user?.emailVerified]);

  useEffect(() => {
    const uid = currentUid();
    if (!uid) {setLoading(false); return;}
    let live = true;
    void Promise.all([fetchTokenTxns(uid, 25), fetchAcceptedWords(uid)]).then(([t, a]) => {
      if (!live) return;
      setTxns(t); setAccepted(a); setLoading(false);
    });
    return () => {live = false;};
  }, []);

  const items = useMemo(() => buildNotifications({
    txns, accepted,
    lastDailyCollect: state.tokens.lastDailyCollect,
    best: state.best,
    days: state.days,
    stageName,
  }).filter(i => shownAfterClear(i.at, clearedAt)), [txns, accepted, state.tokens.lastDailyCollect, state.best, state.days, clearedAt]);
  const notices = adminNotices.filter(n => shownAfterClear(n.at, clearedAt));
  const inbox = messages.filter(m => shownAfterClear(ms(m.createdAt), clearedAt));
  const anything = items.length + notices.length + inbox.length > 0;

  const kinds = useMemo(() => (['tokens', 'learning', 'community'] as NotificationKind[]).filter(k => items.some(i => i.kind === k)), [items]);
  const shown = filter === 'all' ? items : items.filter(i => i.kind === filter);
  const now = Date.now();

  return (
    <ScrollView contentContainerStyle={s.content}>
      <SectionHeader
        eyebrow="ACTIVITY FEED"
        title="Recent activity"
        action={!loading && items.length > 0 ? <Text style={s.count}>{items.length} {items.length === 1 ? 'event' : 'events'}</Text> : undefined}
      />
      {!loading && anything && <Pressable accessibilityRole="button" accessibilityLabel="Clear notification history" onPress={clearHistory} style={({pressed}) => [s.clear, pressed && {opacity: .8}]}>
        <Icon name="trash-outline" size={16} color={C.danger} /><Text style={s.clearText}>Clear history</Text>
      </Pressable>}
      {!!clearedAt && <Text style={s.fine}>History cleared {fmtWhen(clearedAt, Date.now())}. Only newer activity is shown.</Text>}
      {notices.length > 0 && <View style={{gap:8}} accessibilityLabel="Announcements from GenZ Codebook administrators">
        <Text style={s.rowTitle}>Announcements</Text>
        {notices.map(item => <View key={item.id} style={s.rowCard}>
          <IconTile icon="megaphone-outline" from={C.accent} to={C.purple} size={36} iconSize={18}/>
          <View style={{flex:1,gap:3}}><View style={s.titleRow}><Text style={[s.rowTitle,{flexShrink:1}]}>{item.title}</Text>{newSince!==undefined&&item.at>newSince&&<Text accessibilityLabel="New" style={s.newTag}>NEW</Text>}{item.personal&&<Text accessibilityLabel="Sent to you" style={s.youTag}>FOR YOU</Text>}</View><Text selectable style={s.body}>{item.body}</Text><Text style={s.fine}>{item.at ? fmtWhen(item.at, Date.now()) : 'From the team'}</Text></View>
        </View>)}
      </View>}
      {inbox.length>0&&<View style={{gap:8}}><Text style={s.rowTitle}>Messaging</Text>{inbox.map(item=><View key={item.id} style={s.rowCard}><IconTile icon={item.type==='request'?'person-add-outline':'mail-unread-outline'} from={C.accent} to={C.purple} size={36} iconSize={18}/><View style={{flex:1}}><Text style={s.rowTitle}>{item.title}</Text><Text style={s.body}>{item.body}</Text><Text style={s.fine}>{item.type==='request'?(item.title==='Message request accepted'?'Inbox → Personal':'Inbox → Requests'):item.type==='message'?'Inbox → Conversations':'Inbox → Groups'}</Text></View></View>)}</View>}
      {kinds.length > 1 && (
        <View style={s.wrap} accessible accessibilityLabel="Filter notifications">
          <Chip label="All" icon="list-outline" selected={filter === 'all'} onPress={() => setFilter('all')} />
          {kinds.map(k => <Chip key={k} label={KIND_LABEL[k]} icon={KIND_ICON[k]} selected={filter === k} onPress={() => setFilter(k)} />)}
        </View>
      )}
      {loading ? (
        <View style={[s.card, s.center]}>
          <ActivityIndicator color={C.accent} />
          <Text style={s.body}>Loading your activity…</Text>
        </View>
      ) : shown.length === 0 ? (
        <FadeIn>
          <View style={[s.card, s.center]}>
            <IconTile icon="notifications-outline" from={C.accent} to={C.purple} size={36} iconSize={18} />
            <Text style={s.emptyTitle}>{clearedAt ? 'All clear.' : 'Nothing yet.'}</Text>
            <Text style={[s.body, s.centerText]}>{user ? 'Your activity will show up here as it happens.' : 'Sign in to also see purchases and accepted words.'}</Text>
          </View>
        </FadeIn>
      ) : (
        shown.map((item, i) => (
          <FadeIn key={item.id} delay={Math.min(i, 8) * 40}>
            <NotificationRow item={item} now={now} />
          </FadeIn>
        ))
      )}
      {!user && items.length > 0 && <Text style={s.fine}>Showing activity from this device only.</Text>}
      <Button title="Done" onPress={onClose} />
    </ScrollView>
  );
}

function NotificationRow({item, now}: {item: NotificationItem; now: number}) {
  const tile = KIND_TILE[item.kind];
  return (
    <View style={s.rowCard}>
      <IconTile icon={item.icon} from={tile.from} to={tile.to} size={36} iconSize={18} />
      <View style={{flex: 1, gap: 2}}>
        <Text style={s.rowTitle}>{item.title}</Text>
        <Text style={s.caption}>{item.subtitle}</Text>
      </View>
      <Text style={s.when}>{fmtWhen(item.at, now)}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  content: {gap: 12, paddingBottom: 8},
  body: {fontSize: 14, lineHeight: 20, color: C.muted},
  count: {fontSize: 12, fontWeight: '800', color: C.accent, backgroundColor: C.soft, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6, overflow: 'hidden'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  rowTitle: {fontSize: 15, fontWeight: '800', color: C.navy},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 14, gap: 10, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3},
  center: {alignItems: 'center'},
  centerText: {textAlign: 'center'},
  emptyTitle: {fontSize: 18, fontWeight: '800', color: C.navy, letterSpacing: -0.3},
  rowCard: {flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 16, padding: 12, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3},
  titleRow: {flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap'},
  youTag: {fontSize: 10, fontWeight: '900', letterSpacing: 1, color: C.accent, backgroundColor: C.soft, borderRadius: 999, paddingHorizontal: 7, paddingVertical: 2, overflow: 'hidden'},
  newTag: {fontSize: 10, fontWeight: '900', letterSpacing: 1, color: '#fff', backgroundColor: C.danger, borderRadius: 999, paddingHorizontal: 7, paddingVertical: 2, overflow: 'hidden'},
  when: {fontSize: 11, color: C.muted, fontWeight: '700', textAlign: 'right'},
  clear: {flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-end', gap: 6, minHeight: 40, paddingHorizontal: 12, borderRadius: 999, backgroundColor: '#FFF1F0', borderWidth: 1, borderColor: '#FECDC2'},
  clearText: {fontSize: 13, fontWeight: '800', color: C.danger},
});
