/**
 * Build 90: bonus offer after a cleared quiz round (AdMob rewarded interstitial).
 *
 * A moment after the score appears, an intro card covers the results: "Bonus +10 Credits",
 * a 5-second countdown, "Watch now" and "No thanks". AdMob requires this intro (with a clear
 * way to say no) before a rewarded interstitial. If nobody taps, the ad starts when the
 * countdown ends. Skipping, closing the ad early or leaving the app costs nothing.
 *
 * Shown only when an ad is already loaded (no dead screens), never with Premium, at most once
 * per round and once every 3 minutes (rules in src/ads.tsx). Signed-in accounts are paid by
 * the server after Google's verified callback (admobReward); guests get learning points.
 */
import React, {useEffect, useRef, useState} from 'react';
import {AppState, StyleSheet, Text, View} from 'react-native';
import {Button, C, Icon} from './ui';
import {TOKENS} from '../shared/tokens';
import {bonusAdOfferable, bonusAdPaysCredits, noteBonusOffered, showBonusAd, useBonusAdReady} from './ads';

export const BONUS_COUNTDOWN = 5;
/** Lets the player see their score before the intro appears. */
const INTRO_DELAY_MS = 1200;

type Phase = 'wait' | 'intro' | 'showing' | 'over';

export default function BonusAdOffer({round, eligible, onOffered, onResult, onGuestReward}: {
  /** The quiz attempt ID: one offer per round. */
  round: string;
  /** Round finished with at least 3 correct answers. */
  eligible: boolean;
  onOffered: () => void;
  onResult: (note: string) => void;
  onGuestReward: () => void;
}) {
  const ready = useBonusAdReady();
  const [phase, setPhase] = useState<Phase>('wait');
  const [left, setLeft] = useState(BONUS_COUNTDOWN);
  const [credits, setCredits] = useState(false);
  const busy = useRef(false), live = useRef(true);
  useEffect(() => () => {live.current = false;}, []);
  useEffect(() => {setPhase('wait'); setLeft(BONUS_COUNTDOWN); busy.current = false;}, [round]);

  // Open the intro shortly after the results appear, only if an ad is really loaded.
  useEffect(() => {
    if (phase !== 'wait' || !eligible || !ready) return;
    const t = setTimeout(() => {
      if (!bonusAdOfferable()) return;
      setCredits(bonusAdPaysCredits());
      noteBonusOffered();
      setLeft(BONUS_COUNTDOWN);
      setPhase('intro');
      onOffered();
    }, INTRO_DELAY_MS);
    return () => clearTimeout(t);
  }, [phase, eligible, ready, round]);

  const watch = async () => {
    if (busy.current) return;
    busy.current = true;
    setPhase('showing');
    const r = await showBonusAd();
    if (!live.current) return;
    setPhase('over');
    if (!r.earned) return;
    if (!r.credits) onGuestReward();
    onResult(r.credits
      ? `+${TOKENS.REWARDED_AD} Credits will be added after Google confirms the ad.`
      : `+${TOKENS.REWARDED_AD} learning points added. Sign in to earn Credits.`);
  };

  // Countdown; at 0 the ad starts.
  useEffect(() => {
    if (phase !== 'intro') return;
    if (left <= 0) {void watch(); return;}
    const t = setTimeout(() => setLeft(v => v - 1), 1000);
    return () => clearTimeout(t);
  }, [phase, left]);

  // Leaving the app during the intro counts as "No thanks": an ad never starts in the background.
  useEffect(() => {
    if (phase !== 'intro') return;
    const sub = AppState.addEventListener('change', s => {if (s !== 'active') setPhase('over');});
    return () => sub.remove();
  }, [phase]);

  if (phase !== 'intro') return null;
  const reward = `+${TOKENS.REWARDED_AD} ${credits ? 'Credits' : 'learning points'}`;
  const progress = Math.round((BONUS_COUNTDOWN - left) / BONUS_COUNTDOWN * 100);
  return <View style={StyleSheet.absoluteFill} accessibilityViewIsModal>
    <View style={s.dim}>
      <View style={s.card}>
        <View style={s.star}><Icon name="star" size={26} color={C.goldDeep} /></View>
        <Text accessibilityRole="header" style={s.title}>Bonus {reward}</Text>
        <Text style={s.body}>Watch a short ad to earn them. You can skip.</Text>
        <Text accessibilityLabel={`Ad starts in ${left} seconds`} style={s.count}>Ad starts in {left}s</Text>
        <View style={s.track}><View style={[s.fill, {width: `${progress}%`}]} /></View>
        <Button title="Watch now" icon="play-circle-outline" onPress={() => void watch()} />
        <Button light title="No thanks" onPress={() => setPhase('over')} />
      </View>
    </View>
  </View>;
}

const s = StyleSheet.create({
  dim: {flex: 1, backgroundColor: 'rgba(13,23,54,.55)', alignItems: 'center', justifyContent: 'center', padding: 24},
  card: {width: '100%', maxWidth: 360, backgroundColor: '#fff', borderRadius: 24, padding: 20, gap: 10, alignItems: 'stretch'},
  star: {width: 52, height: 52, borderRadius: 26, backgroundColor: '#FFF4D6', alignItems: 'center', justifyContent: 'center', alignSelf: 'center'},
  title: {fontSize: 20, fontWeight: '900', color: C.navy, textAlign: 'center'},
  body: {fontSize: 14, lineHeight: 21, color: C.muted, textAlign: 'center'},
  count: {fontSize: 14, fontWeight: '800', color: C.accent, textAlign: 'center'},
  track: {height: 5, borderRadius: 3, backgroundColor: '#E3EAF8', overflow: 'hidden', marginBottom: 4},
  fill: {height: 5, borderRadius: 3, backgroundColor: C.accent},
});
