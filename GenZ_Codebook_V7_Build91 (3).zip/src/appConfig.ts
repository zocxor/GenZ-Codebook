/**
 * Owner-controlled public app settings (Firestore config/app), shared by every screen
 * through ONE realtime listener that starts when the first screen needs it.
 * - paidCommunity: when true, the chat day pass is charged in Credits. Build 91: new codes and posts
 *   have their own switches (paidCodes, paidPosts), which follow paidCommunity until the admin saves them.
 *   Firestore rules enforce all three.
 * - adPayEnabled (Build 91): users may pay for a code or post with one rewarded ad instead of Credits.
 * - prices: Credit price of every paid action (admin Settings → Prices). Missing values use
 *   the defaults in functions/src/communityPolicy.json.
 * - encodeFreeDaily / decodeFreeDaily: free conversions per user per day (default 10 each).
 */
import {useSyncExternalStore} from 'react';
import {publishingMode,type PublishingMode} from '../shared/publishing';
import rawPolicy from '../functions/src/communityPolicy.json';

export type Fees = {chat: number; post: number; code: number; daily: number; verification: number; encode: number; decode: number};
export type AppConfig = {loaded: boolean; error: boolean; raw: Record<string, unknown>; paidCommunity: boolean; paidCodes: boolean; paidPosts: boolean; adPayEnabled: boolean; encodeFreeDaily: number; decodeFreeDaily: number; fees: Fees};
const intIn = (v: unknown, min: number, max: number, fallback: number) => Number.isInteger(v) && (v as number) >= min && (v as number) <= max ? v as number : fallback;
export const DEFAULT_CONVERT_FEE = 5;
export function parseFees(prices: unknown): Fees {
  const p = (prices && typeof prices === 'object' ? prices : {}) as Record<string, unknown>;
  return {
    chat: intIn(p.chatDay, 1, 100000, rawPolicy.chatDailyFee), post: intIn(p.post, 1, 100000, rawPolicy.postFee),
    code: intIn(p.code, 1, 100000, rawPolicy.dictionaryFee), daily: intIn(p.dailyCode, 1, 100000, rawPolicy.dailyFee),
    verification: intIn(p.verification, 1, 100000, rawPolicy.verificationFee),
    encode: intIn(p.encode, 0, 1000, DEFAULT_CONVERT_FEE), decode: intIn(p.decode, 0, 1000, DEFAULT_CONVERT_FEE),
  };
}
export function parseAppConfig(raw: Record<string, unknown>, loaded = true, error = false): AppConfig {
  const legacy = raw.paidCommunity === true;
  return {loaded, error, raw, paidCommunity: legacy, paidCodes: typeof raw.paidCodes === 'boolean' ? raw.paidCodes : legacy,
    paidPosts: typeof raw.paidPosts === 'boolean' ? raw.paidPosts : legacy, adPayEnabled: raw.adPayEnabled === true, encodeFreeDaily: intIn(raw.encodeFreeDaily, 0, 1000, 10), decodeFreeDaily: intIn(raw.decodeFreeDaily, 0, 1000, 10), fees: parseFees(raw.prices)};
}
let current: AppConfig = parseAppConfig({}, false);
const listeners = new Set<() => void>();
let stop: (() => void) | null = null;
function start() {
  if (stop) return;
  stop = () => {};
  void Promise.all([import('firebase/firestore'), import('./firebase/app')]).then(([{doc, onSnapshot}, {cloudDbLive}]) => {
    stop = onSnapshot(doc(cloudDbLive(), 'config/app'), snap => {
      current = parseAppConfig(snap.data() ?? {});
      listeners.forEach(f => f());
    }, () => {current = {...current, loaded: false, error: true}; listeners.forEach(f => f());});
  }).catch(() => {current = {...current, error: true}; stop = null; listeners.forEach(f => f());});
}
function subscribe(fn: () => void) {listeners.add(fn); start(); return () => {listeners.delete(fn);};}
export const getAppConfig = () => current;
/** Listen for config changes outside React. Returns the unsubscribe function. */
export const subscribeAppConfig = (fn: () => void) => subscribe(fn);
export const useAppConfig = () => useSyncExternalStore(subscribe, getAppConfig);
export function usePublishingModeFromConfig(kind: 'code' | 'post'): {mode: PublishingMode | null; error: string} {
  const c = useAppConfig();
  return {mode: c.loaded ? publishingMode(c.raw, kind) : null, error: c.error ? 'Publishing settings could not be loaded. Please reconnect.' : ''};
}
