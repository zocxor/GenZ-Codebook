import {getFunctions, connectFunctionsEmulator, httpsCallable} from 'firebase/functions';
import {collection, doc, documentId, endAt, getDoc, getDocs, limit, onSnapshot, orderBy, query, startAt, where} from 'firebase/firestore';
import {firebaseApp, cloudDbLive, accountAuth} from './firebase/app';
import {EMULATOR_HOST} from './secure/config';
import {policy} from './fees';
import {communityError} from '../shared/communityErrors';
import {SPARK_MODE} from '../shared/deployment';
import {BACKEND_URL} from './backend';
import {getAppConfig} from './appConfig';
export {policy};

const functions = getFunctions(firebaseApp, BACKEND_URL||'us-central1');
if (EMULATOR_HOST) connectFunctionsEmulator(functions, EMULATOR_HOST, 5001);
const invoke = httpsCallable<Record<string, unknown>, {id?: string;balance?: number;duplicate?: boolean;liked?: boolean;active?:boolean;live?:boolean;termId?:string;status?:string;free?:boolean;freeCode?:boolean;freeDaily?:boolean;paidWith?:'credits'|'ad'|'free';adPayCodeLeft?:number;adPayPostLeft?:number;purpose?:string}>(functions, 'communityFeature',{timeout:30000});

export async function feature(action: string, data: Record<string, unknown> = {}) {
  // Free actions (likes, saves, comments, removing your own post) always use the fast direct path.
  // Creating codes and posts is charged by the server while the owner's switch for each is on (Build 91: separate switches).
  const config=getAppConfig();
  const free=['like-post','save-post','comment-post','delete-post'].includes(action)||(action==='create-code'&&!config.paidCodes)||(action==='create-post'&&!config.paidPosts);
  if(SPARK_MODE&&free)return (await import('./sparkCommunity')).sparkFeature(action,data);
  if(!BACKEND_URL&&!EMULATOR_HOST)throw new Error('Credit services are not connected yet. Free creation, chat and posts remain available.');
  const user = accountAuth.currentUser;
  if (user && (await user.getIdTokenResult()).claims.email_verified !== true) await user.getIdToken(true);
  return (await invoke({action,...data})).data;
}
const finishPhoneAutoSignIn=httpsCallable<{action:string;idToken:string},{token:string}>(functions,'communityFeature');
export async function exchangePhoneVerification(idToken:string){
  return (await finishPhoneAutoSignIn({action:'phone-auto-signin',idToken})).data.token;
}
export const requestKey = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
export const errorOf = communityError;
export const utcDate = (time=Date.now()) => new Date(time).toISOString().slice(0,10);
export const datesAhead = (count=policy.bookingDays, now=Date.now()) => Array.from({length:count},(_,i)=>utcDate(now+(i+1)*86_400_000));
export const ms = (value: unknown) => typeof value === 'number' ? value : typeof (value as {toMillis?: unknown} | null)?.toMillis === 'function' ? (value as {toMillis:()=>number}).toMillis() : 0;
export type FeatureRow = {id:string;uid:string;term?:string;name?:string;meaning?:string;example?:string;category?:string;text?:string;status:string;createdAt?:unknown;updatedAt?:unknown;requestedDate?:string;publicationDate?:string;reservedDate?:string;payment?:string;reason?:string;fee?:number;likeCount?:number;commentCount?:number};
export async function myRows(name: string, uid: string): Promise<FeatureRow[]> {
  const snap = await getDocs(query(collection(cloudDbLive(),name),where('uid','==',uid),orderBy('createdAt','desc'),limit(100)));
  return snap.docs.map(d=>{
    const data=d.data();
    return {...data,id:d.id,status:data.status??(data.hidden?'removed':'pending')} as FeatureRow;
  });
}
export async function slots(from: string, to: string) {
  const snap = await getDocs(query(collection(cloudDbLive(),'dailyCodeDates'),orderBy(documentId()),startAt(from),endAt(to)));
  return Object.fromEntries(snap.docs.map(d=>[d.id,String(d.get('status'))]));
}
export type DailyEntry = {creatorUid?:string;term:string;meaning:string;category:string;date:string;loading?:boolean;/** The app's offline word of the day (no published Daily Code). */fallback?:boolean};
/** One quick REST read of a day's published Daily Code (usually faster than the first live snapshot). */
export async function fetchDailyOnce(date: string): Promise<DailyEntry|null> {
  const [{doc:ldoc,getDoc:lget},{cloudDb}]=await Promise.all([import('firebase/firestore/lite'),import('./firebase/app')]);
  const snap=await lget(ldoc(cloudDb(),'dailyCodePublic',date));
  if(!snap.exists())return null;
  const data=snap.data();
  if(SPARK_MODE&&data.schema===3&&['community','published'].includes(data.wordSource)&&typeof data.wordId==='string'){
    const w=(await lget(ldoc(cloudDb(),data.wordSource==='community'?'communityWords':'publishedContent',data.wordId))).data();
    return w&&['live','published'].includes(w.status)?{creatorUid:data.wordSource==='community'?w.uid:undefined,term:w.term,meaning:w.meaning,category:w.category,date}:null;
  }
  return typeof data.term==='string'?{creatorUid:data.creatorUid,term:data.term,meaning:String(data.meaning??''),category:String(data.category??''),date}:null;
}
export function watchDaily(date: string, onValue:(entry:DailyEntry|null)=>void) {
  let stopWord=()=>{};
  const stop=onSnapshot(doc(cloudDbLive(),'dailyCodePublic',date),s=>{
    stopWord();stopWord=()=>{};
    if(!s.exists()){onValue(null);return;}
    const data=s.data();
    if(SPARK_MODE&&data.schema===3&&['community','published'].includes(data.wordSource)&&typeof data.wordId==='string'){
      stopWord=onSnapshot(doc(cloudDbLive(),data.wordSource==='community'?'communityWords':'publishedContent',data.wordId),word=>{
        const w=word.data();
        onValue(w&&(['live','published'].includes(w.status))?{creatorUid:data.wordSource==='community'?w.uid:undefined,term:w.term,meaning:w.meaning,category:w.category,date}:null);
      },()=>onValue(null));
    }else onValue(data as DailyEntry);
  },()=>onValue(null));
  return ()=>{stop();stopWord();};
}
export type FeedFilter = 'Latest'|'Trending'|'Code Words'|'Slangs';
export function watchPosts(filter:FeedFilter, onValue:(rows:FeatureRow[])=>void, onError:()=>void) {
  const constraints = [where('hidden','==',false),where('status','==','approved')];
  if (filter === 'Code Words' || filter === 'Slangs') constraints.push(where('category','==',filter==='Code Words'?'Code Word':'Slang'));
  return onSnapshot(query(collection(cloudDbLive(),'communityPosts'),...constraints,orderBy(filter==='Trending'?'engagementScore':'publishedAt','desc'),limit(50)),
    s=>onValue(s.docs.map(d=>({...d.data(),id:d.id}) as FeatureRow)),onError);
}
export async function interactions(uid:string) {
  const [likes,saved] = await Promise.all([
    getDocs(query(collection(cloudDbLive(),'communityPostLikes'),where('uid','==',uid))),
    getDocs(collection(cloudDbLive(),'users',uid,'savedCommunityPosts')),
  ]);
  return {liked:new Set(likes.docs.map(d=>String(d.get('postId')))),saved:new Set(saved.docs.map(d=>d.id))};
}
export async function savedPosts(ids: Iterable<string>) {
  const found = await Promise.all([...ids].map(async id=>{
    try {
      const post = await getDoc(doc(cloudDbLive(),'communityPosts',id));
      return post.exists() && post.get('status')==='approved' && post.get('hidden')===false ? {...post.data(),id} as FeatureRow : null;
    } catch {return null;}
  }));
  return found.filter((row):row is FeatureRow=>row!==null);
}
export function watchComments(id:string,onValue:(rows:FeatureRow[])=>void,onError:()=>void) {
  return onSnapshot(query(collection(cloudDbLive(),'communityPosts',id,'comments'),orderBy('createdAt','desc'),limit(50)),
    s=>onValue(s.docs.map(d=>({...d.data(),id:d.id}) as FeatureRow)),onError);
}
