/**
 * Build 89: "Clear history" for the Wallet's transaction list.
 *
 * Clearing only hides what is listed now, on this phone, for this account. Nothing is deleted:
 * the Credit ledger (users/{uid}/tokenLedger) is what the server uses to calculate the balance,
 * so it must stay complete (project rules 1 and 10). Newer transactions appear as usual, and
 * "Show full history" brings the hidden ones back.
 */
/** Loaded on first use, so the pure helpers below can be unit-tested without React Native. */
const storage = async () => (await import('@react-native-async-storage/async-storage')).default;

export const walletClearedKey = (uid?: string) => 'genz.wallet.clearedAt.' + (uid || 'guest');

/** True when an entry made at `at` is still listed after a clear at `clearedAt` (0 = never cleared). */
export const listedAfterClear = (at: number, clearedAt: number) => !clearedAt || at > clearedAt;

export function visibleAfterClear<T extends {createdAt: number}>(rows: T[], clearedAt: number): T[] {
  return clearedAt ? rows.filter(r => listedAfterClear(r.createdAt, clearedAt)) : rows;
}

export async function loadWalletClearedAt(uid?: string): Promise<number> {
  try {
    const v = Number(await (await storage()).getItem(walletClearedKey(uid)));
    return Number.isFinite(v) && v > 0 ? v : 0;
  } catch {return 0;}
}

/** Stores the clear time; pass 0 to show the full history again. Never throws. */
export async function saveWalletClearedAt(uid: string | undefined, at: number): Promise<void> {
  try {
    const store = await storage();
    if (at > 0) await store.setItem(walletClearedKey(uid), String(at));
    else await store.removeItem(walletClearedKey(uid));
  } catch {/* device storage unavailable: the choice lasts until the app closes */}
}
