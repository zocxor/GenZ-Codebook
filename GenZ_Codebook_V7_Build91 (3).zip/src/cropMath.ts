/**
 * Math for the in-app square photo cropper (Build 88). Pure, so it is unit-tested.
 *
 * The picture is shown at `cover * zoom` scale inside a square viewport of `view` points.
 * (x, y) is where the picture's top-left corner sits relative to the viewport's top-left,
 * so both are ≤ 0 while the picture covers the whole square.
 */
export type CropState = {zoom: number; x: number; y: number};
export type CropRect = {originX: number; originY: number; width: number; height: number};
export const MIN_ZOOM = 1, MAX_ZOOM = 4;

/** Scale at which the picture just covers the square (zoom 1). */
export const coverScale = (width: number, height: number, view: number) => Math.max(view / Math.max(1, width), view / Math.max(1, height));

/** Keep the zoom in range and the picture covering the square (no empty edges). */
export function clampCrop(s: CropState, width: number, height: number, view: number): CropState {
  const zoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, Number.isFinite(s.zoom) ? s.zoom : 1));
  const scale = coverScale(width, height, view) * zoom;
  const minX = Math.min(0, view - width * scale), minY = Math.min(0, view - height * scale);
  const clamp = (v: number, lo: number) => Math.min(0, Math.max(lo, Number.isFinite(v) ? v : 0));
  return {zoom, x: clamp(s.x, minX), y: clamp(s.y, minY)};
}

/** Picture centred in the square at zoom 1. */
export function initialCrop(width: number, height: number, view: number): CropState {
  const scale = coverScale(width, height, view);
  return clampCrop({zoom: 1, x: (view - width * scale) / 2, y: (view - height * scale) / 2}, width, height, view);
}

/** Change the zoom while keeping the point under (fx, fy) of the viewport still. */
export function zoomAt(s: CropState, nextZoom: number, fx: number, fy: number, width: number, height: number, view: number): CropState {
  const target = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, nextZoom));
  const ratio = target / s.zoom;
  return clampCrop({zoom: target, x: fx - (fx - s.x) * ratio, y: fy - (fy - s.y) * ratio}, width, height, view);
}

/** The square of the original picture (in pixels) that is visible in the viewport. */
export function cropRect(s: CropState, width: number, height: number, view: number): CropRect {
  const c = clampCrop(s, width, height, view);
  const scale = coverScale(width, height, view) * c.zoom;
  const side = Math.max(1, Math.min(width, height, Math.round(view / scale)));
  const originX = Math.max(0, Math.min(width - side, Math.round(-c.x / scale)));
  const originY = Math.max(0, Math.min(height - side, Math.round(-c.y / scale)));
  return {originX, originY, width: side, height: side};
}
