/**
 * "Saved by N people" for every code (Build 88).
 *
 * Saving a word stays a local learning feature (it works offline and for guests). For signed-in,
 * active accounts the app also keeps one public counter per entry:
 *  - codeSaves/{termId}_{uid}      one private marker per account and entry (only its owner can read it)
 *  - codeSaveCounts/{termId}       {termId, count, updatedAt} — public, read by everyone
 * The marker and the count change together in one transaction, and firestore.rules only accept a
 * count that moves by exactly 1 with the account's own marker, so one account adds at most one save
 * and the count cannot be inflated or drift (the same pattern as post likes).
 */
import {useEffect, useState} from 'react';
import {collection, doc, documentId, getDoc, getDocs, onSnapshot, query, runTransaction, serverTimestamp, where} from 'firebase/firestore';
import {accountAuth, cloudDbLive} from './firebase/app';
import {ID_PATTERN} from '../shared/contentSchema';

const countRef = (termId: string) => doc(cloudDbLive(), 'codeSaveCounts', termId);
const markRef = (termId: string, uid: string) => doc(cloudDbLive(), 'codeSaves', `${termId}_${uid}`);
const known = new Map<string, number>();

/** Record that the signed-in account saved (or un-saved) an entry. Safe to call repeatedly. */
export async function setCodeSaved(termId: string, saved: boolean): Promise<void> {
  const uid = accountAuth.currentUser?.uid;
  if (!uid || !ID_PATTERN.test(termId)) return;
  const db = cloudDbLive(), mark = markRef(termId, uid), count = countRef(termId);
  await runTransaction(db, async tx => {
    const [m, c] = await Promise.all([tx.get(mark), tx.get(count)]);
    if (m.exists() === saved) return;
    const current = c.exists() ? Math.max(0, Number(c.get('count')) || 0) : 0;
    if (!saved && (!c.exists() || current < 1)) return;
    const next = current + (saved ? 1 : -1);
    if (saved) tx.set(mark, {termId, uid, createdAt: serverTimestamp()});
    else tx.delete(mark);
    if (c.exists()) tx.update(count, {count: next, updatedAt: serverTimestamp()});
    else tx.set(count, {termId, count: next, updatedAt: serverTimestamp()});
  });
}

/** Words saved before Build 88 are counted the first time their details are opened. */
export async function ensureCodeSaved(termId: string): Promise<void> {
  const uid = accountAuth.currentUser?.uid;
  if (!uid || !ID_PATTERN.test(termId)) return;
  const mark = await getDoc(markRef(termId, uid));
  if (!mark.exists()) await setCodeSaved(termId, true);
}

/** Live "saved by" count for one entry; null while loading or when it can't be read. */
export function useSaveCount(termId: string | undefined): number | null {
  const [count, setCount] = useState<number | null>(() => (termId && known.has(termId) ? known.get(termId)! : null));
  useEffect(() => {
    if (!termId || !ID_PATTERN.test(termId)) {setCount(null); return;}
    setCount(known.has(termId) ? known.get(termId)! : null);
    return onSnapshot(countRef(termId), snap => {
      const value = snap.exists() ? Math.max(0, Number(snap.get('count')) || 0) : 0;
      known.set(termId, value);
      setCount(value);
    }, () => setCount(null));
  }, [termId]);
  return count;
}

/** Counts for a list of entries (the profile's Saved tab), read in batches of 30. */
export function useSaveCounts(termIds: string[]): Map<string, number> {
  const key = JSON.stringify([...new Set(termIds.filter(id => ID_PATTERN.test(id)))].sort());
  const [counts, setCounts] = useState<Map<string, number>>(() => new Map([...known].filter(([id]) => termIds.includes(id))));
  useEffect(() => {
    const ids = JSON.parse(key) as string[];
    if (!ids.length) {setCounts(new Map()); return;}
    let live = true;
    void Promise.all(Array.from({length: Math.ceil(ids.length / 30)}, (_, i) => ids.slice(i * 30, i * 30 + 30)).map(chunk =>
      getDocs(query(collection(cloudDbLive(), 'codeSaveCounts'), where(documentId(), 'in', chunk))).then(snap => {
        const found = new Map(snap.docs.map(d => [d.id, Math.max(0, Number(d.get('count')) || 0)] as [string, number]));
        for (const id of chunk) known.set(id, found.get(id) ?? 0);
      }, () => {}),
    )).then(() => {if (live) setCounts(new Map(ids.map(id => [id, known.get(id) ?? 0])));});
    return () => {live = false;};
  }, [key]);
  return counts;
}

/** "Saved by 1 person" / "Saved by 12 people". */
export const savedByText = (count: number) => `Saved by ${count.toLocaleString()} ${count === 1 ? 'person' : 'people'}`;
