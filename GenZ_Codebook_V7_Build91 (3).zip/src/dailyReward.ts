/**
 * One daily reward, shared by every screen (Home card, daily pop-up, You page, Wallet).
 *
 * Signed in: one tap collects +10 Credits on the account (server, once per UTC day — the
 * receipt users/{uid}/tokenLedger/daily-YYYY-MM-DD) and the +10 learning points on this device.
 * Signed out: +10 learning points on this device, once per local day.
 *
 * "Collected" is one shared state: when any button collects, every other button shows
 * "Collected today" at once; on start each button checks the server receipt, so a reward
 * collected on another screen or device can't be offered again.
 *
 * Build 88: collecting is instant. The tap marks today as collected and adds the learning points
 * right away; the server credit runs in the background (a cold Cloud Function took several
 * seconds). If the server refuses, the mark is undone and the error is shown, so the reward
 * can be collected again. The server still allows only one credit per account and UTC day.
 */
import {useEffect, useSyncExternalStore} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {BACKEND_URL} from './backend';
import {repository, useAccountUser, useLearningState} from './services';
import {collectDailyReward} from './learning';
import {localDay} from './discovery';
import {errorOf, feature} from './communityFeatures';

const KEY = 'genz.dailyReward.v1';
export const utcDay = (t = Date.now()) => new Date(t).toISOString().slice(0, 10);

const collected = new Set<string>();   // `${uid}:${utcDay}`
const known = new Set<string>();       // keys whose server receipt was checked
let busyKey: string | null = null;
let version = 0, loaded = false;
const listeners = new Set<() => void>();
const emit = () => {version++; listeners.forEach(f => f());};
const subscribe = (f: () => void) => {listeners.add(f); load(); return () => {listeners.delete(f);};};
function load() {
  if (loaded) return;
  loaded = true;
  void AsyncStorage.getItem(KEY).then(raw => {
    const v = raw ? JSON.parse(raw) : null;
    if (Array.isArray(v)) {for (const k of v) if (typeof k === 'string') {collected.add(k); known.add(k);} emit();}
  }).catch(() => {});
}
function mark(key: string) {
  known.add(key);
  if (collected.has(key)) {emit(); return;}
  collected.add(key);
  emit();
  void AsyncStorage.setItem(KEY, JSON.stringify([...collected].slice(-14))).catch(() => {});
}
function unmark(key: string) {
  if (!collected.delete(key)) return;
  emit();
  void AsyncStorage.setItem(KEY, JSON.stringify([...collected].slice(-14))).catch(() => {});
}
const checks = new Map<string, Promise<void>>();
/** Ask the server once per account and day whether today's receipt exists. */
function checkServer(uid: string, day: string) {
  const key = `${uid}:${day}`;
  if (known.has(key) || checks.has(key)) return;
  checks.set(key, (async () => {
    try {
      const [{doc, getDoc}, {cloudDb}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
      const snap = await getDoc(doc(cloudDb(), 'users', uid, 'tokenLedger', `daily-${day}`));
      if (snap.exists()) mark(key); else {known.add(key); emit();}
    } catch {known.add(key); emit();}   // offline: offer the button; the server still refuses a second credit
    finally {checks.delete(key);}
  })());
}

/** Called when the background server credit finishes: an error message, or null on success. */
export type RewardSettled = (error: string | null, duplicate?: boolean) => void;
export type DailyReward = {account: boolean; done: boolean; known: boolean; busy: boolean; collect: (settled?: RewardSettled) => Promise<string>};
export const DAILY_DUPLICATE = 'Today’s reward is already collected. A new one is ready after midnight UTC.';

export function useDailyReward(): DailyReward {
  const user = useAccountUser(), state = useLearningState();
  useSyncExternalStore(subscribe, () => version);
  const account = !!user && !!BACKEND_URL;
  const day = utcDay();
  const key = user ? `${user.uid}:${day}` : '';
  useEffect(() => {if (account && user) checkServer(user.uid, day);}, [account, user?.uid, day]);
  const localDone = state.tokens.lastDailyCollect === localDay();
  const done = account ? collected.has(key) : localDone;
  // While the background credit runs the button already shows "Collected today", so busy only blocks a second tap.
  const busy = account && busyKey === key && !collected.has(key);
  const collect = async (settled?: RewardSettled): Promise<string> => {
    if (done || busy) return '';
    if (!account) {
      await repository.mutate(collectDailyReward);
      return '+10 learning points collected. Come back tomorrow for more.';
    }
    // Instant: every button shows "Collected today" now; the server credit follows in the background.
    mark(key);
    if (!localDone) void repository.mutate(collectDailyReward).catch(() => {});
    busyKey = key;
    void feature('daily-reward').then(
      r => {busyKey = null; emit(); settled?.(null, r.duplicate === true);},
      e => {busyKey = null; unmark(key); settled?.(errorOf(e));},
    );
    return '+10 Credits and +10 learning points collected. Come back tomorrow for more.';
  };
  return {account, done, known: !account || known.has(key) || collected.has(key), busy, collect};
}
