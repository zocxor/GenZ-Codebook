import * as ImagePicker from 'expo-image-picker';
import {usePhotoCropper} from './PhotoCropper';
import * as ImageManipulator from 'expo-image-manipulator';
import {OverflowMenu as SharedOverflowMenu,OverflowMenuItem,type MenuAnchor,type OverflowMenuProps} from './OverflowMenu';
import {MessageAlertPrompt,MessageAlertSettings} from './MessageAlertSettings';
import React,{createContext,useContext,useEffect,useLayoutEffect,useRef,useState} from 'react';
import {ActivityIndicator,AppState,BackHandler,Image,Keyboard,Modal,Pressable,ScrollView,Share,StyleSheet,Text,TextInput,View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {collection,doc,onSnapshot,orderBy,query,limit} from 'firebase/firestore';
import * as Clipboard from 'expo-clipboard';
import {C,BrandAvatar,Button,Chip,Glass,Icon,RoundIcon,confirmAction,type IconName} from './ui';
import {KeyboardDock} from './KeyboardDock';
import {EmojiPicker,quickEmoji} from './EmojiPicker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {search} from './engine';
import {pickChatPhoto,pickChatFile,openChatFile,type ChatFile} from './chatAttachments';
import {ProfileCardSurface,ProfileAction,ProfileIcon,SocialProfile,useProfileColors} from './SocialProfile';
import {CHAT_ATTACHMENT_DAYS} from '../shared/chatAttachments';
import {useSharingCode} from './useSharingCode';
import {referralInstallLink} from '../shared/referral';
import {usePublicAbout,usePublicProfiles} from './publicProfile';
import {VerifiedBadge,useBadges} from './VerifiedBadge';
import {cloudDbLive} from './firebase/app';
import {useAccountUser} from './services';
import {errorOf,ms,requestKey} from './communityFeatures';
import {ensureCommunityRules} from './safety';
import {REPORT_REASONS,USER_REPORT_REASONS} from './ugc';
import {messaging,useInbox,usePrivateMessages,useMessagingPresence,type InboxRow,type Invite,type Person,type ProfileDetails,type PrivateMessage,type ConnectionList} from './messaging';
const time=(v:unknown)=>ms(v)?new Date(ms(v)).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):'';
const chatFont='Calibri';
const no=()=>{};
const chatDark = createContext(false);
const darkColors = {bg:'#111B2E',surface:'#192740',field:'#263957',line:'#3C5071',ink:'#F1F4FF',muted:'#BAC8E2',sender:'#C9B6FF'};
const darkSurface = {backgroundColor:darkColors.surface,borderColor:darkColors.line};
type InboxTab='personal'|'group';
type InboxScope='all'|InboxTab;
type InboxFilter='all'|'unread'|'archived';
const groupIcons=['people','chatbubbles','planet','game-controller'] as const;
type GroupIcon=(typeof groupIcons)[number];
function isGroupIcon(value:unknown):value is GroupIcon{return groupIcons.some(icon=>icon===value);}
function Avatar({person,size=44}:{person:{avatar?:number;photo?:string;type?:string;groupIcon?:string};size?:number}){return person.photo?<Image source={{uri:person.photo}} style={{width:size,height:size,borderRadius:size/3}}/>:person.type==='group'?<View style={[s.groupAvatar,{width:size,height:size,borderRadius:size/3}]}><Icon name={isGroupIcon(person.groupIcon)?person.groupIcon:'people'} color={C.purple}/></View>:<BrandAvatar size={size} index={person.avatar||0}/>;}
function MenuAction({label,icon,onPress,selected=false}:{label:string;icon?:IconName;onPress:()=>void;selected?:boolean}){
 const dark=useContext(chatDark),ink=dark?darkColors.ink:C.blue;
 return <Pressable accessibilityRole="button" accessibilityLabel={label} hitSlop={6} onPress={onPress} style={({pressed})=>({minWidth:32,minHeight:32,paddingHorizontal:icon?8:10,paddingVertical:5,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:5,borderRadius:10,opacity:pressed?.7:1,backgroundColor:dark?darkColors.field:selected?'#dbeaff':'#eef3fa'})}>
 {icon&&<Icon name={icon} size={16} color={ink}/>}{icon==='ellipsis-vertical'?null:<Text style={{fontFamily:chatFont,color:ink,fontSize:12,fontWeight:'400'}}>{label}</Text>}</Pressable>;
}
function ChatMenuItem(props:React.ComponentProps<typeof OverflowMenuItem>){
 const dark=useContext(chatDark);
 return <OverflowMenuItem {...props} colors={dark?darkColors:undefined}/>;
}
function RowOptions({label,onOpen,expanded,overlay=false}:{label:string;onOpen:(anchor:MenuAnchor)=>void;expanded:boolean;overlay?:boolean}){
 const ref=useRef<View>(null);
 return <Pressable ref={ref} collapsable={false} accessibilityRole="button" accessibilityLabel={label} accessibilityState={{expanded}}
  style={[{width:40,height:40,alignItems:'center',justifyContent:'center'},overlay&&s.options]}
  onPress={()=>ref.current?.measureInWindow((x,y,width,height)=>onOpen({x,y,width,height}))}>
  <Icon name="ellipsis-vertical" size={18}/>
 </Pressable>;
}
function OverflowMenu(props:OverflowMenuProps){
 const dark=useContext(chatDark);
 return <SharedOverflowMenu {...props} colors={dark?darkColors:undefined}/>;
}
function Header({badge,title,subtitle,onBack,action,onTitle,titleLabel,avatar}:{badge?:React.ReactNode;avatar?:React.ReactNode;title:string;subtitle?:string;onBack:()=>void;action?:React.ReactNode;onTitle?:()=>void;titleLabel?:string}){
 const dark=useContext(chatDark);
 const heading=<View style={{flex:1,justifyContent:'center'}}><View style={[s.inline,{gap:4}]}><Text accessibilityRole="header" numberOfLines={1} style={[s.title,{flexShrink:1},!!avatar&&{fontSize:15,fontWeight:'400'},dark&&{color:darkColors.ink}]}>{title}</Text>{badge}</View>{subtitle&&<Text style={[s.small,dark&&{color:darkColors.muted}]}>{subtitle}</Text>}</View>;
 return <View collapsable={false} collapsableChildren={false} style={[s.header,dark&&darkSurface]}>
  {avatar?<Pressable accessibilityRole="button" accessibilityLabel="Back" onPress={onBack} style={{width:40,height:44,alignItems:'center',justifyContent:'center'}}><Icon name="arrow-back" size={17} color={dark?darkColors.ink:C.ink}/></Pressable>:<RoundIcon name="arrow-back" label="Back" onPress={onBack}/>}
  {onTitle?<Pressable accessibilityRole="button" accessibilityLabel={titleLabel} onPress={onTitle} style={{flex:1,minHeight:44,flexDirection:'row',alignItems:'center',gap:8}}>{avatar}{heading}</Pressable>:<View style={{flex:1,flexDirection:'row',alignItems:'center',gap:8}}>{avatar}{heading}</View>}{action}
 </View>;
}
function MessageAction({name,label,onPress}:{name:React.ComponentProps<typeof Icon>['name'];label:string;onPress:()=>void}){
 const dark=useContext(chatDark);
 return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={{width:36,height:36,alignItems:'center',justifyContent:'center'}}><Icon name={name} size={18} color={dark?darkColors.ink:C.accent}/></Pressable>;
}
function Notice({text,onDismiss}:{text:string;onDismiss:()=>void}) {
 return <View accessibilityLiveRegion="polite" style={s.notice}>
  <Text style={[s.body,{flex:1}]}>{text}</Text>
  <Pressable accessibilityRole="button" accessibilityLabel="Dismiss notice" hitSlop={8} onPress={onDismiss}><Icon name="close" size={18}/></Pressable>
 </View>;
}
function PresenceDot({uid}:{uid?:string}){const [until,setUntil]=useState(0),[now,setNow]=useState(Date.now());useEffect(()=>{setUntil(0);if(!uid)return;const stop=onSnapshot(doc(cloudDbLive(),'messagingPresence',uid),snap=>setUntil(snap.get('onlineUntil')||0),()=>setUntil(0));const timer=setInterval(()=>setNow(Date.now()),10000);return()=>{stop();clearInterval(timer);};},[uid]);return until>now?<View accessibilityLabel="Online" style={{width:8,height:8,borderRadius:4,backgroundColor:'#0D9A60'}}/>:null;}
export function InboxList({rows,tab,search,filter,onOpen,onOptions,optionsId}:{optionsId?:string;rows:InboxRow[];tab:InboxScope;search:string;filter:InboxFilter;onOpen:(r:InboxRow)=>void;onOptions:(r:InboxRow,anchor:MenuAnchor)=>void}){
 const shown=rows.filter(r=>!r.deleted&&(tab==='all'||r.type===tab)&&(r.type==='personal'?['active','closed','pending']:['active','closed']).includes(r.status)&&(filter==='archived'?r.archived:!r.archived)&&(filter!=='unread'||r.unread>0)&&r.name.toLowerCase().includes(search.trim().toLowerCase())).sort((a,b)=>Number(!!b.pinned)-Number(!!a.pinned)||ms(b.updatedAt)-ms(a.updatedAt));
 const badges=useBadges(shown.flatMap(r=>r.peerId?[r.peerId]:[]));
 // Keep a native parent while the empty state is replaced by live rows.
 return <View collapsable={false} collapsableChildren={false} style={shown.length?s.inboxRows:undefined}>
 {!shown.length&&<Glass><Icon name={tab==='group'?'people-outline':'chatbubbles-outline'} size={32} color={C.purple}/><Text style={s.heading}>{search?'No conversations found':filter==='archived'?'No archived conversations':filter==='unread'?'No unread conversations':'No conversations yet'}</Text><Text style={s.body}>{filter==='all'&&!search?'Tap + to start a message or create a group.':null}</Text></Glass>}
 {shown.map((row,index)=><View key={row.id} style={[s.inboxCard,index>0&&s.rowDivider,row.unread>0&&!row.pinned&&s.inboxCardUnread]}><Pressable accessibilityRole="button" accessibilityLabel={`Open ${row.name}, ${row.unread||0} unread`} onPress={()=>onOpen(row)} style={s.inboxRow}><Avatar person={row}/><View style={{flex:1,gap:4}}><View style={s.inline}><Text style={[s.heading,{flexShrink:1}]} numberOfLines={1}>{row.name}</Text><PresenceDot uid={row.peerId}/><VerifiedBadge verified={badges.has(row.peerId||'')} tier={badges.tier(row.peerId)}/>{row.pinned&&<View accessible accessibilityLabel="Pinned conversation"><Icon name="pin" size={15} color="#935800"/></View>}<View style={{flex:1}}/><Text style={s.small}>{time(row.updatedAt)}</Text></View><Text style={s.body} numberOfLines={1}>{row.lastMessage&&!(row.lastMessage==='Request accepted'&&!row.lastMessageId)?row.lastMessage:'Say hello'}</Text>{row.muted&&<Icon name="notifications-off-outline" size={13} color={C.muted}/>}</View>{row.unread>0&&<View style={s.badge}><Text style={s.badgeText}>{row.unread>99?'99+':row.unread}</Text></View>}</Pressable><RowOptions overlay label={`Options for ${row.name}`} expanded={optionsId===row.id} onOpen={anchor=>onOptions(row,anchor)}/></View>)}
 </View>;
}
export default function MessagingScreen({onClose,onSignIn,initialFind=false,initialConnections,embedded=false,onConversationChange}:{onConversationChange?:(open:boolean)=>void;onClose:()=>void;onSignIn:()=>void;initialFind?:boolean;initialConnections?:ConnectionList;embedded?:boolean}){
 const user=useAccountUser(),uid=user?.uid,eligible=!!user?.emailVerified;
 const feed=useInbox(uid,eligible),[tab,setTab]=useState<InboxScope>('all'),[row,setRow]=useState<InboxRow|null>(null),[mode,setMode]=useState<'inbox'|'find'|'create'|'join'|'privacy'>(initialFind?'find':'inbox'),[person,setPerson]=useState<Person|null>(null),[note,setNote]=useState(''),[busy,setBusy]=useState(false),[invites,setInvites]=useState<Invite[]>([]),[plus,setPlus]=useState(false);
 const [search,setSearch]=useState(''),[searchOpen,setSearchOpen]=useState(false),[filtersOpen,setFiltersOpen]=useState(false),[filter,setFilter]=useState<InboxFilter>('all');
 const [headerHeight,setHeaderHeight]=useState(55),[optionsRow,setOptionsRow]=useState<InboxRow|null>(null);
 const [optionsAnchor,setOptionsAnchor]=useState<MenuAnchor>();
 const dismissOptions=()=>{setFiltersOpen(false);setOptionsRow(null);};
 useEffect(()=>{
  if(!filtersOpen&&!optionsRow)return;
  const sub=BackHandler.addEventListener('hardwareBackPress',()=>{dismissOptions();return true;});
  return ()=>sub.remove();
 },[filtersOpen,optionsRow]);
 const [joinCode,setJoinCode]=useState('');
 const conversationOpen=!!row&&!!uid&&eligible;
 const [dark,setDark]=useState(false);
 useEffect(()=>{let live=true;void AsyncStorage.getItem('inbox.chat.dark').then(value=>{if(live)setDark(value==='true');},no);return()=>{live=false;};},[]);
 const toggleDark=()=>{setDark(!dark);void AsyncStorage.setItem('inbox.chat.dark',String(!dark)).catch(no);};
 useLayoutEffect(()=>{onConversationChange?.(conversationOpen);return()=>onConversationChange?.(false);},[conversationOpen,onConversationChange]);
 const [connections,setConnections]=useState<{uid:string;list:ConnectionList}|null>(()=>uid&&initialConnections?{uid,list:initialConnections}:null);
 const closeConnections=()=>{setConnections(null);if(initialConnections&&!person)onClose();};
 const chooseConnection=(item:Person)=>{
  setConnections(null);
  if(item.uid===uid){onClose();return;}
  setPerson(item);
 };
 useMessagingPresence(uid,eligible);
 useEffect(()=>{if(!row)return;const fresh=feed.rows.find(r=>r.id===row.id);if(fresh)setRow(fresh);},[feed.rows]);
 useEffect(()=>{setInvites([]);if(!uid||!eligible)return;return onSnapshot(query(collection(cloudDbLive(),`users/${uid}/messageInvites`),orderBy('createdAt','desc'),limit(50)),s=>setInvites(s.docs.filter(d=>d.get('status')==='pending').map(d=>({...d.data(),id:d.id})as Invite)),()=>{});},[uid,eligible]);
 const act=async(command:string,data:Record<string,unknown>={})=>{setBusy(true);setNote('');try{return await messaging(command,data);}catch(e){setNote(errorOf(e));}finally{setBusy(false);}};
 const open=(r:InboxRow)=>{Keyboard.dismiss();setNote('');setRow(r);};
 // Build 65: no message requests. Messaging someone opens the conversation straight away.
 const start=async(profile:ProfileDetails)=>{
  const existing=feed.rows.find(r=>r.id===profile.conversationId);
  if(!profile.chatStatus&&!(await ensureCommunityRules()))return;
  const result=await act('request',{uid:profile.uid});
  if(!result)return;
  setConnections(null);setPerson(null);setMode('inbox');setPlus(false);
  setRow(existing?{...existing,status:'active',archived:false,deleted:false}:{
   id:result.id,conversationId:result.id,type:'personal',name:profile.name,peerId:profile.uid,avatar:profile.avatar,
   photo:profile.photo,status:'active',unread:0,
  });
 };
 const startWithPerson=async(p:Person)=>{
  setBusy(true);setNote('');
  try{await start((await messaging('profile',{uid:p.uid})).person);}catch(e){setNote(errorOf(e));}finally{setBusy(false);}
 };

 return <SafeAreaView edges={embedded?['left','right']:undefined} style={[s.screen,conversationOpen&&dark&&{backgroundColor:darkColors.bg}]}><KeyboardDock nativeIme><View collapsable={false} collapsableChildren={false} style={s.fill}>
 {!uid||!eligible?<><Header title="Inbox" onBack={onClose}/><View style={s.content}><Glass><Icon name="mail-unread-outline" color={C.purple} size={36}/><Text style={s.heading}>Your conversations, in one place</Text><Text style={s.body}>{!uid?'Sign in to send private messages and join groups.':'Verify your email before using private messaging.'}</Text><Button title={!uid?'Sign in':'Open account'} onPress={()=>{onClose();onSignIn();}}/></Glass></View></>:row?<chatDark.Provider value={dark}><Conversation key={row.id} onToggleDark={toggleDark} row={row} uid={uid} onBack={()=>{Keyboard.dismiss();setNote('');setRow(null);}} onNote={setNote} note={note} onOpenProfileChat={start}/></chatDark.Provider>:connections?<ConnectionsScreen key={connections.uid+connections.list} target={connections.uid} list={connections.list} onBack={closeConnections} onChoose={chooseConnection}/>:mode==='privacy'?<Privacy uid={uid} onBack={()=>setMode('inbox')}/>:person?<><Header title="Public profile" onBack={()=>{setPerson(null);if(initialConnections&&uid)setConnections({uid,list:initialConnections});}}/><ScrollView removeClippedSubviews={false} contentContainerStyle={s.content}><PersonProfile key={person.uid} person={person} messageBusy={busy} onMessage={start} onConnections={list=>setConnections({uid:person.uid,list})}/></ScrollView></>:mode==='find'?<><Header title="New message" subtitle="Pick a friend or search by name or user code" onBack={()=>setMode('inbox')}/><PeopleSearch onChoose={setPerson} onMessage={p=>void startWithPerson(p)} suggestions={<FriendsList uid={uid} onMessage={p=>void startWithPerson(p)} onProfile={setPerson}/>}/></>:mode==='join'?<><Header title="Join an open group" onBack={()=>setMode('inbox')}/><View style={s.content}><TextInput autoCapitalize="none" autoCorrect={false} accessibilityLabel="Group code" placeholder="Paste group code" maxLength={128} value={joinCode} onChangeText={setJoinCode} style={s.input}/><Button title="Join group" disabled={busy||!joinCode.trim()} onPress={async()=>{if(!(await ensureCommunityRules()))return;if(await act('join-group',{conversationId:joinCode.trim()})){setJoinCode('');setMode('inbox');setFilter('all');setTab('all');setSearch('');setNote('Group joined.');}}}/></View></>:mode==='create'?<CreateGroup onBack={()=>setMode('inbox')} onDone={()=>{setMode('inbox');setTab('all');setFilter('all');setNote('Group created. You and your selected member can start chatting.');}}/>:<><View onLayout={e=>setHeaderHeight(e.nativeEvent.layout.height)}><Header title="Inbox" onBack={onClose} action={<View style={s.inline}>
  <RoundIcon name={searchOpen?'close':'search-outline'} label={searchOpen?'Close search':'Search conversations'} onPress={()=>{if(searchOpen){setSearch('');Keyboard.dismiss();}setSearchOpen(v=>!v);setFiltersOpen(false);}}/>
  <Pressable accessibilityRole="button" accessibilityLabel="Inbox options" accessibilityState={{expanded:filtersOpen}} onPress={()=>{Keyboard.dismiss();setPlus(false);setOptionsRow(null);setFiltersOpen(v=>!v);}} style={{width:44,height:44,alignItems:'center',justifyContent:'center'}}><Icon name="ellipsis-vertical" size={20} color={C.ink}/></Pressable>
 </View>}/></View>
 {searchOpen&&<TextInput autoFocus accessibilityLabel="Search conversations" placeholder="Search conversations…" placeholderTextColor={C.muted} value={search} onChangeText={setSearch} style={[s.input,{marginHorizontal:12,marginTop:8}]}/>}
 <ScrollView removeClippedSubviews={false} keyboardShouldPersistTaps="handled" contentContainerStyle={[s.content,{paddingBottom:84}]}>
 <MessageAlertPrompt uid={uid}/>
 {!!feed.error&&<><Text style={s.error}>{feed.error}</Text><Button light title="Retry Inbox" onPress={feed.retry}/></>}{feed.loading&&<ActivityIndicator color={C.accent}/>}
 {tab!=='personal'&&filter==='all'&&!search&&invites.map(inv=><Glass key={inv.id}><Text style={s.heading}>Invitation: {inv.name}</Text><Text style={s.body}>Only accepted members can read this group.</Text><View style={s.wrap}><Chip label="Accept" onPress={()=>void act('respond-invite',{conversationId:inv.id,accept:true})}/><Chip label="Decline" onPress={()=>void act('respond-invite',{conversationId:inv.id,accept:false})}/></View></Glass>)}
 <InboxList optionsId={optionsRow?.id} rows={feed.rows} tab={tab} search={search} filter={filter} onOpen={open} onOptions={(r,anchor)=>{Keyboard.dismiss();setPlus(false);setFiltersOpen(false);setOptionsAnchor(anchor);setOptionsRow(r);}}/></ScrollView>
  {plus&&<Pressable accessibilityLabel="Close new message menu" onPress={()=>setPlus(false)} style={StyleSheet.absoluteFill}/>}
  <View pointerEvents="box-none" style={s.fabWrap}>
   {plus&&<View style={s.fabMenu}>
    <Pressable accessibilityRole="button" onPress={()=>{setPlus(false);setMode('join');}} style={s.fabItem}><Text style={s.fabText}>Join by group code</Text></Pressable>
    <Pressable accessibilityRole="button" accessibilityLabel="New group" onPress={()=>{setPlus(false);setMode('create');}} style={s.fabItem}><Icon name="people-outline" size={20} color={C.accent}/><Text style={s.fabText}>New group</Text></Pressable>
    <Pressable accessibilityRole="button" accessibilityLabel="New message" onPress={()=>{setPlus(false);setMode('find');}} style={s.fabItem}><Icon name="chatbubble-ellipses-outline" size={20} color={C.accent}/><Text style={s.fabText}>New message</Text></Pressable>
   </View>}
   <Pressable accessibilityRole="button" accessibilityLabel={plus?'Close new message menu':'Start a new message or group'} accessibilityState={{expanded:plus}} onPress={()=>setPlus(v=>!v)} style={s.fab}><Icon name={plus?'close':'add'} size={30} color="#fff"/></Pressable>
  </View>
  {optionsRow&&<OverflowMenu anchor={optionsAnchor} onDismiss={dismissOptions}><>{(['pinned','muted','archived'] as const).map((key,i)=><ChatMenuItem key={key} label={(optionsRow[key]?['Unpin chat','Unmute','Unarchive']:['Pin chat','Mute','Archive'])[i]!} onPress={()=>{dismissOptions();void act('inbox-settings',{conversationId:optionsRow.id,[key]:!optionsRow[key]});}}/>)}
    <ChatMenuItem label="Delete from my inbox" onPress={()=>{dismissOptions();confirmAction('Delete from your inbox?','Other members keep their copies.',()=>void act('inbox-settings',{conversationId:optionsRow.id,deleted:true}),'Delete');}}/>
<ChatMenuItem label="Clear history" onPress={()=>{dismissOptions();confirmAction("Clear chat history?","Earlier messages will be hidden for you.",()=>void act("inbox-settings",{conversationId:optionsRow.id,clearHistory:true}),"Clear");}}/></></OverflowMenu>}
  {filtersOpen&&<OverflowMenu headerHeight={headerHeight} onDismiss={dismissOptions}>

    <Text style={[s.small,{paddingHorizontal:10}]}>Conversation type</Text>
    {(['all','personal','group'] as const).map((value,i)=><ChatMenuItem key={value} label={['All chats','Personal','Groups'][i]!} selected={tab===value} onPress={()=>{setTab(value);dismissOptions();}}/>)}
    <Text style={[s.small,{paddingHorizontal:10}]}>Inbox view</Text>
    {(['all','unread','archived'] as const).map((value,i)=><ChatMenuItem key={value} label={['All messages','Unread','Archived'][i]!} selected={filter===value} onPress={()=>{setFilter(value);dismissOptions();}}/>)}
   <ChatMenuItem label="Settings" onPress={()=>{dismissOptions();setMode('privacy');}}/>
  </OverflowMenu>}</>}
 {!!note&&!conversationOpen&&<Notice text={note} onDismiss={()=>setNote('')}/>}
 </View></KeyboardDock></SafeAreaView>;
}
function PersonProfile({person,onMessage,messageBusy=false,onConnections}:{person:Person;onMessage:(p:ProfileDetails)=>Promise<void>;messageBusy?:boolean;onConnections?:(list:ConnectionList)=>void}){
 const badges=useBadges([person.uid]);
 const sharingCode=useSharingCode(person.uid);
 const [profile,setProfile]=useState<ProfileDetails|null>(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[epoch,retry]=useState(0);
 const colors=useProfileColors();
 const [menu,setMenu]=useState(false),[shareNote,setShareNote]=useState(''),[reporting,setReporting]=useState(false);
 const me=useAccountUser()?.uid;
 // Build 63: report a member. Works even after blocking; the reported person is not told who reported them.
 const reportUser=(reason:string)=>confirmAction(`Report ${(profile??person).name}?`,'A moderator will review this account. They aren’t told who reported them.',()=>void messaging('report-user',{uid:person.uid,reason}).then(r=>{setReporting(false);setMenu(false);setError(r?.duplicate?'You already reported this member. A moderator will review it.':'Report sent. A moderator will review this member. You can also block them from Profile options.');},e=>setError(errorOf(e))),'Report');
 useEffect(()=>{
  let active=true;setProfile(null);setError('');setReporting(false);
  void messaging('profile',{uid:person.uid}).then(r=>{if(active)setProfile(r.person);},e=>{if(active)setError(errorOf(e));});
  return()=>{active=false;};
 },[person.uid,epoch]);
 const follow=async()=>{
  if(!profile||busy)return;
  setBusy(true);setError('');
  try{
   await messaging('follow',{uid:profile.uid,following:!profile.following});
   setProfile((await messaging('profile',{uid:profile.uid})).person);
  }catch(e){setError(errorOf(e));}
  finally{setBusy(false);}
 };
 const visible=profile??person;
 const about=usePublicAbout(profile?.uid);
 const messageLabel='Message';
 if(!colors.ready)return null;
 return <ProfileCardSurface dark={colors.dark}>
  <View style={[s.inline,{justifyContent:'flex-end'}]}>
   <ProfileIcon colors={colors} label={colors.dark?'Switch to light profile':'Switch to dark profile'} name={colors.dark?'sunny-outline':'moon-outline'} onPress={colors.toggle}/>
   {profile&&<ProfileIcon colors={colors} label="Profile options" name="ellipsis-horizontal" onPress={()=>setMenu(v=>!v)}/>}
  </View>
  {profile&&menu&&<View style={{gap:6}}>
   <ProfileAction colors={colors} label="Copy user code" onPress={()=>void Clipboard.setStringAsync(sharingCode).then(()=>setMenu(false),e=>setError(errorOf(e)))}/>
   {person.uid!==me&&<ProfileAction colors={colors} label="Report user" onPress={()=>setReporting(v=>!v)}/>}
   {reporting&&<View style={{gap:8,padding:10,borderRadius:12,borderWidth:1,borderColor:colors.muted}} accessibilityLabel={`Report ${visible.name}`}>
    <Text style={{color:colors.ink,fontWeight:'400'}}>Why are you reporting {visible.name}?</Text>
    <View style={s.wrap}>{USER_REPORT_REASONS.map(reason=><Chip key={reason} label={reason} onPress={()=>reportUser(reason)}/>)}<Chip label="Cancel" onPress={()=>setReporting(false)}/></View>
   </View>}
   <ProfileAction colors={colors} label="Block private messages" onPress={()=>confirmAction(`Block ${visible.name}?`,'You can unblock this person in Settings.',()=>void messaging('block',{uid:person.uid,blocked:true}).then(()=>{
    setProfile(null);setMenu(false);setError('Private messages blocked.');
   },e=>setError(errorOf(e))),'Block')}/>
  </View>}
  <View style={s.inline}>
   <BrandAvatar index={visible.avatar} photo={visible.photo} size={72}/>
   <View style={{flex:1,gap:4}}>
    <View style={s.inline}><Text accessibilityRole="header" style={[s.title,{flexShrink:1,color:colors.ink}]}>{visible.name}</Text>
     <VerifiedBadge verified={badges.has(person.uid)} tier={badges.tier(person.uid)} size={20}/></View>
    <View style={[s.inline,{alignItems:'center',flexWrap:'wrap'}]}>
     <Text selectable style={{color:colors.muted}}>{sharingCode}</Text>
     <ProfileIcon bare colors={colors} label="Copy sharing code" name="copy-outline" onPress={()=>void Clipboard.setStringAsync(sharingCode).then(()=>setShareNote('Sharing code copied'),e=>setShareNote(errorOf(e)))}/>
     <ProfileIcon bare colors={colors} label="Copy invite link" name="link-outline" onPress={()=>void Clipboard.setStringAsync(referralInstallLink(sharingCode)).then(()=>setShareNote('Invite link copied'),e=>setShareNote(errorOf(e)))}/>
    </View>
    {!!shareNote&&<Text accessibilityLiveRegion="polite" style={s.small}>{shareNote}</Text>}
   </View>
  </View>
  {!!profile&&!!about.bio&&<Text numberOfLines={2} style={{color:colors.ink}}>{about.bio}</Text>}
  {!!profile&&!!about.location&&<Text style={{color:colors.muted}}>{about.location}</Text>}
  {profile?<><View style={{flexDirection:'row',gap:8}}>
   <View style={{flex:1}}><ProfileAction colors={colors} label={busy?'Updating…':profile.following?'Following':'Follow'} primary={!profile.following} disabled={busy} onPress={()=>{
    if(profile.following)confirmAction(`Unfollow ${visible.name}?`,'You can follow this member again any time.',()=>void follow(),'Unfollow');
    else void follow();
   }}/></View>
   <View style={{flex:1}}><ProfileAction colors={colors} label={messageBusy?'Opening…':messageLabel} disabled={messageBusy} onPress={()=>void onMessage(profile)}/></View>
  </View>

  <SocialProfile uid={profile.uid} colors={colors} about={about} followers={profile.followers} following={profile.followingCount} likes={profile.postLikes} onConnections={onConnections}/>
  </>:error?<ProfileAction colors={colors} label="Retry profile" onPress={()=>retry(v=>v+1)}/>:<ActivityIndicator color={colors.accent}/>}
  {!!error&&<Text accessibilityLiveRegion="polite" style={{color:colors.muted}}>{error}</Text>}
 </ProfileCardSurface>;
}
function ConnectionsScreen({target,list,onBack,onChoose}:{target:string;list:ConnectionList;onBack:()=>void;onChoose:(person:Person)=>void}){
 const [rows,setRows]=useState<Person[]>([]),[cursor,setCursor]=useState<string|null>(null),[busy,setBusy]=useState(true),[error,setError]=useState('');
 const badges=useBadges(rows.map(person=>person.uid));
 const load=async(after?:string)=>{
  setBusy(true);setError('');
  try{
   const result=await messaging('connections',{uid:target,list,...(after?{cursor:after}:{})});
   setRows(current=>after?[...current,...result.users]:result.users);
   setCursor(result.cursor);
  }catch(e){setError(errorOf(e));}
  finally{setBusy(false);}
 };
 useEffect(()=>{void load();},[target,list]);
 return <><Header title={list==='followers'?'Followers':'Following'} onBack={onBack}/><ScrollView removeClippedSubviews={false} contentContainerStyle={s.content}>
  {busy&&<ActivityIndicator color={C.accent}/>}
  {rows.map(person=><Pressable key={person.uid} accessibilityRole="button" accessibilityLabel={'View '+person.name} onPress={()=>onChoose(person)} style={s.inboxRow}><Avatar person={person}/><View style={[s.inline,{flex:1,minWidth:0}]}><Text style={[s.heading,{flexShrink:1}]} numberOfLines={1}>{person.name}</Text><VerifiedBadge verified={badges.has(person.uid)} tier={badges.tier(person.uid)}/></View><Icon name="chevron-forward" size={18}/></Pressable>)}
  {!!error&&<Text style={s.error}>{error}</Text>}
  {!busy&&(cursor||error)?<Button light title={error?'Try again':'Load more'} onPress={()=>void load(cursor??undefined)}/>:null}
  {!busy&&!error&&!cursor&&!rows.length&&<Text style={s.body}>{list==='followers'?'No followers yet.':'No accounts followed yet.'}</Text>}
 </ScrollView></>;
}
function PeopleSearch({onChoose,onMessage,suggestions}:{onChoose:(p:Person)=>void;onMessage?:(p:Person)=>void;suggestions?:React.ReactNode}){
 const [value,setValue]=useState(''),[rows,setRows]=useState<Person[]>([]),[error,setError]=useState(''),[busy,setBusy]=useState(false),seq=useRef(0);
 const badges=useBadges(rows.map(p=>p.uid));
 useEffect(()=>{const token=++seq.current;setRows([]);setError('');if(value.trim().length<2){setBusy(false);return;}setBusy(true);const timer=setTimeout(()=>{void messaging('search',{query:value.trim()}).then(result=>{if(token===seq.current){setRows(result.users||[]);setBusy(false);}},e=>{if(token===seq.current){setError(errorOf(e));setBusy(false);}});},450);return()=>{clearTimeout(timer);seq.current++;};},[value]);
 return <ScrollView removeClippedSubviews={false} keyboardShouldPersistTaps="handled" contentContainerStyle={s.content}><TextInput accessibilityLabel="Search users by name or user code" autoCapitalize="none" placeholder="Name or user code…" placeholderTextColor={C.muted} value={value} onChangeText={setValue} maxLength={40} style={s.input}/><View collapsable={false} collapsableChildren={false} style={{gap:12}}>{busy&&<ActivityIndicator color={C.accent}/>}{!!error&&<Text style={s.error}>{error}</Text>}{!busy&&!error&&value.trim().length>=2&&!rows.length&&<Text style={s.body}>No available users found. Try their exact user code.</Text>}{value.trim().length<2&&suggestions}{rows.map(p=><Pressable key={p.uid} accessibilityRole="button" accessibilityLabel={(onMessage?'Message ':'View ')+p.name} onPress={()=>(onMessage??onChoose)(p)} style={s.inboxRow}><Avatar person={p}/><View style={[s.inline,{flex:1}]}><Text numberOfLines={2} style={[s.heading,{flexShrink:1}]}>{p.name}</Text><VerifiedBadge verified={badges.has(p.uid)} tier={badges.tier(p.uid)}/></View>{onMessage?<Pressable accessibilityRole="button" accessibilityLabel={'View profile of '+p.name} hitSlop={8} onPress={()=>onChoose(p)}><Icon name="person-circle-outline" size={24} color={C.muted}/></Pressable>:<Icon name="chevron-forward" size={18}/>}</Pressable>)}</View></ScrollView>;
}
/** People you can message with one tap, so a new message does not need a search: accounts you follow, and your followers. */
function FriendsList({uid,onMessage,onProfile}:{uid:string;onMessage:(p:Person)=>void;onProfile:(p:Person)=>void}){
 const [list,setList]=useState<ConnectionList>('following'),[rows,setRows]=useState<Person[]>([]),[cursor,setCursor]=useState<string|null>(null),[busy,setBusy]=useState(true),[error,setError]=useState(''),seq=useRef(0);
 const badges=useBadges(rows.map(p=>p.uid));
 const load=async(after?:string)=>{
  const token=++seq.current;setBusy(true);setError('');
  try{
   const result=await messaging('connections',{uid,list,...(after?{cursor:after}:{})});
   if(token!==seq.current)return;
   setRows(current=>after?[...current,...result.users]:result.users);setCursor(result.cursor);
  }catch(e){if(token===seq.current)setError(errorOf(e));}
  finally{if(token===seq.current)setBusy(false);}
 };
 useEffect(()=>{setRows([]);setCursor(null);void load();return()=>{seq.current++;};},[list]);
 return <View style={{gap:8}}>
  <View style={s.wrap}><Chip label="Following" icon="person-add-outline" selected={list==='following'} onPress={()=>setList('following')}/><Chip label="Followers" icon="people-outline" selected={list==='followers'} onPress={()=>setList('followers')}/></View>
  {rows.map(p=><Pressable key={p.uid} accessibilityRole="button" accessibilityLabel={'Message '+p.name} onPress={()=>onMessage(p)} style={s.inboxRow}><Avatar person={p}/><View style={[s.inline,{flex:1}]}><Text numberOfLines={2} style={[s.heading,{flexShrink:1}]}>{p.name}</Text><VerifiedBadge verified={badges.has(p.uid)} tier={badges.tier(p.uid)}/></View><Pressable accessibilityRole="button" accessibilityLabel={'View profile of '+p.name} hitSlop={8} onPress={()=>onProfile(p)}><Icon name="person-circle-outline" size={24} color={C.muted}/></Pressable></Pressable>)}
  {busy&&<ActivityIndicator color={C.accent}/>}
  {!!error&&<Text style={s.error}>{error}</Text>}
  {!busy&&(cursor||error)?<Button light title={error?'Try again':'Load more'} onPress={()=>void load(cursor??undefined)}/>:null}
  {!busy&&!error&&!rows.length&&<Text style={s.body}>{list==='following'?'You don’t follow anyone yet. Search above by name or user code.':'No followers yet. Search above by name or user code.'}</Text>}
 </View>;
}
function CreateGroup({onBack,onDone}:{onBack:()=>void;onDone:()=>void}){
 const [name,setName]=useState(''),[description,setDescription]=useState(''),[member,setMember]=useState<Person|null>(null),[selecting,setSelecting]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const key=useRef(requestKey());
 const create=async()=>{
  if(!member||busy||!(await ensureCommunityRules()))return;
  setBusy(true);setError('');
  try{await messaging('create-group',{name,description,memberId:member.uid,requestId:key.current});onDone();}
  catch(e){setError(errorOf(e));}finally{setBusy(false);}
 };
 if(selecting)return <><Header title="Choose a member" onBack={()=>setSelecting(false)}/><PeopleSearch onChoose={p=>{setMember(p);setSelecting(false);}}/></>;
 return <><Header title="Create a group" onBack={onBack}/><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.content}><Glass>
 <Text style={s.heading}>A space for your people</Text><Text style={s.body}>Open group · up to 50 members. Anyone with the group code can join.</Text>
 <TextInput accessibilityLabel="Group name" placeholder="Group name" value={name} onChangeText={setName} maxLength={60} style={s.input}/>
 <TextInput accessibilityLabel="Group description" placeholder="Description (optional)" value={description} onChangeText={setDescription} maxLength={240} multiline style={s.input}/>
 <Text style={s.body}>{member?'Selected member: '+member.name:'Choose at least one other person to start.'}</Text>
 <Chip label={member?'Change member':'Add user'} onPress={()=>setSelecting(true)}/>
 {!!error&&<Text style={s.error}>{error}</Text>}<Button title={busy?'Creating…':'Create group'} disabled={busy||!name.trim()||!member} onPress={()=>void create()}/>
 </Glass></ScrollView></>;
}
function Privacy({uid,onBack}:{uid:string;onBack:()=>void}){
 const [prefs,setPrefs]=useState({requests:'everyone',groupInvites:'everyone',showOnline:false,showLastSeen:false});
 const [ready,setReady]=useState(false),[blocked,setBlocked]=useState<string[]>([]),[note,setNote]=useState(''),[busy,setBusy]=useState(false);
 const profiles=usePublicProfiles(blocked);
 useEffect(()=>{
  const stop=onSnapshot(doc(cloudDbLive(),`users/${uid}/messaging/preferences`),snap=>{
   const d=snap.data()||{};
   setPrefs({requests:d.requests??'everyone',groupInvites:d.groupInvites??d.requests??'everyone',showOnline:d.showOnline??d.showPresence??false,showLastSeen:d.showLastSeen??d.showPresence??false});setReady(true);
  },()=>setNote('Privacy settings could not load.'));
  const blocks=onSnapshot(collection(cloudDbLive(),`users/${uid}/messagingBlocks`),snap=>setBlocked(snap.docs.map(d=>d.id)),()=>setNote('Blocked users could not load.'));
  return ()=>{stop();blocks();};
 },[uid]);
 return <><Header title="Settings" onBack={onBack}/><ScrollView contentContainerStyle={s.content}>
  <Glass><Text style={s.heading}>Privacy</Text>
   {(['requests','groupInvites','showOnline','showLastSeen'] as const).map((key,index)=>{
    const access=key==='requests'||key==='groupInvites',choices=access?['Everyone','Nobody']:['Visible','Hidden'];
    return <View key={key} style={{gap:4}}><Text style={s.body}>{['Who can start a private chat?','Who can invite or add you to groups?','Online status','Last seen'][index]}</Text>
     <View style={s.inline}>{choices.map((label,i)=>{const value=access?label.toLowerCase():i===0;return <Chip key={label} label={label} selected={ready&&prefs[key]===value} onPress={()=>setPrefs({...prefs,[key]:value})}/>;})}</View></View>;
   })}
   <Button title={busy?'Saving…':'Save privacy settings'} disabled={busy||!ready} onPress={async()=>{setBusy(true);try{await messaging('preferences',{...prefs,showPresence:prefs.showOnline||prefs.showLastSeen});setNote('Privacy settings saved.');}catch(e){setNote(errorOf(e));}finally{setBusy(false);}}}/>
   {!!note&&<Text accessibilityLiveRegion="polite" style={s.body}>{note}</Text>}
  </Glass><MessageAlertSettings uid={uid}/><Glass><Text style={s.heading}>Blocked users</Text>
   {!blocked.length&&<Text style={s.body}>Nobody blocked.</Text>}{blocked.map((id,index)=><Button light key={id} title={`Unblock ${profiles.get(id)?.name||'user '+(index+1)}`} onPress={()=>void messaging('block',{uid:id,blocked:false}).catch(e=>setNote(errorOf(e)))}/>)}</Glass>
 </ScrollView></>;
}
function ReceivedAttachment({conversationId,message}:{conversationId:string;message:PrivateMessage}){
 const [image,setImage]=useState(''),[loading,setLoading]=useState(false),[error,setError]=useState('');
 const [expired,setExpired]=useState(()=>Date.now()>=(message.attachmentExpiresAt??0));
 useEffect(()=>{
  if(expired)return;
  let timer:ReturnType<typeof setTimeout>;
  const check=()=>{
   const remaining=(message.attachmentExpiresAt??0)-Date.now();
   if(remaining<=0){setExpired(true);setImage('');return;}
   timer=setTimeout(check,Math.min(remaining,86400000));
  };
  check();
  return()=>clearTimeout(timer);
 },[message.attachmentExpiresAt,expired]);
 const open=async()=>{
  setLoading(true);setError('');
  try{
   const result=await messaging('attachment',{conversationId,messageId:message.id});
   if(Date.now()>=(message.attachmentExpiresAt??0)){setExpired(true);return;}
   if(result.fileName)await openChatFile({name:result.fileName,data:result.data});
   else setImage(result.data);
  }catch(e){setError(errorOf(e));}
  finally{setLoading(false);}
 };
 return <View style={s.photoCard}>
  {!!message.fileName&&<Text selectable numberOfLines={2} style={s.body}>{message.fileName}</Text>}
  <Button light icon={message.fileName?'document-outline':'image-outline'} title={expired?'Attachment expired':loading?'Loading…':message.fileName?'Open file':'Open photo'} disabled={expired||loading} onPress={()=>void open()}/>
  {!!error&&<Text accessibilityLiveRegion="polite" style={s.error}>{error}</Text>}
  <Modal visible={!!image&&!expired} onRequestClose={()=>setImage('')} animationType="fade">
   <SafeAreaView style={s.photoViewer}>
    <Header title="Photo" onBack={()=>setImage('')}/>
    {!!image&&<Image accessibilityLabel="Shared photo" style={s.viewerImage} resizeMode="contain" source={{uri:'data:image/jpeg;base64,'+image}}/>}
   </SafeAreaView>
  </Modal>
 </View>;
}
export function MessageBubble({message,mine,read,badges,pinned=false,delivered=false,onPress,conversationId}:{
 message:PrivateMessage;mine:boolean;read:boolean;badges?:ReturnType<typeof useBadges>;
 pinned?:boolean;delivered?:boolean;onPress:(message:PrivateMessage)=>void;conversationId?:string;
}){
 const dark=useContext(chatDark);
 const [quoted,setQuoted]=useState(message.replyText||'Reply');
 const [replySender,setReplySender]=useState(message.replySenderId);
 const [reactions,setReactions]=useState<string[]>([]);
 useEffect(()=>{
  if(!conversationId||!message.replyTo||message.removed)return;
  return onSnapshot(doc(cloudDbLive(),`conversations/${conversationId}/messages/${message.replyTo}`),snapshot=>{
   setQuoted(snapshot.exists()?(snapshot.get('removed')?'Message removed':String(snapshot.get('text')).slice(0,160)):'Message unavailable');
   setReplySender(snapshot.exists()?snapshot.get('senderId'):undefined);
  },()=>setQuoted('Message unavailable'));
 },[conversationId,message.replyTo,message.removed]);
 useEffect(()=>{
  if(!conversationId||message.removed)return;
  return onSnapshot(collection(cloudDbLive(),`conversations/${conversationId}/messages/${message.id}/reactions`),
   snapshot=>setReactions(snapshot.docs.map(d=>d.get('emoji'))),no);
 },[conversationId,message.id,message.removed]);
 const showActions=()=>onPress(message);
 const senderVerified=badges?.has(message.senderId)===true;
 const receipt=read?'Read':delivered?'Delivered':'Sent';
 const muted=dark&&{color:darkColors.muted};
 const pinColor=dark?'#F5CF82':'#935800';
 return <View style={[
  s.bubble,mine?s.mine:s.theirs,
  dark&&{borderColor:darkColors.line,backgroundColor:mine?darkColors.field:darkColors.surface},
  pinned&&{backgroundColor:dark?'#493B25':'#FFF5D6',borderColor:dark?'#E8BE63':'#B87708'},
 ]}>
  <Pressable accessibilityRole="button" accessibilityLabel={`Message from ${message.name}. ${message.text}. Options`}
   onPress={showActions} onLongPress={showActions} style={{gap:2}}>
   {(!mine||senderVerified)&&<View style={[s.inline,{gap:4}]}>
    <Text style={[s.sender,dark&&{color:darkColors.sender}]}>{message.name}</Text>
    <VerifiedBadge verified={senderVerified} tier={badges?.tier(message.senderId)} size={14}/>
   </View>}
   {!message.removed&&message.forwarded&&<Text style={[s.small,muted]}>Forwarded</Text>}
   {!message.removed&&message.replyTo&&<View style={s.reply}>
    <View style={[s.inline,{gap:4}]}>
     <Text style={s.sender}>{message.replyName}</Text>
     <VerifiedBadge verified={badges?.has(replySender||'')===true} tier={badges?.tier(replySender)} size={14}/>
    </View>
    <Text style={s.small} numberOfLines={2}>{quoted}</Text>
   </View>}
   <View style={s.messageLine}>
    {(!message.attachmentExpiresAt||message.attachmentCaption||message.removed)&&
     <Text style={[s.messageText,dark&&{color:darkColors.ink}]}>{message.text}</Text>}
    <View style={s.messageMeta}>
     {pinned&&<Icon name="pin" size={13} color={pinColor}/>}
     <Text style={[s.small,muted]}>{time(message.createdAt)}</Text>
     {mine&&<View accessible accessibilityLabel={receipt}>
      <Icon name={read||delivered?'checkmark-done':'checkmark'} size={15}
       color={read?(dark?'#A9BFFF':C.accent):dark?darkColors.muted:C.muted}/>
     </View>}
    </View>
   </View>
   {!message.removed&&reactions.length>0&&<Text style={[s.body,muted]}>
    {[...new Set(reactions)].map(emoji=>emoji+' '+reactions.filter(value=>value===emoji).length).join('  ')}
   </Text>}
  </Pressable>
  {!!message.attachmentExpiresAt&&!message.removed&&conversationId&&<ReceivedAttachment conversationId={conversationId} message={message}/>}
 </View>;
}
const MemoBubble=React.memo(MessageBubble);
function Conversation({row,uid,onBack,onNote,note,onOpenProfileChat,onToggleDark}:{note:string;onToggleDark:()=>void;row:InboxRow;uid:string;onBack:()=>void;onNote:(v:string)=>void;onOpenProfileChat:(p:ProfileDetails)=>Promise<void>}){
 const [settings,setSettings]=useState(false);
 const [forward,setForward]=useState<{message:PrivateMessage;key:string}|null>(null);
 const [forwarding,setForwarding]=useState(false);
 const forwardLock=useRef(false);
 const inbox=useInbox(uid,!!forward);
 const feed=usePrivateMessages(uid,row),[text,setText]=useState(''),[busy,setBusy]=useState(false),[reply,setReply]=useState<PrivateMessage|null>(null),[selected,setSelected]=useState<PrivateMessage|null>(null),[report,setReport]=useState(false),[detail,setDetail]=useState(false),[groupSettings,setGroupSettings]=useState(false),[members,setMembers]=useState<Person[]>([]),[conversation,setConversation]=useState<Record<string,any>>({}),[typing,setTyping]=useState<{uid:string;until:number}[]>([]),[now,setNow]=useState(Date.now()),[codeOpen,setCodeOpen]=useState(false),[codeQuery,setCodeQuery]=useState(''),[tray,setTray]=useState(false),[menu,setMenu]=useState(false),[reportUser,setReportUser]=useState(false),[strip,setStrip]=useState(false),key=useRef(requestKey()),lastTyping=useRef(0),scroll=useRef<ScrollView>(null),sending=useRef(false);
 const [profilePerson,setProfilePerson]=useState<Person|null>(null),[profileList,setProfileList]=useState<ConnectionList|null>(null);
 const closeProfile=()=>{setProfileList(null);setProfilePerson(null);};
 const openTitle=()=>{
  Keyboard.dismiss();setMenu(false);
  if(row.type==='group'){setGroupSettings(false);setDetail(true);return;}
  if(row.peerId)setProfilePerson(peerBase||{uid:row.peerId,name:row.name,avatar:row.avatar||0,photo:row.photo});
 };
 const [headerHeight,setHeaderHeight]=useState(55);
 useEffect(()=>{
  if(settings){const sub=BackHandler.addEventListener('hardwareBackPress',()=>{setSettings(false);return true;});return ()=>sub.remove();}
  if(!menu)return;
  const sub=BackHandler.addEventListener('hardwareBackPress',()=>{if(reportUser)setReportUser(false);else setMenu(false);return true;});
  return ()=>sub.remove();
 },[menu,reportUser,settings]);
 const selectMessage=React.useCallback((message:PrivateMessage)=>{Keyboard.dismiss();setSelected(message);setReport(false);setTray(false);setCodeOpen(false);},[]);
 const dark=useContext(chatDark);
 const [emojiMode,setEmojiMode]=useState<'compose'|'reaction'|null>(null);
 const followLatest=useRef(true), draftText=useRef(''), newest=useRef('');
 const scrollToLatest=(animated=false)=>{if(followLatest.current)scroll.current?.scrollToEnd({animated});};
 const lastId=feed.rows.at(-1)?.id;
 useEffect(()=>{
  if(!lastId||newest.current===lastId)return;
  const animated=!!newest.current;
  newest.current=lastId;
  const frame=requestAnimationFrame(()=>scrollToLatest(animated));
  return()=>cancelAnimationFrame(frame);
 },[lastId]);
 const [image,setImage]=useState<string|null>(null),[file,setFile]=useState<ChatFile|null>(null),[picking,setPicking]=useState(false);
 const chooseAttachment=async(kind:'photo'|'file')=>{
  setTray(false);setPicking(true);
  try{
   if(kind==='photo'){
    const next=await pickChatPhoto();
    if(next){setImage(next);setFile(null);key.current=requestKey();}
   }else{
    const next=await pickChatFile();
    if(next){setFile(next);setImage(null);key.current=requestKey();}
   }
  }catch(err){onNote(err instanceof Error?err.message:'Could not open that attachment.');}
  finally{setPicking(false);}
 };
 const [receipts,setReceipts]=useState<Record<string,{readAt?:unknown;deliveredAt?:unknown}>>({});
 useEffect(()=>{setReceipts({});return onSnapshot(collection(cloudDbLive(),`conversations/${row.id}/receipts`),snap=>setReceipts(Object.fromEntries(snap.docs.map(d=>[d.id,d.data()]))),()=>{});},[row.id]);
 const reloadRoster=()=>void messaging('roster',{conversationId:row.id}).then(r=>{setMembers(r.members||[]);setConversation(current=>Object.keys(current).length?current:r.conversation||{});},e=>onNote(errorOf(e)));
 useEffect(()=>{reloadRoster();let signature='';return onSnapshot(doc(cloudDbLive(),'conversations',row.id),snap=>{const c=snap.data();if(!c)return;const next=JSON.stringify([c.members,c.roles,c.ownerId,c.name,c.description,c.status,c.photo,c.groupIcon,c.adminsOnly]);if(signature&&signature!==next)reloadRoster();signature=next;setConversation({id:row.id,...c});},e=>onNote(errorOf(e)));},[row.id]);
 useEffect(()=>{if(!['active','closed'].includes(row.status))return;const read=()=>{if(AppState.currentState==='active')void messaging('read',{conversationId:row.id}).catch(no);};read();const timer=setInterval(read,30000);const sub=AppState.addEventListener('change',state=>{if(state==='active')read();else void messaging('viewing',{conversationId:row.id}).catch(no);});return()=>{clearInterval(timer);sub.remove();void messaging('viewing',{conversationId:row.id}).catch(no);};},[row.id,row.status]);
 useEffect(()=>{if(row.status==='active'&&feed.rows.length&&AppState.currentState==='active')void messaging('read',{conversationId:row.id}).catch(no);},[row.id,row.status,feed.rows.at(-1)?.id]);
 useEffect(()=>{if(row.status!=='active')return;const stop=onSnapshot(collection(cloudDbLive(),`conversations/${row.id}/typing`),s=>setTyping(s.docs.filter(d=>d.id!==uid&&d.get('until')>Date.now()).map(d=>({uid:d.id,until:d.get('until')}))),()=>{});const timer=setInterval(()=>setNow(Date.now()),3000);return()=>{stop();clearInterval(timer);};},[row.id,row.status]);
 const call=async(command:string,data:Record<string,unknown>={})=>{try{const result=await messaging(command,{conversationId:row.id,...data});setSelected(null);setReport(false);return result;}catch(e){onNote(errorOf(e));}};
 const reportPerson=(reason:string)=>{if(!row.peerId)return;confirmAction(`Report ${row.name}?`,'A moderator will review this account. They aren’t told who reported them.',()=>void messaging('report-user',{uid:row.peerId,reason}).then(r=>{setReportUser(false);setMenu(false);onNote(r?.duplicate?'You already reported this member. A moderator will review it.':'Report sent. A moderator will review this member. You can also block them here.');},e=>onNote(errorOf(e))),'Report');};
 const blockPerson=()=>{if(!row.peerId)return;confirmAction(`Block ${row.name}?`,'You will no longer receive their private messages. You can unblock them in Settings.',()=>void messaging('block',{uid:row.peerId,blocked:true}).then(onBack,e=>onNote(errorOf(e))),'Block');};
 // A request from an earlier build opens by itself: there is nothing to accept any more.
 useEffect(()=>{if(row.status!=='pending'||row.type!=='personal'||!row.peerId)return;void messaging('request',{uid:row.peerId}).catch(e=>onNote(errorOf(e)));},[row.id,row.status]);
 const send=async()=>{
  if(sending.current||picking||(!draftText.current.trim()&&!image&&!file))return;
  sending.current=true;
  setBusy(true);
  const draft=draftText.current, requestId=key.current;
  try{
   if(!(await ensureCommunityRules()))return;
   onNote('');
   await messaging('send',{conversationId:row.id,text:draft,requestId,...(image?{image}:{}),...(file?{file}:{}),...(reply?{replyTo:reply.id}:{})});
   if(key.current===requestId){draftText.current='';setText('');key.current=requestKey();}
   setImage(null);setFile(null);setReply(null);
   followLatest.current=true;scrollToLatest(true);
   if(!draftText.current)void messaging('typing',{conversationId:row.id,typing:false}).catch(no);
  }catch(e){onNote(errorOf(e)+' Your draft is kept; tap Send to retry.');}
  finally{sending.current=false;setBusy(false);}
 };
 const onText=(v:string)=>{draftText.current=v;setText(v);key.current=requestKey();if(Date.now()-lastTyping.current>4000&&row.status==='active'){lastTyping.current=Date.now();void messaging('typing',{conversationId:row.id,typing:!!v}).catch(no);}};
 const react=(emoji:string)=>{if(!selected)return;setEmojiMode(null);void call('react',{messageId:selected.id,emoji});};
 const [peerPresence,setPeerPresence]=useState<{online?:boolean;onlineUntil?:number;lastSeen?:number}>({online:false});useEffect(()=>{setPeerPresence({online:false});if(!row.peerId)return;return onSnapshot(doc(cloudDbLive(),'messagingPresence',row.peerId),snap=>setPeerPresence({online:snap.get('onlineUntil')>Date.now(),onlineUntil:snap.get('onlineUntil'),lastSeen:ms(snap.get('lastSeen'))}),()=>setPeerPresence({online:false,lastSeen:undefined}));},[row.peerId]);
 const peerBase=members.find(m=>m.uid===row.peerId),peer=peerBase?{...peerBase,...peerPresence,online:peerPresence.online===true&&(peerPresence.onlineUntil||0)>now}:undefined,deliveredAt=Math.min(...members.filter(m=>m.uid!==uid).map(m=>ms(receipts[m.uid]?.deliveredAt))),readAt=Math.min(...members.filter(m=>m.uid!==uid).map(m=>Math.max(m.readAt||0,ms(receipts[m.uid]?.readAt)))),myRole=conversation.roles?.[uid],canModerate=row.type==='group'&&['owner','admin','moderator'].includes(myRole);
 const badges=useBadges([uid,row.peerId||'',...members.map(m=>m.uid),...feed.rows.flatMap(m=>[m.senderId,m.replySenderId||'']),...inbox.rows.map(r=>r.peerId||'')]);
 const canSend=row.status==='active'&&(row.type!=='group'||!conversation.adminsOnly||conversation.ownerId===uid||myRole==='admin');
 const typingPeople=typing.filter(t=>t.until>now);
 if(settings)return <Privacy uid={uid} onBack={()=>setSettings(false)}/>;
 if(detail)return <chatDark.Provider value={false}><View style={[s.fill,{backgroundColor:C.bg}]}><GroupDetails initialEdit={groupSettings} row={row} uid={uid} members={members} presence={peer?.online?'Online':peer?.lastSeen?'Last seen '+new Date(peer.lastSeen).toLocaleString():undefined} conversation={conversation} onBack={()=>{setDetail(false);}} onCall={call} onRefresh={reloadRoster} onLeave={onBack} onOpenProfileChat={onOpenProfileChat}/>{!!note&&<Notice text={note} onDismiss={()=>onNote('')}/>}</View></chatDark.Provider>;
 return <><View onLayout={e=>setHeaderHeight(e.nativeEvent.layout.height)}><Header badge={<VerifiedBadge verified={badges.has(row.peerId||'')} tier={badges.tier(row.peerId)}/>} avatar={<Avatar person={row.type==='personal'&&peerBase?peerBase:{...row,photo:row.type==='group'?conversation.photo??row.photo:row.photo,groupIcon:conversation.groupIcon??row.groupIcon}} size={32}/>} title={peerBase?.name||row.name} onTitle={row.type==='group'||row.peerId?openTitle:undefined} titleLabel={row.type==='group'?'View group details':'View profile of '+row.name} subtitle={row.type==='group'?`${row.memberCount||members.length} members`:'Private conversation'} onBack={onBack} action={<Pressable accessibilityRole="button" accessibilityLabel="More options" accessibilityState={{expanded:menu}} onPress={()=>{Keyboard.dismiss();setReportUser(false);setMenu(v=>!v);}} style={{width:44,height:44,alignItems:'center',justifyContent:'center'}}>
  <Icon name="ellipsis-vertical" size={20} color={dark?darkColors.ink:C.ink}/>
 </Pressable>}/></View>
 {forward&&<Modal visible onRequestClose={()=>{if(!forwardLock.current)setForward(null);}}>
  <SafeAreaView style={s.screen}><Header title="Forward message" onBack={()=>{if(!forwardLock.current)setForward(null);}}/>
   <ScrollView contentContainerStyle={s.content}>{inbox.rows.filter(r=>r.status==='active'&&!r.deleted&&(!forward.message.attachmentExpiresAt||r.type==='personal')).map(r=><View key={r.id} style={s.inline}><View style={{flex:1}}><Button light title={r.name} disabled={forwarding} onPress={()=>{if(forwardLock.current)return;forwardLock.current=true;setForwarding(true);void (async()=>{
    try{if(!(await ensureCommunityRules()))return;await messaging('send',{conversationId:r.id,forwardFrom:{conversationId:row.id,messageId:forward.message.id},requestId:forward.key});setForward(null);onNote('Message forwarded.');
    }catch(e){setForward(null);onNote(errorOf(e));}finally{forwardLock.current=false;setForwarding(false);}
   })();}}/></View>{r.type==='personal'&&<VerifiedBadge verified={badges.has(r.peerId||'')} tier={badges.tier(r.peerId)}/>}</View>)}</ScrollView>
  </SafeAreaView>
 </Modal>}
 {profilePerson&&<Modal visible animationType="none" onRequestClose={()=>profileList?setProfileList(null):closeProfile()}>
  <SafeAreaView style={s.screen}>{profileList?<ConnectionsScreen target={profilePerson.uid} list={profileList} onBack={()=>setProfileList(null)} onChoose={p=>{if(p.uid!==uid){setProfileList(null);setProfilePerson(p);}}}/>:<>
   <Header title="Member profile" onBack={closeProfile}/><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.content}><PersonProfile key={profilePerson.uid} person={profilePerson} onConnections={setProfileList} onMessage={async p=>{if(p.uid!==row.peerId)await onOpenProfileChat(p);closeProfile();}}/></ScrollView>
  </>}</SafeAreaView></Modal>}
 {menu&&<OverflowMenu headerHeight={headerHeight} onDismiss={()=>setMenu(false)}>
    {reportUser?<>{USER_REPORT_REASONS.map(reason=><ChatMenuItem key={reason} label={reason} onPress={()=>reportPerson(reason)}/>)}<ChatMenuItem label="Back" onPress={()=>setReportUser(false)}/></>:<>
     {row.type==='personal'&&row.peerId&&<ChatMenuItem label="View profile" onPress={openTitle}/>}
     <ChatMenuItem label={row.type==='group'?'Group info':'Chat details'} onPress={()=>{setMenu(false);setGroupSettings(false);setDetail(true);}}/>
     <ChatMenuItem label={row.muted?'Unmute':'Mute'} onPress={()=>{setMenu(false);void call('inbox-settings',{muted:!row.muted});}}/>
     <ChatMenuItem label={row.pinned?'Unpin chat':'Pin chat'} onPress={()=>{setMenu(false);void call('inbox-settings',{pinned:!row.pinned});}}/>
     <ChatMenuItem label="Clear history" onPress={()=>{setMenu(false);confirmAction('Clear chat history?','Earlier messages will be hidden for you.',()=>void call('inbox-settings',{clearHistory:true}),'Clear');}}/>
     <ChatMenuItem label="Settings" onPress={()=>{setMenu(false);if(row.type==='group'&&(conversation.ownerId===uid||myRole==='admin')){setGroupSettings(true);setDetail(true);}else setSettings(true);}}/>
     <ChatMenuItem label={dark?'Light theme':'Dark theme'} onPress={()=>{setMenu(false);onToggleDark();}}/>
     {row.type==='personal'&&row.status==='active'&&<><ChatMenuItem label="Report" onPress={()=>setReportUser(true)}/><ChatMenuItem label="Block" onPress={()=>{setMenu(false);blockPerson();}}/></>}
    </>}
 </OverflowMenu>}
 {row.status==='pending'?<View style={[s.content,{alignItems:'center'}]}><ActivityIndicator color={C.accent}/><Text style={s.body}>Opening conversation…</Text></View>:!['active','closed'].includes(row.status)?<View style={s.content}><Text style={s.body}>This conversation is {row.status}. You cannot send messages.</Text></View>:<><ScrollView removeClippedSubviews={false} ref={scroll} style={s.fill} keyboardShouldPersistTaps="handled" contentContainerStyle={s.messages}
   maintainVisibleContentPosition={{minIndexForVisible:0}} scrollEventThrottle={32}
   onScroll={({nativeEvent:{layoutMeasurement,contentOffset,contentSize}})=>{followLatest.current=contentSize.height-contentOffset.y-layoutMeasurement.height<56;}}
   onLayout={()=>scrollToLatest()} onContentSizeChange={()=>scrollToLatest()}>
 {row.type==='personal'&&!strip&&feed.rows.some(m=>m.senderId!==uid)&&!feed.rows.some(m=>m.senderId===uid)&&<View style={s.safety}><Icon name="shield-checkmark-outline" size={22} color={C.accent}/><View style={{flex:1,gap:8}}><Text style={s.body}>Don’t know this person? You can report or block them any time.</Text><View style={s.wrap}><Chip icon="flag-outline" label="Report" onPress={()=>{setMenu(true);setReportUser(true);}}/><Chip icon="ban-outline" label="Block" onPress={blockPerson}/></View></View><RoundIcon name="close" label="Dismiss safety tip" onPress={()=>setStrip(true)}/></View>}
  {feed.more&&<Button light title="Load older messages" disabled={feed.loading} onPress={()=>{followLatest.current=false;void feed.loadOlder();}}/>}
  {!!feed.error&&<><Text style={s.error}>{feed.error}</Text><Button light title="Retry messages" onPress={feed.retry}/></>}{feed.loading&&<ActivityIndicator color={C.accent}/>}{!feed.loading&&!feed.rows.length&&<Text style={[s.body,{textAlign:'center',padding:20}]}>Say hello. Your conversation starts here.</Text>}
 {feed.rows.map(m=><MemoBubble key={m.id} message={m} badges={badges} pinned={row.pinnedMessageId===m.id} mine={m.senderId===uid} read={readAt>=ms(m.createdAt)&&members.length>1} delivered={deliveredAt>=ms(m.createdAt)&&members.length>1} onPress={selectMessage} conversationId={row.id}/>)}
 </ScrollView>{selected&&<View style={[s.actionPanel,dark&&darkSurface]}>
 {report&&<Text style={[s.heading,dark&&{color:darkColors.ink}]}>Report message</Text>}
 <View style={s.wrap}>
  {report?REPORT_REASONS.map(reason=><Chip key={reason} label={reason} onPress={()=>void call('report',{messageId:selected.id,reason})}/>):<>
   {row.status==='active'&&<MessageAction name={row.pinnedMessageId===selected.id?'pin':'pin-outline'} label={row.pinnedMessageId===selected.id?'Unpin message':'Pin message for me'} onPress={()=>void call('pin-message',{messageId:selected.id,pinned:row.pinnedMessageId!==selected.id})}/>}
   <MessageAction name="arrow-undo-outline" label="Reply" onPress={()=>{if(!busy){setReply(selected);key.current=requestKey();}setSelected(null);}}/>
   <MessageAction name="copy-outline" label="Copy message" onPress={()=>{void Clipboard.setStringAsync(selected.text).then(()=>onNote('Message copied.'));setSelected(null);}}/>
   {!selected.removed&&<MessageAction name="arrow-redo-outline" label="Forward" onPress={()=>{setForward({message:selected,key:requestKey()});setSelected(null);}}/>}
   <MessageAction name="eye-off-outline" label="Delete for me" onPress={()=>confirmAction('Hide this message?','It will disappear only for you.',()=>void call('hide-message',{messageId:selected.id}),'Hide')}/>
   {selected.senderId!==uid&&<MessageAction name="flag-outline" label="Report message" onPress={()=>setReport(true)}/>}
   {!selected.removed&&((canModerate&&row.status==='active')||(row.type==='personal'&&selected.senderId===uid))&&<MessageAction name="trash-outline" label="Delete for everyone" onPress={()=>confirmAction('Delete this message?','Everyone in this conversation will see a removal notice.',()=>void call('remove-message',{messageId:selected.id}),'Delete')}/>}
  </>}
  <MessageAction name="close" label="Close message actions" onPress={()=>setSelected(null)}/>
 </View>
 {!report&&row.status==='active'&&!selected.removed&&<View style={s.wrap}>{quickEmoji.map(({glyph,name})=><Pressable key={glyph} accessibilityRole="button" accessibilityLabel={name} style={s.emojiBtn} onPress={()=>react(glyph)}><Text style={{fontSize:22}}>{glyph}</Text></Pressable>)}<MessageAction name="add" label="More reactions" onPress={()=>setEmojiMode('reaction')}/></View>}
 </View>}
 {emojiMode&&<EmojiPicker dark={dark} onClose={()=>setEmojiMode(null)} onClear={emojiMode==='reaction'?()=>react(''):undefined}
  onPick={glyph=>{if(emojiMode==='reaction'){react(glyph);return;}const next=draftText.current+glyph;if(next.length<=1500)onText(next);setEmojiMode(null);}}/>}
 {typingPeople.length>0&&<View style={[s.inline,{flexWrap:'wrap',paddingHorizontal:16}]}>{typingPeople.map(t=><View key={t.uid} style={[s.inline,{gap:3}]}><Text style={s.small}>{members.find(m=>m.uid===t.uid)?.name||'Someone'}</Text><VerifiedBadge verified={badges.has(t.uid)} tier={badges.tier(t.uid)} size={12}/></View>)}<Text style={s.small}>typing…</Text></View>}
 {!!note&&<Notice text={note} onDismiss={()=>onNote('')}/>}
 {canSend?<View style={[s.composer,dark&&darkSurface]}>
 {(image||file)&&<View style={s.inline}>
  {image?<Image style={s.draftPreview} source={{uri:'data:image/jpeg;base64,'+image}}/>:<Icon name="document-outline" color={C.accent}/>}
  <View style={{flex:1}}><Text numberOfLines={1} style={[s.heading,dark&&{color:darkColors.ink}]}>{file?.name??'Photo attached'}</Text><Text style={[s.small,dark&&{color:darkColors.muted}]}>Attachments expire after {CHAT_ATTACHMENT_DAYS} days.</Text></View>
  <RoundIcon name="close" label="Remove attachment" onPress={()=>{if(!busy){setImage(null);setFile(null);key.current=requestKey();}}}/>
 </View>}
 
 {codeOpen&&<View style={{gap:6}}><TextInput accessibilityLabel="Find a dictionary code to share" placeholder="Find a Codebook word…" placeholderTextColor={C.muted} value={codeQuery} onChangeText={setCodeQuery} maxLength={120} style={s.input}/><ScrollView removeClippedSubviews={false} style={{maxHeight:180}} keyboardShouldPersistTaps="handled">{!!codeQuery.trim()&&search(codeQuery).slice(0,6).map(t=><Pressable key={t.id} accessibilityRole="button" accessibilityLabel={'Share '+t.expression} style={{padding:8}} onPress={()=>{const value=[text,`${t.expression}: ${t.meaning}`,t.example?'Example: '+t.example:''].filter(Boolean).join('\n');if(value.length>1500){onNote('This code will not fit in the current message. Shorten your draft first.');return;}onText(value);setCodeOpen(false);setCodeQuery('');}}><Text style={s.heading}>{t.expression}</Text><Text style={s.small} numberOfLines={2}>{t.meaning}</Text></Pressable>)}</ScrollView><Chip label="Close dictionary" onPress={()=>setCodeOpen(false)}/></View>}{reply&&<View style={s.inline}><View style={{flex:1}}><Text style={s.sender}>Replying to {reply.name}</Text><Text style={s.small} numberOfLines={1}>{reply.text}</Text></View><RoundIcon name="close" label="Cancel reply" onPress={()=>{if(!busy){setReply(null);key.current=requestKey();}}}/></View>}{tray&&<View style={s.tray} accessibilityLabel="Attachment options">
   {row.type==='personal'&&<><TrayButton icon="image-outline" tint="#7C3AED" label="Attach photo" onPress={()=>{if(!busy&&!picking)void chooseAttachment('photo');}}/><TrayButton icon="document-outline" tint={C.accent} label="Attach file" onPress={()=>{if(!busy&&!picking)void chooseAttachment('file');}}/></>}
   <TrayButton icon="book-outline" tint="#0D9A60" label="Share a Codebook word" onPress={()=>{setTray(false);setCodeOpen(true);}}/>
  </View>}
  <View style={s.composeRow}>
   <Pressable accessibilityRole="button" accessibilityLabel={tray?'Close attachment options':'Add attachment'} accessibilityState={{expanded:tray}} disabled={busy||picking} onPress={()=>setTray(v=>!v)} style={[s.plus,tray&&{backgroundColor:C.accent,borderColor:C.accent}]}>{picking?<ActivityIndicator accessibilityLabel="Preparing attachment" color={C.accent}/>:<Icon name={tray?'close':'add'} size={26} color={tray?'#fff':C.accent}/>}</Pressable>
   <View style={[s.inputWrap,dark&&{backgroundColor:darkColors.field,borderColor:darkColors.line}]}><TextInput accessibilityLabel="Message" placeholder="Message…" placeholderTextColor={dark?darkColors.muted:C.muted} value={text} onChangeText={onText} maxLength={1500} multiline submitBehavior="newline" onFocus={()=>{setTray(false);setSelected(null);setCodeOpen(false);}} style={[s.inputText,dark&&{color:darkColors.ink}]}/><Pressable accessibilityRole="button" accessibilityLabel="Open emoji picker" hitSlop={4} onPress={()=>{Keyboard.dismiss();setEmojiMode('compose');}} style={s.emojiBtn}><Icon name="happy-outline" size={22} color={dark?darkColors.muted:C.muted}/></Pressable></View>
   <Pressable accessibilityRole="button" accessibilityLabel="Send message" disabled={busy||picking||(!text.trim()&&!image&&!file)} onPress={()=>void send()} style={[s.send,(busy||picking||(!text.trim()&&!image&&!file))&&{opacity:.45}]}>{busy?<ActivityIndicator color="#fff"/>:<Icon name="send" color="#fff" size={19}/>}</Pressable>
  </View>{text.length>1300&&<Text style={s.small}>{text.length}/1500</Text>}</View>:<Text style={[s.body,{padding:16}]}>{row.status==='active'?'Only group admins can send messages here.':'This conversation is closed. Earlier messages remain available.'}</Text>}</>}
 </>;
}
function TrayButton({icon,tint,label,onPress}:{icon:IconName;tint:string;label:string;onPress:()=>void}){return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({pressed})=>[s.trayBtn,{backgroundColor:tint},pressed&&{opacity:.8}]}><Icon name={icon} size={25} color="#fff"/></Pressable>;}
function GroupDetails({initialEdit,row,uid,members,presence,conversation,onBack,onCall,onRefresh,onLeave,onOpenProfileChat}:{initialEdit:boolean;row:InboxRow;uid:string;members:Person[];presence?:string;conversation:Record<string,any>;onBack:()=>void;onCall:(c:string,d?:Record<string,unknown>)=>Promise<Record<string,any>|undefined>;onRefresh:()=>void;onLeave:()=>void;onOpenProfileChat:(p:ProfileDetails)=>Promise<void>}){
 const [memberAnchor,setMemberAnchor]=useState<MenuAnchor>();
 const [actionsFor,setActionsFor]=useState<string|null>(null);
 const [copied,setCopied]=useState(false),[copyError,setCopyError]=useState('');
 const [invite,setInvite]=useState(false),[person,setPerson]=useState<Person|null>(null),[edit,setEdit]=useState(initialEdit),[name,setName]=useState(conversation.name||row.name),[description,setDescription]=useState(conversation.description||'');
 const [photo,setPhoto]=useState<string|undefined>();
 const [groupIcon,setGroupIcon]=useState<GroupIcon|null>(null);
 const [adminsOnly,setAdminsOnly]=useState(conversation.adminsOnly===true);
 const [saving,setSaving]=useState(false);
 const [choosingPhoto,setChoosingPhoto]=useState(false);
 const badges=useBadges(members.map(member=>member.uid));
 // Build 88: the app's own cropper replaces the Android crop screen, whose toolbar was black and hidden under the status bar.
 const cropper=usePhotoCropper('Crop group photo');
 const choosePhoto=async()=>{
  setChoosingPhoto(true);setCopyError('');
  try{
   const picked=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],allowsEditing:false,quality:1});
   if(picked.canceled||!picked.assets?.[0])return;
   const asset=picked.assets[0];
   const rect=await cropper.crop({uri:asset.uri,width:asset.width,height:asset.height},'circle');
   if(!rect)return;
   const thumbnail=await ImageManipulator.manipulateAsync(asset.uri,[{crop:rect},{resize:{width:128,height:128}}],{compress:.7,format:ImageManipulator.SaveFormat.JPEG,base64:true});
   if(!thumbnail.base64)throw new Error('Could not prepare this photo.');
   setPhoto(thumbnail.base64);setGroupIcon(null);
  }catch(e){setCopyError(errorOf(e));}
  finally{setChoosingPhoto(false);}
 };
 const [connections,setConnections]=useState<ConnectionList|null>(null);
 const owner=conversation.ownerId===uid,role=conversation.roles?.[uid],admin=owner||role==='admin',moderator=admin||role==='moderator';
 const m=members.find(item=>item.uid===actionsFor);
 useEffect(()=>{if(!actionsFor)return;const back=BackHandler.addEventListener('hardwareBackPress',()=>{setActionsFor(null);return true;});return ()=>back.remove();},[actionsFor]);
 const open=conversation.privacy==='open';
 if(invite&&open)return <><Header title="Add a member" onBack={()=>setInvite(false)}/><PeopleSearch onChoose={p=>confirmAction('Add '+p.name+'?','They will join the group immediately.',()=>void onCall('add-member',{uid:p.uid}).then(r=>{if(r)setInvite(false);}), 'Add')}/></>;
 if(invite)return <><Header title="Invite a member" onBack={()=>setInvite(false)}/><PeopleSearch onChoose={p=>confirmAction(`Invite ${p.name}?`,'They must accept before joining or reading new messages.',()=>void onCall('invite',{uid:p.uid}).then(r=>{if(r)setInvite(false);}), 'Invite')}/></>;
 if(person&&connections)return <ConnectionsScreen key={person.uid+connections} target={person.uid} list={connections} onBack={()=>setConnections(null)} onChoose={next=>{setConnections(null);if(next.uid!==uid)setPerson(next);}}/>;
 if(person)return <><Header title="Member profile" onBack={()=>setPerson(null)}/><ScrollView removeClippedSubviews={false} contentContainerStyle={s.content}><PersonProfile key={person.uid} person={person} onConnections={setConnections} onMessage={async p=>{await onOpenProfileChat(p);setPerson(null);}}/></ScrollView></>;
 return <><Header title={edit?'Settings':row.type==='group'?'Group info':'Conversation details'} onBack={onBack}/>{cropper.element}<ScrollView removeClippedSubviews={false} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled"><Glass><View style={s.inline}>{row.type==='group'&&<Avatar person={{...row,photo:groupIcon?'':photo?'data:image/jpeg;base64,'+photo:conversation.photo??row.photo,groupIcon:groupIcon??conversation.groupIcon??row.groupIcon}}/>}<Text style={s.title}>{row.name}</Text><VerifiedBadge verified={badges.has(row.peerId||'')} tier={badges.tier(row.peerId)}/></View><Text style={s.body}>{conversation.description|| (row.type==='group'?(open?'Open group':'Private group · '+(conversation.privacy||'invite-only')):'Private conversation')}</Text>{presence&&<Text style={s.small}>{presence}</Text>}{row.type==='group'&&open&&row.status==='active'&&conversation.status==='active'&&<>
   <Text style={s.heading}>Group code</Text>
   <Text selectable style={s.body}>{row.id}</Text>
   <View style={s.wrap}>
    <Chip label={copied?'Code copied':'Copy code'} icon="copy-outline" onPress={()=>void Clipboard.setStringAsync(row.id).then(()=>{setCopied(true);setCopyError('');},e=>setCopyError(errorOf(e)))}/>
    <Chip label="Share code" icon="share-outline" onPress={()=>{setCopyError('');void Share.share({message:row.id}).catch(e=>setCopyError(errorOf(e)));}}/>
   </View>
  </>}
  {row.type==='group'&&conversation.status==='active'&&!open&&<Text style={s.small}>This group is invite-only. An owner, admin or moderator can invite members.</Text>}
  <View style={s.wrap}><MenuAction icon={row.muted?'notifications-outline':'notifications-off-outline'} label={row.muted?'Unmute':'Mute'} onPress={()=>void onCall('inbox-settings',{muted:!row.muted})}/>
  {row.type==='group'&&row.status==='active'&&(open||moderator)&&<MenuAction icon="person-add-outline" label={open?'Add member':'Invite member'} onPress={()=>setInvite(true)}/>}
  {row.type==='group'&&admin&&<MenuAction icon="create-outline" label="Settings" onPress={()=>{setName(conversation.name||row.name);setDescription(conversation.description||'');setAdminsOnly(conversation.adminsOnly===true);setPhoto(undefined);setGroupIcon(null);setEdit(v=>!v);}}/>}</View>{!!copyError&&<Text style={s.error}>{copyError}</Text>}{edit&&<><TextInput accessibilityLabel="Edit group name" value={name} maxLength={60} onChangeText={setName} style={s.input}/><TextInput accessibilityLabel="Edit group description" value={description} maxLength={240} onChangeText={setDescription} style={s.input}/><View style={s.wrap}><Chip label="Upload group image" icon="image-outline" onPress={()=>{if(!choosingPhoto&&!saving)void choosePhoto();}}/>{groupIcons.map((icon,index)=><Chip key={icon} label={['People','Chat','Planet','Gaming'][index]!} icon={icon} selected={groupIcon===icon} onPress={()=>{setPhoto(undefined);setGroupIcon(icon);}}/>)}</View>
 <Text style={s.heading}>Who can send messages?</Text><View style={s.wrap}><Chip label="Open for everyone" selected={!adminsOnly} onPress={()=>setAdminsOnly(false)}/><Chip label="Only admins" selected={adminsOnly} onPress={()=>setAdminsOnly(true)}/></View>
 <Button title="Save group" disabled={saving||choosingPhoto} onPress={()=>{setSaving(true);void onCall('group-update',{name,description,adminsOnly,...(groupIcon||photo?{photo:groupIcon?'':photo,...(groupIcon?{groupIcon}:{})}:{})}).then(r=>{if(r){setEdit(false);onRefresh();}}).finally(()=>setSaving(false));}}/></>}</Glass><Text style={s.heading}>{row.type==='group'?`Members · ${members.length}`:'Participants'}</Text>
 {members.map(m=><Glass key={m.uid}><View style={s.inline}><Pressable accessibilityRole="button" accessibilityLabel={'View profile '+m.name} onPress={()=>m.uid!==uid&&setPerson(m)} style={[s.inline,{flex:1}]}><Avatar person={m}/><View style={{flex:1}}><View style={s.inline}><Text style={s.heading}>{m.name}{m.uid===uid?' (you)':''}</Text><VerifiedBadge verified={badges.has(m.uid)} tier={badges.tier(m.uid)}/></View><Text style={s.small}>{row.type==='group'?m.role:'Community member'}</Text></View></Pressable>{m.uid!==uid&&<RowOptions label={'Options for '+m.name} expanded={actionsFor===m.uid} onOpen={anchor=>{setMemberAnchor(anchor);setActionsFor(m.uid);}}/>}</View></Glass>)}
 {row.type==='group'&&row.status==='active'&&<><Button light title={owner?'Transfer ownership above before leaving':'Leave group'} disabled={owner} onPress={()=>confirmAction('Leave this group?','You will lose access to its messages.',()=>void onCall('group-member',{uid,role:'remove'}).then(r=>{if(r)onLeave();}),'Leave')}/>{owner&&<Button light title="Close group" onPress={()=>confirmAction('Close this group?','Members can read earlier messages but nobody can send new ones.',()=>void onCall('close-group').then(r=>{if(r)onLeave();}),'Close group')}/>}</>}
 </ScrollView>{m&&<OverflowMenu anchor={memberAnchor} onDismiss={()=>setActionsFor(null)}><ChatMenuItem label="Block private messages" onPress={()=>{setActionsFor(null);confirmAction(`Block ${m.name}?`,'Private conversations and invitations between you will be blocked. You can unblock in Settings.',()=>void messaging('block',{uid:m.uid,blocked:true}).then(onLeave,e=>confirmAction('Could not block',errorOf(e),no,'OK')),'Block');}}/>{row.type==='group'&&moderator&&m.uid!==conversation.ownerId&&<ChatMenuItem label="Remove member" onPress={()=>{setActionsFor(null);confirmAction(`Remove ${m.name}?`,'This member will no longer be able to read or send messages in the group.',()=>void onCall('group-member',{uid:m.uid,role:'remove'}).then(onRefresh),'Remove');}}/>}
  {row.type==='group'&&owner&&(['admin','moderator','member','owner']as const).map(r=><ChatMenuItem key={r} label={r==='owner'?'Transfer ownership':'Make '+r} onPress={()=>{setActionsFor(null);confirmAction(r==='owner'?'Transfer group ownership?':`Assign ${r}?`,r==='owner'?'This member will become the owner and you will become an administrator.':`Change the group role for ${m.name}.`,()=>void onCall('group-member',{uid:m.uid,role:r}).then(onRefresh),'Confirm');}}/>)}</OverflowMenu>}</>;
}
const s=StyleSheet.create({inboxRows:{borderWidth:1,borderColor:C.line,borderRadius:14,overflow:'hidden'},rowDivider:{borderTopWidth:StyleSheet.hairlineWidth,borderTopColor:C.line},photoCard:{gap:6},photoViewer:{flex:1,backgroundColor:'#10101A'},viewerImage:{width:'100%',flex:1},draftPreview:{width:50,height:50,borderRadius:9},publicCard:{borderWidth:1,borderColor:C.line,borderRadius:24,overflow:'hidden',backgroundColor:'#fff'},publicStats:{paddingHorizontal:15,gap:16,flexDirection:'row',flexWrap:'wrap',backgroundColor:'#fff'},publicStat:{minHeight:40,justifyContent:'center'},publicActions:{padding:13,gap:8,backgroundColor:'#FAF9FD'},screen:{flex:1,minHeight:0,backgroundColor:C.bg},fill:{flex:1,minHeight:0},header:{paddingHorizontal:9,paddingVertical:5,gap:7,flexDirection:'row',alignItems:'center',borderBottomWidth:1,borderBottomColor:C.line,backgroundColor:'#fff'},title:{fontFamily:chatFont,fontSize:17,fontWeight:'400',color:C.ink},heading:{fontFamily:chatFont,fontSize:15,fontWeight:'400',color:C.ink},body:{fontFamily:chatFont,fontSize:13,lineHeight:19,color:C.muted},small:{fontFamily:chatFont,fontSize:11,lineHeight:16,color:C.muted},sender:{fontFamily:chatFont,fontSize:12,fontWeight:'400',color:C.purple},inline:{flexDirection:'row',alignItems:'center',gap:8},content:{padding:14,gap:12,paddingBottom:28,width:'100%',maxWidth:620,alignSelf:'center'},wrap:{flexDirection:'row',flexWrap:'wrap',gap:7},input:{fontFamily:chatFont,borderRadius:14,borderWidth:1,borderColor:C.line,backgroundColor:'#fff',paddingHorizontal:13,paddingVertical:12,color:C.ink,fontSize:14,minHeight:45},inboxCardUnread:{backgroundColor:'#DBEAFE',borderColor:'#60A5FA'},inboxCard:{backgroundColor:'#fff'},inboxRow:{padding:13,gap:11,flexDirection:'row',alignItems:'center',minHeight:76,paddingRight:42},options:{position:'absolute',right:0,top:26},groupAvatar:{alignItems:'center',justifyContent:'center',backgroundColor:'#EEE8FF'},badge:{minWidth:22,height:22,borderRadius:11,backgroundColor:C.accent,alignItems:'center',justifyContent:'center',paddingHorizontal:5},badgeText:{fontFamily:chatFont,fontSize:11,fontWeight:'400',color:'#fff'},error:{fontFamily:chatFont,color:C.danger,fontSize:13,lineHeight:19},notice:{padding:12,gap:8,flexDirection:'row',alignItems:'center',backgroundColor:'#FFF4D7'},messages:{flexGrow:1,justifyContent:'flex-end',paddingHorizontal:9,paddingVertical:6,gap:4},bubble:{maxWidth:'83%',paddingHorizontal:9,paddingVertical:5,borderRadius:13,gap:2,borderWidth:1,borderColor:C.line,minWidth:64},mine:{alignSelf:'flex-end',backgroundColor:'#E5ECFF',borderBottomRightRadius:5},theirs:{alignSelf:'flex-start',backgroundColor:'#fff',borderBottomLeftRadius:5},messageLine:{flexDirection:'row',flexWrap:'wrap',alignItems:'baseline',columnGap:8,rowGap:1},messageText:{fontFamily:chatFont,color:C.ink,fontSize:15,lineHeight:20,flexShrink:1,maxWidth:'100%'},messageMeta:{flexDirection:'row',alignItems:'center',gap:3,marginLeft:'auto'},reply:{padding:8,borderLeftWidth:3,borderLeftColor:C.purple,borderRadius:6,backgroundColor:'#F0EBFF'},composer:{paddingHorizontal:6,paddingVertical:3,gap:4,flexShrink:0,borderTopWidth:1,borderTopColor:C.line,backgroundColor:'#fff'},send:{width:44,height:44,borderRadius:22,backgroundColor:C.accent,alignItems:'center',justifyContent:'center'},actionPanel:{padding:5,gap:3,borderTopWidth:1,borderTopColor:C.line,backgroundColor:'#fff'},
 composeRow:{flexDirection:'row',alignItems:'flex-end',gap:5},plus:{width:42,height:42,borderRadius:21,borderWidth:1.5,borderColor:C.line,backgroundColor:'#EEF3FF',alignItems:'center',justifyContent:'center'},
 inputWrap:{flex:1,flexDirection:'row',alignItems:'flex-end',minHeight:42,borderRadius:21,borderWidth:1,borderColor:C.line,backgroundColor:'#fff',paddingLeft:11,paddingRight:3},inputText:{fontFamily:chatFont,flex:1,minHeight:40,maxHeight:96,paddingVertical:8,fontSize:15,color:C.ink},emojiBtn:{width:40,height:40,alignItems:'center',justifyContent:'center'},
 tray:{flexDirection:'row',gap:14,paddingVertical:6,paddingHorizontal:4},trayBtn:{width:52,height:52,borderRadius:26,alignItems:'center',justifyContent:'center',shadowColor:'#102A6B',shadowOpacity:.18,shadowRadius:6,shadowOffset:{width:0,height:3},elevation:3},
 safety:{flexDirection:'row',alignItems:'flex-start',gap:10,padding:12,borderRadius:16,borderWidth:1,borderColor:'#D6E0F7',backgroundColor:'#F3F7FF'},
 fabWrap:{position:'absolute',right:16,bottom:14,alignItems:'flex-end',gap:10},fab:{width:58,height:58,borderRadius:29,backgroundColor:C.accent,alignItems:'center',justifyContent:'center',shadowColor:'#102A6B',shadowOpacity:.3,shadowRadius:8,shadowOffset:{width:0,height:4},elevation:6},
 fabMenu:{gap:8,alignItems:'flex-end'},fabItem:{flexDirection:'row',alignItems:'center',gap:8,minHeight:46,paddingHorizontal:16,borderRadius:23,backgroundColor:'#fff',borderWidth:1.5,borderColor:C.line,elevation:4},fabText:{fontFamily:chatFont,fontSize:15,fontWeight:'400',color:C.ink},});
