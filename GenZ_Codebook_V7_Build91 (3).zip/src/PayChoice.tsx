/**
 * Build 91: "How do you want to pay?" — Use Credits or Watch 1 ad. Shown for a 2nd+ code of the day
 * and for community posts, only while the admin's fee switch and "pay with an ad" switch are on.
 * The user picks freely; nothing is charged until they confirm.
 */
import React from 'react';
import {Pressable, StyleSheet, Text, View} from 'react-native';
import {C, Icon} from './ui';
import type {PayWith} from './adPay';

export default function PayChoice({cost, balance, adLeft, value, onChange, disabled = false}: {
  cost: number; balance: number | null; adLeft: number | null; value: PayWith; onChange: (v: PayWith) => void; disabled?: boolean;
}) {
  const short = balance !== null && balance < cost;
  const adsGone = adLeft !== null && adLeft <= 0;
  const tile = (key: PayWith, icon: 'star' | 'play-circle', title: string, detail: string, off: boolean) => {
    const selected = value === key;
    return <Pressable key={key} accessibilityRole="radio" accessibilityState={{selected, disabled: disabled || off}} accessibilityLabel={`${title}. ${detail}`}
      disabled={disabled || off} onPress={() => onChange(key)}
      style={({pressed}) => [s.tile, selected && s.selected, (disabled || off) && {opacity: .55}, pressed && {opacity: .85}]}>
      <View style={[s.icon, {backgroundColor: key === 'credits' ? '#FFF4D6' : '#E8EEFF'}]}><Icon name={icon} size={18} color={key === 'credits' ? C.goldDeep : C.accent} /></View>
      <View style={{flex: 1, minWidth: 0}}>
        <Text numberOfLines={1} style={[s.title, selected && {color: C.accent}]}>{title}</Text>
        <Text numberOfLines={2} style={s.detail}>{detail}</Text>
      </View>
      <Icon name={selected ? 'radio-button-on' : 'radio-button-off'} size={18} color={selected ? C.accent : C.muted} />
    </Pressable>;
  };
  return <View accessibilityRole="radiogroup" accessibilityLabel="How do you want to pay?" style={{gap: 6}}>
    <Text style={s.label}>How do you want to pay?</Text>
    <View style={s.row}>
      {tile('credits', 'star', `Use ${cost} Credits`, short ? `You have ${balance}` : balance === null ? 'Checking balance…' : `Balance ${balance.toLocaleString()}`, false)}
      {tile('ad', 'play-circle', 'Watch 1 ad', adsGone ? 'Used up today' : adLeft === null ? 'Free' : `Free · ${adLeft} left today`, adsGone)}
    </View>
  </View>;
}

const s = StyleSheet.create({
  label: {fontSize: 13, fontWeight: '800', color: C.navy},
  row: {flexDirection: 'row', gap: 8},
  tile: {flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8, minHeight: 56, padding: 10, borderRadius: 14, borderWidth: 1.5, borderColor: '#D8E2F4', backgroundColor: '#fff'},
  selected: {borderColor: C.accent, backgroundColor: '#F2F6FF'},
  icon: {width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center'},
  title: {fontSize: 13.5, fontWeight: '800', color: C.ink},
  detail: {fontSize: 11.5, color: C.muted, marginTop: 1},
});
