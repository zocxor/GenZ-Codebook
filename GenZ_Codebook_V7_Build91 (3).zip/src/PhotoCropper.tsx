/**
 * In-app photo cropper (Build 88) for the profile photo and the group photo.
 *
 * The Android system crop screen drew its toolbar (with the confirm tick) under the status bar on
 * edge-to-edge phones, so it looked black and the crop controls were hidden. This screen is drawn
 * by the app itself, inside the safe area, in the app's light colours: drag to move, pinch or use
 * − / + to zoom, then "Use photo". The math lives in cropMath.ts (unit-tested).
 */
import React,{useCallback,useRef,useState} from 'react';
import {Image,Modal,PanResponder,Pressable,StyleSheet,Text,View,useWindowDimensions,type GestureResponderEvent} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {C,Icon} from './ui';
import {clampCrop,coverScale,cropRect,initialCrop,zoomAt,MAX_ZOOM,MIN_ZOOM,type CropRect,type CropState} from './cropMath';

export type CropSource={uri:string;width:number;height:number};
export type CropShape='circle'|'square';

function CropperScreen({source,shape,title,onCancel,onDone}:{source:CropSource;shape:CropShape;title:string;onCancel:()=>void;onDone:(rect:CropRect)=>void}){
 const {width:screenW,height:screenH}=useWindowDimensions();
 const view=Math.round(Math.max(200,Math.min(screenW-40,screenH-320,380)));
 const {width:w,height:h}=source;
 const [state,setState]=useState<CropState>(()=>initialCrop(w,h,view));
 const live=useRef(state);live.current=state;
 const box=useRef<View>(null);
 const origin=useRef({x:0,y:0});
 const base=useRef<{s:CropState;n:number;dist:number;cx:number;cy:number}|null>(null);
 const read=(e:GestureResponderEvent)=>{
  const t=e.nativeEvent.touches;
  if(t.length>=2){const a=t[0]!,b=t[1]!;return {n:2,dist:Math.hypot(a.pageX-b.pageX,a.pageY-b.pageY),cx:(a.pageX+b.pageX)/2-origin.current.x,cy:(a.pageY+b.pageY)/2-origin.current.y};}
  const a=t[0]??e.nativeEvent;
  return {n:1,dist:0,cx:a.pageX-origin.current.x,cy:a.pageY-origin.current.y};
 };
 const responder=useRef(PanResponder.create({
  onStartShouldSetPanResponder:()=>true,
  onMoveShouldSetPanResponder:()=>true,
  onPanResponderTerminationRequest:()=>false,
  onPanResponderGrant:e=>{base.current={s:live.current,...read(e)};},
  onPanResponderMove:e=>{
   const r=read(e),b=base.current;
   if(!b||b.n!==r.n){base.current={s:live.current,...r};return;}
   if(r.n===2&&b.dist>0){
    const zoomed=zoomAt(b.s,b.s.zoom*r.dist/b.dist,b.cx,b.cy,w,h,view);
    setState(clampCrop({...zoomed,x:zoomed.x+(r.cx-b.cx),y:zoomed.y+(r.cy-b.cy)},w,h,view));
   }else setState(clampCrop({zoom:b.s.zoom,x:b.s.x+(r.cx-b.cx),y:b.s.y+(r.cy-b.cy)},w,h,view));
  },
  onPanResponderRelease:()=>{base.current=null;},
  onPanResponderTerminate:()=>{base.current=null;},
 })).current;
 const scale=coverScale(w,h,view)*state.zoom;
 const step=(delta:number)=>setState(s=>zoomAt(s,s.zoom+delta,view/2,view/2,w,h,view));
 const ring=Math.round(view*.32);
 return <SafeAreaView style={c.screen} edges={['top','bottom','left','right']}>
  <View style={c.bar}>
   <Pressable accessibilityRole="button" accessibilityLabel="Cancel" hitSlop={10} onPress={onCancel} style={c.barButton}><Icon name="close" size={24} color={C.ink}/></Pressable>
   <Text accessibilityRole="header" style={c.title}>{title}</Text>
   <Pressable accessibilityRole="button" accessibilityLabel="Use this photo" hitSlop={10} onPress={()=>onDone(cropRect(live.current,w,h,view))} style={c.barButton}><Icon name="checkmark" size={26} color={C.accent}/></Pressable>
  </View>
  <View style={c.body}>
   <Text style={c.hint}>Drag to move · pinch or use − / + to zoom</Text>
   <View ref={box} collapsable={false} onLayout={()=>box.current?.measureInWindow((x,y)=>{origin.current={x,y};})}
    style={[c.viewport,{width:view,height:view}]} {...responder.panHandlers}
    accessible accessibilityLabel="Photo crop area" accessibilityHint="Drag to move the photo, pinch to zoom">
    <Image source={{uri:source.uri}} accessibilityIgnoresInvertColors resizeMode="stretch"
     style={{position:'absolute',left:state.x,top:state.y,width:w*scale,height:h*scale}}/>
    {shape==='circle'
     ?<View pointerEvents="none" style={{position:'absolute',left:-ring,top:-ring,width:view+ring*2,height:view+ring*2,borderRadius:view/2+ring,borderWidth:ring,borderColor:'rgba(15,23,42,.55)'}}/>
     :<View pointerEvents="none" style={StyleSheet.absoluteFill}>
      {[1,2].map(i=><View key={'v'+i} style={[c.grid,{left:view*i/3,top:0,bottom:0,width:1}]}/>)}
      {[1,2].map(i=><View key={'h'+i} style={[c.grid,{top:view*i/3,left:0,right:0,height:1}]}/>)}
     </View>}
    <View pointerEvents="none" style={[StyleSheet.absoluteFill,{borderWidth:2,borderColor:'#fff',borderRadius:shape==='circle'?view/2:12}]}/>
   </View>
   <View style={c.zoomRow}>
    <Pressable accessibilityRole="button" accessibilityLabel="Zoom out" disabled={state.zoom<=MIN_ZOOM} onPress={()=>step(-.25)} style={[c.zoomButton,state.zoom<=MIN_ZOOM&&{opacity:.4}]}><Icon name="remove" size={22} color={C.accent}/></Pressable>
    <Text style={c.zoomText}>{Math.round(state.zoom*100)}%</Text>
    <Pressable accessibilityRole="button" accessibilityLabel="Zoom in" disabled={state.zoom>=MAX_ZOOM} onPress={()=>step(.25)} style={[c.zoomButton,state.zoom>=MAX_ZOOM&&{opacity:.4}]}><Icon name="add" size={22} color={C.accent}/></Pressable>
    <Pressable accessibilityRole="button" accessibilityLabel="Reset crop" onPress={()=>setState(initialCrop(w,h,view))} style={c.reset}><Icon name="refresh" size={17} color={C.muted}/><Text style={c.resetText}>Reset</Text></Pressable>
   </View>
  </View>
  <View style={c.footer}>
   <Pressable accessibilityRole="button" onPress={onCancel} style={[c.action,c.cancel]}><Text style={[c.actionText,{color:C.ink}]}>Cancel</Text></Pressable>
   <Pressable accessibilityRole="button" onPress={()=>onDone(cropRect(live.current,w,h,view))} style={[c.action,c.confirm]}><Icon name="checkmark-circle" size={19} color="#fff"/><Text style={[c.actionText,{color:'#fff'}]}>Use photo</Text></Pressable>
  </View>
 </SafeAreaView>;
}

/** `crop(source)` opens the cropper and resolves with the chosen square, or null when cancelled. Render `element`. */
export function usePhotoCropper(title='Crop your photo'){
 const [job,setJob]=useState<{source:CropSource;shape:CropShape;resolve:(rect:CropRect|null)=>void}|null>(null);
 const crop=useCallback(async(source:{uri:string;width?:number;height?:number},shape:CropShape='circle')=>{
  let {width=0,height=0}=source;
  if(!width||!height){
   try{[width,height]=await new Promise<[number,number]>((ok,fail)=>Image.getSize(source.uri,(a,b)=>ok([a,b]),fail));}
   catch{return null;}
  }
  return new Promise<CropRect|null>(resolve=>setJob({source:{uri:source.uri,width,height},shape,resolve}));
 },[]);
 const finish=(rect:CropRect|null)=>{job?.resolve(rect);setJob(null);};
 const element=<Modal visible={!!job} animationType="slide" onRequestClose={()=>finish(null)}>
  {job&&<CropperScreen source={job.source} shape={job.shape} title={title} onCancel={()=>finish(null)} onDone={finish}/>}
 </Modal>;
 return {crop,element};
}

const c=StyleSheet.create({
 screen:{flex:1,backgroundColor:'#F4F7FF'},
 bar:{flexDirection:'row',alignItems:'center',gap:8,paddingHorizontal:10,paddingVertical:6,borderBottomWidth:1,borderBottomColor:'#E2E8F5',backgroundColor:'#FFFFFF'},
 barButton:{width:44,height:44,alignItems:'center',justifyContent:'center'},
 title:{flex:1,textAlign:'center',fontSize:17,fontWeight:'800',color:C.ink},
 body:{flex:1,alignItems:'center',justifyContent:'center',gap:14,padding:16},
 hint:{fontSize:13,color:C.muted,textAlign:'center'},
 viewport:{overflow:'hidden',borderRadius:16,backgroundColor:'#0F172A'},
 grid:{position:'absolute',backgroundColor:'rgba(255,255,255,.45)'},
 zoomRow:{flexDirection:'row',alignItems:'center',gap:12},
 zoomButton:{width:44,height:44,borderRadius:22,alignItems:'center',justifyContent:'center',backgroundColor:'#FFFFFF',borderWidth:1,borderColor:'#D6E2F5'},
 zoomText:{minWidth:52,textAlign:'center',fontSize:14,fontWeight:'800',color:C.ink},
 reset:{flexDirection:'row',alignItems:'center',gap:4,minHeight:44,paddingHorizontal:12},
 resetText:{fontSize:13,fontWeight:'700',color:C.muted},
 footer:{flexDirection:'row',gap:10,padding:14,borderTopWidth:1,borderTopColor:'#E2E8F5',backgroundColor:'#FFFFFF'},
 action:{flex:1,minHeight:50,borderRadius:16,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:7},
 cancel:{backgroundColor:'#EEF2FA',borderWidth:1,borderColor:'#D6E2F5'},
 confirm:{backgroundColor:C.accent},
 actionText:{fontSize:15.5,fontWeight:'800'},
});
