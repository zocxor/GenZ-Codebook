import {BACKEND_URL} from './backend';
import {SPARK_MODE} from '../shared/deployment';
/** AdMob: rewarded ads pay a benefit (Credits, a quiz hint, a level unlock) when the user taps for one.
 * A short skippable full-screen ad (close X) is shown when the user deletes their own community post, or
 * when they tap "Watch a short ad". Build 90: after a cleared quiz round, a bonus intro screen may offer
 * a rewarded interstitial (+10) — it counts down 5 seconds and always has "No thanks" (AdMob policy for
 * this format). Nothing else appears automatically: no ad on opening a screen, posting, searching,
 * chatting or after N activities. Unavailable ads never prevent normal app use. */
import {Platform} from 'react-native';
import {useSyncExternalStore} from 'react';
import {AdEventType, InterstitialAd, MobileAds, RewardedAd, RewardedAdEventType, RewardedInterstitialAd, TestIds} from 'react-native-google-mobile-ads';
import {accountAuth} from './firebase/app';
import {IS_DEV} from './secure/config';
const getRewardUserId=()=>accountAuth.currentUser?.uid;

export const ADMOB_APP_ID = 'ca-app-pub-9776667186789824~9376759074';
/** Rewarded unit (created in AdMob 2026-11-08). Pays only on the SDK's EARNED_REWARD callback; dev builds use Google's test rewarded ad. */
export const REWARDED_AD_UNIT_ID = 'ca-app-pub-9776667186789824/4151797642';
/** Rewarded interstitial unit (created in AdMob 2026-11-08). Build 90: the bonus offer after a cleared quiz round (src/BonusAdOffer.tsx), always behind an intro screen with "No thanks". Never use it as a plain interstitial. */
export const REWARDED_INTERSTITIAL_AD_UNIT_ID = 'ca-app-pub-9776667186789824/6311057124';
/** Interstitial unit (created in AdMob 2026-11-08). Full-screen skippable ad, preloaded at boot and shown only when the user deletes their post or taps "Watch a short ad". Skippable, never gates a feature. */
export const INTERSTITIAL_AD_UNIT_ID = 'ca-app-pub-9776667186789824/4760116398';
/** Interstitial ad unit ID: Google's test interstitial in dev; the real one in release builds. */
export function interstitialAdUnitId(): string | null {
  if (IS_DEV) return TestIds.INTERSTITIAL;
  return INTERSTITIAL_AD_UNIT_ID || null;
}

/** Rewarded interstitial unit ID: Google's test unit in dev; the real one in release builds. */
export function rewardedInterstitialAdUnitId(): string | null {
  if (IS_DEV) return TestIds.REWARDED_INTERSTITIAL;
  return REWARDED_INTERSTITIAL_AD_UNIT_ID || null;
}

/** Rewarded ad unit ID: Google's test rewarded ad in dev; the real one in release builds, or null until one is created in AdMob. */
export function rewardedAdUnitId(): string | null {
  if (IS_DEV) return TestIds.REWARDED;
  return REWARDED_AD_UNIT_ID || null;
}

/**
 * Build 89: the last reason Google gave for not delivering an ad (for example "Account not approved yet."
 * while the AdMob account is under review, or "No fill."). Shown under "No reward yet" so the owner can
 * see on the phone why no ad appeared. Nothing is sent anywhere.
 */
let lastAdProblem = '';
function noteAdError(e: unknown): void {
  const info = (e as {userInfo?: {code?: string; message?: string}} | null)?.userInfo;
  const raw = info?.message || (e instanceof Error ? e.message : '') || '';
  const text = raw.replace(/^\[[^\]]*\]\s*/, '').trim();
  const code = info?.code ?? '';
  lastAdProblem = [text, code && !text.includes(code) ? `(${code})` : ''].filter(Boolean).join(' ').slice(0, 160);
}
export function lastAdLoadProblem(): string {
  return lastAdProblem;
}
/** Text for the "No reward yet" message, with Google's own reason when there is one. */
export function adUnavailableText(): string {
  const base = 'The ad may be unavailable or your daily allowance may be used. No reward was charged. Try again later.';
  return lastAdProblem ? `${base}\n\nGoogle said: ${lastAdProblem}` : base;
}

let adsStarted = false;
let adsDisabled = false;
let rewardedActive = false;
const adsDisabledListeners = new Set<(disabled: boolean) => void>();
/**
 * Premium (ad-free) switch. App.tsx sets this from the subscription
 * entitlement (users/{uid}/subscription/current). While it is on, no
 * interstitial is preloaded or shown. Rewarded ads stay available — they
 * are opt-in earning, not an interruption. Defaults to ads on; a failed
 * subscription read leaves ads on.
 */
export function setAdsDisabled(disabled: boolean): void {
  if (adsDisabled === disabled) return;
  adsDisabled = disabled;
  if (disabled) discardBonusAd();
  adsDisabledListeners.forEach(cb => {
    try {cb(disabled);} catch {/* ignore */}
  });
  emitSupportAdReady();
}
export function onAdsDisabledChange(cb: (disabled: boolean) => void): () => void {
  adsDisabledListeners.add(cb);
  return () => {adsDisabledListeners.delete(cb);};
}
export function isAdsDisabled(): boolean {
  return adsDisabled;
}

/** Initialise the SDK once, Android only, and preload one interstitial. Safe to call on every launch; a failure only means no ads. */
export function initAds(): void {
  if (adsStarted || Platform.OS !== 'android') return;
  adsStarted = true;
  void MobileAds().initialize().catch(() => undefined);
  preloadInterstitial();
}

/**
 * The preloaded interstitial, if any. A fresh instance is created per load:
 * once an interstitial is shown it cannot be shown again, so the CLOSED
 * listener clears it and preloads the next one.
 */
let interstitial: InterstitialAd | null = null;
let interstitialLoaded = false;

/** Lets the "Watch a short ad" button appear only while an ad is really ready (no dead buttons). */
const supportReadyListeners = new Set<() => void>();
function emitSupportAdReady(): void {
  supportReadyListeners.forEach(cb => {try {cb();} catch {/* ignore */}});
}
const supportAdReady = (): boolean => Platform.OS === 'android' && !adsDisabled && !rewardedActive && !!interstitial && interstitialLoaded;
/** True while a skippable support ad is loaded and the user may choose to watch it (never with Premium). */
export function useSupportAdReady(): boolean {
  return useSyncExternalStore(cb => {supportReadyListeners.add(cb); return () => {supportReadyListeners.delete(cb);};}, supportAdReady, () => false);
}

/**
 * Preload one interstitial so it is ready if the user taps "Watch a short ad".
 * No-op when ads are disabled (Premium), when there is no unit
 * ID, or when one is already loaded or loading. A failed load simply leaves
 * nothing ready — the next launch (or the next close) retries.
 */
export function preloadInterstitial(): void {
  if (Platform.OS !== 'android' || adsDisabled) return;
  const unitId = interstitialAdUnitId();
  if (!unitId) return;
  if (interstitial) return;
  // Constructing the interstitial touches the native ads module. If that
  // module is not ready this throws synchronously — and preloadInterstitial
  // runs from a setTimeout / ad-event listener that no ErrorBoundary covers,
  // so a throw here kills the app process. Never throw: a failed preload
  // just means no interstitial is ready.
  let ad: InterstitialAd;
  try {
    ad = InterstitialAd.createForAdRequest(unitId, {requestNonPersonalizedAdsOnly: true});
  } catch {
    interstitial = null;
    interstitialLoaded = false;
    return;
  }
  interstitial = ad;
  const unsubs: (() => void)[] = [];
  const clear = () => {
    for (const u of unsubs) {try {u();} catch {/* ignore */}}
    unsubs.length = 0;
  };
  unsubs.push(
    ad.addAdEventListener(AdEventType.LOADED, () => {interstitialLoaded = true; emitSupportAdReady();}),
    ad.addAdEventListener(AdEventType.CLOSED, () => {
      clear();
      interstitial = null;
      interstitialLoaded = false;
      emitSupportAdReady();
      preloadInterstitial();
    }),
    ad.addAdEventListener(AdEventType.ERROR, e => {
      noteAdError(e);
      clear();
      interstitial = null;
      interstitialLoaded = false;
      emitSupportAdReady();
    }),
  );
  try { ad.load(); } catch { interstitial = null; interstitialLoaded = false; }
}

/**
 * Show the preloaded skippable full-screen ad (it has a close X). Called when the user deletes
 * their post or taps "Watch a short ad".
 * Resolves true when the ad was shown and closed. Resolves false at once when nothing is
 * ready, on Premium, or during a rewarded ad, so the screen never waits on ads.
 */
export function showSupportAd(): Promise<boolean> {
  if (!supportAdReady()) return Promise.resolve(false);
  const ad = interstitial!;
  return new Promise<boolean>(resolve => {
    let finished = false;
    let shown = false;
    const unsubs: (() => void)[] = [];
    const done = () => {
      if (finished) return;
      finished = true;
      for (const u of unsubs) {try {u();} catch {/* ignore */}}
      resolve(shown);
    };
    try {
      unsubs.push(
        ad.addAdEventListener(AdEventType.OPENED, () => {shown = true;}),
        ad.addAdEventListener(AdEventType.CLOSED, done),
        ad.addAdEventListener(AdEventType.ERROR, done),
      );
      interstitialLoaded = false;
      emitSupportAdReady();
      void Promise.resolve(ad.show()).catch(done);
    } catch {done(); return;}
    setTimeout(done, 90_000);   // never leave the caller hanging
  });
}

/**
 * Show one rewarded ad. Resolves true only when the user actually earned the
 * reward (watched to the end); closing early, an error, or no ad unit ID
 * resolves false and pays nothing. The caller grants the benefit: tokens, a quiz
 * hint ('hint') or a level unlock ('unlock'). Non-token benefits still play when the
 * secure reward check is unavailable.
 */
export async function watchRewardedAd(canShow:()=>boolean=()=>true,benefit:'tokens'|'hint'|'unlock'='tokens'): Promise<boolean> {
  if (Platform.OS !== 'android' || rewardedActive) return Promise.resolve(false);
  const unitId = rewardedAdUnitId();
  if (!unitId) return Promise.resolve(false);
  lastAdProblem = '';
  rewardedActive = true;
  emitSupportAdReady();
  let userId=BACKEND_URL?getRewardUserId():undefined,customData:string|undefined;
  if(userId){
    try{const result=await (await import('./communityFeatures')).feature('reward-intent');customData=result.id;}
    catch{if(benefit==='tokens'){lastAdProblem='The secure reward check could not be reached. Check your connection.';rewardedActive=false;emitSupportAdReady();return false;}userId=undefined;}
  }
  if(!canShow()){rewardedActive=false;emitSupportAdReady();return false;}
  return playRewarded(unitId, {requestNonPersonalizedAdsOnly: true,...(userId?{serverSideVerificationOptions:{userId,...(customData?{customData}:{})}}:{})}, canShow);
}

/**
 * Load and show one rewarded ad (the caller has set rewardedActive). Resolves true only when Google
 * reports the reward (watched to the end); closing early, an error or a 15-second load timeout resolve false.
 */
function playRewarded(unitId: string, options: Parameters<typeof RewardedAd.createForAdRequest>[1], canShow: () => boolean): Promise<boolean> {
  return new Promise(resolve => {
    let done = false;
    let earned = false;
    const unsubs: (() => void)[] = [];
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(loadTimeout);
      rewardedActive = false;
      emitSupportAdReady();
      for (const u of unsubs) {try {u();} catch {/* ignore */}}
      resolve(earned);
    };
    const loadTimeout = setTimeout(() => {if (!lastAdProblem) lastAdProblem = 'No ad arrived within 15 seconds.'; finish();}, 15_000);
    try {
      const ad = RewardedAd.createForAdRequest(unitId, options);
      unsubs.push(ad.addAdEventListener(RewardedAdEventType.LOADED, () => {
        clearTimeout(loadTimeout);
        if(!canShow()){finish();return;}
        try {void ad.show().catch(finish);} catch {finish();}
      }));
      unsubs.push(ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => {earned = true;}));
      unsubs.push(ad.addAdEventListener(AdEventType.CLOSED, finish));
      unsubs.push(ad.addAdEventListener(AdEventType.ERROR, e => {noteAdError(e); finish();}));
      ad.load();
    } catch {finish();}
  });
}

/**
 * Build 91: watch one rewarded ad to pay for a new code or a community post instead of Credits.
 * The server reserves an intent for that purpose first (refused when the admin switch is off or
 * today's 3 ad payments are used), so a user never watches an ad that cannot pay. Resolves the
 * intent ID once Google reports the reward; the server then needs Google's signed callback
 * before it accepts the payment (see src/adPay.ts for the short wait).
 */
export async function watchAdToPay(kind: 'code' | 'post'): Promise<{ok: true; intent: string} | {ok: false; message: string}> {
  if (Platform.OS !== 'android') return {ok: false, message: 'Paying with an ad works in the Android app.'};
  if (rewardedActive) return {ok: false, message: 'Another ad is already open.'};
  const unitId = rewardedAdUnitId(), userId = BACKEND_URL ? getRewardUserId() : undefined;
  if (!unitId || !userId) return {ok: false, message: 'Sign in to pay with an ad.'};
  lastAdProblem = '';
  rewardedActive = true;
  emitSupportAdReady();
  const features = await import('./communityFeatures');
  let intent: string;
  try {
    intent = String((await features.feature('reward-intent', {purpose: kind})).id ?? '');
    if (!/^[a-f0-9]{48}$/.test(intent)) throw new Error('The ad could not be reserved. Please try again.');
  } catch (e) {
    rewardedActive = false;
    emitSupportAdReady();
    return {ok: false, message: features.errorOf(e)};
  }
  const earned = await playRewarded(unitId, {requestNonPersonalizedAdsOnly: true, serverSideVerificationOptions: {userId, customData: intent}}, () => true);
  if (earned) return {ok: true, intent};
  return {ok: false, message: lastAdProblem
    ? `No ad was shown, so nothing was created and no Credits were charged.\n\nGoogle said: ${lastAdProblem}`
    : 'The ad was closed before the end, so nothing was created and no Credits were charged.'};
}

/* ---------- Build 90: bonus rewarded interstitial after a cleared quiz round ---------- */

/** The server's reward intent lives 20 minutes; a prepared bonus is replaced after 15 so the reward still verifies. */
export const BONUS_FRESH_MS = 15 * 60_000;
/** At most one bonus offer every 3 minutes, however fast rounds are played. */
export const BONUS_MIN_GAP_MS = 3 * 60_000;
type BonusEntry = {ad: RewardedInterstitialAd; loaded: boolean; preparedAt: number; uid?: string; unsubs: (() => void)[]};
let bonus: BonusEntry | null = null;
let bonusPreparing = false;
let lastBonusOfferAt = 0;

function discardBonusAd(): void {
  const entry = bonus;
  bonus = null;
  if (entry) for (const u of entry.unsubs) {try {u();} catch {/* ignore */}}
  emitSupportAdReady();
}

/** True when the prepared bonus may still be offered: loaded, fresh, not Premium, no other rewarded ad open, gap respected. */
export function bonusAdOfferable(now = Date.now()): boolean {
  return Platform.OS === 'android' && !adsDisabled && !rewardedActive && !!bonus && bonus.loaded
    && now - bonus.preparedAt < BONUS_FRESH_MS && now - lastBonusOfferAt >= BONUS_MIN_GAP_MS;
}
export function useBonusAdReady(): boolean {
  return useSyncExternalStore(cb => {supportReadyListeners.add(cb); return () => {supportReadyListeners.delete(cb);};}, () => bonusAdOfferable(), () => false);
}
/** Whether the prepared bonus pays account Credits (signed in, server-verified) or device learning points. */
export function bonusAdPaysCredits(): boolean {
  return !!bonus?.uid;
}

/**
 * Prepare (load) one bonus ad, called when a quiz round starts so it is ready by the results screen.
 * Signed-in accounts first get a server reward intent (the same 20-a-day allowance as other rewarded
 * ads); if that fails, no bonus is prepared, so the offer never promises Credits it cannot pay.
 * A prepared, unused bonus is kept for the next round until it is 15 minutes old. Never throws.
 */
export async function prepareBonusAd(): Promise<void> {
  if (Platform.OS !== 'android' || adsDisabled || bonusPreparing) return;
  const unitId = rewardedInterstitialAdUnitId();
  if (!unitId) return;
  const uid = BACKEND_URL ? getRewardUserId() : undefined;
  if (bonus && bonus.uid === uid && Date.now() - bonus.preparedAt < BONUS_FRESH_MS) return;
  bonusPreparing = true;
  try {
    discardBonusAd();
    let customData: string | undefined;
    if (uid) {
      try {customData = (await (await import('./communityFeatures')).feature('reward-intent')).id;}
      catch {return;}
    }
    if (adsDisabled) return;
    let ad: RewardedInterstitialAd;
    try {
      ad = RewardedInterstitialAd.createForAdRequest(unitId, {requestNonPersonalizedAdsOnly: true, ...(uid ? {serverSideVerificationOptions: {userId: uid, ...(customData ? {customData} : {})}} : {})});
    } catch {return;}
    const entry: BonusEntry = {ad, loaded: false, preparedAt: Date.now(), uid, unsubs: []};
    bonus = entry;
    entry.unsubs.push(
      ad.addAdEventListener(RewardedAdEventType.LOADED, () => {if (bonus === entry) {entry.loaded = true; emitSupportAdReady();}}),
      ad.addAdEventListener(AdEventType.ERROR, e => {noteAdError(e); if (bonus === entry) discardBonusAd();}),
    );
    try {ad.load();} catch {if (bonus === entry) discardBonusAd();}
  } finally {
    bonusPreparing = false;
  }
}

/** Marks the bonus as offered (the intro screen appeared); starts the 3-minute gap. */
export function noteBonusOffered(now = Date.now()): void {
  lastBonusOfferAt = now;
  emitSupportAdReady();
}

/**
 * Show the prepared bonus ad (one use). Resolves when it closes: `earned` only when Google reports the
 * reward; `credits` tells whether the server pays Credits (signed in) or the caller adds learning points.
 */
export function showBonusAd(): Promise<{shown: boolean; earned: boolean; credits: boolean}> {
  const entry = bonus;
  if (Platform.OS !== 'android' || !entry || !entry.loaded || adsDisabled || rewardedActive) return Promise.resolve({shown: false, earned: false, credits: false});
  bonus = null;
  rewardedActive = true;
  emitSupportAdReady();
  return new Promise(resolve => {
    let done = false, shown = false, earned = false;
    const unsubs: (() => void)[] = [];
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(timeout);
      rewardedActive = false;
      for (const u of [...unsubs, ...entry.unsubs]) {try {u();} catch {/* ignore */}}
      emitSupportAdReady();
      resolve({shown, earned, credits: !!entry.uid});
    };
    const timeout = setTimeout(finish, 180_000);   // never leave the results screen waiting
    try {
      unsubs.push(
        entry.ad.addAdEventListener(AdEventType.OPENED, () => {shown = true;}),
        entry.ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => {earned = true;}),
        entry.ad.addAdEventListener(AdEventType.CLOSED, finish),
        entry.ad.addAdEventListener(AdEventType.ERROR, e => {noteAdError(e); finish();}),
      );
      void Promise.resolve(entry.ad.show()).catch(finish);
    } catch {finish();}
  });
}
