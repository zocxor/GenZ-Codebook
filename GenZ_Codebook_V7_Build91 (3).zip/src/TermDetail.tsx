import React,{useEffect,useState} from 'react';import {View,Text,Pressable,Linking,StyleSheet,Share,Platform} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import {Term,categoryLabels} from './content';import {C,Icon,IconName,Button,IconTile,FadeIn} from './ui';
import {LinearGradient} from 'expo-linear-gradient';
import TermCopyBar from './TermCopyBar';
import {termKind,termKindColors,termKindHelp} from './termKind';
import {termCopyText} from './termCopy';
import {PLAY_STORE_URL} from '../shared/brand';
import {useAccountUser} from './services';
import {ensureCodeSaved,savedByText,useSaveCount} from './codeSaves';
const allowed=new Set(['en.wiktionary.org','www.dictionary.com','github.com','huggingface.co','slang.net','www.cyberdefinitions.com','www.slang.org','creativecommons.org','www.apache.org','www.unicode.org']);
function Card({icon,tint,title,children,delay=0}:{icon:IconName;tint?:string;title:string;children:React.ReactNode;delay?:number}){return <FadeIn delay={delay}><View style={s.card}><View style={s.cardHead}><IconTile icon={icon} from={tint??C.accent} to={tint??C.accent} size={32} iconSize={16}/><Text style={s.label}>{title}</Text></View>{children}</View></FadeIn>;}

/** Build 88: who created a community code (public `uid` field of communityWords), so only its creator sees Edit. */
const creators=new Map<string,string|null>();
function useCreator(t:Term){
 const [uid,setUid]=useState<string|null|undefined>(()=>t.status==='Community'?creators.get(t.id):null);
 useEffect(()=>{
  if(t.status!=='Community'){setUid(null);return;}
  if(creators.has(t.id)){setUid(creators.get(t.id));return;}
  let live=true;
  void Promise.all([import('firebase/firestore/lite'),import('./firebase/app')]).then(([{doc,getDoc},{cloudDb}])=>getDoc(doc(cloudDb(),'communityWords',t.id))).then(snap=>{
   const owner=snap.exists()&&snap.get('status')==='live'&&typeof snap.get('uid')==='string'?String(snap.get('uid')):null;
   creators.set(t.id,owner);if(live)setUid(owner);
  },()=>{if(live)setUid(null);});
  return ()=>{live=false;};
 },[t.id,t.status]);
 return uid;
}

function Action({icon,label,onPress,tint}:{icon:IconName;label:string;onPress:()=>void;tint:string}){
 return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({pressed})=>[s.action,pressed&&{opacity:.8,transform:[{translateY:1}]}]}>
  <View style={[s.actionIcon,{backgroundColor:tint}]}><Icon name={icon} size={17} color="#fff"/></View>
  <Text numberOfLines={1} style={s.actionText}>{label}</Text>
 </Pressable>;
}

export default function TermDetail({term:t,saved,onSave,onReport,saveError,onPost,onApplyDaily,onEdit}:{term:Term;saved:boolean;onSave:()=>void;onReport?:()=>void;saveError?:string;/** Build 88 */onPost?:()=>void;onApplyDaily?:()=>void;onEdit?:()=>void}){const [others,setOthers]=useState(false);const open=async(url:string)=>{try{const u=new URL(url);if(u.protocol==='https:'&&allowed.has(u.hostname))await Linking.openURL(url);}catch{}};
 const kind=termKind(t),look=termKindColors[kind];
 const user=useAccountUser();
 const creator=useCreator(t);
 const mine=!!user&&!!creator&&creator===user.uid;
 const saves=useSaveCount(t.id);
 const [shareNote,setShareNote]=useState('');
 // Words saved before this version are added to the public count the first time they are opened.
 useEffect(()=>{if(saved&&user)void ensureCodeSaved(t.id).catch(()=>{});},[t.id,saved,user?.uid]);
 const share=async()=>{
  const message=`${termCopyText(t,'all',categoryLabels[t.category])}\nType: ${kind}\n\nFind more codes in GenZ Codebook: ${PLAY_STORE_URL}`;
  setShareNote('');
  try{
   if(Platform.OS==='web'){await Clipboard.setStringAsync(message);setShareNote('Copied for sharing.');}
   else await Share.share({message,title:`${t.expression} · GenZ Codebook`});
  }catch{setShareNote('Couldn’t open sharing on this device. Use Copy all details instead.');}
 };
 return <><FadeIn><View style={{gap:10}}>
  <View style={s.pillRow}>
   <View accessible accessibilityLabel={`Type: ${kind}`} style={[s.kindPill,{backgroundColor:look.bg}]}><Icon name={kind==='Slang'?'chatbubble-ellipses':kind==='Emoji'?'happy':kind==='Term'?'school':kind==='Numeric Code'?'keypad':'code-slash'} size={13} color={look.fg}/><Text style={[s.kindText,{color:look.fg}]}>{kind.toUpperCase()}</Text></View>
   <View style={s.metaPill}><Text style={s.metaPillText}>{categoryLabels[t.category]}</Text></View>
   {saved&&<View style={[s.metaPill,{backgroundColor:'#EFE7FF',borderColor:'#D9C8FF',flexDirection:'row',alignItems:'center',gap:4}]}><Icon name="bookmark" size={11} color={C.purple}/><Text style={[s.metaPillText,{color:C.purple}]}>SAVED</Text></View>}
  </View>
  <Text selectable style={[s.expression,t.expression.length>18&&{fontSize:36}]}>{t.expression}</Text><LinearGradient colors={[C.accent,C.purple]} start={{x:0,y:0}} end={{x:1,y:0}} style={s.rule}/><Text selectable style={s.title}>{t.full}</Text>
  <Text style={s.meta}>{kind} · {categoryLabels[t.category]} · {t.language} · {t.status}</Text>
  <Text style={[s.kindHelp,{color:look.fg,backgroundColor:look.bg}]}>{termKindHelp[kind]}</Text>
  <View style={s.savedLine}><Icon name="bookmark-outline" size={14} color={C.muted}/><Text style={s.meta}>{saves===null?'Saved count loading…':savedByText(saves)}{mine?' · Created by you':''}</Text></View>
 </View></FadeIn>
 {<FadeIn delay={20}><View accessibilityLabel="Code actions" style={s.actions}>
  {onPost&&<Action icon="people" label="Post" tint="#7C3AED" onPress={onPost}/>}
  {onApplyDaily&&<Action icon="calendar" label="Daily Code" tint="#E39A12" onPress={onApplyDaily}/>}
  <Action icon="share-social" label="Share" tint={C.accent} onPress={()=>void share()}/>
  {mine&&onEdit&&<Action icon="create" label="Edit" tint="#0E9F8A" onPress={onEdit}/>}
 </View></FadeIn>}
 {!!shareNote&&<Text accessibilityLiveRegion="polite" style={s.meta}>{shareNote}</Text>}
 <FadeIn delay={30}><View style={[s.card,s.copyCard]}><TermCopyBar term={t}/></View></FadeIn>
 <Card icon="text-outline" title="The simple meaning" delay={60}><Text selectable style={s.meaning}>{t.meaning}</Text><Text style={s.meta}>{t.tone} · {t.region}</Text>{t.sensitivity==='Caution'&&<Text style={s.warning}>Usage caution: this expression can be vulgar, insulting, or highly context-dependent.</Text>}</Card>
 {t.example&&<Card icon="chatbubble-ellipses-outline" tint={C.purple} title="In a conversation" delay={120}><Text selectable style={s.meaning}>“{t.example}”</Text></Card>}
 <Card icon="arrow-undo-outline" title={t.reply?'You could say':'If you’re unsure, ask'} delay={160}><Text selectable style={s.meaning}>“{t.reply||'What do you mean here?'}”</Text></Card>
 <Card icon="alert-circle-outline" tint={C.warn} title="Context changes things" delay={200}><Text style={s.body}>{t.caution}</Text>{t.aliases.length>0&&<Text style={s.meta}>Also searchable: {t.aliases.join(' · ')}</Text>}</Card>
 {t.senses.length>0&&<FadeIn delay={240}><View style={s.card}><Pressable accessibilityRole="button" onPress={()=>setOthers(v=>!v)} style={s.row}><IconTile icon="layers-outline" from={C.purple} to={C.accent} size={36} iconSize={18}/><Text style={[s.label,{flex:1}]}>{others?'Hide':'Show'} other recorded senses ({t.senses.length})</Text><Icon name={others?'chevron-up':'chevron-down'} color={C.accent}/></Pressable>{others&&t.senses.map((sense,i)=><View key={i} style={[s.sense,i>0&&{borderTopWidth:1,borderTopColor:'#e6eef8',paddingTop:14}]}><Text style={s.senseLabel}>{categoryLabels[sense.category]}</Text><Text selectable style={s.body}>{sense.definition}</Text><Text style={s.meta}>{sense.labels.join(' · ')}</Text></View>)}</View></FadeIn>}
 <Card icon="shield-checkmark-outline" tint={C.success} title="Source & confidence" delay={280}><Text style={s.body}>{t.status==='Standard reference'?'Standard symbol name.':t.status==='Source checked'?'Checked against a named source.':t.status==='Authored draft'?'Original wording. Needs review.':t.status==='Editor reviewed'?'Published by GenZ Codebook editors.':t.status==='Community'?'Added by a user. Not reviewed yet.':'Imported reference. Not individually reviewed.'}</Text>{t.source?<><Text selectable style={s.meta}>{t.source.name}</Text><Text selectable style={s.meta}>{t.source.url}</Text><Text style={s.meta}>{t.source.license} · retrieved {t.source.date}</Text>{t.source.license==='CC BY-SA 4.0'&&<Text selectable style={s.meta}>CC BY-SA 4.0 · Wiktionary contributors.</Text>}{t.source.license==='Unicode-3.0'&&<Text selectable style={s.meta}>Unicode-3.0 · Unicode, Inc. and contributors.</Text>}<Button title="Open reference" icon="open-outline" light onPress={()=>open(t.source!.url)}/></>:<Text style={s.meta}>{t.status==='Community'?'Community contribution · no external source.':'Original GenZ Codebook starter explanation; external verification pending.'}</Text>}</Card>
 {!!saveError&&<Text accessibilityRole="alert" style={s.warning}>{saveError}</Text>}<Button title={saved?'Saved — tap to remove':'Save this code'} icon={saved?'bookmark':'bookmark-outline'} onPress={onSave}/>
 {saves!==null&&<Text style={[s.meta,{textAlign:'center'}]}>{savedByText(saves)}{saved?' · including you':''}</Text>}
 {onReport&&<Pressable accessibilityRole="button" onPress={onReport} style={s.row}><Icon name="flag-outline" color={C.muted} size={18}/><Text style={[s.meta,{fontWeight:'700'}]}>Report a problem with this entry</Text></Pressable>}</>;
}
const s=StyleSheet.create({expression:{fontSize:44,fontWeight:'900',color:C.accent,letterSpacing:-1},rule:{width:64,height:5,borderRadius:3},pillRow:{flexDirection:'row',flexWrap:'wrap',alignItems:'center',gap:6},kindPill:{flexDirection:'row',alignItems:'center',gap:5,borderRadius:20,paddingHorizontal:11,paddingVertical:6},kindText:{fontSize:11.5,fontWeight:'900',letterSpacing:.9},kindHelp:{alignSelf:'flex-start',fontSize:12.5,lineHeight:18,fontWeight:'700',borderRadius:12,paddingHorizontal:10,paddingVertical:6,overflow:'hidden'},savedLine:{flexDirection:'row',alignItems:'center',gap:5},metaPill:{alignSelf:'flex-start',backgroundColor:C.soft,borderWidth:1,borderColor:'#d6e8fb',borderRadius:20,paddingHorizontal:12,paddingVertical:6},metaPillText:{fontSize:11,fontWeight:'800',color:C.accent,letterSpacing:.6},title:{fontSize:20,fontWeight:'800',color:C.navy,lineHeight:27,letterSpacing:-.3},meta:{fontSize:12,color:C.muted,lineHeight:19},label:{fontSize:16,fontWeight:'800',color:C.navy},meaning:{fontSize:16,lineHeight:24,color:C.navy},body:{fontSize:15,lineHeight:24,color:C.muted},warning:{color:C.warn,lineHeight:21,backgroundColor:'#fff7e6',borderRadius:14,padding:12,overflow:'hidden'},row:{flexDirection:'row',alignItems:'center',gap:10,minHeight:48},card:{backgroundColor:'#fff',borderColor:'#dce8f5',borderWidth:1.5,borderRadius:18,padding:14,gap:8,shadowColor:'#3e6c9a',shadowOffset:{width:0,height:6},shadowOpacity:.08,shadowRadius:14,elevation:3},cardHead:{flexDirection:'row',alignItems:'center',gap:10},copyCard:{paddingVertical:10,backgroundColor:'#F7FAFF'},sense:{gap:5},senseLabel:{fontSize:11,fontWeight:'800',letterSpacing:1.2,color:C.accent},
 actions:{flexDirection:'row',gap:8,backgroundColor:'#fff',borderColor:'#dce8f5',borderWidth:1.5,borderRadius:18,padding:8},
 action:{flex:1,minWidth:0,alignItems:'center',gap:5,paddingVertical:6,borderRadius:12},
 actionIcon:{width:36,height:36,borderRadius:12,alignItems:'center',justifyContent:'center'},
 actionText:{fontSize:12,fontWeight:'800',color:C.navy}});
