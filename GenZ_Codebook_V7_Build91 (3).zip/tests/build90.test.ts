import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read = (f: string) => readFileSync(f, 'utf8');

test('rewarded interstitial: real unit in release, Google test unit in dev, never a plain interstitial', () => {
  const ads = read('src/ads.tsx');
  assert.match(ads, /REWARDED_INTERSTITIAL_AD_UNIT_ID = 'ca-app-pub-9776667186789824\/6311057124'/);
  assert.match(ads, /if \(IS_DEV\) return TestIds\.REWARDED_INTERSTITIAL;\n  return REWARDED_INTERSTITIAL_AD_UNIT_ID \|\| null;/);
  assert.match(ads, /RewardedInterstitialAd\.createForAdRequest\(unitId/);
  assert.doesNotMatch(ads, /InterstitialAd\.createForAdRequest\(REWARDED_INTERSTITIAL/);
});

test('bonus ad: prepared at round start, Credits only with a server reward intent, never with Premium', () => {
  const ads = read('src/ads.tsx'), app = read('App.tsx');
  assert.match(app, /attemptId\.current=newAttemptId\(\);setBonus\(\{round:attemptId\.current,offered:false,note:''\}\);void prepareBonusAd\(\)/);
  const prepare = ads.slice(ads.indexOf('export async function prepareBonusAd'), ads.indexOf('export function noteBonusOffered'));
  assert.match(prepare, /feature\('reward-intent'\)\)\.id;\}\n      catch \{return;\}/, 'no intent, no offer');
  assert.match(prepare, /serverSideVerificationOptions: \{userId: uid/);
  assert.match(ads, /adsDisabled = disabled;\n  if \(disabled\) discardBonusAd\(\);/, 'Premium drops a prepared bonus');
  assert.match(ads, /BONUS_FRESH_MS = 15 \* 60_000/, 'replaced before the 20-minute server intent expires');
  assert.match(ads, /BONUS_MIN_GAP_MS = 3 \* 60_000/);
  assert.match(ads, /now - lastBonusOfferAt >= BONUS_MIN_GAP_MS/);
});

test('bonus intro: 5-second countdown, Watch now, No thanks, and only when an ad is loaded', () => {
  const offer = read('src/BonusAdOffer.tsx');
  assert.match(offer, /export const BONUS_COUNTDOWN = 5;/);
  assert.match(offer, /title="Watch now"/);
  assert.match(offer, /title="No thanks" onPress=\{\(\) => setPhase\('over'\)\}/);
  assert.match(offer, /if \(!bonusAdOfferable\(\)\) return;/);
  assert.match(offer, /if \(left <= 0\) \{void watch\(\); return;\}/);
  assert.match(offer, /if \(s !== 'active'\) setPhase\('over'\)/, 'never starts while the app is in the background');
  assert.match(offer, /if \(!r\.credits\) onGuestReward\(\);/, 'guests get learning points; accounts are paid by the server');
});

test('bonus offer sits on the quiz results only, after 3+ correct answers, and replaces the support card for that round', () => {
  const app = read('App.tsx');
  assert.equal((app.match(/<BonusAdOffer /g) ?? []).length, 1);
  assert.match(app, /<BonusAdOffer round=\{attemptId\.current\} eligible=\{finished&&score>=3\}/);
  assert.match(app, /!\(bonus\.round===attemptId\.current&&bonus\.offered\)&&<SupportAdButton\/>/);
  assert.match(app, /onGuestReward=\{\(\)=>void act\(earnTokens\(TOKENS\.REWARDED_AD\)\)\}/);
});

test('server pays the bonus unit like the rewarded unit; Terms and privacy describe the bonus ad', () => {
  const rewards = read('functions/src/adRewards.ts');
  assert.match(rewards, /const bonusUnit='ca-app-pub-9776667186789824\/6311057124';/);
  assert.match(rewards, /!REWARD_AD_UNITS\.includes\(data\.get\('ad_unit'\)\?\?''\)/);
  assert.match(read('src/AboutScreen.tsx'), /After you clear a quiz round, a bonus screen may offer \+10 Credits/);
  assert.match(read('admin/site/privacy.html'), /a bonus ad offered after you clear a quiz round/);
});
