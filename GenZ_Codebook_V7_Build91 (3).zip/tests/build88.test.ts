import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {looksLikeCode, postCategoryFor, postCategoryLook, termKind} from '../src/termKind';
import {clampCrop, coverScale, cropRect, initialCrop, zoomAt, MAX_ZOOM} from '../src/cropMath';
import {SOCIAL_LINKS} from '../shared/brand';

const read = (f: string) => readFileSync(f, 'utf8');

test('every entry says whether it is a Code, Numeric Code, Slang, Emoji or Term', () => {
  assert.equal(termKind({expression: 'BRB', full: 'be right back', category: 'Chat'}), 'Code');
  assert.equal(termKind({expression: 'goat', full: 'greatest of all time', category: 'Social'}), 'Code', 'acronym of its long form');
  assert.equal(termKind({expression: 'l8r', full: 'later', category: 'Social'}), 'Code', 'letters + digits shorthand');
  assert.equal(termKind({expression: 'HDOT', full: 'HDOT', category: 'Chat'}), 'Code', 'a user-created capital code');
  assert.equal(termKind({expression: '143', full: 'I love you', category: 'Numbers'}), 'Numeric Code');
  assert.equal(termKind({expression: 'rizz', full: 'charisma', category: 'Social'}), 'Slang');
  assert.equal(termKind({expression: 'no cap', full: 'no lie', category: 'Social'}), 'Slang');
  assert.equal(termKind({expression: 'yaar', full: 'friend', category: 'Regional'}), 'Slang');
  assert.equal(termKind({expression: 'Netflix', full: 'streaming service', category: 'Social'}), 'Slang', 'a capitalised word is not a code');
  assert.equal(termKind({expression: '🔥', full: 'fire', category: 'Emoji'}), 'Emoji');
  assert.equal(termKind({expression: 'onboarding', full: 'getting started at work', category: 'Work'}), 'Term');
  assert.equal(looksLikeCode('no cap', 'no lie'), false);
});

test('Community post category follows the type, and each category has its own colours (Code Word unchanged)', () => {
  assert.equal(postCategoryFor({expression: 'BRB', full: 'be right back', category: 'Chat'}), 'Code Word');
  assert.equal(postCategoryFor({expression: 'rizz', full: 'charisma', category: 'Social'}), 'Slang');
  assert.equal(postCategoryFor({expression: 'onboarding', category: 'Work'}), 'General Term');
  assert.deepEqual(postCategoryLook['Code Word'].chip, ['#8B3FE0', '#4B3BDB'], 'code word keeps the original purple chip');
  assert.equal(postCategoryLook['Code Word'].tagFg, '#E11D61', 'and the original red tag');
  assert.equal(postCategoryLook.Slang.chip[0], '#16A34A', 'slang is green');
  assert.equal(postCategoryLook.Slang.tagFg, '#E11D61', 'with the red tag');
  assert.notDeepEqual(postCategoryLook['General Term'].chip, postCategoryLook['Code Word'].chip);
  assert.notDeepEqual(postCategoryLook['General Term'].chip, postCategoryLook.Slang.chip);
});

test('photo cropper math: the picture always covers the square and the crop stays inside the photo', () => {
  const w = 4000, h = 3000, view = 300;
  const start = initialCrop(w, h, view);
  assert.equal(start.zoom, 1);
  assert.equal(start.y, 0);
  assert.ok(start.x < 0, 'a landscape photo is centred horizontally');
  const centre = cropRect(start, w, h, view);
  assert.deepEqual(centre, {originX: 500, originY: 0, width: 3000, height: 3000}, 'zoom 1 = centre square');
  // Dragging past the edge is clamped.
  const far = clampCrop({zoom: 1, x: 999, y: -999}, w, h, view);
  assert.equal(far.x, 0); assert.equal(far.y, 0);
  // Zooming in on the centre keeps the centre and shrinks the square.
  const zoomed = zoomAt(start, 2, view / 2, view / 2, w, h, view);
  const r = cropRect(zoomed, w, h, view);
  assert.equal(r.width, 1500);
  assert.equal(r.originX, 1250); assert.equal(r.originY, 750);
  // Zoom is limited and the crop never leaves the photo.
  const max = zoomAt(start, 99, 0, 0, w, h, view);
  assert.equal(max.zoom, MAX_ZOOM);
  for (const s of [start, zoomed, max, clampCrop({zoom: 3, x: -1e9, y: -1e9}, w, h, view)]) {
    const c = cropRect(s, w, h, view);
    assert.ok(c.originX >= 0 && c.originY >= 0 && c.originX + c.width <= w && c.originY + c.height <= h, JSON.stringify(c));
  }
  assert.equal(coverScale(1000, 2000, 300), 0.3);
});

test('TikTok @genzcodebook is one of the official follow links', () => {
  const tiktok = SOCIAL_LINKS.find(l => l.id === 'tiktok');
  assert.ok(tiktok);
  assert.equal(tiktok.handle, '@genzcodebook');
  assert.equal(tiktok.url, 'https://www.tiktok.com/@genzcodebook');
  assert.match(read('src/FollowUs.tsx'), /tiktok:\{ion:'logo-tiktok'/);
});

test('Inside the code: Post, Daily Code, Share, Edit (creator only), type badge and saved count', () => {
  const detail = read('src/TermDetail.tsx'), app = read('App.tsx');
  assert.match(detail, /<Action icon="people" label="Post"/);
  assert.match(detail, /<Action icon="calendar" label="Daily Code"/);
  assert.match(detail, /<Action icon="share-social" label="Share"/);
  assert.match(detail, /\{mine&&onEdit&&<Action icon="create" label="Edit"/, 'Edit only for the creator of the code');
  assert.match(detail, /const mine=!!user&&!!creator&&creator===user\.uid;/);
  assert.match(detail, /termKindHelp\[kind\]/);
  assert.match(detail, /savedByText\(saves\)/);
  assert.match(app, /onPost=\{\(\)=>postFromDetail\(detail\)\}/);
  assert.match(app, /initialWordId=\{sheet==='daily-apply'\?dailyWordId:undefined\}/);
  assert.match(app, /if\(ok&&user\)void setCodeSaved\(t\.id,next\)/);
});

test('saved counts: one marker per account and a counter that moves by exactly 1 (rules)', () => {
  const rules = read('firebase/firestore.rules');
  assert.match(rules, /match \/codeSaveCounts\/\{termId\}/);
  assert.match(rules, /request\.resource\.data\.count == resource\.data\.count \+ \(existsAfter\(saveMarker\(termId\)\) \? 1 : -1\)/);
  assert.match(rules, /match \/codeSaves\/\{saveId\}/);
  assert.match(rules, /saveId == request\.resource\.data\.termId \+ '_' \+ me\(\)/);
  assert.match(rules, /allow get: if signedIn\(\) && \(resource == null \|\| resource\.data\.uid == me\(\)\);/, 'markers are private');
  assert.match(read('firebase/rules-tests/rules.test.mjs'), /code saves: an active account adds exactly one save per entry/);
});

test('Community composer finds the user’s own codes, including long ones, and shortens them for the post', () => {
  const panel = read('src/CommunityPostsPanel.tsx');
  assert.doesNotMatch(panel, /t\.meaning\.length<=200&&t\.example\.length<=200/, 'long meanings no longer hide a code');
  const sync = read('src/contentSync.ts');
  assert.match(sync, /where\('uid', '==', uid\), where\('status', '==', 'live'\)/);
  assert.match(sync, /const r = toCommunityRecord\(d\.id, d\.data\(\)\);/, 'own words are validated like every community word');
  assert.match(panel, /syncOwnCommunityWords\(uid\)/);
  assert.match(read('App.tsx'), /void syncOwnCommunityWords\(user\.uid\)/, 'synced on sign-in for every search');
  assert.match(panel, /meaning=fit\(selected\?\.meaning\?\?'',POST_TEXT\)/);
  assert.match(panel, /colors=\{postLook\(row\.category\)\.chip\}/);
});

test('profile: three-line menu opens a compact top-right panel; account sections live there; Saved is a tab; cards in a 4-column grid', () => {
  const dash = read('src/ProfileDashboard.tsx'), social = read('src/SocialProfile.tsx');
  assert.match(dash, /label="Profile menu" name="menu"/);
  assert.doesNotMatch(dash, /ellipsis-horizontal/);
  assert.doesNotMatch(dash, /<Text style=\{s\.sectionLabel\}>ACCOUNT & COMMUNITY<\/Text>/, 'no section at the bottom of the page');
  assert.match(dash, /<MenuLabel text="ACCOUNT & COMMUNITY"\/>/);
  assert.match(dash, /title="Settings" onPress=\{pick\(\(\)=>onOpen\('settings'\)\)\}/);
  assert.doesNotMatch(dash, /label="Saved words"/, 'saved words moved out of the menu');
  assert.match(social, /\['Overview','Slangs','Codes','Posts','Saved'\]/);
  assert.match(social, /const GRID_COLUMNS=4/);
});

test('verified ticks: Daily Code byline, followers/following lists and the forward picker', () => {
  assert.match(read('src/ContributionScreens.tsx'), /<VerifiedBadge verified=\{!!author&&authorBadge\.has\(author\)\}/);
  const m = read('src/MessagingScreen.tsx');
  assert.match(m, /\{person\.name\}<\/Text><VerifiedBadge verified=\{badges\.has\(person\.uid\)\}/);
  assert.match(m, /\{r\.type==='personal'&&<VerifiedBadge verified=\{badges\.has\(r\.peerId\|\|''\)\}/);
});

test('photos use the in-app cropper, never the system crop screen', () => {
  const m = read('src/MessagingScreen.tsx'), avatar = read('src/avatarPhoto.ts'), app = read('App.tsx');
  assert.doesNotMatch(m, /allowsEditing:true/);
  assert.match(m, /cropper\.crop\(\{uri:asset\.uri,width:asset\.width,height:asset\.height\},'circle'\)/);
  assert.match(avatar, /allowsEditing: false/);
  assert.match(app, /pickAndSavePhoto\(asset=>photoCropper\.crop\(asset,'circle'\)\)/);
  assert.match(read('src/PhotoCropper.tsx'), /<SafeAreaView style=\{c\.screen\} edges=\{\['top','bottom','left','right'\]\}>/);
});

test('daily reward is instant, and a refused credit is undone; messaging retries brief failures', () => {
  const reward = read('src/dailyReward.ts'), msg = read('src/messaging.ts');
  assert.match(reward, /mark\(key\);\n\s+if \(!localDone\) void repository\.mutate\(collectDailyReward\)/);
  assert.match(msg, /if\(attempt>=2\|\|!transientCallError\(e\)\)throw e;/);
  assert.match(read('functions/src/communityEndpoints.ts'), /maxInstances:20, timeoutSeconds:60/);
});

test('sign-up: compact banner and a highlighted friend’s user code box under the passwords', () => {
  const portal = read('src/AuthPortal.tsx'), account = read('src/AccountScreen.tsx');
  assert.match(portal, /if \(mode === 'create'\) return <LinearGradient colors=\{\['#DCE7FF', '#EEE6FF', '#DDF5FF'\]\}/, 'same banner colours');
  assert.match(account, /Friend’s user code/);
  assert.ok(account.indexOf('Confirm account password') < account.indexOf('Friend’s user code'));
  assert.ok(account.indexOf('Friend’s user code') < account.indexOf('By creating an account you agree'));
});

test('profile cards: one light colour per family — every code purple, every slang green — with dark same-hue text', async () => {
  const {cardTints, termKindColors} = await import('../src/termKind');
  assert.deepEqual(cardTints['Code Word'], cardTints.Code);
  assert.deepEqual(cardTints['Numeric Code'], cardTints.Code);
  assert.deepEqual(cardTints['General Term'], cardTints.Term);
  assert.deepEqual(termKindColors['Numeric Code'], termKindColors.Code);
  assert.notDeepEqual(cardTints.Slang, cardTints.Code);
  assert.match(read('src/SocialProfile.tsx'), /backgroundColor:colors\.dark\?item\.accent\+'38':item\.tint\.bg/);
  assert.match(read('src/SocialProfile.tsx'), /<ProfileAction label="Copy" onPress=\{\(\)=>void copyItem\(opened\)\}/);
});

test('Notifications: Clear history hides older items on this phone and deletes nothing', () => {
  const screen = read('src/NotificationsScreen.tsx');
  assert.match(screen, /accessibilityLabel="Clear notification history"/);
  assert.match(screen, /AsyncStorage\.setItem\(CLEARED_KEY\(user\?\.uid\), String\(at\)\)/);
  assert.doesNotMatch(screen, /deleteDoc|writeBatch/, 'nothing is deleted on the server');
  assert.match(screen, /export const shownAfterClear = \(at: number, clearedAt: number\) => !clearedAt \|\| at > clearedAt;/);
  assert.match(screen, /\.filter\(i => shownAfterClear\(i\.at, clearedAt\)\)/);
});

test('message alerts: the Inbox offers a one-tap opt-in and notifications show the sender name', () => {
  assert.match(read('src/MessagingScreen.tsx'), /<MessageAlertPrompt uid=\{uid\}\/>/);
  assert.match(read('src/MessageAlertSettings.tsx'), /PermissionsAndroid\.PERMISSIONS\.POST_NOTIFICATIONS/);
  assert.match(read('functions/src/inboxAlerts.ts'), /title:typeof notice\.title==='string'\?notice\.title\.slice\(0,60\):''/);
  assert.match(read('android/app/src/main/java/com/genzmode/app/InboxPushService.kt'), /setContentTitle\(if \(from\.isNotEmpty\(\)\) from else "GenZ Codebook"\)/);
});
