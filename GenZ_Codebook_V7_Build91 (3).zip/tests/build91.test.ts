import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {AD_PENDING_MESSAGE, adIntentSpent, isAdPending, retryWhileAdPending} from '../src/adPay';
import {parseAppConfig} from '../src/appConfig';
const read = (f: string) => readFileSync(f, 'utf8');

test('config: code and post switches follow paidCommunity until saved; pay-with-ad is off by default', () => {
  assert.deepEqual((({paidCommunity, paidCodes, paidPosts, adPayEnabled}) => ({paidCommunity, paidCodes, paidPosts, adPayEnabled}))(parseAppConfig({paidCommunity: true})),
    {paidCommunity: true, paidCodes: true, paidPosts: true, adPayEnabled: false});
  const split = parseAppConfig({paidCommunity: false, paidCodes: true, paidPosts: false, adPayEnabled: true});
  assert.equal(split.paidCodes, true); assert.equal(split.paidPosts, false); assert.equal(split.paidCommunity, false); assert.equal(split.adPayEnabled, true);
  assert.equal(parseAppConfig({adPayEnabled: 'yes'}).adPayEnabled, false);
});

test('pay with an ad: waits only while Google is confirming, then gives a clear message', async () => {
  const pending = Object.assign(new Error('Google is still confirming your ad. Trying again…'), {details: {pending: true}});
  assert.equal(isAdPending(pending), true);
  assert.equal(isAdPending(new Error('You need 100 Credits')), false);
  assert.equal(adIntentSpent(new Error('This ad was already used. Watch a new one.')), true);
  assert.equal(adIntentSpent(new Error('This ad has expired. Watch a new one.')), true);
  assert.equal(adIntentSpent(pending), false);
  let calls = 0;
  const ok = await retryWhileAdPending(async () => {calls++; if (calls < 3) throw pending; return 'created';}, 8, 0, async () => {});
  assert.equal(ok, 'created'); assert.equal(calls, 3);
  calls = 0;
  await assert.rejects(retryWhileAdPending(async () => {calls++; throw new Error('Not enough Credits');}, 8, 0, async () => {}), /Not enough/);
  assert.equal(calls, 1, 'other errors are not retried');
  calls = 0;
  await assert.rejects(retryWhileAdPending(async () => {calls++; throw pending;}, 4, 0, async () => {}), e => isAdPending(e));
  assert.equal(calls, 4);
  assert.match(AD_PENDING_MESSAGE, /won’t need to watch another ad/);
});

test('code and post forms offer "Use Credits" or "Watch 1 ad" only when a fee applies and the admin switch is on', () => {
  const form = read('src/SubmitForms.tsx'), posts = read('src/CommunityPostsPanel.tsx'), choice = read('src/PayChoice.tsx');
  assert.match(form, /const adChoice=!!cost&&config\.adPayEnabled&&Platform\.OS==='android'&&credits\.free!==null;/, 'no choice for the free code of the day');
  assert.match(form, /watchAdToPay\('code'\)/);
  assert.match(form, /retryWhileAdPending\(\(\)=>feature\('create-code',\{term,meaning,example,category,requestId:key\.current,\.\.\.payment\}\)\)/);
  assert.match(posts, /const adChoice=paid&&config\.adPayEnabled&&Platform\.OS==='android';/);
  assert.match(posts, /watchAdToPay\('post'\)/);
  assert.match(posts, /const paid=config\.paidPosts;/);
  assert.match(choice, /How do you want to pay\?/);
  assert.match(choice, /Use \$\{cost\} Credits/);
  assert.match(choice, /'Watch 1 ad'/);
});

test('free paths follow the separate switches; chat keeps paidCommunity', () => {
  const features = read('src/communityFeatures.ts');
  assert.match(features, /\(action==='create-code'&&!config\.paidCodes\)\|\|\(action==='create-post'&&!config\.paidPosts\)/);
  assert.match(read('src/CommunityScreen.tsx'), /paid = useAppConfig\(\)\.paidCommunity/);
  const ads = read('src/ads.tsx');
  assert.match(ads, /feature\('reward-intent', \{purpose: kind\}\)/);
  assert.match(ads, /serverSideVerificationOptions: \{userId, customData: intent\}/);
});

test('server, rules and admin portal carry the three switches', () => {
  const server = read('functions/src/communityFeatures.ts'), intents = read('functions/src/accountRewards.ts'), verifier = read('functions/src/adRewards.ts');
  assert.match(server, /export const AD_PAY_DAILY_LIMIT = 3;/);
  assert.match(server, /if \(intent\.get\('used'\) !== true\) throw new HttpsError\('failed-precondition', 'Google is still confirming your ad\. Trying again…', \{pending: true\}\);/);
  assert.match(intents, /if\(!paid\.adPay\|\|!\(purpose==='code'\?paid\.codes:paid\.posts\)\)/);
  assert.match(verifier, /if\(intentRef&&\(purpose==='code'\|\|purpose==='post'\)\)\{/);
  const rules = read('firebase/firestore.rules');
  assert.match(rules, /get\(c\)\.data\.get\('paidCodes', get\(c\)\.data\.get\('paidCommunity', false\)\) == true/);
  assert.match(rules, /postingMode\('post'\) != 'paused' && !paidPosts\(\) && freePost\(\)/);
  const settings = read('admin/src/pages/Settings.tsx');
  assert.match(settings, /<FeeRow name="New codes \/ words"[^\n]*on=\{value\.paidCodes\}/);
  assert.match(settings, /<FeeRow name="Community posts"[^\n]*on=\{value\.paidPosts\}/);
  assert.match(settings, /<FeeRow name="Community chat"[^\n]*on=\{value\.paidCommunity\}/);
  assert.match(settings, /<Toggle label="Pay with 1 ad instead of Credits" checked=\{value\.adPayEnabled\} disabled=\{!value\.paidCodes && !value\.paidPosts\}/);
  assert.match(settings, /up to 3 codes and 3 posts per user per day/);
});

test('admin Settings is a grouped control panel: sections, switches, one save bar with unsaved-changes state', () => {
  const settings = read('admin/src/pages/Settings.tsx'), css = read('admin/src/theme.css');
  for (const title of ['Publishing', 'Charges and payments', 'App delivery']) assert.match(settings, new RegExp(`<Card title="${title}"`));
  for (const label of ['Community charges', 'Alternative payment', 'Always charged']) assert.match(settings, new RegExp(`className="section-label">${label}<`));
  assert.match(settings, /type="checkbox" role="switch"/);
  assert.match(settings, /const dirty = !!draft && JSON\.stringify\(draft\) !== JSON\.stringify\(cfg\.data\);/);
  assert.match(settings, /<div className="save-bar" role="region" aria-label="Save settings">/);
  assert.match(settings, /\{busy \? 'Saving…' : 'Save settings'\}/);
  assert.match(settings, /Discard changes/);
  assert.equal((settings.match(/<input type="checkbox"/g) ?? []).length, 1, 'every on/off control uses the one Switch component');
  assert.match(css, /Build 91 — Settings control panel/);
  assert.match(css, /\.switch input:checked\+\.switch-track\{background:var\(--primary\)\}/);
});

test('admin portal version follows the app release (sidebar and Settings → About)', () => {
  const version = read('admin/src/version.ts'), app = read('admin/src/App.tsx'), settings = read('admin/src/pages/Settings.tsx');
  assert.match(version, /import app from '\.\.\/\.\.\/app\.json';/);
  assert.match(version, /PORTAL_VERSION: string = app\.expo\.version/);
  assert.match(app, /import \{PORTAL_VERSION\} from '\.\/version';/);
  assert.doesNotMatch(app, /const PORTAL_VERSION = '/);
  assert.match(settings, /<dd>\{PORTAL_VERSION\} · Build \{PORTAL_BUILD\}<\/dd>/);
  assert.doesNotMatch(settings, /First release/);
});
