package com.genzmode.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.facebook.react.ReactPackage
import com.facebook.react.bridge.*
import com.facebook.react.uimanager.ViewManager
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import org.json.JSONObject

private fun Context.prefs() = getSharedPreferences("inbox_alerts", Context.MODE_PRIVATE)
private fun Context.options(uid: String) = JSONObject(prefs().getString("options.$uid", "{}") ?: "{}")
private val audio = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
private fun sound(ctx: Context, tone: String): Uri? {
    val resource = when(tone) {
        "prism" -> R.raw.prism
        "tidal" -> R.raw.tidal
        "pebble" -> R.raw.pebble
        else -> return null
    }
    val name = ctx.resources.getResourceEntryName(resource)
    return Uri.parse("android.resource://${ctx.packageName}/raw/$name")
}
private fun pattern(mode: String) = when(mode) {
    "short" -> longArrayOf(0,90)
    "double" -> longArrayOf(0,80,100,100)
    else -> null
}

class InboxPushService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        val data = message.data
        val uid = data["recipient"] ?: return
        if (uid != prefs().getString("active","")) return
        val options = options(uid)
        if (!options.optBoolean("enabled") || !NotificationManagerCompat.from(this).areNotificationsEnabled()) return
        val kind = if (data["kind"] == "group") "group" else "personal"
        val tone = options.optString(kind, "prism")
        val vibration = options.optString("vibration","short")
        val channelId = "inbox.$kind.$tone.$vibration"
        val uri = sound(this,tone)
        val pulse = pattern(vibration)
        if (Build.VERSION.SDK_INT >= 26) {
            val label = if (kind == "group") "Group messages" else "Personal messages"
            val channel = NotificationChannel(channelId, "$label · $tone · $vibration", NotificationManager.IMPORTANCE_HIGH)
            channel.setSound(uri,audio)
            channel.vibrationPattern = pulse
            channel.enableVibration(pulse != null)
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val intent = Intent(this,MainActivity::class.java).setAction(Intent.ACTION_VIEW)
            .setData(Uri.parse("genzcode://inbox")).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val tap = PendingIntent.getActivity(this,74,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        // Build 88: sender or group name as the title (older servers send none → app name).
        val from = data["title"]?.trim()?.take(60).orEmpty()
        val notification = NotificationCompat.Builder(this,channelId)
            .setSmallIcon(android.R.drawable.stat_notify_chat).setContentTitle(if (from.isNotEmpty()) from else "GenZ Codebook")
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentText(if(kind=="group") "New group message" else "New personal message")
            .setSound(uri).setVibrate(pulse).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setAutoCancel(true)
            .setOnlyAlertOnce(true).setContentIntent(tap).build()
        getSystemService(NotificationManager::class.java)?.notify(data["event"] ?: return,74,notification)
    }
}

class InboxAlertsModule(private val ctx: ReactApplicationContext) : ReactContextBaseJavaModule(ctx) {
    override fun getName() = "InboxAlerts"
    @ReactMethod fun account(uid: String) {
        if (ctx.prefs().getString("active","") != uid) {
            ctx.getSystemService(NotificationManager::class.java)?.cancelAll()
            ctx.prefs().edit().putString("active",uid).apply()
        }
    }
    @ReactMethod fun read(uid: String,promise: Promise) { promise.resolve(ctx.options(uid).toString()) }
    @ReactMethod fun save(uid: String,value: String) { ctx.prefs().edit().putString("options.$uid",value).apply() }
    @ReactMethod fun token(promise: Promise) {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { promise.resolve(it) }
            .addOnFailureListener { promise.reject("registration",it) }
    }
    @ReactMethod fun preview(tone: String,vibration: String) {
        val mode = ctx.getSystemService(AudioManager::class.java)?.ringerMode
        if (mode == AudioManager.RINGER_MODE_SILENT) return
        pattern(vibration)?.let { ctx.getSystemService(Vibrator::class.java)?.vibrate(it,-1,audio) }
        if (mode != AudioManager.RINGER_MODE_NORMAL) return
        sound(ctx,tone)?.let { uri ->
            val player = MediaPlayer()
            try {
                player.setAudioAttributes(audio)
                player.setDataSource(ctx,uri)
                player.setOnCompletionListener { it.release() }
                player.setOnErrorListener { p,_,_ -> p.release(); true }
                player.setOnPreparedListener { it.start() }
                player.prepareAsync()
            } catch (_: Exception) { player.release() }
        }
    }
}

class InboxAlertsPackage : ReactPackage {
    override fun createNativeModules(context: ReactApplicationContext): List<NativeModule> = listOf(InboxAlertsModule(context))
    override fun createViewManagers(context: ReactApplicationContext): List<ViewManager<*,*>> = emptyList()
}
