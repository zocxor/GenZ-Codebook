import {randomBytes} from 'node:crypto';
import {FieldValue,Timestamp,type Firestore} from 'firebase-admin/firestore';
import {HttpsError} from 'firebase-functions/v2/https';
import {wallet,paidSwitches,adPayCounter,AD_PAY_DAILY_LIMIT} from './communityFeatures';
/**
 * Reserve one rewarded ad. Default purpose: +10 Credits. Build 91: purpose 'code' or 'post' makes the
 * verified ad pay for one code or post instead (no Credits); allowed only while that fee and the
 * admin's "pay with an ad" switch are on and today's 3 ad payments for that kind are not used up.
 */
export async function rewardIntent(db:Firestore,uid:string,now=Date.now(),purposeInput?:unknown){
  const day=new Date(now).toISOString().slice(0,10),id=randomBytes(24).toString('hex');
  if(purposeInput!==undefined&&purposeInput!=='credits'&&purposeInput!=='code'&&purposeInput!=='post')throw new HttpsError('invalid-argument','Unknown ad purpose.');
  const purpose=purposeInput==='code'||purposeInput==='post'?purposeInput:null;
  return db.runTransaction(async tx=>{
    const quota=db.doc(`users/${uid}/adAllowance/${day}`);
    const [user,used,config,paidToday]=await Promise.all([tx.get(db.doc('users/'+uid)),tx.get(quota),
      purpose?tx.get(db.doc('config/app')):Promise.resolve(null),purpose?tx.get(adPayCounter(db,uid,purpose,now)):Promise.resolve(null)]);
    if(user.get('status')!=='active')throw new HttpsError('permission-denied','An active account is required.');
    if(purpose){
      const paid=paidSwitches(config?.data()??{});
      if(!paid.adPay||!(purpose==='code'?paid.codes:paid.posts))throw new HttpsError('failed-precondition','Paying with an ad is turned off right now. Use Credits instead.');
      if(Number(paidToday?.get('count')??0)>=AD_PAY_DAILY_LIMIT)throw new HttpsError('resource-exhausted',`You’ve used today’s ${AD_PAY_DAILY_LIMIT} ad payments for ${purpose==='code'?'codes':'posts'}. Use Credits or try tomorrow (UTC).`);
    }
    const starts=Number(used.get('starts')??0);
    if(starts>=20)throw new HttpsError('resource-exhausted','Your daily rewarded-ad allowance is used. Try again tomorrow UTC.');
    tx.set(quota,{starts:starts+1,updatedAt:FieldValue.serverTimestamp()});
    tx.create(db.doc('adRewardIntents/'+id),{uid,createdAt:Timestamp.fromMillis(now),expiresAt:Timestamp.fromMillis(now+20*60000),used:false,...(purpose?{purpose}:{})});
    return {id,reward:purpose?0:10,remaining:19-starts,...(purpose?{purpose}:{})};
  });
}
export async function dailyReward(db:Firestore,uid:string,now=Date.now()){
  const day=new Date(now).toISOString().slice(0,10);
  return db.runTransaction(async tx=>{
    const receipt=db.doc(`users/${uid}/tokenLedger/daily-${day}`),[user,prior,w]=await Promise.all([tx.get(db.doc('users/'+uid)),tx.get(receipt),wallet(db,tx,uid)]);
    if(user.get('status')!=='active')throw new HttpsError('permission-denied','An active account is required.');
    if(prior.exists)return {id:day,duplicate:true,balance:w.balance};
    const amount=Math.min(10,Math.max(0,1000000-w.balance));
    tx.create(receipt,{type:'feature_reward',amount,ref:'daily-'+day,note:'Daily account reward',createdAt:FieldValue.serverTimestamp()});
    tx.set(w.ref,{...w.legacy,balance:Math.min(1000000,Math.max(0,Number(w.legacy.balance??0))+amount),earnedTotal:Number(w.legacy.earnedTotal??0)+amount,updatedAt:FieldValue.serverTimestamp()});
    return {id:day,balance:w.balance+amount};
  });
}
