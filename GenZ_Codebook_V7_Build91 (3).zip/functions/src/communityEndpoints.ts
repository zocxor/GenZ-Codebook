import {purgeExpiredChatAttachments} from './chatAttachments';
import {messagingAction,purgeMessagingUser} from './messaging';
import {getAuth} from 'firebase-admin/auth';
import {getFirestore} from 'firebase-admin/firestore';
import {HttpsError,onCall} from 'firebase-functions/v2/https';
import {error} from 'firebase-functions/logger';
import {onDocumentUpdated} from 'firebase-functions/v2/firestore';
import {onSchedule} from 'firebase-functions/v2/scheduler';
import {rewardIntent,dailyReward} from './accountRewards';
import {communityAction, runDailySchedule, purgeContributions, paidSwitches} from './communityFeatures';

// Build 88: maxInstances 3 → 20. Each instance serves one request at a time (default 256 MiB, fractional CPU),
// so 3 instances were shared by every chat, read receipt, presence ping and post in the app, and busy
// moments were refused ("Could not reach the Community service"). Still scales to zero; billing is per use.
export const communityFeature = onCall({region:'us-central1',cors:true,invoker:'public', minInstances:0,maxInstances:20, timeoutSeconds:60}, async request => {
  try {
    const input=request.data??{},db=getFirestore();
    if(input.action==='phone-auto-signin'){
      if(typeof input.idToken!=='string'||input.idToken.length>8192)throw new HttpsError('invalid-argument','Phone verification is required.');
      const auth=getAuth();
      const proof=await auth.verifyIdToken(input.idToken,true).catch(()=>null);
      const age=proof?Date.now()/1000-proof.auth_time:Infinity;
      if(!proof||proof.firebase.sign_in_provider!=='phone'||!proof.phone_number||age>120||age< -15)
        throw new HttpsError('unauthenticated','Phone verification expired. Try again.');
      return {token:await auth.createCustomToken(proof.uid)};
    }
    if(!request.auth)throw new HttpsError('unauthenticated','Sign in to continue.');
    if(request.auth.token.email_verified!==true)throw new HttpsError('permission-denied','Verify your email to use Credits.');
    if(input.action==='messaging')return await messagingAction(db,input,request.auth);
    // Paid community actions run only while the owner's switch for that action is on (admin Settings →
    // Credits). Build 91: separate switches — paidCodes, paidPosts, and paidCommunity for the chat pass.
    if(['create-code','create-post','chat-pass'].includes(input.action)){
      const paid=paidSwitches((await db.doc('config/app').get()).data()??{});
      if(!(input.action==='create-code'?paid.codes:input.action==='create-post'?paid.posts:paid.chat))throw new HttpsError('failed-precondition','Code creation, posting and chat are free right now. Please update the app if this keeps appearing.');
    }
    if(input.action==='reward-intent')return rewardIntent(db,request.auth.uid,Date.now(),input.purpose);
    if(input.action==='daily-reward')return dailyReward(db,request.auth.uid);
    return await communityAction(db,input,request.auth);
  } catch (cause) {
    if (cause instanceof HttpsError) throw cause;
    error('communityFeature failed',cause);
    throw new HttpsError('internal','The server could not complete this request. Retry or check the communityFeature logs in Firebase.');
  }
});
export const publishDailyCodes = onSchedule({schedule:'every 5 minutes',timeZone:'UTC',region:'us-central1',maxInstances:1,retryCount:3}, async ()=>{
  await runDailySchedule(getFirestore());
  await purgeExpiredChatAttachments(getFirestore());
});

export const cleanupContributions = onDocumentUpdated({document:'users/{uid}',region:'us-central1',retry:true}, async event=>{
  if(event.data?.after.get('status')==='deleted' && event.data.before.get('status')!=='deleted'){
    await purgeContributions(getFirestore(),event.params.uid);
    await purgeMessagingUser(getFirestore(),event.params.uid);
    try{await getAuth().deleteUser(event.params.uid);}catch(cause){if((cause as {code?:string}).code!=='auth/user-not-found')throw cause;}
  }
});
