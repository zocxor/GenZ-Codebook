const {test,after}=require('node:test');
const assert=require('node:assert/strict');
const {initializeApp,deleteApp}=require('firebase-admin/app');
const {getFirestore}=require('firebase-admin/firestore');
assert.ok(process.env.FIRESTORE_EMULATOR_HOST,'Use the Firestore emulator.');
const app=initializeApp({projectId:'demo-genz-feature-core'}),db=getFirestore(app);
const {communityFeature}=require('../lib/communityEndpoints');
after(()=>deleteApp(app));
const invoke=(uid,action,data={},verified=true)=>communityFeature.run({data:{action,...data},auth:uid?{uid,token:{email_verified:verified}}:undefined});
test('Cloud callable rejects unauthenticated and unverified users, and old paid core actions',async()=>{
 await assert.rejects(invoke(null,'balance'),e=>e.code==='unauthenticated');
 await assert.rejects(invoke('cloud-user','balance',{},false),e=>e.code==='permission-denied');
 for(const action of ['create-code','create-post','chat-pass'])await assert.rejects(invoke('cloud-user',action),e=>e.code==='failed-precondition');
});
test('Cloud callable exposes usable grants, idempotent daily bonuses and bounded ad intents',async()=>{
 await db.doc('users/cloud-user').set({status:'active'});
 await db.doc('users/cloud-admin').set({status:'active'});
 await db.doc('admins/cloud-admin').set({active:true,role:'super_admin'});
 await invoke('cloud-admin','grant-tokens',{uid:'cloud-user',amount:500,requestId:'cloud-opening'});
 assert.equal((await invoke('cloud-user','balance')).balance,500);
 const bonuses=await Promise.all([invoke('cloud-user','daily-reward'),invoke('cloud-user','daily-reward')]);
 assert.equal(bonuses.filter(v=>v.duplicate).length,1);
 assert.equal((await invoke('cloud-user','balance')).balance,510);
 const intent=await invoke('cloud-user','reward-intent');assert.match(intent.id,/^[a-f0-9]{48}$/);assert.equal(intent.reward,10);
 assert.equal((await db.doc('adRewardIntents/'+intent.id).get()).get('uid'),'cloud-user');
 await assert.rejects(invoke('cloud-user','grant-tokens',{uid:'cloud-user',amount:500,requestId:'forged'}),e=>e.code==='permission-denied');
 assert.equal((await invoke('cloud-user','balance')).balance,510);
});

// ---------- Build 91: separate fee switches and "pay with an ad" ----------
const {creditAdReward}=require('../lib/adRewards');
const today=()=>new Date().toISOString().slice(0,10);
const verifyAd=(uid,intent,transaction)=>creditAdReward(db,new URLSearchParams({ad_unit:'4151797642',reward_amount:'10',transaction_id:transaction,user_id:uid,custom_data:intent,timestamp:String(Date.now())}),true);
const code=(term,extra={})=>({term,meaning:'An original test expression for a happy moment.',example:'',category:'Social',requestId:'req-'+term,...extra});
const post=(term,extra={})=>({term,meaning:'An original test expression.',example:'',category:'Slang',requestId:'post-'+term,...extra});
async function adUser(uid){
 await db.doc('users/'+uid).set({status:'active'});
 await db.doc(`users/${uid}/allowances/code-${today()}`).set({kind:'code',ref:'seed'}); // today's free code is used
}
test('Build 91: codes, posts and chat each follow their own switch; old paidCommunity still covers all three until saved',async()=>{
 await db.doc('config/app').set({paidCommunity:false,paidCodes:false,paidPosts:true});
 await adUser('switch-user');
 await assert.rejects(invoke('switch-user','create-code',code('Switchglowa')),e=>e.code==='failed-precondition'&&/free right now/.test(e.message));
 await assert.rejects(invoke('switch-user','chat-pass'),e=>e.code==='failed-precondition'&&/free right now/.test(e.message));
 await assert.rejects(invoke('switch-user','create-post',post('Switchglowb')),e=>e.code==='failed-precondition'&&/Credits/i.test(e.message)); // gate passed: fails on payment (0 Credits)
 const {paidSwitches}=require('../lib/communityFeatures');
 assert.deepEqual(paidSwitches({paidCommunity:true}),{codes:true,posts:true,chat:true,adPay:false});
 assert.deepEqual(paidSwitches({paidCommunity:true,paidCodes:false,paidPosts:false,adPayEnabled:true}),{codes:false,posts:false,chat:true,adPay:true});
});
test('Build 91: one verified ad pays for one code or post, adds no Credits, 3 a day each, and only while switched on',async()=>{
 await db.doc('config/app').set({paidCodes:true,paidPosts:true,adPayEnabled:false});
 await adUser('ad-user');
 await assert.rejects(invoke('ad-user','reward-intent',{purpose:'code'}),e=>e.code==='failed-precondition');
 await assert.rejects(invoke('ad-user','reward-intent',{purpose:'gems'}),e=>e.code==='invalid-argument');
 await db.doc('config/app').set({paidCodes:true,paidPosts:true,adPayEnabled:true});
 const first=await invoke('ad-user','reward-intent',{purpose:'code'});
 assert.equal(first.reward,0);assert.equal(first.purpose,'code');
 // Before Google's callback the payment is "pending" and nothing is created.
 await assert.rejects(invoke('ad-user','create-code',code('Adpaycodea',{payWith:'ad',adIntent:first.id})),e=>e.code==='failed-precondition'&&e.details?.pending===true);
 await verifyAd('ad-user',first.id,'adpay-tx-1');
 assert.equal((await invoke('ad-user','balance')).balance,0,'a pay-with-ad callback adds no Credits');
 const made=await invoke('ad-user','create-code',code('Adpaycodea',{payWith:'ad',adIntent:first.id}));
 assert.equal(made.paidWith,'ad');assert.equal(made.free,false);assert.equal(made.balance,0);
 assert.equal((await db.doc('submissions/'+made.id).get()).get('payment'),'ad');
 // The same ad cannot pay twice, and a code ad cannot pay for a post.
 await assert.rejects(invoke('ad-user','create-code',code('Adpaycodeb',{payWith:'ad',adIntent:first.id})),e=>e.code==='already-exists');
 const forCode=await invoke('ad-user','reward-intent',{purpose:'code'});await verifyAd('ad-user',forCode.id,'adpay-tx-2');
 await assert.rejects(invoke('ad-user','create-post',post('Adpaypostx',{payWith:'ad',adIntent:forCode.id})),e=>e.code==='permission-denied');
 // A normal +10 Credits ad cannot pay for a code either.
 const normal=await invoke('ad-user','reward-intent');await verifyAd('ad-user',normal.id,'adpay-tx-3');
 assert.equal((await invoke('ad-user','balance')).balance,10);
 await assert.rejects(invoke('ad-user','create-code',code('Adpaycodec',{payWith:'ad',adIntent:normal.id})),e=>e.code==='permission-denied');
 // Daily limit: 3 codes paid with ads (forCode is the 2nd), then refused before another ad is watched.
 await invoke('ad-user','create-code',code('Adpaycoded',{payWith:'ad',adIntent:forCode.id}));
 const third=await invoke('ad-user','reward-intent',{purpose:'code'});await verifyAd('ad-user',third.id,'adpay-tx-4');
 await invoke('ad-user','create-code',code('Adpaycodee',{payWith:'ad',adIntent:third.id}));
 await assert.rejects(invoke('ad-user','reward-intent',{purpose:'code'}),e=>e.code==='resource-exhausted');
 const left=await invoke('ad-user','balance');assert.equal(left.adPayCodeLeft,0);assert.equal(left.adPayPostLeft,3);
 // Posts have their own 3.
 const p=await invoke('ad-user','reward-intent',{purpose:'post'});await verifyAd('ad-user',p.id,'adpay-tx-5');
 const posted=await invoke('ad-user','create-post',post('Adpaypostz',{payWith:'ad',adIntent:p.id}));
 assert.equal(posted.paidWith,'ad');assert.equal(posted.balance,10);
 const doc=(await db.doc('communityPosts/'+posted.id).get()).data();assert.equal(doc.payment,'ad');assert.equal(doc.fee,0);
 assert.equal((await invoke('ad-user','balance')).balance,10,'Credits untouched by ad payments');
 // Paying with Credits still works next to it.
 await assert.rejects(invoke('ad-user','create-post',post('Adpaypostw')),e=>e.code==='failed-precondition'); // 10 < post fee
});
