import React, {useMemo, useState} from 'react';
import {FlatList, KeyboardAvoidingView, Modal, Platform, Pressable, StyleSheet, Text, TextInput, View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import catalog from '../shared/chatEmoji.json';
import {C, RoundIcon} from './ui';

const entries = catalog.map(([glyph, name], index) => ({glyph: glyph!, name: name!, index}));
export const quickEmoji = entries.slice(0, 6);
export const emojiForIndex = (index: number) => entries[index]?.glyph;

export function EmojiPicker({onPick, onClose, onClear, dark = false}: {
  onPick: (glyph: string, index: number) => void;
  onClose: () => void;
  onClear?: () => void;
  dark?: boolean;
}) {
  const [search, setSearch] = useState('');
  const visible = useMemo(() => {
    const query = search.toLowerCase().trim();
    return query ? entries.filter(item => item.name.toLowerCase().includes(query) || item.glyph.includes(query)) : entries;
  }, [search]);
  const ink = dark ? '#EBF0FF' : C.ink;
  return <Modal animationType="slide" onRequestClose={onClose} presentationStyle="pageSheet">
    <SafeAreaView style={[styles.screen, {backgroundColor: dark ? '#18243B' : C.bg}]}>
      <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <Text accessibilityRole="header" style={[styles.title, {color: ink}]}>{onClear ? 'React with emoji' : 'Emoji'}</Text>
          {onClear && <RoundIcon name="remove-circle-outline" label="Remove my reaction" onPress={onClear}/>}
          <RoundIcon name="close" label="Close emoji picker" onPress={onClose}/>
        </View>
        <TextInput accessibilityLabel="Search emoji" placeholder="Search emoji" placeholderTextColor={dark ? '#BAC9E5' : C.muted}
          value={search} onChangeText={setSearch} autoCorrect={false} style={[styles.search, {color: ink}]}/>
        <FlatList data={visible} keyExtractor={item => item.glyph} numColumns={7} keyboardShouldPersistTaps="handled"
          ListEmptyComponent={<Text style={{color: ink, padding: 12}}>No emoji found</Text>}
          renderItem={({item}) => <Pressable accessibilityRole="button" accessibilityLabel={item.name}
            style={styles.cell} onPress={() => onPick(item.glyph, item.index)}><Text style={styles.glyph}>{item.glyph}</Text></Pressable>}/>
      </KeyboardAvoidingView>
    </SafeAreaView>
  </Modal>;
}

const styles = StyleSheet.create({
  screen: {flex: 1},
  header: {flexDirection: 'row', alignItems: 'center', gap: 6, padding: 10},
  title: {flex: 1, fontSize: 20, fontWeight: '800'},
  search: {marginHorizontal: 10, paddingHorizontal: 12, minHeight: 44, borderWidth: 1, borderColor: C.line, borderRadius: 14},
  cell: {width: '14.2857%', minHeight: 44, alignItems: 'center', justifyContent: 'center'},
  glyph: {fontSize: 24},
});
