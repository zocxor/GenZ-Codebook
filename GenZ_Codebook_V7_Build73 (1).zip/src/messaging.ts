import {useEffect,useMemo,useRef,useState} from 'react';
import {AppState} from 'react-native';
import {collection,doc,getDocs,limit,onSnapshot,orderBy,query,startAfter,Timestamp,where,type QueryDocumentSnapshot} from 'firebase/firestore';
import {getFunctions,connectFunctionsEmulator,httpsCallable} from 'firebase/functions';
import {firebaseApp,cloudDbLive,accountAuth} from './firebase/app';
import {EMULATOR_HOST} from './secure/config';
import {BACKEND_URL} from './backend';
import {ms} from './communityFeatures';
export type Person={uid:string;name:string;avatar:number;photo?:string;role?:string;online?:boolean;lastSeen?:number;readAt?:number};
export type ConnectionList='followers'|'following';
export type ProfileDetails=Person&{premiumUntil:number;followers:number;postLikes?:number;followingCount:number;following:boolean;chatStatus:string|null;conversationId:string|null;requestedByMe:boolean};
export type InboxRow={id:string;conversationId:string;type:'personal'|'group';name:string;peerId?:string;avatar?:number;photo?:string;memberCount?:number;ownerId?:string;status:string;requestedBy?:string;unread:number;updatedAt?:unknown;lastMessage?:string;lastMessageId?:string;pinned?:boolean;muted?:boolean;archived?:boolean;deleted?:boolean;hiddenBefore?:unknown;visibleFrom?:unknown};
export type PrivateMessage={id:string;senderId:string;name:string;text:string;createdAt?:unknown;replyTo?:string;replyText?:string;replyName?:string;attachmentExpiresAt?:number;attachmentCaption?:boolean;fileName?:string;removed?:boolean};
export type Invite={id:string;name:string;invitedBy:string;status:string};
export type MessageNotice={id:string;title:string;body:string;type:string;conversationId:string;createdAt?:unknown;read?:boolean};
const deliveredKeys=new Map<string,number>();
const functions=getFunctions(firebaseApp,BACKEND_URL||'us-central1');
if(EMULATOR_HOST)connectFunctionsEmulator(functions,EMULATOR_HOST,5001);
const invoke=httpsCallable<Record<string,unknown>,Record<string,any>>(functions,'communityFeature',{timeout:30000});
export async function messaging(command:string,data:Record<string,unknown>={}){const user=accountAuth.currentUser;if(user&&(await user.getIdTokenResult()).claims.email_verified!==true)await user.getIdToken(true);return (await invoke({action:'messaging',command,...data})).data;}
export function useInbox(uid?:string,enabled=true){
 const [rows,setRows]=useState<InboxRow[]>([]),[error,setError]=useState(''),[loading,setLoading]=useState(!!uid),[epoch,reload]=useState(0);
 useEffect(()=>{setRows([]);setError('');if(!uid||!enabled){setLoading(false);return;}setLoading(true);return onSnapshot(query(collection(cloudDbLive(),`users/${uid}/inbox`),orderBy('updatedAt','desc'),limit(200)),snap=>{const next=snap.docs.map(d=>({...d.data(),id:d.id})as InboxRow);setRows(next);for(const r of next.filter(r=>r.unread>0&&r.status==='active').slice(0,10)){const key=uid+'|'+r.id,value=ms(r.updatedAt);if(deliveredKeys.get(key)!==value){deliveredKeys.set(key,value);void messaging('delivered',{conversationId:r.id}).catch(()=>deliveredKeys.delete(key));}}setLoading(false);setError('');},()=>{setLoading(false);setError('Inbox could not connect. Check your connection and retry.');});},[uid,enabled,epoch]);
 return {rows,error,loading,retry:()=>reload(x=>x+1),unread:rows.filter(r=>!r.deleted&&r.status==='active'&&r.unread>0).length,requests:rows.filter(r=>!r.deleted&&!r.archived&&r.status==='pending'&&r.requestedBy!==uid).length};
}
export function useMessageNotices(uid?:string){const [rows,setRows]=useState<MessageNotice[]>([]);useEffect(()=>{setRows([]);if(!uid)return;return onSnapshot(query(collection(cloudDbLive(),`users/${uid}/messageNotifications`),orderBy('createdAt','desc'),limit(50)),s=>setRows(s.docs.map(d=>({...d.data(),id:d.id})as MessageNotice)),()=>setRows([]));},[uid]);return rows;}
export function usePrivateMessages(uid:string|undefined,row:InboxRow|null){
 const [rows,setRows]=useState<PrivateMessage[]>([]),[older,setOlder]=useState<PrivateMessage[]>([]),[error,setError]=useState(''),[loading,setLoading]=useState(false),[more,setMore]=useState(false),[cursor,setCursor]=useState<QueryDocumentSnapshot|null>(null),[epoch,reload]=useState(0),[hidden,setHidden]=useState<Set<string>>(new Set());
 const boundary=Math.max(ms(row?.visibleFrom),ms(row?.hiddenBefore)),cid=row?.id,first=useRef(true);
 const rawBound=ms(row?.visibleFrom)>=ms(row?.hiddenBefore)?row?.visibleFrom:row?.hiddenBefore;
 const bound=rawBound instanceof Timestamp?rawBound:Timestamp.fromMillis(boundary);
 useEffect(()=>{first.current=true;setRows([]);setOlder([]);setCursor(null);setMore(false);setError('');if(!uid||!cid||!['active','closed'].includes(row?.status||'')){setLoading(false);return;}
 setLoading(true);return onSnapshot(query(collection(cloudDbLive(),`conversations/${cid}/messages`),where('createdAt','>=',bound),orderBy('createdAt','desc'),limit(40)),{includeMetadataChanges:true},s=>{setRows(prev=>[...new Map([...prev,...s.docs.map(d=>({...d.data(),id:d.id})as PrivateMessage)].map(m=>[m.id,m])).values()]);if(first.current&&!s.metadata.fromCache){setCursor(s.docs.at(-1)||null);setMore(s.size===40);first.current=false;}setLoading(false);setError('');},()=>{setLoading(false);setError('Messages could not load. Check membership or connection, then retry.');});},[uid,cid,row?.status,boundary,epoch]);
 useEffect(()=>{setHidden(new Set());if(!uid||!cid)return;return onSnapshot(query(collection(cloudDbLive(),`users/${uid}/hiddenMessages`),where('conversationId','==',cid)),s=>setHidden(new Set(s.docs.map(d=>d.get('messageId')))),()=>{});},[uid,cid]);
 const loadOlder=async()=>{if(!cursor||!more||!cid||loading)return;setLoading(true);try{const snap=await getDocs(query(collection(cloudDbLive(),`conversations/${cid}/messages`),where('createdAt','>=',bound),orderBy('createdAt','desc'),startAfter(cursor),limit(40)));setOlder(v=>[...v,...snap.docs.map(d=>({...d.data(),id:d.id})as PrivateMessage)]);setCursor(snap.docs.at(-1)||null);setMore(snap.size===40);}catch{setError('Older messages could not load. Try again.');}finally{setLoading(false);}};
 const ordered=useMemo(()=>{const merged=new Map([...older,...rows].map(m=>[m.id,m]));return [...merged.values()].filter(m=>!hidden.has(m.id)).sort((a,b)=>ms(a.createdAt)-ms(b.createdAt)||a.id.localeCompare(b.id));},[older,rows,hidden]);return {rows:ordered,error,loading,more,loadOlder,retry:()=>reload(x=>x+1)};
}
export function useMessagingPresence(uid?:string,active=true){useEffect(()=>{if(!uid||!active)return;const ping=()=>{if(AppState.currentState==='active')void messaging('presence').catch(()=>{});};ping();const timer=setInterval(ping,40000);const sub=AppState.addEventListener('change',state=>{void messaging('presence',{online:state==='active'}).catch(()=>{});});return()=>{clearInterval(timer);sub.remove();void messaging('presence',{online:false}).catch(()=>{});};},[uid,active]);}
