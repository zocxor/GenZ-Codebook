const lastShownKey = 'genz.dailyReward.prompt.lastShown';
const day = 24 * 60 * 60 * 1000;

type Storage = {
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
};

/** The cooldown is per installation. Reward receipts have their own account and day rules. */
export function createRewardPrompt(storage: Storage, now = Date.now) {
  let lastShown = 0;
  let checking = false;
  async function recordDisplay() {
    lastShown = now();
    await storage.setItem(lastShownKey, String(lastShown));
  }
  async function openIfDue(eligible: () => boolean, open: () => void) {
    if (checking || !eligible() || (lastShown && now() - lastShown < day)) return;
    checking = true;
    try {
      const saved = Number(await storage.getItem(lastShownKey));
      if (Number.isFinite(saved)) lastShown = Math.max(lastShown, saved);
      if (!eligible() || (lastShown && now() - lastShown < day)) return;
      await recordDisplay();
      if (eligible()) open();
    } catch {
      // If storage is unavailable, the reward remains accessible from Home.
    } finally {
      checking = false;
    }
  }
  return {openIfDue, recordDisplay};
}
