import React, {useEffect, useState} from 'react';
import {Pressable, Text, View} from 'react-native';
import {collection, deleteDoc, doc, onSnapshot, setDoc} from 'firebase/firestore';
import {EmojiPicker, emojiForIndex, quickEmoji} from './EmojiPicker';
import {cloudDbLive} from './firebase/app';
import {ensureCommunityRules} from './safety';
import {C, RoundIcon} from './ui';

export function CommunityReactions({messageId, uid, open, onClose, onError}: {
  messageId: string;
  uid?: string;
  open: boolean;
  onClose: () => void;
  onError: (note: string) => void;
}) {
  const [reactions, setReactions] = useState<Record<string, number>>({});
  const [picker, setPicker] = useState(false);
  useEffect(() => onSnapshot(collection(cloudDbLive(), 'communityMessages', messageId, 'reactions'),
    snapshot => setReactions(Object.fromEntries(snapshot.docs.map(item => [item.id, item.get('emojiIndex')]))),
    () => setReactions({})), [messageId]);
  const reaction = uid ? reactions[uid] : undefined;
  const save = async (index?: number) => {
    if (!uid) return;
    try {
      if (!(await ensureCommunityRules())) return;
      const target = doc(cloudDbLive(), 'communityMessages', messageId, 'reactions', uid);
      if (index === undefined || index === reaction) await deleteDoc(target);
      else await setDoc(target, {emojiIndex: index});
      setPicker(false);
      onClose();
    } catch {
      setPicker(false);
      onError('Could not save your reaction. Verify your email or try again.');
    }
  };
  const counts = new Map<number, number>();
  for (const index of Object.values(reactions)) counts.set(index, (counts.get(index) ?? 0) + 1);
  return <>
    {!!counts.size && <View style={{flexDirection:'row',flexWrap:'wrap',gap:8}}>
      {[...counts].map(([index,count]) => <Text key={index} style={{color:C.ink}}>{emojiForIndex(index)} {count}</Text>)}
    </View>}
    {open && uid && <View style={{flexDirection:'row',flexWrap:'wrap',gap:3,alignItems:'center'}}>
      {quickEmoji.map(({glyph,name,index}) => <Pressable key={index} accessibilityRole="button" accessibilityLabel={name}
        accessibilityState={{selected:reaction===index}} onPress={()=>void save(index)}
        style={{minWidth:36,minHeight:40,borderRadius:12,alignItems:'center',justifyContent:'center',backgroundColor:reaction===index?C.soft:undefined}}>
        <Text style={{fontSize:20}}>{glyph}</Text>
      </Pressable>)}
      <RoundIcon name="add" label="More reactions" onPress={()=>setPicker(true)}/>
    </View>}
    {open && picker && <EmojiPicker onClose={()=>setPicker(false)} onClear={()=>void save()}
      onPick={(_glyph,index)=>void save(index)}/>}
  </>;
}
