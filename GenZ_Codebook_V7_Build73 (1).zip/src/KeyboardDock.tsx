import React,{useCallback,useEffect,useRef,useState} from 'react';
import {Keyboard,KeyboardAvoidingView,Platform,View} from 'react-native';

export function useKeyboardVisible() {
  const [visible,setVisible]=useState(()=>Keyboard.isVisible());
  useEffect(()=>{
    const show=Keyboard.addListener(Platform.OS==='ios'?'keyboardWillShow':'keyboardDidShow',()=>setVisible(true));
    const hide=Keyboard.addListener(Platform.OS==='ios'?'keyboardWillHide':'keyboardDidHide',()=>setVisible(false));
    return ()=>{show.remove();hide.remove();};
  },[]);
  return visible;
}

export function KeyboardDock({children,nativeIme=false}:{children:React.ReactNode;nativeIme?:boolean}) {
  const view=useRef<View>(null);
  const [overlap,setOverlap]=useState(0);
  const measure=useCallback(()=>{
    if(Platform.OS!=='android'||(nativeIme&&Number(Platform.Version)>=30))return;
    if(!Keyboard.isVisible()){setOverlap(0);return;}
    view.current?.measureInWindow((_x,y,_width,height)=>{
      const metrics=Keyboard.metrics();
      setOverlap(metrics?Math.max(0,Math.round(y+height-metrics.screenY)):0);
    });
  },[nativeIme]);
  useEffect(()=>{
    if(Platform.OS!=='android'||(nativeIme&&Number(Platform.Version)>=30))return;
    const show=Keyboard.addListener('keyboardDidShow',measure);
    const hide=Keyboard.addListener('keyboardDidHide',()=>setOverlap(0));
    return ()=>{show.remove();hide.remove();};
  },[measure,nativeIme]);
  if(Platform.OS==='ios')return <KeyboardAvoidingView style={{flex:1,minHeight:0}} behavior="padding">{children}</KeyboardAvoidingView>;
  // Android may already resize the window. Only reserve the remaining overlap.
  return <View ref={view} collapsable={false} onLayout={measure} style={{flex:1,minHeight:0,paddingBottom:overlap}}>{children}</View>;
}
