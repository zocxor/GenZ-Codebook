import type {Segment} from './engine';

export const conversational: Record<string, string> = {
  lowkey: 'kind of',
  cooked: 'in trouble',
  rn: 'right now',
  'no cap': 'honestly',
  fr: 'for real',
  brb: 'I’ll be right back',
  omw: 'I’m on my way',
  btw: 'by the way',
  imo: 'in my opinion',
  ngl: 'honestly',
};

export const lowkeyMeaning = "I’m kind of in trouble right now.";

export function interpretMessage(segments: Segment[]): string {
  if (!segments.some(segment => segment.term)) return '';
  const source = segments.map(segment => segment.text).join('');
  // In a subjectless chat fragment, these three terms work together as a
  // first-person statement. Preserve explicit subjects in longer messages.
  if (/^\s*lowkey[,\s]+cooked[,\s]+rn[.!?\s,]*$/i.test(source)) {
    return lowkeyMeaning;
  }
  let message = segments.map((segment, index) => {
    if (!segment.term) return segment.text;
    if (/^[\p{P}\s]+$/u.test(segment.text)) return segment.text;
    const key = segment.term.expression.toLowerCase();
    if (key === 'cooked' && /^\s+[\p{L}]/u.test(segments[index + 1]?.text ?? '') &&
        !segments[index + 1]?.term && !segments[index + 1]?.text.trim().startsWith('right now')) {
      return segment.text;
    }
    if (key === '20' && /what is your/i.test(segment.text)) return 'Where are you';
    const meaning = conversational[key] ?? segment.term.full.split(/\s+\/\s+/)[0]!;
    // Lowercase dictionary headings inside a sentence, keeping proper nouns
    // and the pronoun “I” as supplied.
    return meaning.replace(/^[A-Z](?=[a-z])/, letter => letter.toLowerCase());
  }).join('').replace(/[ \t]+/g, ' ').replace(/\s+([,.?!])/g, '$1').trim();
  message = message.replace(/([.?!])([.?!])$/u, '$2');
  if (!message) return '';
  message = message.charAt(0).toUpperCase() + message.slice(1);
  return /[.!?…]$/u.test(message) ? message : message + (source.trim().match(/\?$/u) ? '?' : '.');
}
