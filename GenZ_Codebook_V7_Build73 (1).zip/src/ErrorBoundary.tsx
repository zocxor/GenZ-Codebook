import React from 'react';import {View,Text,StyleSheet} from 'react-native';import {Button,C,Mark} from './ui';
export default class ErrorBoundary extends React.Component<{children:React.ReactNode},{failed:boolean}>{
 state={failed:false};static getDerivedStateFromError(){return {failed:true};}
 render(){if(!this.state.failed)return this.props.children;return <View style={s.page}><Mark large/><Text accessibilityRole="header" style={s.title}>Under maintenance</Text><Text style={s.body}>GenZ Codebook couldn’t open this screen. Try again to reload the app. Unsaved input may need to be entered again.</Text><Button title="Try again" icon="refresh-outline" onPress={()=>this.setState({failed:false})}/></View>;}
}
const s=StyleSheet.create({page:{flex:1,padding:28,gap:24,justifyContent:'center',backgroundColor:'#edf8ff'},title:{fontSize:28,fontWeight:'800',color:C.ink},body:{fontSize:17,lineHeight:26,color:C.muted}});
