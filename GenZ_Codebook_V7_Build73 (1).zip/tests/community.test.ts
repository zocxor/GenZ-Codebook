import {TOKENS,emptyTokens,canSuggest,canEditSuggestion} from '../shared/tokens';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {communityId, screenWord, containsOwnName, OWN_NAME_ERROR, COMMUNITY_ID_PATTERN, CONTACT_PATTERN, PHONE_PATTERN} from '../shared/community';
import {toCommunityRecord, communityTerm, addLocalCommunityWord, findExistingTerm} from '../src/contentSync';
import {communityError} from '../shared/communityErrors';

test('Community distinguishes the endpoint 404 from a missing post and insufficient credits', () => {
  assert.match(communityError({code:'functions/not-found',message:'not-found [404]'}),/service is unavailable/);
  assert.equal(communityError({code:'functions/not-found',message:'Post not found.'}),'Post not found.');
  assert.equal(communityError({code:'functions/failed-precondition',message:'You need 25 eligible tokens.'}),'You need 25 eligible tokens.');
});
import {termsById, terms} from '../src/content';
import {search, decode} from '../src/engine';
import {logger} from '../src/secure/logger';
logger.setSink(null);

test('one stable, rule-compatible document ID per word', () => {
  assert.equal(communityId('rizz'), 'c-rizz');
  assert.equal(communityId('  RIZZ '), 'c-rizz');
  assert.equal(communityId('143'), 'c-143');
  assert.equal(communityId('No Cap'), communityId('no   cap'));
  assert.notEqual(communityId('no cap'), communityId('no-cap'));
  for (const w of ['rizz', 'no cap', '😭💀', 'کیا سین ہے', 'a'.repeat(60), 'x!y?z', "it's giving"]) {
    const id = communityId(w);
    assert.match(id, COMMUNITY_ID_PATTERN, w);
    assert.ok(id.length <= 80);
  }
});

test('word filter: contact details refused, sensitive words go to moderators, normal slang goes live', () => {
  assert.deepEqual(screenWord({term: 'skibidi', meaning: 'A nonsense word for fun.', example: ''}), {ok: true, review: false});
  assert.deepEqual(screenWord({term: 'bc', meaning: 'because', example: 'I left early bc I was tired'}), {ok: true, review: false});
  assert.deepEqual(screenWord({term: '143', meaning: 'I love you (1-4-3 letters)', example: ''}), {ok: true, review: false});
  for (const bad of [{meaning: 'see https://x.example'}, {meaning: 'visit www.spam.example'}, {example: 'mail me@spam.io'}, {meaning: 'call 0300 1234567'}]) {
    const r = screenWord({term: 'x', meaning: 'fine meaning', example: '', ...bad});
    assert.equal(r.ok, false, JSON.stringify(bad));
  }
  assert.deepEqual(screenWord({term: 'kys', meaning: 'short for something hurtful', example: ''}), {ok: true, review: true});
  assert.deepEqual(screenWord({term: 'r3tard', meaning: 'an insult', example: ''}), {ok: true, review: true});
  assert.equal(screenWord({term: 'ok', meaning: 'x', example: ''}).ok, false);
});

test('Firestore rules use the same link / phone patterns as the app', () => {
  const rules = readFileSync('firebase/firestore.rules', 'utf8');
  const contact = rules.match(/function noContact\(v\) \{ return !v\.lower\(\)\.matches\('\(\?s\)\.\*(.+)\.\*'\); \}/)?.[1];
  const phone = rules.match(/function noPhone\(v\) \{ return !v\.matches\('\(\?s\)\.\*(.+)\.\*'\); \}/)?.[1];
  assert.ok(contact && phone, 'rules functions found');
  // Rules `matches` must match the whole string; (?s) lets . cross newlines.
  const rulesContact = new RegExp(`^.*${contact}.*$`, 's'), rulesPhone = new RegExp(`^.*${phone}.*$`, 's');
  const samples = ['hello', 'see https://a.b', 'HTTP://A.B', 'www.x.y', 'me@x.io', 'ok\nhttps://x.y', '143', 'call 0300 1234567', '1-4-3', '+92 (300) 123-4567', 'email@ me'];
  for (const s of samples) {
    assert.equal(rulesContact.test(s.toLowerCase()), CONTACT_PATTERN.test(s), `contact: ${JSON.stringify(s)}`);
    assert.equal(rulesPhone.test(s), PHONE_PATTERN.test(s), `phone: ${JSON.stringify(s)}`);
  }
});

test('community records are validated before use', () => {
  assert.equal(toCommunityRecord('bad id', {status: 'live', term: 'x', meaning: 'yy', category: 'Chat'}), null);
  assert.equal(toCommunityRecord('c-x', {status: 'pending', term: 'x', meaning: 'yy', category: 'Chat'}), null);
  assert.equal(toCommunityRecord('c-x', {status: 'live', term: 'x', meaning: 'yy', category: 'Nope'}), null);
  assert.equal(toCommunityRecord('c-x', {status: 'live', term: 'x', meaning: '<script>alert(1)</script>', category: 'Chat'}), null);
  assert.deepEqual(toCommunityRecord('c-x', {status: 'hidden', term: 'secret text'}), {status: 'hidden'});
  const r = toCommunityRecord('c-x', {status: 'live', term: ' x ', meaning: 'a  meaning', example: '', category: 'Chat', uid: 'u1'});
  assert.deepEqual(r, {status: 'live', term: 'x', meaning: 'a meaning', example: '', category: 'Chat'});
  const t = communityTerm('c-x', r!);
  assert.equal(t?.status, 'Community');
  assert.equal(t?.expression, 'x');
});

test('a published word is searchable and decodable at once, and never replaces a bundled word', async () => {
  const before = terms.length;
  await addLocalCommunityWord('c-zorptastic', {term: 'zorptastic', meaning: 'Extremely good, in a weird way.', example: 'that fit is zorptastic', category: 'Social'});
  assert.equal(terms.length, before + 1);
  assert.equal(termsById.get('c-zorptastic')?.status, 'Community');
  assert.equal(search('zorptastic')[0]?.id, 'c-zorptastic');
  assert.equal(decode('ngl that was zorptastic').segments.find(s => s.term?.id === 'c-zorptastic')?.text, 'zorptastic');
  assert.equal(findExistingTerm('ZORPTASTIC')?.id, 'c-zorptastic');
  // Duplicate of a bundled word: ignored, the bundled entry stays.
  const idk = findExistingTerm('idk')!;
  assert.ok(idk && idk.status !== 'Community');
  await addLocalCommunityWord('c-idk', {term: 'idk', meaning: 'Something misleading.', example: '', category: 'Chat'});
  assert.equal(termsById.get('c-idk'), undefined);
  assert.equal(findExistingTerm('idk')?.id, idk.id);
  assert.equal(terms.length, before + 1);
});

test('Spark contribution prices allow zero-balance users while level unlocks retain a useful reward sink',()=>{
 const wallet=emptyTokens();
 assert.equal(TOKENS.SUGGEST_COST,0);assert.equal(TOKENS.EDIT_SUGGESTION_COST,0);assert.equal(TOKENS.POST_COST,0);assert.equal(TOKENS.CHAT_DAILY_COST,0);
 assert.equal(canSuggest(wallet),true);assert.equal(canEditSuggestion(wallet),true);
 assert.equal(TOKENS.REWARDED_AD,10);assert.equal(TOKENS.UNLOCK_LEVEL_COST,50);
});

test('own-name block: nickname as a whole word, or as the whole term, is refused; a substring is fine', () => {
  // Nickname in the term.
  assert.equal(containsOwnName({term: 'Ali', meaning: 'a word', example: ''}, 'Ali'), true);
  // Term equals the nickname, case-insensitive.
  assert.equal(containsOwnName({term: 'ALI', meaning: 'a word', example: ''}, 'ali'), true);
  // Nickname in the meaning, case-insensitive.
  assert.equal(containsOwnName({term: 'rizz', meaning: 'Ali is the coolest', example: ''}, 'ali'), true);
  // Nickname in the example, case-insensitive.
  assert.equal(containsOwnName({term: 'rizz', meaning: 'charm', example: 'Ali said it first'}, 'ALI'), true);
  // A common word that merely contains the nickname as a substring is fine.
  assert.equal(containsOwnName({term: 'alibi', meaning: 'an excuse', example: ''}, 'Ali'), false);
  assert.equal(containsOwnName({term: 'rizz', meaning: 'an alibi for later', example: ''}, 'Ali'), false);
  // Multi-word nickname: the whole phrase must appear, not just one word of it.
  assert.equal(containsOwnName({term: 'rizz', meaning: 'the Code Explorer guide', example: ''}, 'Code Explorer'), true);
  assert.equal(containsOwnName({term: 'rizz', meaning: 'code is fun to learn', example: ''}, 'Code Explorer'), false);
  // No nickname, or a one-letter nickname, never blocks.
  assert.equal(containsOwnName({term: 'Ali', meaning: 'a word', example: ''}, ''), false);
  assert.equal(containsOwnName({term: 'a', meaning: 'a word', example: ''}, 'A'), false);
  // The error message is the one the forms show.
  assert.match(OWN_NAME_ERROR, /own name or nickname/);
});

test('server faults display maintenance while offline and validation errors retain their own messages', () => {
  assert.match(communityError({code:'functions/internal',message:'internal [500]'}), /under maintenance/);
  assert.match(communityError({code:'functions/internal'}), /under maintenance/);
  assert.match(communityError({code:'functions/internal',message:'The server could not complete this request. Retry or check the communityFeature logs in Firebase.'}), /under maintenance/);
  assert.match(communityError({code:'functions/internal',message:'internal [0]'}), /reconnect/);
  assert.equal(communityError({code:'functions/invalid-argument',message:'Enter a meaning.'}), 'Enter a meaning.');
});
