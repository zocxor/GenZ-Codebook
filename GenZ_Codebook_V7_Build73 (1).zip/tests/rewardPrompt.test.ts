import assert from 'node:assert/strict';
import test from 'node:test';
import {createRewardPrompt} from '../src/rewardPrompt';

test('a dismissed reward stays dismissed across relaunch and midnight until 24 hours pass',async()=>{
  let now=Date.UTC(2026,10,23,23,59),count=0;
  const data=new Map<string,string>();
  const storage={getItem:async(k:string)=>data.get(k)??null,setItem:async(k:string,v:string)=>{data.set(k,v);}};
  const launch=()=>createRewardPrompt(storage,()=>now);
  const show=()=>count++;
  const first=launch();
  await Promise.all([first.openIfDue(()=>true,show),first.openIfDue(()=>true,show)]);
  assert.equal(count,1);
  now+=86400000-1;
  await launch().openIfDue(()=>true,show);
  assert.equal(count,1);
  now++;
  await launch().openIfDue(()=>false,show);
  await launch().openIfDue(()=>true,show);
  assert.equal(count,2);
  now+=86400000;
  await launch().recordDisplay();
  await launch().openIfDue(()=>true,show);
  assert.equal(count,2);
});

test('navigation away during the storage read does not open the popup or start a cooldown',async()=>{
  let active=true,writes=0,opens=0;
  const gate=createRewardPrompt({getItem:async()=>{active=false;return null;},setItem:async()=>{writes++;}});
  await gate.openIfDue(()=>active,()=>opens++);
  assert.equal(writes,0);
  assert.equal(opens,0);
});
