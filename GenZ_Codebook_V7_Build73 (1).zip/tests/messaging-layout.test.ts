import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';

test('messaging layouts render literal text only inside Text', () => {
  // Inspect emitted children so JSX indentation is ignored, but a rendered space is caught.
  const file = 'src/MessagingScreen.tsx';
  const {outputText} = ts.transpileModule(readFileSync(file, 'utf8'), {
    fileName: file,
    compilerOptions: {jsx: ts.JsxEmit.React, target: ts.ScriptTarget.ESNext},
  });
  const tree = ts.createSourceFile(file + '.js', outputText, ts.ScriptTarget.ESNext, true);
  const violations: string[] = [];
  function visit(node: ts.Node) {
    if (ts.isCallExpression(node) && node.expression.getText(tree) === 'React.createElement') {
      const [component, , ...children] = node.arguments;
      assert.ok(component);
      if (component.getText(tree) !== 'Text') {
        for (const child of children) {
          if (ts.isStringLiteral(child) && child.text.length) {
            violations.push(component.getText(tree) + ' contains ' + JSON.stringify(child.text));
          }
        }
      }
    }
    ts.forEachChild(node, visit);
  }
  visit(tree);
  assert.deepEqual(violations, []);
});
