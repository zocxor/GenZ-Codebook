import test from 'node:test';
import assert from 'node:assert/strict';
import {decode} from '../src/engine';
import {encode} from '../src/encode';
import {interpretMessage} from '../src/messageInterpretation';

test('message meaning combines slang into a whole sentence and leaves the breakdown intact', () => {
  const result = decode('Lowkey, cooked, rn');
  assert.equal(interpretMessage(result.segments), 'I’m kind of in trouble right now.');
  assert.deepEqual(result.segments.flatMap(segment => segment.term ? [segment.term.expression] : []), ['lowkey', 'cooked', 'rn']);
  assert.equal(interpretMessage(decode('She’s lowkey cooked rn.').segments), 'She’s kind of in trouble right now.');
  assert.equal(interpretMessage(decode('xyzzy.').segments), '');
});

test('the plain meaning of the encoded message preserves the entire original sentence', () => {
  const original = 'Be right back, I’ll tell you later.';
  const result = encode(original);
  assert.ok(result.replaced > 0);
  assert.equal(result.segments.map(segment => segment.text).join(''), original);
});

test('Encode restores the suggested meaning and preserves explicit subjects and punctuation',()=>{
 const source='Lowkey cooked rn',decoded=decode(source).segments;
 const meaning=interpretMessage(decoded);
 assert.equal(encode(meaning).output,source);
 assert.equal(encode(meaning.replace('’',"'"),{},decoded).output,source);
 for(const original of ['She’s lowkey cooked rn.', 'no cap fr', 'What is your 20?']){
  const segments=decode(original).segments;
  assert.equal(encode(interpretMessage(segments),{},segments).output,original);
 }
 assert.equal(encode('be right back',{},decoded).output,'brb');
});
