package com.genzmode.app

import android.os.Build
import android.os.Bundle
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsAnimationCompat
import androidx.core.view.WindowInsetsCompat

import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate

import expo.modules.ReactActivityDelegateWrapper

class MainActivity : ReactActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    // Set the theme to AppTheme BEFORE onCreate to support
    // coloring the background, status bar, and navigation bar.
    // This is required for expo-splash-screen.
    setTheme(R.style.AppTheme);
    super.onCreate(null)

    // The activity draws edge to edge. Resize its content by the keyboard
    // inset. The safe-area provider recomputes its bottom inset against
    // the resized content, so it no longer adds navigation-bar padding.
    // API 29 and below still use the legacy adjustResize path.
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      val content = findViewById<android.view.View>(android.R.id.content)
      var imeAnimating = false
      fun applyKeyboardInsets(insets: WindowInsetsCompat) {
        val bottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
        if (bottom != content.paddingBottom) {
          content.setPadding(content.paddingLeft, content.paddingTop, content.paddingRight, bottom)
        }
      }
      ViewCompat.setOnApplyWindowInsetsListener(content) { _, insets ->
        if (!imeAnimating) applyKeyboardInsets(insets)
        insets
      }
      ViewCompat.setWindowInsetsAnimationCallback(content,
        object : WindowInsetsAnimationCompat.Callback(WindowInsetsAnimationCompat.Callback.DISPATCH_MODE_CONTINUE_ON_SUBTREE) {
          override fun onPrepare(animation: WindowInsetsAnimationCompat) {
            if ((animation.typeMask and WindowInsetsCompat.Type.ime()) != 0) imeAnimating = true
          }

          override fun onProgress(
            insets: WindowInsetsCompat,
            runningAnimations: MutableList<WindowInsetsAnimationCompat>
          ): WindowInsetsCompat {
            applyKeyboardInsets(insets)
            return insets
          }

          override fun onEnd(animation: WindowInsetsAnimationCompat) {
            if ((animation.typeMask and WindowInsetsCompat.Type.ime()) != 0) {
              imeAnimating = false
              ViewCompat.getRootWindowInsets(content)?.let { applyKeyboardInsets(it) }
            }
          }
        })
      ViewCompat.requestApplyInsets(content)
    }
  }

  /**
   * Returns the name of the main component registered from JavaScript. This is used to schedule
   * rendering of the component.
   */
  override fun getMainComponentName(): String = "main"

  /**
   * Returns the instance of the [ReactActivityDelegate]. We use [DefaultReactActivityDelegate]
   * which allows you to enable New Architecture with a single boolean flags [fabricEnabled]
   */
  override fun createReactActivityDelegate(): ReactActivityDelegate {
    return ReactActivityDelegateWrapper(
          this,
          BuildConfig.IS_NEW_ARCHITECTURE_ENABLED,
          object : DefaultReactActivityDelegate(
              this,
              mainComponentName,
              fabricEnabled
          ){})
  }

  /**
    * Align the back button behavior with Android S
    * where moving root activities to background instead of finishing activities.
    * @see <a href="https://developer.android.com/reference/android/app/Activity#onBackPressed()">onBackPressed</a>
    */
  override fun invokeDefaultOnBackPressed() {
      if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.R) {
          if (!moveTaskToBack(false)) {
              // For non-root activities, use the default implementation to finish them.
              super.invokeDefaultOnBackPressed()
          }
          return
      }

      // Use the default back button implementation on Android S
      // because it's doing more than [Activity.moveTaskToBack] in fact.
      super.invokeDefaultOnBackPressed()
  }
}
