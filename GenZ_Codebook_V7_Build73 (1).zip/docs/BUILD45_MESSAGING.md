# Build 45 — Private Inbox, Personal Chat and Groups

Version 1.1.0 · 17 November 2026 · extends Build 44.

## Delivered behavior

The mail icon in the existing Community header opens a dedicated Inbox. The five main navigation destinations are unchanged. The earlier dictionary post selector, profile layout and admin login improvements remain included.

The Inbox has Personal and Groups tabs, conversation search, unread-only and archived views, pinned conversations, mute/unmute, archive/unarchive and deletion from the current user's inbox. Deletion hides that user's earlier history through a server timestamp boundary; it does not delete another participant's copy. New messages can reopen a deleted or archived conversation while respecting the history boundary. The header badge counts unread conversations, not total messages. The current Inbox query is bounded to the latest 200 conversations.

**Updated in Build 65: there are no message requests.** Messaging someone opens an active conversation straight away (the `request` command keeps its name and now creates it as active). Blocks, the "Nobody" privacy choice, suspensions and the 10-new-chats-a-day limit still apply, and every chat has Report user and Block user. Requests left over from earlier builds open by themselves on first use. The original text follows for history: personal conversations began with a request that the recipient accepted or declined. User search uses public profile names and existing referral/user codes; names are normalized for future profile publishes, with bounded legacy-name queries and exact user-code lookup for existing profiles. Public profiles show only shared public information, never e-mail addresses or private synced profiles.

Groups support a name, description, Private / Invite-only label, invitations requiring recipient acceptance, up to 50 members, member profiles, owner/admin/moderator/member roles, invitation and member management, editable details, message removal by group moderators, explicit ownership transfer, leaving, and closure. Both group modes require invitations; there is no public group discovery or public join link, so separate join-request approval is not applicable. A removed member loses access. A newly accepted or rejoining member starts at the new membership timestamp and cannot fetch older history. An owner must explicitly transfer ownership before leaving. Account deletion removes group membership and closes groups owned by that account rather than silently transferring ownership.

Chat includes ordered real-time messages, timestamps, sent/delivered/read states, typing expiry, emoji text and reactions, reply references, copy, hide-for-me, reports, and server-enforced private-message blocks. The composer reuses KeyboardDock, retains a failed-send draft for manual retry, and offers a dictionary picker for sharing a Codebook term, meaning and example. Message IDs remain stable across a retry so a committed send cannot charge or duplicate a message. Private and group messages never write to a token ledger or deduct Credits.

Private-messaging blocks are account-backed and can be undone in Messaging privacy. Existing device-local community content blocks retain their existing behavior. Messaging privacy controls who can request chats/invite the user and whether online/last-seen presence is visible. Presence is hidden by default. Accepted personal contacts can subscribe to opted-in presence; other users and blocked contacts cannot. Groups with mutually blocked members do not permit those members to send messages to each other through the group. Inactive/restricted recipients do not receive new group inbox updates; active members can continue using the group.

## Architecture and access boundaries

All new mutations use the existing `communityFeature` callable with `action: messaging` and a `command`. No second Firebase project, authentication system, billing system or new exported Cloud Function was added.

| Data | Purpose / access |
| --- | --- |
| conversations/{id} | Participant IDs, type, status, group owner and roles. Participant-only metadata reads; no client writes or collection-wide listing. |
| conversations/{id}/messages/{id} | Server-authored sender, text, timestamp and optional reply reference. Only verified active participants can read accepted/closed conversation history within their visibility boundary. |
| conversations/{id}/typing/{uid} | Server-written short-lived typing status. Participant reads. |
| conversations/{id}/receipts/{uid} | Server-written delivery and read acknowledgements. Participant reads; clients cannot forge another user's receipt. |
| conversations/{id}/messages/{id}/reactions/{uid} | Server-validated reactions; participant-only reads. |
| users/{uid}/inbox/{id} | Private summary, unread count, read/viewing state, pin/mute/archive/delete preferences, membership/deletion history boundaries. Owner-only client reads. |
| users/{uid}/messageInvites/{id} | Per-user invitation and decision; does not grant conversation access before acceptance. |
| users/{uid}/messaging/preferences | Request/presence privacy choices; server written, owner read. |
| users/{uid}/messagingBlocks/{uid} | Private-messaging block enforcement in both directions. |
| users/{uid}/messagingContacts/{uid} | Server-created accepted-contact authorization for opted-in presence. Not directly readable or writable by clients. |
| users/{uid}/hiddenMessages/{id} | Hide-for-me markers, separate from other users' copies. |
| users/{uid}/messageNotifications/{id} | Real in-app messaging activity. Owner reads; server writes. |
| users/{uid}/messagingLimits/{kind} | Transactional anti-spam counters; no client access. |
| messagingPresence/{uid} | Server presence heartbeat, available only under explicit consent and accepted-contact rules. |
| messagingReports/{id} | Snapshot of the one reported message. No direct client/admin reads; permission-checked moderation callable only. |
| messagingGroups/{id} | Admin group metadata without messages. Callable-only. |
| messagingStats/global; messagingReportedUsers/{uid} | Server-maintained totals and unique reported-user counts. Callable-only. |

The service verifies authentication, verified e-mail, active account state, messaging restrictions, mutual blocks, conversation status, membership and group role before relevant operations. All protected fields are server-written. Conversation mutations, counts, notifications and rate limits commit together in transactions. Group size stays below the transaction write limit. There are no destructive database migrations and no renaming of existing collections or fields.

Message timestamps and receipts are generated by the server. The live history query uses the exact Firestore membership/deletion Timestamp as its lower bound. History uses 40-message pages with document snapshot cursors. Replies store references instead of duplicating quoted message bodies; removed originals no longer remain visible through copied quote text. Moderation also clears the latest-message inbox preview when it points to the removed message.

## Moderation

The new admin Messaging page uses the existing portal design and `reports.moderate` navigation permission. Super Admin, Content Manager and Moderator can view messaging totals, unique reported users, the pending reported-message queue and group metadata. They can resolve/dismiss reports, remove the reported message, restrict/restore private messaging, and close groups. Existing account suspension also prevents messaging.

The backend independently checks the staff role, active administrator flag, verified e-mail and configured MFA requirement. It records queue access and moderation actions in auditLogs. Staff do not receive unrestricted private-message access: the queue returns only the reported message snapshot, and the Firestore participant rules contain no blanket admin bypass.

## Notifications and limits

In-app events cover personal requests and responses, group invitations and joins, group administration updates, and new messages. Muted conversations suppress new-message notifications. Viewing/read heartbeats suppress notifications while the conversation is active; leaving or backgrounding clears viewing state. Events appear in the existing Notifications activity screen as well as the Inbox/invitation UI. FCM was not configured in the supplied app, so this release does not add operating-system push notifications or ask for notification permissions.

Server limits: 10 new personal requests per user/day; 3 group creations/day; 20 invitations/day; 30 messages/minute; 30 user searches/minute; 25 typing updates/minute; 60 reactions/minute; 20 reports/day. Each group supports 50 members. Duplicate pending/declined invitations cannot be repeatedly resent; a previously accepted invitation can be renewed after a day when the former member is no longer in the group. No limit is monetized.

Messages are text-only, up to 1,500 characters. Optional image/file sharing and group image uploads are not offered because the supplied Storage rules do not provide a secure private attachment architecture. Existing public profile pictures remain usable according to the user's sharing preference. Message access is controlled through Firebase; it is not end-to-end encryption. The privacy policy now explains this data, opt-in presence, private blocks and delivered-message retention after account deletion.

## Verification performed

- App TypeScript and 171 existing app tests passed; the targeted static security scan reports no findings.
- Admin tests (32), TypeScript, portal build and public-site build passed.
- Backend build/TypeScript and in-memory regression tests passed, including seven new messaging scenarios (authentication/request acceptance, rejection/privacy/blocks, group roles/invitations, receipts/mute/presence/hide/reactions, moderation/auditing, rate limits/search, account deletion).
- The official Firestore emulator passed 68 rules tests. New cases cover verified membership, denied staff/outsider reads, pending request protection, forged sender/role/receipt writes, history boundaries, removals/restrictions, reports, and opted-in contact presence.
- The official Auth + Firestore emulator passed the original 43 backend/payment regressions and the new real-time integration scenario. The latest messaging suite was rerun against the official emulator after the final service updates: eight messaging tests passed.
- The real-time integration uses two actual Firebase client SDK contexts, the existing callable router, an arriving message listener, an unread-count listener, a receipt listener, paginated non-overlapping history, outsider-denial checks and membership revocation. It is not a production Firebase test.
- Android JavaScript/Hermes bundle export passed. No signed APK/AAB was produced or uploaded here.
- Browser QA rendered the actual Inbox list, message bubble and group creation components in isolated React Native Web fixtures, with clearly labelled sample conversations. Personal/Groups switching, unread filtering, no-match search and group creation's empty-name state were inspected. Screenshots are in docs/build45-previews. These are component previews, not screenshots from a signed-in Android device or the live service. Preview-only entry files, sample data and native-ad stubs are excluded from the deliverable.

## Required owner release steps

1. Replace the repository's old project ZIP with GenZ_Codebook_V7_Build45.zip; keep exactly one project ZIP.
2. Copy the included `.github/workflows/deploy-firebase.yml` into the repository's actual `.github/workflows/` directory. It now runs the messaging and real-time emulator tests before deployment. Other workflow files are unchanged.
3. Start a new Deploy Firebase run with target **community**. This updates the rules, indexes, communityFeature, cleanupContributions and hosting. **admin-portal alone is insufficient.** Wait for success and index readiness before testing the app.
4. Run Android APK with the AAB option. Install the test APK on two real Android devices/accounts first, then upload the AAB to Internal testing.
5. Verify login/e-mail verification, request accept/decline, two-way messages, background/foreground notification suppression, receipts, offline retry, Android keyboard visibility, pagination, group invitation/role/removal/ownership controls, private blocks/privacy, reports and account deletion. Repeat existing community post/chat and Credits/purchase checks. Device keyboard behavior, the live deployed Firebase environment and Play purchases were not tested here.
6. Review the updated privacy policy and update the Play Console Data safety answers for the new private messaging data before production release. No Play products, signing setup or new secret was changed.

This release is implemented and locally/emulator validated. Production deployment and real-device acceptance testing remain pending; it is not represented as fully production-verified.

## Modified files relative to Build 44

- .github/workflows/deploy-firebase.yml
- README.md
- admin/site/privacy.html
- admin/src/App.tsx
- android/app/build.gradle
- app.json
- docs/PROJECT_GUIDE.md
- firebase/firestore.indexes.json
- firebase/firestore.rules
- firebase/rules-tests/rules.test.mjs
- functions/package.json
- functions/src/communityEndpoints.ts
- functions/tests/fake-firestore.cjs
- src/CommunityScreen.tsx
- src/NotificationsScreen.tsx
- src/publicProfile.ts
- tests/build40.test.ts

- docs/V7_UPGRADE_REPORT.md

## Added files

- functions/src/messaging.ts
- functions/tests/messaging.test.cjs
- functions/tests/messaging-realtime.test.cjs
- src/messaging.ts
- src/MessagingScreen.tsx
- admin/src/pages/Messaging.tsx
- docs/BUILD45_MESSAGING.md
- docs/build45-previews/create-group.jpg
- docs/build45-previews/inbox.jpg
- docs/build45-previews/messaging-pages.png
- docs/build45-previews/groups.jpg
- docs/build45-previews/group-chat.jpg
